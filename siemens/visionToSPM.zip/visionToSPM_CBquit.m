function visionToSPM_CBquit( figHandle);

close( figHandle);
return;