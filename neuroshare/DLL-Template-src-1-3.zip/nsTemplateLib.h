#if !defined(NSTEMPLATELIB_H_INCLUDED)
#define NSTEMPLATELIB_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>

// Include the Neuroshare API library type definitions
#include "nsAPItypes.h"

// _stdcall calling conventions used for exported functions to make them compatible with
// application using both C++ and Pascal (using VBasic) calling conventions. 

// Define function type
#define nsAPIReturn ns_RESULT _stdcall 

// Only need to specify "C" naming convention if using mixed C/C++
// It won't hurt if all C or all C++, so let's be safe
#ifdef __cplusplus
extern "C" 
{
#endif



// Define global constants for internal use


//////////////////////////////////////////////////////////////////////////////////////////////////

// Specify byte packing for the internal structures to be 4-bytes as specified by API
// This will override any project settings
#pragma pack(4)

// Declare structures for internal use by library


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#ifdef __cplusplus
}
#endif

#endif // !defined(NSTEMPLATELIB_H_INCLUDED)
