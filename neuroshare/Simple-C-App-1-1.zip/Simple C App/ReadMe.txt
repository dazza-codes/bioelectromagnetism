This package contains the following files:

The bin directory contains all of the binary files.

The src directory contains all of the source files.

Simple C App\ReadMe.txt

Simple C App\bin\nsNEVLibrary.dll
Simple C App\bin\sim100.nev
Simple C App\bin\Simple-C-App.exe

Simple C App\src\main.c
Simple C App\src\nsAPIdllimp.h
Simple C App\src\nsAPItypes.h
Simple C App\src\Simple C App.dsp
Simple C App\src\Simple C App.dsw
Simple C App\src\UsingLibrary.c
Simple C App\src\UsingLibrary.h


Revision History:
Version 1.1
 - Updated to support the new version 1.0 API
 - Added the function ns_GetLastErrorMsg()