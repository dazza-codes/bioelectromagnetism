///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//	www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: UsingLibrary.c $
//
// Description   : This is the implementation of the "Using Library" functions
//
// Authors       : Kirk Korver
//
// $Date: 2/24/03 11:04a $
//
/* $History: UsingLibrary.c $
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 2/24/03    Time: 11:04a
// Updated in $/Neuroshare/Simple C App
// Added support for the Version 1.0 API
 * 
 * *****************  Version 4  *****************
 * User: Kirk         Date: 1/10/03    Time: 2:03p
 * Updated in $/Neuroshare/Simple C App
 * fixed file headers
 * 
 * *****************  Version 3  *****************
 * User: Kirk         Date: 1/09/03    Time: 1:43p
 * Updated in $/Neuroshare/Simple C App
 * Added necessary file headers
 * 
 * *****************  Version 2  *****************
 * User: Kirk         Date: 1/09/03    Time: 11:14a
 * Updated in $/Neuroshare/Simple C App
 * First functional version
 */
///////////////////////////////////////////////////////////////////////////////////////////////////

// Make the compiler a little less forgiving
#define STRICT

#include <windows.h>        // gotta have those windows types!

#include "UsingLibrary.h"
#include "nsAPIdllimp.h"




// These were all declared external by nsAPIdllimp, 
// they are global data and can be used at will

NS_GETLIBRARYINFO       ns_GetLibraryInfo = 0;
NS_OPENFILE             ns_OpenFile = 0;
NS_GETFILEINFO          ns_GetFileInfo = 0;
NS_CLOSEFILE            ns_CloseFile = 0;
NS_GETENTITYINFO        ns_GetEntityInfo = 0;
NS_GETEVENTINFO         ns_GetEventInfo = 0;
NS_GETEVENTDATA         ns_GetEventData = 0;
NS_GETANALOGINFO        ns_GetAnalogInfo = 0;
NS_GETANALOGDATA        ns_GetAnalogData = 0;
NS_GETSEGMENTINFO       ns_GetSegmentInfo = 0;
NS_GETSEGMENTSOURCEINFO ns_GetSegmentSourceInfo = 0;
NS_GETSEGMENTDATA       ns_GetSegmentData = 0;
NS_GETNEURALINFO        ns_GetNeuralInfo = 0;
NS_GETNEURALDATA        ns_GetNeuralData = 0;
NS_GETINDEXBYTIME       ns_GetIndexByTime = 0;
NS_GETTIMEBYINDEX       ns_GetTimeByIndex = 0;
NS_GETLASTERRORMSG      ns_GetLastErrorMsg = 0;


// Data, but which is hidden from other files
static HINSTANCE m_hDLL = 0;        // the handle to the loaded DLL



// Author & Date:   Kirk Korver     08 Jan 2003
// Purpose: Load the DLL into memory set all of the function pointers
// Inputs:
//  szDLLName - the fully qualified path name of the DLL to load
// Returns:
//  TRUE if life is good; FALSE, otherwise
BOOL LoadDll(const char * szDLLName)
{
    // Make it so we don't have to remember to unload prior to loading
    if (m_hDLL)
        UnloadDll();

    do
    {
        // This is a windows API which says, there is a DLL by this name,
        // put it into memory so I can start using it. However, we still
        // can't call any functions, because we need to get the funciton
        // pointers.
        m_hDLL = LoadLibrary(szDLLName);
        if (!m_hDLL)
            break;


        ///////////////////////////////////////////////////////////
        // Now lets set all of our pointers


        // A macro to help with getting/setting the function pointers
        //
        // Note that there is no requirement that the name on 1 side of the 
        // DLL match the name on the other side. I just did it here for
        // convenience.
        //
        // Inputs:
        //  MyName - the name of the pointer on my side of the world
        //  Type - the type of pointer (think type-casting here)
        //  DllName - the name of the function on the DLL side
        #define SetPointers(MyName, Type, DllName)                  \
            MyName = (Type) GetProcAddress(m_hDLL, DllName);        \
            if (0 == MyName)                                        \
                break;                                              


        SetPointers(ns_GetLibraryInfo, NS_GETLIBRARYINFO, "ns_GetLibraryInfo")
        SetPointers(ns_OpenFile, NS_OPENFILE, "ns_OpenFile")
        SetPointers(ns_GetFileInfo, NS_GETFILEINFO, "ns_GetFileInfo")
        SetPointers(ns_CloseFile, NS_CLOSEFILE, "ns_CloseFile")
        SetPointers(ns_GetEntityInfo, NS_GETENTITYINFO, "ns_GetEntityInfo")
        SetPointers(ns_GetEventInfo, NS_GETEVENTINFO, "ns_GetEventInfo")
        SetPointers(ns_GetEventData, NS_GETEVENTDATA, "ns_GetEventData")
        SetPointers(ns_GetAnalogInfo, NS_GETANALOGINFO, "ns_GetAnalogInfo")
        SetPointers(ns_GetAnalogData, NS_GETANALOGDATA, "ns_GetAnalogData")
        SetPointers(ns_GetSegmentInfo, NS_GETSEGMENTINFO, "ns_GetSegmentInfo")
        SetPointers(ns_GetSegmentSourceInfo, NS_GETSEGMENTSOURCEINFO, "ns_GetSegmentSourceInfo")
        SetPointers(ns_GetSegmentData, NS_GETSEGMENTDATA, "ns_GetSegmentData")
        SetPointers(ns_GetNeuralInfo, NS_GETNEURALINFO, "ns_GetNeuralInfo")
        SetPointers(ns_GetNeuralData, NS_GETNEURALDATA, "ns_GetNeuralData")
        SetPointers(ns_GetIndexByTime, NS_GETINDEXBYTIME, "ns_GetIndexByTime")
        SetPointers(ns_GetTimeByIndex, NS_GETTIMEBYINDEX, "ns_GetTimeByIndex")
        SetPointers(ns_GetLastErrorMsg, NS_GETLASTERRORMSG, "ns_GetLastErrorMsg")


        // We don't need the macro any more
        #undef SetPointers


        // If we get here, then life is good, say so
        return TRUE;

    } while (FALSE);

    // if we got here, then bad things have happened
    UnloadDll();
    return FALSE;

}



// Author & Date:   Kirk Korver     08 Jan 2003
// Purpose: Clean up all of the function pointers and unload the DLL
void UnloadDll(void)
{
    if (m_hDLL)
    {
        // Tell Windows that we don't need this DLL any more
        FreeLibrary(m_hDLL);
        m_hDLL = 0;
    }

    // Now we need to clear out all of the function pointers. After
    // all, we don't want people to try to use these function pointers
    // now that the memory they are pointing to is not around any more.
    ns_GetLibraryInfo = 0;
    ns_OpenFile = 0;
    ns_GetFileInfo = 0;
    ns_CloseFile = 0;
    ns_GetEntityInfo = 0;
    ns_GetEventInfo = 0;
    ns_GetEventData = 0;
    ns_GetAnalogInfo = 0;
    ns_GetAnalogData = 0;
    ns_GetSegmentInfo = 0;
    ns_GetSegmentSourceInfo = 0;
    ns_GetSegmentData = 0;
    ns_GetNeuralInfo = 0;
    ns_GetNeuralData = 0;
    ns_GetIndexByTime = 0;
    ns_GetTimeByIndex = 0;
}
