///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//	www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: UsingLibrary.h $
//
// Description   : This is the header file for the "Using Library" functions
//
// Authors       : Kirk Korver
//
// $Date: 1/10/03 2:03p $
//
/* $History: UsingLibrary.h $
 * 
 * *****************  Version 4  *****************
 * User: Kirk         Date: 1/10/03    Time: 2:03p
 * Updated in $/Neuroshare/Simple C App
 * fixed file headers
 * 
 * *****************  Version 3  *****************
 * User: Kirk         Date: 1/09/03    Time: 1:43p
 * Updated in $/Neuroshare/Simple C App
 * Added necessary file headers
 */
///////////////////////////////////////////////////////////////////////////////////////////////////

// Standard Include Guards
#ifndef USINGLIBRARY_H_DEFINED
#define USINGLIBRARY_H_DEFINED

#include <windows.h>

// Don't really need these includes, but they make the system happier
#include "nsAPIdllimp.h"
#include "nsAPItypes.h"



// Only need to specify "C" naming convention if using mixed C/C++
// It won't hurt if all C or all C++, so let's be safe
#ifdef __cplusplus
extern "C" 
{
#endif





// Purpose: Load the DLL into memory set all of the function pointers
// Inputs:
//  szDLLName - the fully qualified path name of the DLL to load
// Returns:
//  TRUE if life is good; FALSE, otherwise
BOOL LoadDll(const char * szDLLName);

// Purpose: Clean up all of the function pointers and unload the DLL
void UnloadDll(void);






#ifdef __cplusplus
}
#endif




#endif