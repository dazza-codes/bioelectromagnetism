///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//	www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: main.c $
//
// Description   : This is where it all begins.
//
// Authors       : Kirk Korver
//
// $Date: 1/10/03 2:03p $
//
/* $History: main.c $
 * 
 * *****************  Version 4  *****************
 * User: Kirk         Date: 1/10/03    Time: 2:03p
 * Updated in $/Neuroshare/Simple C App
 * Fixed file headers
 * 
 * *****************  Version 3  *****************
 * User: Kirk         Date: 1/09/03    Time: 1:43p
 * Updated in $/Neuroshare/Simple C App
 * Added necessary file headers
 * 
 * *****************  Version 2  *****************
 * User: Kirk         Date: 1/09/03    Time: 11:14a
 * Updated in $/Neuroshare/Simple C App
 * First functional version
 */
///////////////////////////////////////////////////////////////////////////////////////////////////

// Make the compiler a little less forgiving
#define STRICT

#include <stdio.h>
#include <stdlib.h>

#include "UsingLibrary.h"
#include "nsAPItypes.h"
#include "nsAPIdllimp.h"


// Purpose: Display some of the file information to the screen
void ShowInfo(uint32 hFile);


// This is where it all starts
void main(void)
{
    char szDllToLoad[]      = "nsNEVLibrary.dll";
    char szNevFileToLoad[]  = "sim100.nev";
    uint32 hFile;

    puts("A a simple test of the Neuroshare Library");
    printf("Will load   %s\n", szNevFileToLoad);
    printf("Using DLL   %s\n\n", szDllToLoad);

    if (LoadDll(szDllToLoad))
    {
        // Ok, lets try to load a file and get some data from it!
        if (ns_OK == ns_OpenFile(szNevFileToLoad, &hFile))
        {
            // Let's get some info from this file
            ShowInfo(hFile);
            
            // Don't forget to close the file :-)
            ns_CloseFile(hFile);
        }
        else
        {
            puts("I had a problem loading");
            puts(szNevFileToLoad);
        }
    }
    else
    {
        puts("I had a problem loading");
        puts(szDllToLoad);
    }
    
    UnloadDll();
}

void ShowInfo(uint32 hFile)
{
    ns_LIBRARYINFO isLibInfo;   // the library informaiton
    ns_FILEINFO isFileInfo;     // The file information


    // This is really about the DLL, and not the data file
    if (ns_OK != ns_GetLibraryInfo(&isLibInfo, sizeof(isLibInfo)))
    {
        puts("Error getting Library Information");
    }
    else
    {
        // Life is good, so let's show it
        puts("================= The DLL Says ======================");
        printf("Library Version:  %lu.%lu\n", isLibInfo.dwLibVersionMaj, isLibInfo.dwLibVersionMin);
        printf("Description:      %s\n", isLibInfo.szDescription);
    }


    if (ns_OK != ns_GetFileInfo(hFile, &isFileInfo, sizeof(isFileInfo)))
        puts("There was an error loading the file information!");
    else
    {
        puts("================= The Data File Says ================");
        
        // Ok we read it in, now let's put the stuff on the screen
        printf("File Type:        %s\n", isFileInfo.szFileType);
        printf("Num of Entities:  %lu\n\n", isFileInfo.dwEntityCount);

        // Now let's deal with time
        printf("Time Resolution:  %.3f\n", 1.0 / isFileInfo.dTimeStampResolution);
        printf("Time Span:        %.3f\n", isFileInfo.dTimeSpan);
        printf("Application:      %s\n\n", isFileInfo.szAppName);
        
        // And how about when this was created
        printf("When Created:     %lu/%lu/%lu  %lu:%lu:%lu\n", 
            isFileInfo.dwTime_Month, isFileInfo.dwTime_Day, isFileInfo.dwTime_Year,
            isFileInfo.dwTime_Hour, isFileInfo.dwTime_Min, isFileInfo.dwTime_Sec);


        // Now the very nice comments
        printf("\nComments:\n%s", isFileInfo.szFileComment);
    }
}