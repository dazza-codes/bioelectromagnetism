///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DLLTesterDlg.h $
//
// Description   : This header file defines a return structure (SReturn) used for some functions
//                 in the corresponding cpp file. It also defines a union of structures (m_InVars)
//                 used as input variables to the TestFunction function.
//
// Authors       : Almut Branner
//
// $Date: 2/25/03 11:00a $
//
/* $History: DLLTesterDlg.h $
// 
// *****************  Version 11  *****************
// User: Almut        Date: 2/25/03    Time: 11:00a
// Updated in $/Neuroshare/DLLTester
// Changed back to the nsAPIdllimp.h and nsAPItypes.h header files instead
// of nsAPIdllimp10.h and nsAPItypes10.h.
// 
// *****************  Version 10  *****************
// User: Almut        Date: 2/17/03    Time: 11:47a
// Updated in $/Neuroshare/DLLTester
// - Tester now conforms to Neuroshare API Specification 1.0
// 
// *****************  Version 9  *****************
// User: Almut        Date: 1/22/03    Time: 11:14a
// Updated in $/Neuroshare/DLLTester
// - Settings of the test check boxes is now saved in the registry and
// pulled out everytime the program is run
// - The tester now also tests whether inputting NULL as a data pointer in
// event and segment entities will return the timestamp or not
// 
// *****************  Version 8  *****************
// User: Almut        Date: 1/21/03    Time: 1:17p
// Updated in $/Neuroshare/DLLTester
// Each function can now be selected in the checklistbox and only its
// tests will be run.
// 
// *****************  Version 7  *****************
// User: Almut        Date: 1/20/03    Time: 5:36p
// Updated in $/Neuroshare/DLLTester
// All occurences of NEV in variable names and text were eliminated.
// 
// *****************  Version 6  *****************
// User: Almut        Date: 1/20/03    Time: 4:56p
// Updated in $/Neuroshare/DLLTester
// CheckListBox dialog now works but the function selection is not
// implemented when the tests are run. 
// 
// *****************  Version 5  *****************
// User: Almut        Date: 1/17/03    Time: 1:58p
// Updated in $/Neuroshare/DLLTester
// - changed test descriptions to be more meaningful
 * 
 * *****************  Version 4  *****************
 * User: Almut        Date: 1/14/03    Time: 5:18p
 * Updated in $/Neuroshare/DLLTester
 * Made changes suggested by code review (Kirk):
 * - changed variable names (m_)
 * - changes function names to remove _
 * - changed numbers to enum in TestFunction
 * - some variables now passed by const ref
 * - fixed memory leaks
 * - changed from malloc/free to new/delete
 * 
 * *****************  Version 3  *****************
 * User: Almut        Date: 1/13/03    Time: 5:45p
 * Updated in $/Neuroshare/DLLTester
 * Changed some variable names and added the Neuroshare header.
*/
///////////////////////////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLLTESTERDLG_H__5EE4A647_A527_492D_8C11_2B30E115CCE4__INCLUDED_)
#define AFX_DLLTESTERDLG_H__5EE4A647_A527_492D_8C11_2B30E115CCE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nsAPItypes.h"
#include "nsAPIdllimp.h"

/* Macro Definitions ------------------------------------------------------*/
/* Manifest Constant Definitions ------------------------------------------*/
/* Structures, Classes, & Typedefs ----------------------------------------*/

struct SReturn
{
    ns_RESULT m_nsResult;
    uint32 m_dwMinDataLength;
    uint32 m_dwMaxDataLength;
    uint32 m_nsType;
};

struct InVarsOpenFile
{
    const char *m_fname;
};

struct InVarsCloseFile
{
    uint32 m_filehandle;
};

struct InVarsGetInfo 
{
    uint32 m_filehandle;
    uint32 m_dwEntityID;
};

struct InVarsGetData 
{
    uint32 m_filehandle;
    uint32 m_dwEntityID;
    uint32 m_nStartIndex;
    uint32 m_dwIndexCount; 
};

struct InVarsIndexByTime 
{
    uint32 m_filehandle;
    uint32 m_dwEntityID;
    double m_dTime;
    int32 m_nFlag;
};

struct InVarsTimeByIndex 
{
    uint32 m_filehandle;
    uint32 m_dwEntityID;
    uint32 m_dwIndex;
};

union InVars 
{
    InVarsOpenFile m_OFIn;
    InVarsGetInfo m_InfoIn;
    InVarsGetData m_DataIn;
    InVarsIndexByTime m_IndXTime;
    InVarsTimeByIndex m_TimeXInd;
    InVarsCloseFile m_CFIn;
};

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterDlg dialog

class CDLLTesterDlg : public CDialog
{
// Construction
public:
    CDLLTesterDlg(CWnd* pParent = NULL);    // standard constructor
    
// Dialog Data
    //{{AFX_DATA(CDLLTesterDlg)
    enum { IDD = IDD_DLLTESTER_DIALOG };
    CTreeCtrl   m_TreeData;
    CButton m_SelectDataFile;
    CButton m_RunTests;
    CProgressCtrl   m_ProgressBar;
    CListCtrl   m_ListTests;
    CStatic m_filename;
    CStatic m_dllname;
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDLLTesterDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    HICON m_hIcon;

    enum ErrMsgType
    {
        FileError,          // 0
        TypeError,          // 1
        BadFile,            // 2
        BadEntity,          // 3
        BadIndexInvEvent,   // 4
        BadIndexNegTime,    // 5
        BadIndexInvTime,    // 6
        EventIndex,         // 7
        AnalogIndex,        // 8
        SegmentIndex,       // 9
        NeuralIndex,        // 10
        EventTime,          // 11
        AnalogTime,         // 12
        SegmentTime,        // 13
        NeuralTime,         // 14
        Execution           // 15
    };

    enum FuncType
    {
        OpenFile,               // 0
        GetFileInfo,            // 1
        GetEntityInfo,          // 2
        GetEventInfo,           // 3
        GetEventData,           // 4
        GetAnalogInfo,          // 5
        GetAnalogData,          // 6
        GetSegmentInfo,         // 7
        GetSegmentSourceInfo,   // 8
        GetSegmentData,         // 9
        GetNeuralInfo,          // 10
        GetNeuralData,          // 11
        GetIndexByTime,         // 12
        GetTimeByIndex,         // 13
        CloseFile               // 14
    };

    void CleanUp();
    void TestFunction(const InVars& Inputs, ErrMsgType enErrMsg, FuncType enFunc, ns_RESULT ExpError);
    ns_RESULT TestOpenFile(const CString& fname);
    ns_RESULT TestGetFileInfo();
    int32 TestGetEntityInfo();
    void TestEventEntities();
    SReturn TestEventInfo(uint32 nsID);
    SReturn TestEventData(uint32 nsID, uint32 nsIndex, uint32 nsType, uint32 nsDataBufferSize);
    void TestAnalogEntities();
    ns_RESULT TestAnalogInfo(uint32 nsID);
    ns_RESULT TestAnalogData(uint32 nsID, uint32 nsIndex, uint32 nsIndexCount);
    void TestSegmentEntities();
    SReturn TestSegmentInfo(uint32 nsID);
    ns_RESULT TestSegmentSourceInfo(uint32 nsID, uint32 nsSourceID);
    SReturn TestSegmentData(uint32 nsID, uint32 nsIndex, uint32 nsSources, uint32 nsDataBufferSize);
    void TestNeuralEntities();
    ns_RESULT TestNeuralInfo(uint32 nsID);
    ns_RESULT TestNeuralData(uint32 nsID, uint32 nsIndex, uint32 nsIndexCount);
    void TestGetIndexByTime();
    void TestGetTimeByIndex();
    void TestGetLastErrorMsg();
    void TestCloseFile();

    // Generated message map functions
    //{{AFX_MSG(CDLLTesterDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnBUTTONSelectDataFile();
    afx_msg void OnBUTTONSelectDLL();
    afx_msg void OnBUTTONSelectFunctions();
    afx_msg void OnBUTTONRunTests();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/* Externals --------------------------------------------------------------*/
/* Global Variables -------------------------------------------------------*/
/* Local Function Prototypes ----------------------------------------------*/

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLLTESTERDLG_H__5EE4A647_A527_492D_8C11_2B30E115CCE4__INCLUDED_)
