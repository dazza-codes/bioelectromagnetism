#if !defined(AFX_SELECTFUNCTIONSDLG_H__745B06E5_468E_47A4_8F3B_B8BF17A7D4C8__INCLUDED_)
#define AFX_SELECTFUNCTIONSDLG_H__745B06E5_468E_47A4_8F3B_B8BF17A7D4C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectFunctionsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SelectFunctionsDlg dialog

class SelectFunctionsDlg : public CDialog
{
// Construction
public:
    BOOL m_abSelFunc[18];
    SelectFunctionsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(SelectFunctionsDlg)
    enum { IDD = IDD_DIALOG_SelectFunctions };
    CCheckListBox m_ListSelectFunctions;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(SelectFunctionsDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    // Generated message map functions
    //{{AFX_MSG(SelectFunctionsDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnBUTTONSelectAll();
    afx_msg void OnBUTTONSelectNone();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTFUNCTIONSDLG_H__745B06E5_468E_47A4_8F3B_B8BF17A7D4C8__INCLUDED_)
