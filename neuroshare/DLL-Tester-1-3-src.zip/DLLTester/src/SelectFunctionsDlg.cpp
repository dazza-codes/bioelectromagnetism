// SelectFunctionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DLLTester.h"
#include "DLLTesterDlg.h"
#include "SelectFunctionsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SelectFunctionsDlg dialog


SelectFunctionsDlg::SelectFunctionsDlg(CWnd* pParent /*=NULL*/)
    : CDialog(SelectFunctionsDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(SelectFunctionsDlg)
    //}}AFX_DATA_INIT
}


void SelectFunctionsDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(SelectFunctionsDlg)
    DDX_Control(pDX, IDC_LIST_SelectFunctions, m_ListSelectFunctions);
    //}}AFX_DATA_MAP

    if (pDX->m_bSaveAndValidate)
    {
        for (int i = 0; i < 18; ++i)
        {
            m_abSelFunc[i] = m_ListSelectFunctions.GetCheck(i);
        }
    }
}


BEGIN_MESSAGE_MAP(SelectFunctionsDlg, CDialog)
    //{{AFX_MSG_MAP(SelectFunctionsDlg)
    ON_BN_CLICKED(IDC_BUTTON_SelectAll, OnBUTTONSelectAll)
    ON_BN_CLICKED(IDC_BUTTON_SelectNone, OnBUTTONSelectNone)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SelectFunctionsDlg message handlers

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function is called when the dialog opens.
//          The list of tests in the CheckListBox is built and the checkboxes
//          are set to match the current settings.
// Inputs:  none
// Outputs: BOOL, whether the function was successful or not.

BOOL SelectFunctionsDlg::OnInitDialog() 
{
    CDialog::OnInitDialog();
    
    m_ListSelectFunctions.SetCheckStyle(BS_AUTOCHECKBOX);
    m_ListSelectFunctions.ResetContent();

    m_ListSelectFunctions.AddString(" Load DLL library");       // 0
    m_ListSelectFunctions.AddString(" ns_GetLibraryInfo");      // 1
    m_ListSelectFunctions.AddString(" ns_OpenFile");            // 2
    m_ListSelectFunctions.AddString(" ns_GetFileInfo");         // 3
    m_ListSelectFunctions.AddString(" ns_CloseFile");           // 4
    m_ListSelectFunctions.AddString(" ns_GetEntityInfo");       // 5
    m_ListSelectFunctions.AddString(" ns_GetEventInfo");        // 6
    m_ListSelectFunctions.AddString(" ns_GetEventData");        // 7
    m_ListSelectFunctions.AddString(" ns_GetAnalogInfo");       // 8
    m_ListSelectFunctions.AddString(" ns_GetAnalogData");       // 9
    m_ListSelectFunctions.AddString(" ns_GetSegmentInfo");      // 10
    m_ListSelectFunctions.AddString(" ns_GetSegmentSourceInfo");// 11
    m_ListSelectFunctions.AddString(" ns_GetSegmentData");      // 12
    m_ListSelectFunctions.AddString(" ns_GetNeuralInfo");       // 13
    m_ListSelectFunctions.AddString(" ns_GetNeuralData");       // 14
    m_ListSelectFunctions.AddString(" ns_GetIndexByTime");      // 15
    m_ListSelectFunctions.AddString(" ns_GetTimeByIndex");      // 16
    m_ListSelectFunctions.AddString(" ns_GetLastErrorMsg");     // 17

    for (int i = 0; i < 18; ++i)
    {
        m_ListSelectFunctions.SetCheck(i, (int) m_abSelFunc[i]);
    }

    return TRUE;  // return TRUE unless you set the focus to a control
                  // EXCEPTION: OCX Property Pages should return FALSE
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function is called to select all tests (button pushed).
//          The checkboxes are changed to all be checked.
// Inputs:  none
// Outputs: none

void SelectFunctionsDlg::OnBUTTONSelectAll() 
{
    for (int i = 0; i < 18; ++i)
    {
        m_ListSelectFunctions.SetCheck(i, 1);
    }
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function is called to deselect all tests (button pushed).
//          The checkboxes are changed to all be unchecked.
// Inputs:  none
// Outputs: none

void SelectFunctionsDlg::OnBUTTONSelectNone() 
{
    for (int i = 0; i < 18; ++i)
    {
        m_ListSelectFunctions.SetCheck(i, 0);
    }
}
