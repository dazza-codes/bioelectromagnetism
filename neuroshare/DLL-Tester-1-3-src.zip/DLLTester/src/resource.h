//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DLLTester.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DLLTESTER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDI_ICONPass                    130
#define IDI_ICONFail                    131
#define IDB_BITMAPLogo                  133
#define IDI_ICON_N_A                    134
#define IDI_ICONExclamation             135
#define IDI_ICONBlank                   137
#define IDD_DIALOG_SelectFunctions      138
#define IDC_STATIC_filename             1000
#define IDC_BUTTON_LoadNEV              1014
#define IDC_BUTTON_SelectDataFile       1014
#define IDC_TREE_NEVinfo                1016
#define IDC_TREE_Data                   1016
#define IDC_STATIC_dllname              1017
#define IDC_BUTTON_SelectDLL            1019
#define IDC_LIST_Tests                  1020
#define IDC_PROGRESS1                   1021
#define IDC_BUTTON_SelectFunctions      1022
#define IDC_LIST_SelectFunctions        1023
#define IDC_BUTTON_SelectAll            1024
#define IDC_BUTTON_SelectNone           1025
#define IDC_BUTTON_RunTests             1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
