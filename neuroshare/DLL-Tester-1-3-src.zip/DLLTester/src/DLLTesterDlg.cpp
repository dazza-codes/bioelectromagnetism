///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: DLLTesterDlg.cpp $
//
// Description   : Main program for the DLL tester
//
// Authors       : Almut Branner
//
// $Date: 4/07/03 11:14a $
//
// $History: DLLTesterDlg.cpp $
// 
// *****************  Version 21  *****************
// User: Almut        Date: 4/07/03    Time: 11:14a
// Updated in $/Neuroshare/DLLTester
// Fixed Neuroshare Anomaly #11.
// Maximum number of indeces was too low.
// 
// *****************  Version 20  *****************
// User: Almut        Date: 4/02/03    Time: 5:21p
// Updated in $/Neuroshare/DLLTester
// Fixed spelling errors in function ns_GetTimeByIndex.
// 
// *****************  Version 19  *****************
// User: Almut        Date: 4/02/03    Time: 12:25p
// Updated in $/Neuroshare/DLLTester
// Fixed Neuroshare Anomaly # 7, 8,  and 9. Anomaly # 9 was not our
// problem and the other two were related. 
// This fixed the location and message of error messages.
// 
// *****************  Version 18  *****************
// User: Almut        Date: 2/28/03    Time: 12:23p
// Updated in $/Neuroshare/DLLTester
// Changed registry settings to version 1.2.
// Changed information in about box.
// 
// *****************  Version 17  *****************
// User: Almut        Date: 2/20/03    Time: 3:05p
// Updated in $/Neuroshare/DLLTester
// Fixed memory bug (pointer in LibInfo test was wrong)
// 
// *****************  Version 16  *****************
// User: Almut        Date: 2/20/03    Time: 2:34p
// Updated in $/Neuroshare/DLLTester
// Fixed problem with registry settings of functions.
// 
// *****************  Version 15  *****************
// User: Almut        Date: 2/20/03    Time: 2:21p
// Updated in $/Neuroshare/DLLTester
// Fixed the following bugs:
// - sent pointer NULL for pLibInfo, am now sending pointer - 1
// - setting for function ns_GetLastErrorMsg wasn't loaded from the
// registry and the function pointer was not defined.
// 
// *****************  Version 14  *****************
// User: Almut        Date: 2/17/03    Time: 11:47a
// Updated in $/Neuroshare/DLLTester
// - Tester now conforms to Neuroshare API Specification 1.0
// 
// *****************  Version 13  *****************
// User: Almut        Date: 2/17/03    Time: 10:06a
// Updated in $/Neuroshare/DLLTester
// - Took out safeguards (if more than 100000 entities)
// - Last version before switching to library version 1.0
// 
// *****************  Version 12  *****************
// User: Almut        Date: 1/22/03    Time: 11:14a
// Updated in $/Neuroshare/DLLTester
// - Settings of the test check boxes is now saved in the registry and
// pulled out everytime the program is run
// - The tester now also tests whether inputting NULL as a data pointer in
// event and segment entities will return the timestamp or not
// 
// *****************  Version 11  *****************
// User: Almut        Date: 1/21/03    Time: 1:17p
// Updated in $/Neuroshare/DLLTester
// Each function can now be selected in the checklistbox and only its
// tests will be run.
// 
// *****************  Version 10  *****************
// User: Almut        Date: 1/20/03    Time: 5:36p
// Updated in $/Neuroshare/DLLTester
// All occurences of NEV in variable names and text were eliminated.
// 
// *****************  Version 9  *****************
// User: Almut        Date: 1/20/03    Time: 4:56p
// Updated in $/Neuroshare/DLLTester
// CheckListBox dialog now works but the function selection is not
// implemented when the tests are run. 
// 
// *****************  Version 8  *****************
// User: Almut        Date: 1/17/03    Time: 1:58p
// Updated in $/Neuroshare/DLLTester
// - changed test descriptions to be more meaningful
// 
// *****************  Version 7  *****************
// User: Almut        Date: 1/14/03    Time: 5:18p
// Updated in $/Neuroshare/DLLTester
// Made changes suggested by code review (Kirk):
// - changed variable names (m_)
// - changes function names to remove _
// - changed numbers to enum in TestFunction
// - some variables now passed by const ref
// - fixed memory leaks
// - changed from malloc/free to new/delete
// 
// *****************  Version 6  *****************
// User: Almut        Date: 1/13/03    Time: 5:50p
// Updated in $/Neuroshare/DLLTester
// Included Neuroshare headers.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "direct.h"

// Load library for Neuroshare

#include "DLLTester.h"
#include "SelectFunctionsDlg.h"
#include "DLLTesterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/* Macro Definitions ------------------------------------------------------*/
/* Manifest Constant Definitions ------------------------------------------*/

// List of common error messages the tester can produce
const char      *g_aszErrMsg[] = {
                    ": Invalid file name (last char deleted) -> ns_FILEERROR",           // 0
                    ": Incorrect file type ('Test.nev', not data file) -> ns_TYPEERROR", // 1
                    ": Invalid file handle (filehandle + 1) -> ns_BADFILE",              // 2
                    ": Invalid entity identifier (last entity + 1) -> ns_BADENTITY",     // 3
                    ": Invalid event identifier (last index + 1) -> ns_BADINDEX",        // 4
                    ": Invalid time (negative time, search before) -> ns_BADINDEX",      // 5
                    ": Invalid time (2 x timespan, search after) -> ns_BADINDEX",        // 6
                    ": Searching for event index (first event entity, time = 0)",        // 7
                    ": Searching for analog index (first analog entity, time = 0)",      // 8
                    ": Searching for segment index (first segment entity, time = 0)",    // 9
                    ": Searching for neural index (first neural entity, time = 0)",      // 10
                    ": Searching for event time (first event entity, index = 0)",        // 11
                    ": Searching for analog time (first analog entity, index = 0)",      // 12
                    ": Searching for segment time (first segment entity, index = 0)",    // 13
                    ": Searching for neural time (first neuralentity, index = 0)",       // 14
                    ": Execution"};                                                      // 15

// List of functions that are called when testing a DLL
const char      *g_aszFunc[] = {
                    "ns_OpenFile",              // 0
                    "ns_GetFileInfo",           // 1
                    "ns_GetEntityInfo",         // 2
                    "ns_GetEventInfo",          // 3
                    "ns_GetEventData",          // 4
                    "ns_GetAnalogInfo",         // 5
                    "ns_GetAnalogData",         // 6
                    "ns_GetSegmentInfo",        // 7
                    "ns_GetSegmentSourceInfo",  // 8
                    "ns_GetSegmentData",        // 9
                    "ns_GetNeuralInfo",         // 10
                    "ns_GetNeuralData",         // 11
                    "ns_GetIndexByTime",        // 12
                    "ns_GetTimeByIndex",        // 13
                    "ns_CloseFile"};            // 14

// Maximum number of total and individual entities
static const uint16 MAXNUMENTITIES  = 1024;
static const uint16 MAXNUMINDEXES   = 65535;
static const uint16 MAXNUMEVENTS    = 1024;
static const uint16 MAXNUMANALOG    = 1024;
static const uint16 MAXNUMSEGMENTS  = 1024;
static const uint16 MAXNUMNEURALS   = 1024;

// These numbers will define the icon to be used on the test list
static const uint8 PASS     = 0;
static const uint8 FAIL     = 1;
static const uint8 N_A      = 2;
static const uint8 EXCL     = 3;
static const uint8 BLANK    = 4;

/* Structures, Classes, & Typedefs ----------------------------------------*/
/* Externals --------------------------------------------------------------*/
/* Global Variables -------------------------------------------------------*/

//Define library function variables

NS_GETLIBRARYINFO       ns_GetLibraryInfo;
NS_OPENFILE             ns_OpenFile;
NS_GETFILEINFO          ns_GetFileInfo;
NS_CLOSEFILE            ns_CloseFile;
NS_GETENTITYINFO        ns_GetEntityInfo;
NS_GETEVENTINFO         ns_GetEventInfo;
NS_GETEVENTDATA         ns_GetEventData;
NS_GETANALOGINFO        ns_GetAnalogInfo;
NS_GETANALOGDATA        ns_GetAnalogData;
NS_GETSEGMENTINFO       ns_GetSegmentInfo;
NS_GETSEGMENTSOURCEINFO ns_GetSegmentSourceInfo;
NS_GETSEGMENTDATA       ns_GetSegmentData;
NS_GETNEURALINFO        ns_GetNeuralInfo;
NS_GETNEURALDATA        ns_GetNeuralData;
NS_GETINDEXBYTIME       ns_GetIndexByTime;
NS_GETTIMEBYINDEX       ns_GetTimeByIndex;
NS_GETLASTERRORMSG      ns_GetLastErrorMsg;

// Global variables

BOOL            g_bFileLoaded;          // FALSE if program did not load a file yet, otherwise TRUE
ns_RESULT       g_nsResult;             // Used for all Neuroshare function calls later
int32           g_nGenResult;           // General return variable for functions (if NOT ns_RESULT)
CString         g_szTemp;               // Temporary information for formatting the tree list
HTREEITEM       g_hTreeItems[10];       // This array will hold the handles for parent tree items
                                        // g_hTreeItems[0] is always the parent of library info
uint32          g_hfile;                // Handle to the loaded file
HINSTANCE       g_hNeuDLL;              // Handle to Neuroshare library DLL
CImageList      g_icIconsSmall, g_icIconsNormal;    // Pointer to image/icons for list
ns_LIBRARYINFO  g_nsLibInfo;            // Variable to hold library information
uint8           g_nList = 0;            // Counter for the tests performed
uint32          g_nEntity = 0;          // Counter for the number of entities in a data file
void            *g_pvData = NULL;       // Pointer for all the data structure, new will be used
                                        // to define the size
double          g_dTimeSpan;            // Timespan of the current data file
uint32          g_nIndecesRead = 50;    // The number of consecutive indeces read (analog, neural)
BOOL            g_abFunc[18];           // List of which functions should be run

// List of entity IDs for all different entities
uint32  g_anIndeces[MAXNUMENTITIES];
uint32  g_aidUnknown[MAXNUMENTITIES];
uint32  g_aidEvent[MAXNUMEVENTS];
uint32  g_aidAnalog[MAXNUMANALOG];
uint32  g_aidSegment[MAXNUMSEGMENTS];
uint32  g_aidNeural[MAXNUMNEURALS];

// Total number of elements in the lists above
uint16  g_nEvent = 0;
uint16  g_nAnalog = 0;
uint16  g_nSegment = 0;
uint16  g_nNeural = 0;

/* Local Function Prototypes ----------------------------------------------*/


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
    CAboutDlg();

// Dialog Data
    //{{AFX_DATA(CAboutDlg)
    enum { IDD = IDD_ABOUTBOX };
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAboutDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    //{{AFX_MSG(CAboutDlg)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
    //{{AFX_DATA_INIT(CAboutDlg)
    //}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAboutDlg)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
    //{{AFX_MSG_MAP(CAboutDlg)
        // No message handlers
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterDlg dialog

CDLLTesterDlg::CDLLTesterDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CDLLTesterDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CDLLTesterDlg)
    //}}AFX_DATA_INIT
    // Note that LoadIcon does not require a subsequent DestroyIcon in Win32
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDLLTesterDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CDLLTesterDlg)
    DDX_Control(pDX, IDC_TREE_Data, m_TreeData);
    DDX_Control(pDX, IDC_BUTTON_SelectDataFile, m_SelectDataFile);
    DDX_Control(pDX, IDC_BUTTON_RunTests, m_RunTests);
    DDX_Control(pDX, IDC_PROGRESS1, m_ProgressBar);
    DDX_Control(pDX, IDC_LIST_Tests, m_ListTests);
    DDX_Control(pDX, IDC_STATIC_filename, m_filename);
    DDX_Control(pDX, IDC_STATIC_dllname, m_dllname);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDLLTesterDlg, CDialog)
    //{{AFX_MSG_MAP(CDLLTesterDlg)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDC_BUTTON_SelectDataFile, OnBUTTONSelectDataFile)
    ON_BN_CLICKED(IDC_BUTTON_SelectDLL, OnBUTTONSelectDLL)
    ON_BN_CLICKED(IDC_BUTTON_SelectFunctions, OnBUTTONSelectFunctions)
    ON_BN_CLICKED(IDC_BUTTON_RunTests, OnBUTTONRunTests)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterDlg message handlers

BOOL CDLLTesterDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Add "About..." menu item to system menu.

    // IDM_ABOUTBOX must be in the system command range.
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);

    CMenu* pSysMenu = GetSystemMenu(FALSE);
    if (pSysMenu != NULL)
    {
        CString strAboutMenu;
        strAboutMenu.LoadString(IDS_ABOUTBOX);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);         // Set big icon
    SetIcon(m_hIcon, FALSE);        // Set small icon
    
    g_bFileLoaded = FALSE;   // No DLL or file was loaded yet

    // Get settings from registry
    g_abFunc[0] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("0"), 1);
    g_abFunc[1] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("1"), 1);
    g_abFunc[2] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("2"), 1);
    g_abFunc[3] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("3"), 1);
    g_abFunc[4] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("4"), 1);
    g_abFunc[5] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("5"), 1);
    g_abFunc[6] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("6"), 1);
    g_abFunc[7] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("7"), 1);
    g_abFunc[8] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("8"), 1);
    g_abFunc[9] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("9"), 1);
    g_abFunc[10] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("10"), 1);
    g_abFunc[11] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("11"), 1);
    g_abFunc[12] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("12"), 1);
    g_abFunc[13] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("13"), 1);
    g_abFunc[14] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("14"), 1);
    g_abFunc[15] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("15"), 1);
    g_abFunc[16] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("16"), 1);
    g_abFunc[17] = AfxGetApp()->GetProfileInt(_T ("v1.2"), _T ("17"), 1);

    CString szTemp = AfxGetApp()->GetProfileString(_T ("v1.2"), _T ("DLLname"), "");
    if (szTemp != "")
    {
        m_dllname.SetWindowText(szTemp);
        m_dllname.EnableWindow(TRUE);
    }
    else
        m_dllname.EnableWindow(FALSE);

    szTemp = AfxGetApp()->GetProfileString(_T ("v1.2"), _T ("Filename"), "");
    if (szTemp != "")
    {
        m_filename.SetWindowText(szTemp);
        m_filename.EnableWindow(TRUE);
        if (0 != m_dllname.IsWindowEnabled())
            m_RunTests.EnableWindow(TRUE);
    }
    else
        m_filename.EnableWindow(FALSE);

    // Create and initialize image lists with icons for list of tests

    g_icIconsSmall.Create(16, 16, FALSE, 5, 0);
    g_icIconsNormal.Create(32, 32, FALSE, 5, 0);

    HICON hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONPass));
    g_icIconsSmall.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONFail));
    g_icIconsSmall.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICON_N_A));
    g_icIconsSmall.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONExclamation));
    g_icIconsSmall.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONBlank));
    g_icIconsSmall.Add(hIcon);

    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONPass));
    g_icIconsNormal.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONFail));
    g_icIconsNormal.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICON_N_A));
    g_icIconsNormal.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONExclamation));
    g_icIconsNormal.Add(hIcon);
    hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ICONBlank));
    g_icIconsNormal.Add(hIcon);

    m_ListTests.InsertColumn(0, "Test", LVCFMT_LEFT, 414, 0);

    m_ListTests.SetImageList(&g_icIconsSmall, LVSIL_SMALL);
    m_ListTests.SetImageList(&g_icIconsNormal, LVSIL_NORMAL);

    return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDLLTesterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        CAboutDlg dlgAbout;
        dlgAbout.DoModal();
    }
    else
    {
        CDialog::OnSysCommand(nID, lParam);
    }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDLLTesterDlg::OnPaint() 
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
        CDialog::OnPaint();
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDLLTesterDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}

/////////////////////////////////////////////////////////////////////////////
//
//  Test functions for each of the Neuroshare functions
//
//      The different entities (event, analog, segment, neural) each have a
//      general function (e.g. test_EventEntities) that then calls separate
//      functions for the info and data functions.
//
/////////////////////////////////////////////////////////////////////////////

// Author & Date:   Almut Branner, 1/8/03
// Purpose: This function is called from most test functions. Its purpose is
//          to call a particular Neuroshare function based on the input
//          variables and catch any excemption/memory error the Neuroshare
//          DLL might produce and display an error message in that case. The
//          function also displays to the used when the function executes
//          successfully.
// Inputs:  Inputs - the input variables that the Neuroshare function requires
//          enErrMsg - number of the message about the error tested
//          enFunc - which function is tested
//          ExpError - which return is expected from the Neuroshare function
// Outputs: none

void CDLLTesterDlg::TestFunction(const InVars& Inputs, ErrMsgType enErrMsg, FuncType enFunc,
                                 ns_RESULT ExpError)
{
    ns_RESULT testResult;

    try
    {
        switch (enFunc)
        {
        case OpenFile:
            testResult = ns_OpenFile(Inputs.m_OFIn.m_fname, &g_hfile);
            break;
        case GetFileInfo:
            {
                ns_FILEINFO nsFileInfo;
                testResult = ns_GetFileInfo(Inputs.m_InfoIn.m_filehandle, &nsFileInfo, 
                    sizeof(nsFileInfo));
            }
            break;
        case GetEntityInfo:
            {
                ns_ENTITYINFO nsEntityInfo;
                testResult = ns_GetEntityInfo(Inputs.m_InfoIn.m_filehandle, 
                    Inputs.m_InfoIn.m_dwEntityID, &nsEntityInfo, sizeof(nsEntityInfo));
            }
            break;
        case GetEventInfo:
            {
                ns_EVENTINFO nsEventInfo;
                testResult = ns_GetEventInfo(Inputs.m_InfoIn.m_filehandle, 
                    Inputs.m_InfoIn.m_dwEntityID, &nsEventInfo, sizeof(nsEventInfo));
            }
            break;
        case GetEventData:
            {
                double pdTimeStamp;
                uint32 pdwDataSize;
                testResult = ns_GetEventData(Inputs.m_DataIn.m_filehandle, 
                    Inputs.m_DataIn.m_dwEntityID, Inputs.m_DataIn.m_nStartIndex, &pdTimeStamp,
                    g_pvData, 16, &pdwDataSize);
            }
            break;
        case GetAnalogInfo:
            {
                ns_ANALOGINFO nsAnalogInfo;
                testResult = ns_GetAnalogInfo(Inputs.m_InfoIn.m_filehandle, 
                    Inputs.m_InfoIn.m_dwEntityID, &nsAnalogInfo, sizeof(nsAnalogInfo));
            }
            break;
        case GetAnalogData:
            {
                testResult = ns_GetAnalogData(Inputs.m_DataIn.m_filehandle, 
                    Inputs.m_DataIn.m_dwEntityID, Inputs.m_DataIn.m_nStartIndex, 
                    Inputs.m_DataIn.m_dwIndexCount, NULL, (double *) g_pvData);
            }
            break;
        case GetSegmentInfo:
            {
                ns_SEGMENTINFO nsSegmentInfo;
                testResult = ns_GetSegmentInfo(Inputs.m_InfoIn.m_filehandle, 
                    Inputs.m_InfoIn.m_dwEntityID, &nsSegmentInfo, sizeof(nsSegmentInfo));
            }
            break;
        case GetSegmentSourceInfo:
            {
                ns_SEGSOURCEINFO nsSegmentSourceInfo;
                testResult = ns_GetSegmentSourceInfo(Inputs.m_DataIn.m_filehandle, 
                    Inputs.m_DataIn.m_dwEntityID, 0, &nsSegmentSourceInfo, 
                    sizeof(nsSegmentSourceInfo));
            }
            break;
        case GetSegmentData:
            {
                double pdTimeStamp;
                uint32 pdwSampleCount, pdwUnitID;
                testResult = ns_GetSegmentData(Inputs.m_DataIn.m_filehandle, 
                    Inputs.m_DataIn.m_dwEntityID, Inputs.m_DataIn.m_nStartIndex, &pdTimeStamp, 
                    (double *) g_pvData, sizeof(double), &pdwSampleCount, &pdwUnitID);
            }
            break;
        case GetNeuralInfo:
            {
                ns_NEURALINFO nsNeuralInfo;
                testResult = ns_GetNeuralInfo(Inputs.m_InfoIn.m_filehandle, 
                    Inputs.m_InfoIn.m_dwEntityID, &nsNeuralInfo, sizeof(nsNeuralInfo));
            }
            break;
        case GetNeuralData:
            {
                testResult = ns_GetNeuralData(Inputs.m_DataIn.m_filehandle, 
                    Inputs.m_DataIn.m_dwEntityID, Inputs.m_DataIn.m_nStartIndex, 
                    Inputs.m_DataIn.m_dwIndexCount, (double *) g_pvData);
            }
            break;
        case GetIndexByTime:
            {
                uint32 pdwIndex;
                testResult = ns_GetIndexByTime(Inputs.m_IndXTime.m_filehandle, 
                    Inputs.m_IndXTime.m_dwEntityID, Inputs.m_IndXTime.m_dTime, 
                    Inputs.m_IndXTime.m_nFlag, &pdwIndex);
            }
            break;
        case GetTimeByIndex:
            {
                double pdTime;
                testResult = ns_GetTimeByIndex(Inputs.m_TimeXInd.m_filehandle,
                    Inputs.m_TimeXInd.m_dwEntityID, Inputs.m_TimeXInd.m_dwIndex, &pdTime);
            }
            break;
        case CloseFile:
            {
                testResult = ns_CloseFile(Inputs.m_CFIn.m_filehandle);
            }
            break;
        }
    }
    catch(...)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  " + (CString) g_aszFunc[enFunc] + ": A general library error occured!", EXCL);
        g_nsResult = ns_LIBERROR;
    }
    if (enFunc != CloseFile)
    {
        if (ExpError == testResult)
            m_ListTests.InsertItem(g_nList++, "  " + (CString) g_aszFunc[enFunc] + 
                (CString) g_aszErrMsg[enErrMsg], PASS);
        else
            m_ListTests.InsertItem(g_nList++, "  " + (CString) g_aszFunc[enFunc] + 
                (CString) g_aszErrMsg[enErrMsg], FAIL);
    }
    else if (g_abFunc[4])
    {
        if (ExpError == testResult)
            m_ListTests.InsertItem(g_nList++, "  " + (CString) g_aszFunc[enFunc] + 
                (CString) g_aszErrMsg[enErrMsg], PASS);
        else
            m_ListTests.InsertItem(g_nList++, "  " + (CString) g_aszFunc[enFunc] + 
                (CString) g_aszErrMsg[enErrMsg], FAIL);
    }
    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Run tests for ns_OpenFile
// Inputs:  fname - file to be opened
// Outputs: ns_RESULT - what error was returned by the function (should be 0)

ns_RESULT CDLLTesterDlg::TestOpenFile(const CString& fname)
{
    ns_RESULT testResult;
    CString tempChar;
    InVars Inputs;
    uint32 hfile = -1;

    if (g_abFunc[2])    // Only performed if test selected
    {
        // Testing for ns_FILEERROR by inputting a filename that does not exist
        tempChar = fname.Left(fname.GetLength() - 1);
        Inputs.m_OFIn.m_fname = tempChar;
        TestFunction(Inputs, FileError, OpenFile, ns_FILEERROR);
    
        // Testing for ns_TYPEERROR by inputting a file that is not of the expected type
        tempChar = "Test.nev";
        Inputs.m_OFIn.m_fname = tempChar;
        TestFunction(Inputs, TypeError, OpenFile, ns_TYPEERROR);
    }

    // Testing the actual loading of a file (perform this first so I can test for opening
    //     multiple files.
    testResult = ns_OpenFile(fname, &g_hfile);

//    if (g_abFunc[2])
//    {
//        // TODO: Testing the loading of multiple files. Should this return the same filehandle?
//        ns_OpenFile(fname, &hfile);
//    }
    
    return(testResult);
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Run tests for ns_GetFileInfo
// Inputs:  none
// Outputs: ns_RESULT - what error was returned by the function (should be 0)

ns_RESULT CDLLTesterDlg::TestGetFileInfo()
{
    ns_RESULT testResult;
    ns_FILEINFO nsFileInfo;
    InVars Inputs;

    if (g_abFunc[3])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile+1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetFileInfo, ns_BADFILE);
    }

    testResult = ns_GetFileInfo(g_hfile, &nsFileInfo, sizeof(nsFileInfo));
    if (testResult != 0) 
    {
        m_ListTests.InsertItem(g_nList++, "  Reading nsFileInfo with ns_GetFileInfo", FAIL);
        AfxMessageBox("Running function nsGetLibInfo did not work", MB_OK | MB_ICONINFORMATION);
    }
    else
    {
        // Put header information in the dialog box

        g_hTreeItems[1] = m_TreeData.InsertItem("File Information");

        g_szTemp.Format("File Type Descriptor: %s", nsFileInfo.szFileType);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

        g_szTemp.Format("Entity Count: %d", nsFileInfo.dwEntityCount);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        g_nEntity = nsFileInfo.dwEntityCount;
        
        g_szTemp.Format("Time Stamp Resolution: %g", nsFileInfo.dTimeStampResolution);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        
        g_szTemp.Format("Time Span (sec): %g", nsFileInfo.dTimeSpan);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        g_dTimeSpan = nsFileInfo.dTimeSpan;
        
        g_szTemp.Format("Application: %s", nsFileInfo.szAppName);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

        CTime ctime(nsFileInfo.dwTime_Year, nsFileInfo.dwTime_Month, nsFileInfo.dwTime_Day,
            nsFileInfo.dwTime_Hour, nsFileInfo.dwTime_Min, nsFileInfo.dwTime_Sec,0);
        m_TreeData.InsertItem(ctime.Format("Created: %#I:%M:%S %p,  %a, %b %d, %Y"),
            g_hTreeItems[1]);

        // Remove newline from string in the comment field because they show up as weird characters
        char *pChar = NULL;
        pChar = strchr(nsFileInfo.szFileComment, 13);
        while (pChar) 
        {
            memcpy(pChar, "  ", 2);
            pChar = strchr(nsFileInfo.szFileComment, 13);
        }

        g_szTemp.Format("Comment: %s", nsFileInfo.szFileComment);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
    }

    return(testResult);
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Run tests for ns_GetEntityInfo
// Inputs:  none
// Outputs: int32 - returns which icon to present with the message set in g_szTemp

int32 CDLLTesterDlg::TestGetEntityInfo()
{
    ns_ENTITYINFO nsEntityInfo;
    ns_RESULT testResult;
    InVars Inputs;
    uint16 cg_aidUnknown = 0;
    BOOL bIndexCount = TRUE;

    if (g_abFunc[5])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile+1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetEntityInfo, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting a entity ID that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile;
        Inputs.m_InfoIn.m_dwEntityID = g_nEntity;
        TestFunction(Inputs, BadEntity, GetEntityInfo, ns_BADENTITY);
    }

    // Execute the function
    if (0 == g_nEntity)
    {
        g_szTemp = "  ns_GetEntityInfo: No nsEntityInfo available for reading";
        return(EXCL);
    }
    else
    {
        g_hTreeItems[1] = m_TreeData.InsertItem("Entity Info");

        // Try to load all entity infos
        // The g_nEntity is defined in TestGetFileInfo
        for (uint32 i = 0; i < g_nEntity; i++)
        {
            testResult = ns_GetEntityInfo(g_hfile, i, &nsEntityInfo, sizeof(nsEntityInfo));

            if (testResult != 0)
            {
                g_szTemp.Format("  Reading nsEntityInfo with ns_GetEntityInfo (ID %d)", i);
                return(FAIL);
            }
            else if (0 == testResult)
            {
                g_szTemp.Format("Entity ID: %d", i);
                g_hTreeItems[2] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

                g_szTemp.Format("Label: %s", nsEntityInfo.szEntityLabel);
                m_TreeData.InsertItem(g_szTemp, g_hTreeItems[2]);

                switch (nsEntityInfo.dwEntityType)
                {
                case 0:
                    m_TreeData.InsertItem("Type: ns_ENTITY_UNKNOWN", g_hTreeItems[2]);
                    g_aidUnknown[cg_aidUnknown++] = i;
                    break;
                case 1:
                    m_TreeData.InsertItem("Type: ns_ENTITY_EVENT", g_hTreeItems[2]);
                    g_aidEvent[g_nEvent++] = i;
                    break;
                case 2:
                    m_TreeData.InsertItem("Type: ns_ENTITY_ANALOG", g_hTreeItems[2]);
                    g_aidAnalog[g_nAnalog++] = i;
                    break;
                case 3:
                    m_TreeData.InsertItem("Type: ns_ENTITY_SEGMENT", g_hTreeItems[2]);
                    g_aidSegment[g_nSegment++] = i;
                    break;
                case 4:
                    m_TreeData.InsertItem("Type: ns_ENTITY_NEURALEVENT", g_hTreeItems[2]);
                    g_aidNeural[g_nNeural++] = i;
                    break;
                }

                g_szTemp.Format("Item Count: %d", nsEntityInfo.dwItemCount);
                m_TreeData.InsertItem(g_szTemp, g_hTreeItems[2]);

                // This is to ensure that no 'endless' loops are created
                //if (nsEntityInfo.dwItemCount > 100000)
                //{
                //    bIndexCount = FALSE;
                //    g_anIndeces[i] = 0;
                //}
                //else
                    g_anIndeces[i] = nsEntityInfo.dwItemCount;
            }
        }

        //if (FALSE == bIndexCount)
        //    m_ListTests.InsertItem(g_nList++, 
        //        "  Some nsEntityInfo.dwItemCount were over 100000 (set to 0).", EXCL);

        if (g_abFunc[5])
            m_ListTests.InsertItem(g_nList++, "  Reading nsEntityInfo with ns_GetEntityInfo", PASS);

        // Indicate how many Unknown Entities were found
    
        g_hTreeItems[1] = m_TreeData.InsertItem("Unknown Entities");
        g_szTemp.Format("Count: %d", cg_aidUnknown);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

        return(testResult);
    }
}

// Author & Date:   Almut Branner, 2/17/03
// Purpose: Run tests for ns_GetEventInfo and ns_GetEventData. General tests are
//          performed and then all possible entities (both info and data) are loaded.
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestEventEntities()
{
    SReturn returnInfo, returnData;
    BOOL bGetInfo = TRUE;
    BOOL bGetData = TRUE;
    InVars Inputs;
    uint8 tempPos;

    // Perform error tests first for both ns_GetEventInfo and ns_GetEventData

    if (g_abFunc[6])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile+1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetEventInfo, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity ID that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile;
        Inputs.m_InfoIn.m_dwEntityID = g_nEntity;
        TestFunction(Inputs, BadEntity, GetEventInfo, ns_BADENTITY);

        tempPos = g_nList;
        m_ListTests.InsertItem(g_nList++, "-", BLANK);

        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList - 1, 0);
        m_ListTests.UpdateWindow();
    }

    if (g_abFunc[7])
    {
        g_pvData = new uint16;
    
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile+1;
        Inputs.m_DataIn.m_dwEntityID = g_aidEvent[0];
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 0;
        TestFunction(Inputs, BadFile, GetEventData, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity ID that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile;
        Inputs.m_DataIn.m_dwEntityID = g_nEntity;
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 0;
        TestFunction(Inputs, BadEntity, GetEventData, ns_BADENTITY);

        delete g_pvData;
        g_pvData = NULL;
    }

    if (0 == g_nEvent)
    {
        // Tests cannot be performed if there are no event entities

        if (g_abFunc[6])
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  ns_GetEventInfo: No nsEventInfo available for reading", EXCL, 0, 
                LVIS_SELECTED, NULL);
        if (g_abFunc[7])
        {
            m_ListTests.InsertItem(g_nList++, "  ns_GetEventData: Cannot test for ns_BADINDEX", EXCL);
            m_ListTests.InsertItem(g_nList++, 
                "  ns_GetEventData: Could not test (pData = NULL) returns timestamp (optional)", EXCL);
            m_ListTests.InsertItem(g_nList++, 
                "  ns_GetEventData: No Event Data available for reading", EXCL);
        }
    }
    else
    {
        if (g_abFunc[7])
        {
            // Testing for ns_BADINDEX by inputting an event index that does not exist
            g_pvData = new uint16;

            Inputs.m_DataIn.m_filehandle = g_hfile;
            Inputs.m_DataIn.m_dwEntityID = g_aidEvent[0];
            Inputs.m_DataIn.m_nStartIndex = g_anIndeces[g_aidEvent[0]]+1;
            TestFunction(Inputs, BadIndexInvEvent, GetEventData, ns_BADINDEX);

            // Testing whether inputting NULL will just return the timestamp
            // Compare that result with the result returned with a data pointer
            ns_RESULT nsResult1, nsResult2;
            double pdTimeStamp1 = -1, pdTimeStamp2 = -1;
            uint32 pdwDataSize;

            nsResult1 = ns_GetEventData(g_hfile, g_aidEvent[0], 0, &pdTimeStamp1, g_pvData, 16,
                &pdwDataSize);
            nsResult2 = ns_GetEventData(g_hfile, g_aidEvent[0], 0, &pdTimeStamp2, NULL, 16,
                &pdwDataSize);
            // Test with data pointer has to pass (indication that the function itself works)
            if (!nsResult1)
            {
                if (pdTimeStamp1 == pdTimeStamp2)
                    m_ListTests.InsertItem(g_nList++, 
                        "  ns_GetEventData: Inputting (pData = NULL) returns timestamp (optional)", PASS);
                else
                    m_ListTests.InsertItem(g_nList++, 
                        "  ns_GetEventData: Inputting (pData = NULL) returns timestamp (optional)", FAIL);
            }
            else
                m_ListTests.InsertItem(g_nList++, 
                    "  ns_GetEventData: Could not test (pData = NULL) returns timestamp (optional)", EXCL);

            delete g_pvData;
            g_pvData = NULL;
        }

        uint32 dwDataBufferSize;

        g_hTreeItems[1] = m_TreeData.InsertItem("Event Entities");
        for (uint32 i = 0; i < g_nEvent; i++)
        {
            m_ProgressBar.SetPos(i * 100 / g_nEntity);

            returnInfo = TestEventInfo(g_aidEvent[i]);

            if (returnInfo.m_nsResult != 0)
            {
                // Test will abort if an event entity info structure cannot be read

                bGetInfo = FALSE;
                g_szTemp.Format("  Reading nsEventInfo with ns_GetEventInfo (ID %d)",
                    g_aidEvent[i]);
                m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, g_szTemp, FAIL, 0, 
                    LVIS_SELECTED, NULL);
                break;
            }
            else if (g_abFunc[7])
            {
                // Data pointer is allocated
                switch (returnInfo.m_nsType)
                {
                case 0:
                    g_pvData = new char[returnInfo.m_dwMaxDataLength];
                    dwDataBufferSize = returnInfo.m_dwMaxDataLength;
                    break;
                case 1:
                    g_pvData = new char[returnInfo.m_dwMaxDataLength];
                    dwDataBufferSize = returnInfo.m_dwMaxDataLength;
                    break;
                case 2:
                    g_pvData = new uint8[1];
                    dwDataBufferSize = 8;
                    break;
                case 3:
                    g_pvData = new uint16[1];
                    dwDataBufferSize = 16;
                    break;
                case 4:
                    g_pvData = new uint32[1];
                    dwDataBufferSize = 32;
                    break;
                }

                // Each data index will be read in and tested
                for (uint32 j = 0; j < g_anIndeces[g_aidEvent[i]]; j++)
                {
                    returnData = TestEventData(g_aidEvent[i], j, returnInfo.m_nsType, 
                                               dwDataBufferSize);

                    // Test will jump to the next EntityID in the loop if reading an index failed
                    if ((returnData.m_nsResult != 0) & (TRUE == bGetData))
                    {
                        bGetData = FALSE;
                        g_szTemp.Format("  Reading Event Data with ns_GetEventData (ID %d.%d)", 
                            g_aidEvent[i], j);
                        m_ListTests.InsertItem(g_nList++, g_szTemp, FAIL);
                        break;
                    }

                    // Test will abort if more data is read in than was allocated
                    if (returnData.m_dwMaxDataLength > returnInfo.m_dwMaxDataLength)
                    {
                        g_szTemp.Format(
                            "  ns_GetEventData: More data read than allocated (ID %d.%d)", 
                            g_aidEvent[i], j);
                        m_ListTests.InsertItem(g_nList++, g_szTemp, FAIL);
                        m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                            "  Testing ns_GetEventInfo not completed (ns_GetEventData), successful so far",
                            EXCL, 0, LVIS_SELECTED, NULL);

                        AfxMessageBox(
                            "ns_GetEventInfo: More data read than allocated!\nTest aborted!", 
                            MB_OK | MB_ICONINFORMATION);
                        delete [] g_pvData;
                        g_pvData = NULL;
                        return;
                    }

                    // Test will jump to the next EntityID in the loop if less data was read
                    if (returnData.m_dwMaxDataLength < returnInfo.m_dwMinDataLength)
                    {
                        g_szTemp.Format("  Less data read than allocated (ID %d.%d)", 
                            g_aidEvent[i], j);
                        m_ListTests.InsertItem(g_nList++, g_szTemp, EXCL);
                        break;
                    }
                }

                delete [] g_pvData;
                g_pvData = NULL;
            }
        }

        // All entity IDs and indeces have to pass the test for both info and data

        if (g_abFunc[6] && TRUE == bGetInfo)
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  Reading nsEventInfo with ns_GetEventInfo", PASS, 0, LVIS_SELECTED, NULL);
        if (g_abFunc[7] && TRUE == bGetData)
            m_ListTests.InsertItem(g_nList++, "  Reading Event Data with ns_GetEventData", PASS);
    }

    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();
    return;
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Load data for ns_GetEventInfo. This function is called for each entity
//          and the info structure is displayed.
// Inputs:  nsID - which event entity is to be loaded
// Outputs: SReturn - a structure containing the result of the Neuroshare function,
//                    the data type and the min and max data length (required for data
//                    reading which follows).

SReturn CDLLTesterDlg::TestEventInfo(uint32 nsID)
{
    SReturn returnStruct;
    ns_EVENTINFO nsEventInfo;

    returnStruct.m_nsResult = ns_GetEventInfo(g_hfile, nsID, &nsEventInfo, sizeof(nsEventInfo));

    if (0 == returnStruct.m_nsResult)
    {
        g_szTemp.Format("ID: %d", nsID);
        g_hTreeItems[2] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        g_hTreeItems[3] = m_TreeData.InsertItem("Info", g_hTreeItems[2]);
        if (g_abFunc[7])
            g_hTreeItems[4] = m_TreeData.InsertItem("Data", g_hTreeItems[2]);

        switch (nsEventInfo.dwEventType)
        {
        case 0:
            m_TreeData.InsertItem("Type: ns_EVENT_TEXT", g_hTreeItems[3]);
            break;
        case 1:
            m_TreeData.InsertItem("Type: ns_EVENT_CSV", g_hTreeItems[3]);
            break;
        case 2:
            m_TreeData.InsertItem("Type: ns_EVENT_BYTE", g_hTreeItems[3]);
            break;
        case 3:
            m_TreeData.InsertItem("Type: ns_EVENT_WORD", g_hTreeItems[3]);
            break;
        case 4:
            m_TreeData.InsertItem("Type: ns_EVENT_DWORD", g_hTreeItems[3]);
            break;
        }
        returnStruct.m_nsType = nsEventInfo.dwEventType;

        g_szTemp.Format("Min # bytes: %d", nsEventInfo.dwMinDataLength);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        returnStruct.m_dwMinDataLength = nsEventInfo.dwMinDataLength;
        returnStruct.m_dwMaxDataLength = nsEventInfo.dwMaxDataLength;

        g_szTemp.Format("Max # bytes: %d", nsEventInfo.dwMaxDataLength);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Description of CSV events: %s", nsEventInfo.szCSVDesc);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);
    }

    return(returnStruct);
}

// Author & Date:   Almut Branner, 2/17/03
// Purpose: Run tests for ns_GetEventData. 
// Inputs:  nsID - which event entity is to be loaded
//          nsIndex - which index in that entity is to be loaded
//          nsType - what is the data type
//          nsDataBufferSize - how big is the memory allocated for the returned data
// Outputs: SReturn - a structure containing the result of the Neuroshare function
//                    and how much data was loaded (for error checking).

SReturn CDLLTesterDlg::TestEventData(uint32 nsID, uint32 nsIndex, uint32 nsType, 
                                     uint32 nsDataBufferSize)
{
    SReturn returnStruct;
    double pdTimeStamp;
    uint32 pdwDataSize;

    try
    {
        returnStruct.m_nsResult = ns_GetEventData(g_hfile, nsID, nsIndex, &pdTimeStamp, g_pvData,
            nsDataBufferSize, &pdwDataSize);
    }
    catch(...)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetEventData: A general library error occured!", EXCL);
        returnStruct.m_nsResult = ns_LIBERROR;
    }

    if (0 == returnStruct.m_nsResult)
    {
        g_szTemp.Format("Index: %d", nsIndex);
        g_hTreeItems[5] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[4]);

        g_szTemp.Format("Timestamp (sec): %g", pdTimeStamp);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[5]);

        g_szTemp.Format("Data Size (bytes): %d", pdwDataSize);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[5]);
                
        switch (nsType)
        {
        case 0:
            //g_szTemp.Format("Data value: %s", *((CString*)g_pvData));
            g_szTemp = "Data value: Not supported";
            break;
        case 1:
            //g_szTemp.Format("Data value: %s", *((CString*)g_pvData));
            g_szTemp = "Data value: Not supported";
            break;
        case 2:
            g_szTemp.Format("Data value: %g", *((uint8*)g_pvData));
            break;
        case 3:
            g_szTemp.Format("Data value: %u", *((uint16*)g_pvData));
            break;
        case 4:
            g_szTemp.Format("Data value: %d", *((uint32*)g_pvData));
            break;
        }
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[5]);
    }

    // Not used here and hence set to zero
    returnStruct.m_dwMinDataLength = 0;
    returnStruct.m_nsType = 0;

    // Data size is used for checking whether more data was read than supposed to
    returnStruct.m_dwMaxDataLength = pdwDataSize;

    return(returnStruct);
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Run tests for ns_GetAnalogInfo and ns_GetAnalogData. General tests are
//          performed and then all possible entities (both info and data) are loaded.
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestAnalogEntities()
{
    BOOL bGetInfo = TRUE;
    BOOL bGetData = TRUE;
    InVars Inputs;
    uint8 tempPos;

    // Perform error tests first for both ns_GetAnalogInfo and ns_GetAnalogData

    if (g_abFunc[8])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile + 1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetAnalogInfo, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity ID that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile;
        Inputs.m_InfoIn.m_dwEntityID = g_nEntity;
        TestFunction(Inputs, BadEntity, GetAnalogInfo, ns_BADENTITY);

        tempPos = g_nList;
        m_ListTests.InsertItem(g_nList++, "-", BLANK);

        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList - 1, 0);
        m_ListTests.UpdateWindow();
    }

    if (g_abFunc[9])
    {
        g_pvData = new double;

        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile + 1;
        Inputs.m_DataIn.m_dwEntityID = g_aidAnalog[0];
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 1;
        TestFunction(Inputs, BadFile, GetAnalogData, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity ID that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile;
        Inputs.m_DataIn.m_dwEntityID = g_nEntity;
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 1;
        TestFunction(Inputs, BadEntity, GetAnalogData, ns_BADENTITY);

        delete g_pvData;
        g_pvData = NULL;
    }

    if (0 == g_nAnalog)
    {
        // Tests cannot be performed if there are no event entities

        if (g_abFunc[8])
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  ns_GetAnalogInfo: No nsAnalogInfo available for reading",
                EXCL, 0, LVIS_SELECTED, NULL);
        if (g_abFunc[9])
        {
            m_ListTests.InsertItem(g_nList++,   "  ns_GetAnalogData: Cannot test for ns_BADINDEX", EXCL);
            m_ListTests.InsertItem(g_nList++,
                "  ns_GetAnalogData: No analog data available for reading", EXCL);
        }
    }
    else
    {
        if (g_abFunc[9])
        {
            // Testing for ns_BADINDEX by inputting an entity index that does not exist
            // Test will not be performed if no analog entities exist
            g_pvData = new double;

            Inputs.m_DataIn.m_filehandle = g_hfile;
            Inputs.m_DataIn.m_dwEntityID = g_aidAnalog[0];
            Inputs.m_DataIn.m_nStartIndex = g_anIndeces[g_aidAnalog[0]]+1;
            Inputs.m_DataIn.m_dwIndexCount = 1;
            TestFunction(Inputs, BadIndexInvEvent, GetAnalogData, ns_BADINDEX);

            delete g_pvData;
            g_pvData = NULL;
        }

        g_hTreeItems[1] = m_TreeData.InsertItem("Analog Entities");

        uint32 k;
        for (uint32 i = 0; i < g_nAnalog; i++)
        {
            m_ProgressBar.SetPos((g_nEvent + i) * 100 / g_nEntity);

            g_nsResult = TestAnalogInfo(g_aidAnalog[i]);

            if (g_nsResult != 0)
            {
                // Test will abort if reading an analog info structure fails

                bGetInfo = FALSE;
                g_szTemp.Format("  Reading nsAnalogInfo with ns_GetAnalogInfo (ID %d)",
                    g_aidAnalog[i]);
                m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, g_szTemp, FAIL, 0, 
                    LVIS_SELECTED, NULL);

                break;
            }
            else if (g_abFunc[9])
            {
                g_pvData = new double[g_nIndecesRead];

                for (uint32 j = 0; j < g_anIndeces[g_aidAnalog[i]]; j = j + g_nIndecesRead)
                {
                    // g_nIndecesRead values will be read in if they are available otherwise the number of
                    // values still left will be read in
                    if ((g_anIndeces[g_aidAnalog[i]] - j) > g_nIndecesRead)
                        k = g_nIndecesRead;
                    else
                        k = g_anIndeces[g_aidAnalog[i]] - j;

                    g_nsResult = TestAnalogData(g_aidAnalog[i], j, k);

                    if ((g_nsResult != 0) & (TRUE == bGetData))
                    {
                        bGetData = FALSE;
                        g_szTemp.Format("  Reading Analog Data with ns_GetAnalogData (ID %d.%d)",
                            g_aidAnalog[i], j);
                        m_ListTests.InsertItem(g_nList++, g_szTemp, FAIL);
                        break;
                    }
                }

                delete [] g_pvData;
                g_pvData = NULL;
            }
        }

        // All entity IDs and indeces have to pass the test

        if (g_abFunc[8] && TRUE == bGetInfo)
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  Reading nsAnalogInfo with ns_GetAnalogInfo", PASS, 0, LVIS_SELECTED, NULL);
        if (g_abFunc[9] && TRUE == bGetData)
            m_ListTests.InsertItem(g_nList++, "  Reading Analog Data with ns_GetAnalogData", PASS);
    }

    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();

    return;
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Load data for ns_GetAnalogInfo. This function is called for each entity
//          and the info structure is displayed.
// Inputs:  nsID - which analog entity is to be loaded
// Outputs: ns_Return - the result of the Neuroshare function

ns_RESULT CDLLTesterDlg::TestAnalogInfo(uint32 nsID)
{
    ns_ANALOGINFO nsAnalogInfo;
    ns_RESULT testResult;

    testResult = ns_GetAnalogInfo(g_hfile, nsID, &nsAnalogInfo, sizeof(nsAnalogInfo));

    if (0 == testResult)
    {
        g_szTemp.Format("ID: %d", nsID);
        g_hTreeItems[2] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        g_hTreeItems[3] = m_TreeData.InsertItem("Info", g_hTreeItems[2]);
        if (g_abFunc[9])
            g_hTreeItems[4] = m_TreeData.InsertItem("Data", g_hTreeItems[2]);

        g_szTemp.Format("Sampling Rate (Hz): %g", nsAnalogInfo.dSampleRate);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Min value of input signal: %g", nsAnalogInfo.dMinVal);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Max value of input signal: %g", nsAnalogInfo.dMaxVal);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Rec units of measurement: %s", nsAnalogInfo.szUnits);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Min input step size: %g", nsAnalogInfo.dResolution);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("X coordinate (m): %g", nsAnalogInfo.dLocationX);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Y coordinate (m): %g", nsAnalogInfo.dLocationY);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Z coordinate (m): %g", nsAnalogInfo.dLocationZ);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Additional position information: %g", 
            nsAnalogInfo.dLocationUser);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("High freq cut-off (Hz): %g", nsAnalogInfo.dHighFreqCorner);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("High filter order: %d", nsAnalogInfo.dwHighFreqOrder);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("High filter type: %s", nsAnalogInfo.szHighFilterType);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Low freq cut-off (Hz): %g", nsAnalogInfo.dLowFreqCorner);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Low filter order: %d", nsAnalogInfo.dwLowFreqOrder);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Low filter type: %s", nsAnalogInfo.szLowFilterType);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Info about signal source: %s", nsAnalogInfo.szProbeInfo);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);
    }

    return(testResult);
}

// Author & Date:   Almut Branner, 1/8/03
// Purpose: Run tests for ns_GetAnalogData. 
// Inputs:  nsID - which analog entity is to be loaded
//          nsIndex - at which index in that entity to start loading
//          nsIndexCount - how many consecutive indeces are to be loaded
// Outputs: ns_Return - the result of the Neuroshare function

ns_RESULT CDLLTesterDlg::TestAnalogData(uint32 nsID, uint32 nsIndex, uint32 nsIndexCount)
{
    ns_RESULT testResult;
    CString tempString;

    try
    {
        testResult = ns_GetAnalogData(g_hfile, nsID, nsIndex, nsIndexCount, NULL, (double *) g_pvData);
    }
    catch(...)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetAnalogData: A general library error occured!", EXCL);
        testResult = ns_LIBERROR;
    }

    if (0 == testResult)
    {
        g_szTemp.Format("Index: %d", nsIndex);
        g_hTreeItems[5] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[4]);

        g_szTemp.Format("Data values: %g", *((double *) g_pvData));
        for (uint32 i = 1; i < nsIndexCount; i++)
        {
            tempString.Format(", %g", *((double *) g_pvData + i));
            g_szTemp += tempString;
        }
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[5]);
    }

    return(testResult);
}

// Author & Date:   Almut Branner, 2/17/03
// Purpose: Run tests for ns_GetSegmentInfo, ns_GetSegmentSourceInfo and ns_GetSegmentData.
//          General tests are performed and then all possible entities (info, source info
//          and data) are loaded.
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestSegmentEntities()
{
    ns_SEGSOURCEINFO pSourceInfo;
    SReturn returnInfo, returnData;
    BOOL bGetInfo = TRUE;
    BOOL bGetSourceInfo = TRUE;
    BOOL bGetData = TRUE;
    InVars Inputs;
    uint8 tempPos;
    uint8 tempPos1;

    // Perform error tests first for both ns_GetSegmentInfo, ns_GetSegmentSourceInfo and
    // ns_GetEventData

    if (g_abFunc[10])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile + 1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetSegmentInfo, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity index that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile;
        Inputs.m_InfoIn.m_dwEntityID = g_nEntity;
        TestFunction(Inputs, BadEntity, GetSegmentInfo, ns_BADENTITY);

        tempPos = g_nList;
        m_ListTests.InsertItem(g_nList++, "-", BLANK);

        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList - 1, 0);
        m_ListTests.UpdateWindow();
    }

    if (g_abFunc[11])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile + 1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetSegmentSourceInfo, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity index that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile;
        Inputs.m_InfoIn.m_dwEntityID = g_nEntity;
        TestFunction(Inputs, BadEntity, GetSegmentSourceInfo, ns_BADENTITY);

        tempPos1 = g_nList;
        m_ListTests.InsertItem(g_nList++, "-", BLANK);
        m_ListTests.InsertItem(g_nList++, "-", BLANK);

        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
    }

    if (g_abFunc[12])
    {
        g_pvData = new double;

        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile + 1;
        Inputs.m_DataIn.m_dwEntityID = g_aidSegment[0];
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 0;
        TestFunction(Inputs, BadFile, GetSegmentData, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity index that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile;
        Inputs.m_DataIn.m_dwEntityID = g_nEntity;
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 0;
        TestFunction(Inputs, BadEntity, GetSegmentData, ns_BADENTITY);

        delete g_pvData;
        g_pvData = NULL;
    }
    
    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();

    if (0 == g_nSegment)
    {
        if (g_abFunc[10])
        {
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE,
                "  ns_GetSegmentInfo: No nsSegmentInfo available for reading", EXCL, 0, 
                LVIS_SELECTED, NULL);
        }
        if (g_abFunc[11])
        {
            m_ListTests.SetItem(tempPos1, 0, LVIF_TEXT | LVIF_IMAGE,
                "  ns_GetSegmentSourceInfo: Cannot test for ns_BADSOURCE", EXCL, 0, LVIS_SELECTED,
                NULL);
            m_ListTests.SetItem(tempPos1 + 1, 0, LVIF_TEXT | LVIF_IMAGE,
                "  ns_GetSegmentSourceInfo: No nsSegmentSources available for reading", EXCL, 0, 
                LVIS_SELECTED, NULL);
        }
        if (g_abFunc[12])
        {
            m_ListTests.InsertItem(g_nList++,
                "  ns_GetSegmentData: Cannot test for ns_BADINDEX", EXCL);
            m_ListTests.InsertItem(g_nList++, 
                "  ns_GetSegmentData: Could not test (pData = NULL) returns timestamp (optional)", EXCL);
            m_ListTests.InsertItem(g_nList++,
                "  ns_GetSegmentData: No segment data available for reading", EXCL);
        }
        m_ListTests.EnsureVisible(g_nList - 1, 0);
        m_ListTests.UpdateWindow();
    }
    else
    {
        g_hTreeItems[1] = m_TreeData.InsertItem("Segment Entities");

        if (g_abFunc[12])
        {
            // Testing for ns_BADINDEX by inputting an entity index that does not exist
            g_pvData = new double;

            Inputs.m_DataIn.m_filehandle = g_hfile;
            Inputs.m_DataIn.m_dwEntityID = g_aidSegment[0];
            Inputs.m_DataIn.m_nStartIndex = g_anIndeces[g_aidSegment[0]]+1;
            Inputs.m_DataIn.m_dwIndexCount = 0;
            TestFunction(Inputs, BadIndexInvEvent, GetSegmentData, ns_BADINDEX);

            m_ListTests.EnsureVisible(g_nList - 1, 0);
            m_ListTests.UpdateWindow();
            delete [] g_pvData;
            g_pvData = NULL;
        }

        for (uint32 i = 0; i < g_nSegment; i++)
        {
            m_ProgressBar.SetPos((g_nEvent + g_nAnalog + i) * 100 / g_nEntity);

            returnInfo = TestSegmentInfo(g_aidSegment[i]);

            if ((returnInfo.m_nsResult != 0) & (TRUE == bGetData))
            {
                bGetInfo = FALSE;
                g_szTemp.Format("  Reading nsSegmentInfo with ns_GetSegmentInfo (ID %d)",
                    g_aidSegment[i]);
                m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, g_szTemp, FAIL, 0, 
                    LVIS_SELECTED, NULL);
                m_ListTests.EnsureVisible(g_nList - 1, 0);
                m_ListTests.UpdateWindow();

                break;
            }
            else if (g_abFunc[11] || g_abFunc[12])
            {
                if (0 == i && g_abFunc[11])
                {
                    // Testing for ns_BADSOURCE by inputting a source ID that does not exist
                    g_nsResult = ns_GetSegmentSourceInfo(g_hfile, g_aidSegment[0], 
                        returnInfo.m_nsType+1, &pSourceInfo, sizeof(pSourceInfo));
                    if (ns_BADSOURCE == g_nsResult)
                        m_ListTests.SetItem(tempPos1, 0, LVIF_TEXT | LVIF_IMAGE, 
                            "  ns_GetSegmentSourceInfo: Invalid source (last source + 1) -> ns_BADSOURCE",
                            PASS, 0, LVIS_SELECTED, NULL);
                    else
                        m_ListTests.SetItem(tempPos1, 0, LVIF_TEXT | LVIF_IMAGE, 
                            "  ns_GetSegmentSourceInfo: Invalid source (last source + 1) -> ns_BADSOURCE",
                            FAIL, 0, LVIS_SELECTED, NULL);
                    m_ListTests.EnsureVisible(g_nList - 1, 0);
                    m_ListTests.UpdateWindow();
                }

                // ns_Type is the source count here
                for (uint32 j = 0; j < returnInfo.m_nsType; j++)
                {
                    g_nsResult = TestSegmentSourceInfo(g_aidSegment[i], j);

                    if ((g_nsResult != 0) & (TRUE == bGetSourceInfo))
                    {
                        bGetSourceInfo = FALSE;
                        g_szTemp.Format(
                            "  Reading pSourceInfo with ns_GetSegmentSourceInfo (ID %d.%d)",
                            g_aidSegment[i], j);
                        m_ListTests.SetItem(tempPos1 + 1, 0, LVIF_TEXT | LVIF_IMAGE, g_szTemp, 
                            FAIL, 0, LVIS_SELECTED, NULL);
                        m_ListTests.EnsureVisible(g_nList - 1, 0);
                        m_ListTests.UpdateWindow();
                        // return;
                    }
                }

                uint32 dwDataBufferSize;

                if (g_abFunc[12])
                {
                    switch (returnInfo.m_nsType)
                    {
                    case 1:
                        g_pvData = new double[returnInfo.m_dwMaxDataLength];
                        dwDataBufferSize = returnInfo.m_dwMaxDataLength * sizeof(double);
                        break;
                    case 2:
                        {
                        g_pvData = new double[MAXNUMSEGMENTS][2];
                        dwDataBufferSize = 2 * MAXNUMSEGMENTS * sizeof(double);
                        }
                        break;
                    case 3:
                        {
                        g_pvData = new double[MAXNUMSEGMENTS][3];
                        dwDataBufferSize = 3 * MAXNUMSEGMENTS * sizeof(double);
                        }
                        break;
                    case 4:
                        {
                        g_pvData = new double[MAXNUMSEGMENTS][4];
                        dwDataBufferSize = 4 * MAXNUMSEGMENTS * sizeof(double);
                        }
                        break;
                    }

                    for (uint32 k = 0; k < g_anIndeces[g_aidSegment[i]]; k++)
                    {
                        if (0 == i && 0 == k)
                        {
                            // Testing whether inputting NULL will just return the timestamp
                            // Compare that result with the result returned with a data pointer
                            ns_RESULT nsResult1, nsResult2;
                            double pdTimeStamp1 = -1, pdTimeStamp2 = -1;
                            uint32 pdwSampleCount, pdwUnitID;

                            nsResult1 = ns_GetSegmentData(g_hfile, g_aidSegment[0], 0, &pdTimeStamp1,
                                (double *) g_pvData, dwDataBufferSize, &pdwSampleCount, &pdwUnitID);
                            nsResult2 = ns_GetSegmentData(g_hfile, g_aidSegment[0], 0, &pdTimeStamp2,
                                NULL, 0, &pdwSampleCount, &pdwUnitID);
                            // Test with data pointer has to pass (indication that the function itself works)
                            if (!nsResult1)
                            {
                                if (pdTimeStamp1 == pdTimeStamp2)
                                    m_ListTests.InsertItem(g_nList++, 
                                        "  ns_GetSegmentData: Inputting (pData = NULL) returns timestamp (optional)", PASS);
                                else
                                    m_ListTests.InsertItem(g_nList++, 
                                        "  ns_GetSegmentData: Inputting (pData = NULL) returns timestamp (optional)", FAIL);
                            }
                            else
                                m_ListTests.InsertItem(g_nList++, 
                                    "  ns_GetSegmentData: Could not test (pData = NULL) returns timestamp (optional)", EXCL);
                            m_ListTests.EnsureVisible(g_nList - 1, 0);
                            m_ListTests.UpdateWindow();
                        }

                        returnData = TestSegmentData(g_aidSegment[i], k, returnInfo.m_nsType,
                                                     dwDataBufferSize);

                        if ((returnData.m_nsResult != 0) & (TRUE == bGetData))
                        {
                            bGetData = FALSE;
                            g_szTemp.Format(
                                "  Reading Segment Data with ns_GetSegmentData (ID %d.%d)",
                                g_aidSegment[i], k);
                            m_ListTests.InsertItem(g_nList++, g_szTemp, FAIL);
                            m_ListTests.EnsureVisible(g_nList - 1, 0);
                            m_ListTests.UpdateWindow();
                            break;
                        }

                        // Test will abort if more data is read in than was allocated
                        if (returnData.m_dwMaxDataLength > returnInfo.m_dwMaxDataLength)
                        {
                            g_szTemp.Format(
                                "  ns_GetSegmentData: More data read than allocated (ID %d.%d)", 
                                g_aidSegment[i], k);
                            m_ListTests.InsertItem(g_nList++, g_szTemp, FAIL);
                            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                                "  Testing ns_GetSegmentInfo not completed (ns_GetSegmentData), successful so far", 
                                EXCL, 0, LVIS_SELECTED, NULL);
                            m_ListTests.EnsureVisible(g_nList - 1, 0);
                            m_ListTests.UpdateWindow();

                            AfxMessageBox(
                                "ns_GetSegmentInfo: More data read than allocated!\nTest aborted!", 
                                MB_OK | MB_ICONINFORMATION);
                            delete [] g_pvData;
                            g_pvData = NULL;
                            return;
                        }

                        // Test will jump to the next EntityID in the loop if less data was read
                        if (returnData.m_dwMaxDataLength < returnInfo.m_dwMinDataLength)
                        {
                            g_szTemp.Format("  Less data read than allocated (ID %d.%d)", 
                                g_aidSegment[i], k);
                            m_ListTests.InsertItem(g_nList++, g_szTemp, EXCL);
                            m_ListTests.EnsureVisible(g_nList - 1, 0);
                            m_ListTests.UpdateWindow();
                            break;
                        }
                    }

                    delete [] g_pvData;
                    g_pvData = NULL;
                }
            }
        }
        if (g_abFunc[10] && TRUE == bGetInfo)
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  Reading nsSegmentInfo with ns_GetSegmentInfo", PASS, 0, LVIS_SELECTED, NULL);
        if (g_abFunc[11] && TRUE == bGetSourceInfo)
            m_ListTests.SetItem(tempPos1 + 1, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  Reading pSourceInfo with ns_GetSegmentSourceInfo", PASS, 0, LVIS_SELECTED, NULL);
        if (g_abFunc[12] && TRUE == bGetData)
            m_ListTests.InsertItem(g_nList++, "  Reading Segment Data with ns_GetSegmentData", PASS);
    }

    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();
    return;
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Load data for ns_GetSegmentInfo. This function is called for each entity
//          and the info structure is displayed.
// Inputs:  nsID - which segment entity is to be loaded
// Outputs: SReturn - a structure containing the result of the Neuroshare function,
//                    the number of sources and the min and max sample count (required
//                    for data reading which follows).

SReturn CDLLTesterDlg::TestSegmentInfo(uint32 nsID)
{
    ns_SEGMENTINFO nsSegmentInfo;
    SReturn returnStruct;
    BOOL bIndexCount = TRUE;

    returnStruct.m_nsResult = ns_GetSegmentInfo(g_hfile, nsID, &nsSegmentInfo, sizeof(nsSegmentInfo));

    if (0 == returnStruct.m_nsResult)
    {
        g_szTemp.Format("ID: %d", nsID);
        g_hTreeItems[2] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        g_hTreeItems[3] = m_TreeData.InsertItem("Info", g_hTreeItems[2]);
        if (g_abFunc[11] || g_abFunc[12])
            g_hTreeItems[4] = m_TreeData.InsertItem("Source Info", g_hTreeItems[2]);
        if (g_abFunc[12])
            g_hTreeItems[5] = m_TreeData.InsertItem("Data", g_hTreeItems[2]);

        g_szTemp.Format("Number of sources: %d", nsSegmentInfo.dwSourceCount);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        //if (nsSegmentInfo.dwSourceCount > 100000)
        //{
        //    returnStruct.m_nsType = 0;
        //    bIndexCount = FALSE;
        //}
        //else
            returnStruct.m_nsType = nsSegmentInfo.dwSourceCount;

        returnStruct.m_dwMinDataLength = nsSegmentInfo.dwMinSampleCount;
        returnStruct.m_dwMaxDataLength = nsSegmentInfo.dwMaxSampleCount;

        g_szTemp.Format("Min # samples: %d", nsSegmentInfo.dwMinSampleCount);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Max # samples: %d", nsSegmentInfo.dwMaxSampleCount);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Sampling Rate (Hz): %g", nsSegmentInfo.dSampleRate);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Units of measurement: %s", nsSegmentInfo.szUnits);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);
    }

    //if (FALSE == bIndexCount)
    //    m_ListTests.InsertItem(g_nList++, 
    //        "  Some nsSegmentInfo.dwSourceCount were over 100000 (set to 0).", EXCL);

    return(returnStruct);
}

// Author & Date:   Almut Branner, 1/8/03
// Purpose: Load data for ns_GetSegmentSourceInfo. This function is called for each entity
//          and source and the info structure is displayed.
// Inputs:  nsID - which segment entity is to be loaded
//          nsSourceID - which source to read from
// Outputs: nsReturn - the result of the Neuroshare function

ns_RESULT CDLLTesterDlg::TestSegmentSourceInfo(uint32 nsID, uint32 nsSourceID)
{
    ns_RESULT testResult;
    ns_SEGSOURCEINFO pSourceInfo;

    testResult = ns_GetSegmentSourceInfo(g_hfile, nsID, nsSourceID, &pSourceInfo,sizeof(pSourceInfo));

    if (0 == testResult)
    {
        g_szTemp.Format("Source ID: %d", nsSourceID);
        g_hTreeItems[6] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[4]);

        g_szTemp.Format("Min value of input signal: %g", pSourceInfo.dMinVal);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Max value of input signal: %g", pSourceInfo.dMaxVal);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Min input step size: %g", pSourceInfo.dResolution);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Sample time shift: %s", pSourceInfo.dSubSampleShift);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("X coordinate (m): %g", pSourceInfo.dLocationX);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Y coordinate (m): %g", pSourceInfo.dLocationY);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Z coordinate (m): %g", pSourceInfo.dLocationZ);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Additional position information: %g", pSourceInfo.dLocationUser);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("High freq cut-off (Hz): %g",pSourceInfo.dHighFreqCorner);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("High filter order: %d", pSourceInfo.dwHighFreqOrder);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("High filter type: %s", pSourceInfo.szHighFilterType);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Low freq cut-off (Hz): %g", pSourceInfo.dLowFreqCorner);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Low filter order: %d", pSourceInfo.dwLowFreqOrder);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Low filter type: %s", pSourceInfo.szLowFilterType);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);

        g_szTemp.Format("Info about signal source: %s", pSourceInfo.szProbeInfo);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[6]);
    }

    return(testResult);
}

// Author & Date:   Almut Branner, 2/17/03
// Purpose: Run tests for ns_GetSegmentData. 
// Inputs:  nsID - which segment entity is to be loaded
//          nsIndex - which index in that entity is to be loaded
//          nsSources - which source to read from
//          nsDataBufferSize - the size of the buffer allocated for the returned data
// Outputs: SReturn - a structure containing the result of the Neuroshare function,
//                    the number of samples read (for error checking).

SReturn CDLLTesterDlg::TestSegmentData(uint32 nsID, uint32 nsIndex, uint32 nsSources, 
                                       uint32 nsDataBufferSize)
{
    SReturn returnStruct;
    double pdTimeStamp;
    uint32 pdwSampleCount, pdwUnitID;
    CString tempString;

    try
    {
        returnStruct.m_nsResult = ns_GetSegmentData(g_hfile, nsID, nsIndex, &pdTimeStamp, 
            (double *) g_pvData, nsDataBufferSize, &pdwSampleCount, &pdwUnitID);
    }
    catch(...)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetSegmentData: A general library error occured!", EXCL);
        returnStruct.m_nsResult = ns_LIBERROR;
    }

    if (0 == returnStruct.m_nsResult)
    {
        g_szTemp.Format("Index: %d", nsIndex);
        g_hTreeItems[7] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[5]);

        g_szTemp.Format("Timestamp (sec): %g", pdTimeStamp);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[7]);

        g_szTemp.Format("Sample Count: %d", pdwSampleCount);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[7]);
                
        g_szTemp.Format("Unit ID: %d", pdwUnitID);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[7]);
                
        for (uint32 i = 0; i < nsSources; i++)
        {
            g_szTemp.Format("Data values (source %d): %g", i+1, *((double *) g_pvData));
            for (uint32 j = 1; j < pdwSampleCount; j++)
            {
                tempString.Format(", %g", *((double *) g_pvData + j*nsSources + i));
                g_szTemp += tempString;
            }
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[7]);
        }
    }

    // Not used here and hence set to zero
    returnStruct.m_dwMinDataLength = 0;
    returnStruct.m_nsType = 0;

    // Data size is used for checking whether more data was read than supposed to
    returnStruct.m_dwMaxDataLength = pdwSampleCount;

    return(returnStruct);
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Run tests for ns_GetNeuralInfo and ns_GetNeuralData.
//          General tests are performed and then all possible entities (both info 
//          and data) are loaded.
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestNeuralEntities()
{
    BOOL bGetInfo = TRUE;
    BOOL bGetData = TRUE;
    InVars Inputs;
    uint8 tempPos;

    // Perform error tests first for both ns_GetNeuralInfo and ns_GetNeuralData

    if (g_abFunc[13])
    {
        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile + 1;
        Inputs.m_InfoIn.m_dwEntityID = 0;
        TestFunction(Inputs, BadFile, GetNeuralInfo, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity ID that does not exist
        Inputs.m_InfoIn.m_filehandle = g_hfile;
        Inputs.m_InfoIn.m_dwEntityID = g_nEntity;
        TestFunction(Inputs, BadEntity, GetNeuralInfo, ns_BADENTITY);

        tempPos = g_nList;
        m_ListTests.InsertItem(g_nList++, "-", BLANK);

        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList - 1, 0);
        m_ListTests.UpdateWindow();
    }

    if (g_abFunc[14])
    {
        g_pvData = new double;

        // Testing for ns_BADFILE by inputting a file handle that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile + 1;
        Inputs.m_DataIn.m_dwEntityID = g_aidNeural[0];
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 1;
        TestFunction(Inputs, BadFile, GetNeuralData, ns_BADFILE);

        // Testing for ns_BADENTITY by inputting an entity ID that does not exist
        Inputs.m_DataIn.m_filehandle = g_hfile;
        Inputs.m_DataIn.m_dwEntityID = g_nEntity;
        Inputs.m_DataIn.m_nStartIndex = 0;
        Inputs.m_DataIn.m_dwIndexCount = 1;
        TestFunction(Inputs, BadEntity, GetNeuralData, ns_BADENTITY);

        m_ListTests.EnsureVisible(g_nList - 1, 0);
        m_ListTests.UpdateWindow();
        delete g_pvData;
        g_pvData = NULL;
    }

    if (0 == g_nNeural)
    {
        if (g_abFunc[13])
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  ns_GetNeuralInfo: No nsNeuralInfo available for reading", EXCL, 0, 
                LVIS_SELECTED, NULL);
        if (g_abFunc[14])
        {
            m_ListTests.InsertItem(g_nList++, 
                "  ns_GetNeuralData: Cannot test for ns_BADINDEX", EXCL);
            m_ListTests.InsertItem(g_nList++, 
                "  ns_GetNeuralData: No Neural Data available for reading", EXCL);
        }
    }
    else
    {
        if (g_abFunc[14])
        {
            // Testing for ns_BADINDEX by inputting an neural index that does not exist
            g_pvData = new double;

            Inputs.m_DataIn.m_filehandle = g_hfile;
            Inputs.m_DataIn.m_dwEntityID = g_aidNeural[0];
            Inputs.m_DataIn.m_nStartIndex = g_anIndeces[g_aidNeural[0]]+1;
            Inputs.m_DataIn.m_dwIndexCount = 1;
            TestFunction(Inputs, BadIndexInvEvent, GetNeuralData, ns_BADINDEX);

            delete g_pvData;
            g_pvData = NULL;
        }

        g_hTreeItems[1] = m_TreeData.InsertItem("Neural Entities");

        uint32 k;
        for (uint32 i = 0; i < g_nNeural; i++)
        {
            m_ProgressBar.SetPos((g_nEvent + g_nAnalog + g_nSegment + i) * 100 / g_nEntity);

            g_nsResult = TestNeuralInfo(g_aidNeural[i]);

            if (g_nsResult != 0)
            {
                bGetInfo = FALSE;
                g_szTemp.Format("  Reading nsNeuralInfo with ns_GetNeuralInfo (ID %d)",
                    g_aidNeural[i]);
                m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, g_szTemp, FAIL, 0, 
                    LVIS_SELECTED, NULL);

                break;
            }
            else if (g_abFunc[14])
            {
                g_pvData = new double[g_nIndecesRead];

                for (uint32 j = 0; j < g_anIndeces[g_aidNeural[i]]; j = j + g_nIndecesRead)
                {
                    // g_nIndecesRead values will be read in if they are available otherwise the number of
                    // values still left will be read in
                    if ((g_anIndeces[g_aidNeural[i]] - j) > g_nIndecesRead)
                        k = g_nIndecesRead;
                    else
                        k = g_anIndeces[g_aidNeural[i]] - j;

                    g_nsResult = TestNeuralData(g_aidNeural[i], j, k);

                    if ((g_nsResult != 0) & (TRUE == bGetData))
                    {
                        bGetData = FALSE;
                        g_szTemp.Format("  Reading Neural Data with ns_GetNeuralData (ID %d.%d)",
                            g_aidNeural[i], j);
                        m_ListTests.InsertItem(g_nList++, g_szTemp, FAIL);
                        break;
                    }
                }

                delete [] g_pvData;
                g_pvData = NULL;
            }
        }

        if (g_abFunc[13] && TRUE == bGetInfo)
            m_ListTests.SetItem(tempPos, 0, LVIF_TEXT | LVIF_IMAGE, 
                "  Reading nsNeuralInfo with ns_GetNeuralInfo", PASS, 0, LVIS_SELECTED, NULL);
        if (g_abFunc[14] && TRUE == bGetData)
            m_ListTests.InsertItem(g_nList++, "  Reading Neural Data with ns_GetNeuralData", PASS);
    }

    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();
    return;
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Load data for ns_GetNeuralInfo. This function is called for each entity
//          and the info structure is displayed.
// Inputs:  nsID - which neural entity is to be loaded
// Outputs: ns_Return - the result of the Neuroshare function

ns_RESULT CDLLTesterDlg::TestNeuralInfo(uint32 nsID)
{
    ns_NEURALINFO nsNeuralInfo;
    ns_RESULT testResult;

    testResult = ns_GetNeuralInfo(g_hfile, nsID, &nsNeuralInfo, sizeof(nsNeuralInfo));
    
    if (0 == testResult)
    {
        g_szTemp.Format("ID: %d", nsID);
        g_hTreeItems[2] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);
        g_hTreeItems[3] = m_TreeData.InsertItem("Info", g_hTreeItems[2]);
        if (g_abFunc[14])
            g_hTreeItems[4] = m_TreeData.InsertItem("Data", g_hTreeItems[2]);

        g_szTemp.Format("Optional ID: %d", nsNeuralInfo.dwSourceEntityID);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Optional sorted unit ID: %d", nsNeuralInfo.dwSourceUnitID);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);

        g_szTemp.Format("Probe information: %s", nsNeuralInfo.szProbeInfo);
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[3]);
    }

    return(testResult);
}

// Author & Date:   Almut Branner, 1/8/03
// Purpose: Run tests for ns_GetNeuralData. 
// Inputs:  nsID - which neural entity is to be loaded
//          nsIndex - at which index in that entity to start loading
//          nsIndexCount - how many consecutive indeces are to be read
// Outputs: ns_Return - the result of the Neuroshare function

ns_RESULT CDLLTesterDlg::TestNeuralData(uint32 nsID, uint32 nsIndex, uint32 nsIndexCount)
{
    ns_RESULT testResult;
    CString tempString;

    try
    {
        testResult = ns_GetNeuralData(g_hfile, nsID, nsIndex, nsIndexCount, (double *) g_pvData);
    }
    catch(...)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetNeuralData: A general library error occured!", EXCL);
        testResult = ns_LIBERROR;
    }
    if (0 == testResult)
    {
        g_szTemp.Format("Index: %d", nsIndex);
        g_hTreeItems[5] = m_TreeData.InsertItem(g_szTemp, g_hTreeItems[4]);

        g_szTemp.Format("Data values: %g", *((double *) g_pvData));
        for (uint32 i = 1; i < nsIndexCount; i++)
        {
            tempString.Format(", %g", *((double *) g_pvData + i));
            g_szTemp += tempString;
        }
        m_TreeData.InsertItem(g_szTemp, g_hTreeItems[5]);
    }

    return(testResult);
}

// Author & Date:   Almut Branner, 1/8/03
// Purpose: Run tests for ns_GetIndexByTime. 
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestGetIndexByTime()
{
    InVars Inputs;

    // Perform error tests first for ns_GetIndexByTime

    // Testing for ns_BADFILE by inputting a file handle that does not exist
    Inputs.m_IndXTime.m_filehandle = g_hfile + 1;
    Inputs.m_IndXTime.m_dwEntityID = 0;
    Inputs.m_IndXTime.m_dTime = 0;
    Inputs.m_IndXTime.m_nFlag = 0;
    TestFunction(Inputs, BadFile, GetIndexByTime, ns_BADFILE);

    // Testing for ns_BADENTITY by inputting an entity ID that does not exist
    Inputs.m_IndXTime.m_filehandle = g_hfile;
    Inputs.m_IndXTime.m_dwEntityID = g_nEntity;
    Inputs.m_IndXTime.m_dTime = 0;
    Inputs.m_IndXTime.m_nFlag = 0;
    TestFunction(Inputs, BadEntity, GetIndexByTime, ns_BADENTITY);

    // Testing for ns_BADINDEX by inputting a negative time and searching before it
    Inputs.m_IndXTime.m_filehandle = g_hfile;
    Inputs.m_IndXTime.m_dwEntityID = 0;
    Inputs.m_IndXTime.m_dTime = -1;
    Inputs.m_IndXTime.m_nFlag = -1;
    TestFunction(Inputs, BadIndexNegTime, GetIndexByTime, ns_BADINDEX);

    // Testing for ns_BADINDEX by inputting twice the actual time span and searching after it
    Inputs.m_IndXTime.m_filehandle = g_hfile;
    Inputs.m_IndXTime.m_dwEntityID = 0;
    Inputs.m_IndXTime.m_dTime = g_dTimeSpan * 2;
    Inputs.m_IndXTime.m_nFlag = 1;
    TestFunction(Inputs, BadIndexInvTime, GetIndexByTime, ns_BADINDEX);

    // Testing function for different entities
    // Event
    if ((g_nEvent != 0) & (g_anIndeces[g_aidEvent[0]] != 0))
    {
        Inputs.m_IndXTime.m_filehandle = g_hfile;
        Inputs.m_IndXTime.m_dwEntityID = g_aidEvent[0];
        Inputs.m_IndXTime.m_dTime = 0;
        Inputs.m_IndXTime.m_nFlag = 0;
        TestFunction(Inputs, EventIndex, GetIndexByTime, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Event Entity Times: No Event Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetIndexByTime: No Event Entities available", EXCL);
    }

    // Analog
    if ((g_nAnalog != 0) & (g_anIndeces[g_aidAnalog[0]] != 0))
    {
        Inputs.m_IndXTime.m_filehandle = g_hfile;
        Inputs.m_IndXTime.m_dwEntityID = g_aidAnalog[0];
        Inputs.m_IndXTime.m_dTime = 0;
        Inputs.m_IndXTime.m_nFlag = 0;
        TestFunction(Inputs, AnalogIndex, GetIndexByTime, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Analog Entity Times: No Analog Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetIndexByTime: No Analog Entities available", EXCL);
    }

    // Segment
    if ((g_nSegment != 0) & (g_anIndeces[g_aidSegment[0]] != 0))
    {
        Inputs.m_IndXTime.m_filehandle = g_hfile;
        Inputs.m_IndXTime.m_dwEntityID = g_aidSegment[0];
        Inputs.m_IndXTime.m_dTime = 0;
        Inputs.m_IndXTime.m_nFlag = 0;
        TestFunction(Inputs, SegmentIndex, GetIndexByTime, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Segment Entity Times: No Segment Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetIndexByTime: No Segment Entities available", EXCL);
    }

    // Neural
    if ((g_nNeural != 0) & (g_anIndeces[g_aidNeural[0]] != 0))
    {
        Inputs.m_IndXTime.m_filehandle = g_hfile;
        Inputs.m_IndXTime.m_dwEntityID = g_aidNeural[0];
        Inputs.m_IndXTime.m_dTime = 0;
        Inputs.m_IndXTime.m_nFlag = 0;
        TestFunction(Inputs, NeuralIndex, GetIndexByTime, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Neural Entity Times: No Neural Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetIndexByTime: No Neural Entities available", EXCL);
    }

    return;
}

// Author & Date:   Almut Branner, 1/8/03
// Purpose: Run tests for ns_GetTimeByIndex. 
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestGetTimeByIndex()
{
    InVars Inputs;

    // Perform error tests first for ns_GetTimeByIndex

    // Testing for ns_BADFILE by inputting a file handle that does not exist
    Inputs.m_TimeXInd.m_filehandle = g_hfile + 1;
    Inputs.m_TimeXInd.m_dwEntityID = 0;
    Inputs.m_TimeXInd.m_dwIndex = 0;
    TestFunction(Inputs, BadFile, GetTimeByIndex, ns_BADFILE);

    // Testing for ns_BADENTITY by inputting an entity ID that does not exist
    Inputs.m_TimeXInd.m_filehandle = g_hfile;
    Inputs.m_TimeXInd.m_dwEntityID = g_nEntity;
    Inputs.m_TimeXInd.m_dwIndex = 0;
    TestFunction(Inputs, BadEntity, GetTimeByIndex, ns_BADENTITY);

    // Testing for ns_BADFILE by inputting an index that does not exist
    Inputs.m_TimeXInd.m_filehandle = g_hfile;
    Inputs.m_TimeXInd.m_dwEntityID = 0;
    Inputs.m_TimeXInd.m_dwIndex = MAXNUMINDEXES + 1;
    TestFunction(Inputs, BadIndexInvEvent, GetTimeByIndex, ns_BADINDEX);

    // Testing function for different entities
    // Event
    if ((g_nEvent != 0) & (g_anIndeces[g_aidEvent[0]] != 0))
    {
        Inputs.m_TimeXInd.m_filehandle = g_hfile;
        Inputs.m_TimeXInd.m_dwEntityID = g_aidEvent[0];
        Inputs.m_TimeXInd.m_dwIndex = 0;
        TestFunction(Inputs, EventTime, GetTimeByIndex, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Event Entity Index: No Event Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetTimeByIndex: No Event Entities available", EXCL);
    }

    // Analog
    if ((g_nAnalog != 0) & (g_anIndeces[g_aidAnalog[0]] != 0))
    {
        Inputs.m_TimeXInd.m_filehandle = g_hfile;
        Inputs.m_TimeXInd.m_dwEntityID = g_aidAnalog[0];
        Inputs.m_TimeXInd.m_dwIndex = 0;
        TestFunction(Inputs, AnalogTime, GetTimeByIndex, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Analog Entity Index: No Analog Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetTimeByIndex: No Analog Entities available", EXCL);
    }

    // Segment
    if ((g_nSegment != 0) & (g_anIndeces[g_aidSegment[0]] != 0))
    {
        Inputs.m_TimeXInd.m_filehandle = g_hfile;
        Inputs.m_TimeXInd.m_dwEntityID = g_aidSegment[0];
        Inputs.m_TimeXInd.m_dwIndex = 0;
        TestFunction(Inputs, SegmentTime, GetTimeByIndex, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Segment Entity Index: No Segment Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetTimeByIndex: No Segment Entities available", EXCL);
    }

    // Neural
    if ((g_nNeural != 0) & (g_anIndeces[g_aidNeural[0]] != 0))
    {
        Inputs.m_TimeXInd.m_filehandle = g_hfile;
        Inputs.m_TimeXInd.m_dwEntityID = g_aidNeural[0];
        Inputs.m_TimeXInd.m_dwIndex = 0;
        TestFunction(Inputs, NeuralTime, GetTimeByIndex, 0);
    }
    else
    {
        m_TreeData.InsertItem("Search Neural Entity Index: No Neural Entities available.");
        m_ListTests.InsertItem(g_nList++, "  ns_GetTimeByIndex: No Neural Entities available", EXCL);
    }

    return;
}

// Author & Date:   Almut Branner, 2/17/03
// Purpose: Run tests for ns_GetLastErrorMsg. 
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::TestGetLastErrorMsg()
{
    ns_RESULT nsResult;

    g_pvData = new char[256];
    try
    {
        nsResult = ns_GetLastErrorMsg((char *) g_pvData, 256);
    }
    catch(...)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetLastErrorMsg: A general library error occured!", EXCL);
        delete [] g_pvData;
        return;
    }
    if (0 == nsResult)
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetLastErrorMsg: Execution", PASS);
    }
    else
    {
        m_ListTests.InsertItem(g_nList++, 
            "  ns_GetLastErrorMsg: Execution", FAIL);
    }
    
    delete [] g_pvData;
    return;
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: Run tests for ns_CloseFile. 
// Inputs:  none (file handle is a global variable)
// Outputs: none

void CDLLTesterDlg::TestCloseFile()
{
    InVars Inputs;

    if (g_abFunc[4])
    {
        Inputs.m_CFIn.m_filehandle = g_hfile + 1;
        TestFunction(Inputs, BadFile, CloseFile, ns_BADFILE);
    }

    Inputs.m_CFIn.m_filehandle = g_hfile;
    TestFunction(Inputs, Execution, CloseFile, 0);
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function gets called when a data file is selected (button pushed).
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::OnBUTTONSelectDataFile() 
{
    // TODO: Possibly include list of vendors files later but have the default be *.*
//    g_szTemp.Format("%s|*.%s||", g_nsLibInfo.FileDesc->szDescription, 
//        g_nsLibInfo.FileDesc->szExtension);
    CFileDialog fdlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST, NULL, NULL);

    if (IDOK == fdlg.DoModal()) 
    {
        m_filename.EnableWindow(TRUE);
        m_filename.SetWindowText(fdlg.GetPathName());
        if (0 != m_dllname.IsWindowEnabled())
            m_RunTests.EnableWindow(TRUE);
        AfxGetApp()->WriteProfileString(_T ("v1.2"), _T ("Filename"), fdlg.GetPathName());
    }
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function is called when a DLL library is selected (button pushed).
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::OnBUTTONSelectDLL() 
{
    _chdir("..\\suppl");

    CFileDialog fdlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST,
        "Dynamic Link Libraries (*.dll)|*.dll||", NULL);

    if (IDOK == fdlg.DoModal())
    {
        // Put the filename in the window
        m_dllname.EnableWindow(TRUE);
        m_dllname.SetWindowText(fdlg.GetPathName());
        if (0 != m_filename.IsWindowEnabled())
            m_RunTests.EnableWindow(TRUE);
        AfxGetApp()->WriteProfileString(_T ("v1.2"), _T ("DLLname"), fdlg.GetPathName());
    }
}

// Author & Date:   Almut Branner, 2/20/03
// Purpose: This function is called when a DLL library is selected (button pushed).
//          The addresses of Neuroshare functions are obtained here.
//          All test functions that involve the data file are called from here.
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::OnBUTTONRunTests() 
{
    int i;  // Used for loops

    // Clear all list since new tests are run and reset the counter
    g_nList = 0;
    g_bFileLoaded = FALSE;
    m_ListTests.DeleteAllItems();
    m_ListTests.UpdateWindow();
    m_TreeData.DeleteAllItems();
    m_TreeData.EnableWindow(TRUE);
    m_TreeData.UpdateWindow();

    // Initialize progress bar
    m_ProgressBar.SetRange(0, 100);
    m_ProgressBar.SetPos(0);

    // Test and load Neuroshare DLL

    CString szFileName;
    m_dllname.GetWindowText(szFileName);

    if (g_abFunc[0])
    {
        // Test Loading of DLL (Only performed if the test was selected)
        g_hNeuDLL = LoadLibrary(szFileName);
        if (!g_hNeuDLL)
        {
            m_ListTests.InsertItem(g_nList++, "  Loading DLL", FAIL);
            AfxMessageBox("Loading DLL did not work.\nTests cannot be performed.", MB_OK | 
                MB_ICONINFORMATION);
            return;
        }
        m_ListTests.InsertItem(g_nList++, "  Loading DLL.", PASS);

        // Test unloading of DLL
        if (!FreeLibrary(g_hNeuDLL))
        {
            m_ListTests.InsertItem(g_nList++, "  Unloading DLL", FAIL);
            AfxMessageBox("Unloading DLL did not work.\nTests cannot be performed.", MB_OK | 
                MB_ICONINFORMATION);
            return;
        }
        m_ListTests.InsertItem(g_nList++, "  Unloading DLL", PASS);

        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
        m_ListTests.UpdateWindow();
    }

    // Are there actually other tests selected?
    int nSum = 0;
    for (i = 1; i < 18; ++i)
    {
        nSum = nSum + g_abFunc[i];
    }
    
    if (!nSum && !g_abFunc[0])      // No tests were selected
    {
        AfxMessageBox("No tests selected!", MB_OK | MB_ICONINFORMATION);
        return;
    }
    else if (!nSum && g_abFunc[0])  // Only DLL loading is tested
        return;

    // Actually load DLL to be used in consecutive tests
    g_hNeuDLL = LoadLibrary(szFileName);
    if (!g_hNeuDLL && !g_abFunc[0])     // Message only needs to be displayed if tests not run
    {
        AfxMessageBox("Loading DLL did not work.\nTests cannot be performed.", MB_OK | 
            MB_ICONINFORMATION);
        return;
    }

    // Get address of all imported functions and define the function pointer variable.
    // These functions are accessible throughout the application wherever
    // #include "nsAPIdllimp.h"
    // statement is used.

    ns_GetLibraryInfo =  (NS_GETLIBRARYINFO)  GetProcAddress(g_hNeuDLL, "ns_GetLibraryInfo");
    ns_OpenFile =        (NS_OPENFILE)        GetProcAddress(g_hNeuDLL, "ns_OpenFile");
    ns_GetFileInfo =     (NS_GETFILEINFO)     GetProcAddress(g_hNeuDLL, "ns_GetFileInfo");
    ns_CloseFile =       (NS_CLOSEFILE)       GetProcAddress(g_hNeuDLL, "ns_CloseFile");
    ns_GetEntityInfo =   (NS_GETENTITYINFO)   GetProcAddress(g_hNeuDLL, "ns_GetEntityInfo");
    ns_GetEventInfo =    (NS_GETEVENTINFO)    GetProcAddress(g_hNeuDLL, "ns_GetEventInfo");
    ns_GetEventData =    (NS_GETEVENTDATA)    GetProcAddress(g_hNeuDLL, "ns_GetEventData");
    ns_GetAnalogInfo =   (NS_GETANALOGINFO)   GetProcAddress(g_hNeuDLL, "ns_GetAnalogInfo");
    ns_GetAnalogData =   (NS_GETANALOGDATA)   GetProcAddress(g_hNeuDLL, "ns_GetAnalogData");
    ns_GetSegmentInfo =  (NS_GETSEGMENTINFO)  GetProcAddress(g_hNeuDLL, "ns_GetSegmentInfo");
    ns_GetSegmentSourceInfo =   (NS_GETSEGMENTSOURCEINFO)   GetProcAddress(g_hNeuDLL, 
        "ns_GetSegmentSourceInfo");
    ns_GetSegmentData =  (NS_GETSEGMENTDATA)  GetProcAddress(g_hNeuDLL, "ns_GetSegmentData");
    ns_GetNeuralInfo =   (NS_GETNEURALINFO)   GetProcAddress(g_hNeuDLL, "ns_GetNeuralInfo");
    ns_GetNeuralData =   (NS_GETNEURALDATA)   GetProcAddress(g_hNeuDLL, "ns_GetNeuralData");
    ns_GetIndexByTime =  (NS_GETINDEXBYTIME)  GetProcAddress(g_hNeuDLL, "ns_GetIndexByTime");
    ns_GetTimeByIndex =  (NS_GETTIMEBYINDEX)  GetProcAddress(g_hNeuDLL, "ns_GetTimeByIndex");
    ns_GetLastErrorMsg = (NS_GETLASTERRORMSG) GetProcAddress(g_hNeuDLL, "ns_GetLastErrorMsg");

    // Call and test Neuroshare function "ns_GetLibraryInfo"

    if (g_abFunc[1])
    {
        g_nsResult = ns_GetLibraryInfo((ns_LIBRARYINFO *) 0xFFFFFFFF, (uint32)sizeof(ns_LIBRARYINFO));
        if (ns_LIBERROR == g_nsResult)
            m_ListTests.InsertItem(g_nList++,
                "  ns_GetLibraryInfo: Invalid pLibraryInfo (invalid pointer) -> ns_LIBERROR", PASS);
        else
            m_ListTests.InsertItem(g_nList++,
                "  ns_GetLibraryInfo: Invalid pLibraryInfo (invalid pointer) -> ns_LIBERROR", FAIL);

        g_nsResult = ns_GetLibraryInfo(&g_nsLibInfo, (uint32)sizeof(ns_LIBRARYINFO));
        if (ns_LIBERROR == g_nsResult) {
            m_ListTests.InsertItem(g_nList++, "  Loading library info with nsGetLibInfo", FAIL);
            m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", 
                BLANK);
        }
        else
        {
            m_ListTests.InsertItem(g_nList++, "  Loading library info with nsGetLibInfo", PASS);
            m_ListTests.UpdateWindow();

            // Build and display the Library Information tree list

            g_hTreeItems[0] = m_TreeData.InsertItem("Library Information");

            g_szTemp.Format("Library Version %d.%d", g_nsLibInfo.dwLibVersionMaj, g_nsLibInfo.dwLibVersionMin);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_szTemp.Format("API Spec Version %d.%d", g_nsLibInfo.dwAPIVersionMaj, g_nsLibInfo.dwAPIVersionMin);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_szTemp.Format("Description: %s", g_nsLibInfo.szDescription);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_szTemp.Format("Creator: %s", g_nsLibInfo.szCreator);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_szTemp.Format("Modified: %d/%d/%d", g_nsLibInfo.dwTime_Month, g_nsLibInfo.dwTime_Day,
                g_nsLibInfo.dwTime_Year);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            BOOL prev = FALSE;

            g_szTemp = "Flag: ";
            if (g_nsLibInfo.dwFlags & ns_LIBRARY_DEBUG)
            {
                g_szTemp = g_szTemp + "DEBUG ";
                prev = TRUE;
            }
            if (g_nsLibInfo.dwFlags & ns_LIBRARY_MODIFIED)
            {
                if (FALSE == prev)
                {
                    g_szTemp = g_szTemp + "MODIFIED ";
                    prev = TRUE;
                }
                else
                    g_szTemp = g_szTemp + "+ MODIFIED ";
            }
            if (g_nsLibInfo.dwFlags & ns_LIBRARY_PRERELEASE) 
            {
                if (FALSE == prev)
                {
                    g_szTemp = g_szTemp + "PRERELEASE ";
                    prev = TRUE;
                }
                else
                    g_szTemp = g_szTemp + "+ PRERELEASE ";
            }
            if (g_nsLibInfo.dwFlags & ns_LIBRARY_SPECIALBUILD)
            {
                if (FALSE == prev)
                {
                    g_szTemp = g_szTemp + "SPECIALBUILD ";
                    prev = TRUE;
                }
                else
                    g_szTemp = g_szTemp + "+ SPECIALBUILD ";
            }
            if (g_nsLibInfo.dwFlags & ns_LIBRARY_MULTITHREADED)
            {
                if (FALSE == prev)
                    g_szTemp = g_szTemp + "MULTITHREADED";
                else
                    g_szTemp = g_szTemp + "+ MULTITHREADED";
            }
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_szTemp.Format("Max.number of files library can open: %d", g_nsLibInfo.dwMaxFiles);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_szTemp.Format("Number of valid file decription entries: %d", 
                g_nsLibInfo.dwFileDescCount);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[0]);

            g_hTreeItems[1] = m_TreeData.InsertItem("File Type Decription", g_hTreeItems[0]);

            g_szTemp.Format("Description: %s", g_nsLibInfo.FileDesc->szDescription);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

            g_szTemp.Format("Extension: %s", g_nsLibInfo.FileDesc->szExtension);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

            g_szTemp.Format("Codes used on Mac: %s", g_nsLibInfo.FileDesc->szMacCodes);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

            g_szTemp.Format("Code at beginning: %s", g_nsLibInfo.FileDesc->szMagicCode);
            m_TreeData.InsertItem(g_szTemp, g_hTreeItems[1]);

            m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------", BLANK);
            m_ListTests.UpdateWindow();
        }
    }

    // Initialize Lists to prevent endless loops
    {
        for (uint32 j = 0; j < MAXNUMENTITIES; ++j)
        {
            g_anIndeces[j] = 0;
            g_aidUnknown[j] = 0;
            g_aidEvent[j] = 0;
            g_aidAnalog[j] = 0;
            g_aidSegment[j] = 0;
            g_aidNeural[j] = 0;
        }
    }

    // Reset all counters and global variables
    g_nEvent = 0;
    g_nAnalog = 0;
    g_nSegment = 0;
    g_nNeural = 0;
    g_dTimeSpan = 0;
    g_nEntity = 0;

// Call and test Neuroshare function "ns_OpenFile"

    // Exit if no more tests are selected
    nSum = nSum - g_abFunc[1];
    if (!nSum)
    {
        CleanUp();
        return;
    }

    m_filename.GetWindowText(szFileName);
    g_nsResult = TestOpenFile(szFileName);  // Function will test what tests to perform

    if (g_nsResult != 0) 
    {
        if (g_abFunc[2])
            m_ListTests.InsertItem(g_nList++, "  Opening file with ns_OpenFile", FAIL);
        AfxMessageBox("Running function nsOpenFile did not work.\nFollowing tests cannot be performed.\nData file might be of wrong type.",
            MB_OK | MB_ICONINFORMATION);
        CleanUp();
        return;
    }
    if (g_abFunc[2])
    {
        m_ListTests.InsertItem(g_nList++, "  Opening file with ns_OpenFile", PASS);

        m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }

    g_bFileLoaded = TRUE;       // File was loaded successfully

// Call and test Neuroshare function "ns_GetFileInfo"

    // Check if any following tests are selected
    nSum = nSum - g_abFunc[2];
    if (!nSum)
    {
        CleanUp();
        return;
    }

    g_nsResult = TestGetFileInfo();

    if (g_nsResult != 0)
    {
        if (g_abFunc[3])
            m_ListTests.InsertItem(g_nList++, "  Reading nsFileInfo with ns_GetFileInfo", FAIL);
        AfxMessageBox(
            "Running function nsGetFileInfo did not work\nSome tests cannot be performed.",
            MB_OK | MB_ICONINFORMATION);
        CleanUp();
        return;
    }

    if (g_abFunc[3])
    {
        m_ListTests.InsertItem(g_nList++, "  Reading nsFileInfo with ns_GetFileInfo", PASS);

        m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }

// Call and test Neuroshare function ns_GetEntityInfo

    uint8 nTempList;
    nTempList = g_nList;    // Gives me a way to check whether messages were inserted

    // Check if any following tests are selected (CloseFile excluded)
    nSum = nSum - g_abFunc[3] - g_abFunc[4];
    if (!nSum)
    {
        CleanUp();
        return;
    }

    g_nGenResult = TestGetEntityInfo();     // Needed for all following tests

    // Following tests do not make sense if there are no entities at all or if there was an
    // error reading one of the entities. The program will perform ns_CloseFile and return.

    if (g_nGenResult != 0)
    {
        // g_szTemp is defined in test_GetEntityInfo
        // The result of the function determines the icon used here (EXCL or FAIL)
        m_ListTests.InsertItem(g_nList++,   g_szTemp, g_nGenResult);
        m_ListTests.InsertItem(g_nList++, "  ---------------------------------------------",
            BLANK);

        AfxMessageBox(
            "No Entities available or reading nsEntityInfo did not work.\nMost following tests will not be performed.",
            MB_OK | MB_ICONINFORMATION);

        CleanUp();
        return;
    }

    if (nTempList != g_nList)
    {
        m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
    }
    m_TreeData.UpdateWindow();

// Call and test Neuroshare function ns_GetEventInfo and ns_GetEventData

    if (g_abFunc[6] || g_abFunc[7])
    {
        TestEventEntities();

        if (g_abFunc[7]) 
            m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }
    m_ProgressBar.SetPos(g_nEvent * 100 / g_nEntity);

// Call and test Neuroshare function ns_GetAnalogInfo and ns_GetAnalogData

    if (g_abFunc[8] || g_abFunc[9])
    {
        TestAnalogEntities();

        if (g_abFunc[9])
            m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }
    m_ProgressBar.SetPos((g_nEvent + g_nAnalog) * 100 / g_nEntity);

// Call and test Neuroshare function ns_GetSegmentInfo

    if (g_abFunc[10] || g_abFunc[11] || g_abFunc[12])
    {
        TestSegmentEntities();

        if (g_abFunc[12])
            m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }
    m_ProgressBar.SetPos((g_nEvent + g_nAnalog + g_nSegment) * 100 / g_nEntity);

// Call and test Neuroshare function ns_GetNeuralInfo

    if (g_abFunc[13] || g_abFunc[14])
    {
        TestNeuralEntities();

        if (g_abFunc[14])
            m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }
    m_ProgressBar.SetPos((g_nEvent + g_nAnalog + g_nSegment + g_nNeural) * 100 / 
        g_nEntity);

// Call and test Neuroshare function ns_GetIndexByTime

    if (g_abFunc[15])
    {
        TestGetIndexByTime();

        m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }

// Call and test Neuroshare function ns_GetTimeByIndex

    if (g_abFunc[16])
    {
        TestGetTimeByIndex();

        m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }

// Call and test Neuroshare function ns_GetLastErrorMsg

    if (g_abFunc[17])
    {
        TestGetLastErrorMsg();

        m_ListTests.InsertItem(g_nList, "  ---------------------------------------------", BLANK);
        m_ListTests.EnsureVisible(g_nList++, 0);
        m_ListTests.UpdateWindow();
        m_TreeData.UpdateWindow();
    }

// Call and test Neuroshare function ns_CloseFile

    TestCloseFile();    // Has to be called in any case but messages won't be shown
    m_ListTests.EnsureVisible(g_nList - 1, 0);
    m_ListTests.UpdateWindow();

// Unload DLL when done with everything (was already tested earlier)
    FreeLibrary(g_hNeuDLL);
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function is called when functions to be tested are selected (button pushed).
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::OnBUTTONSelectFunctions() 
{
    SelectFunctionsDlg sdlg;
    int i;

    // Send the current settings to the SelectFunctions dialog box
    for (i = 0; i < 18; ++i)
    {
        sdlg.m_abSelFunc[i] = g_abFunc[i];
    }

    if (IDOK == sdlg.DoModal())
    {
        // Get information (BOOL array) from the dialog box
        for (i = 0; i < 18; ++i)
        {
            g_abFunc[i] = sdlg.m_abSelFunc[i];
        }

        // Put settings into the registry
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("0"), g_abFunc[0]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("1"), g_abFunc[1]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("2"), g_abFunc[2]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("3"), g_abFunc[3]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("4"), g_abFunc[4]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("5"), g_abFunc[5]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("6"), g_abFunc[6]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("7"), g_abFunc[7]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("8"), g_abFunc[8]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("9"), g_abFunc[9]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("10"), g_abFunc[10]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("11"), g_abFunc[11]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("12"), g_abFunc[12]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("13"), g_abFunc[13]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("14"), g_abFunc[14]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("15"), g_abFunc[15]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("16"), g_abFunc[16]);
        AfxGetApp()->WriteProfileInt(_T ("v1.2"), _T ("17"), g_abFunc[17]);
    }
}

// Author & Date:   Almut Branner, 1/21/03
// Purpose: This function is called whenever no more test are run or something went run.
//          It's purpose is to closes open files and unload the DLL library.
// Inputs:  none
// Outputs: none

void CDLLTesterDlg::CleanUp()
{
    if (g_bFileLoaded)
        TestCloseFile();

    if (g_hNeuDLL)
        FreeLibrary(g_hNeuDLL);
    
    return;
}
