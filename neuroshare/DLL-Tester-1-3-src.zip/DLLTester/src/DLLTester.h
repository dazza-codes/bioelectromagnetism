///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DLLTester.h $
//
// Description   : Nothing much defined here except stuff that Visual C++ put in automatically.
//
// Authors       : Almut Branner
//
// $Date: 1/22/03 11:14a $
//
/* $History: DLLTester.h $
// 
// *****************  Version 4  *****************
// User: Almut        Date: 1/22/03    Time: 11:14a
// Updated in $/Neuroshare/DLLTester
// - Settings of the test check boxes is now saved in the registry and
// pulled out everytime the program is run
// - The tester now also tests whether inputting NULL as a data pointer in
// event and segment entities will return the timestamp or not
 * 
 * *****************  Version 3  *****************
 * User: Almut        Date: 1/13/03    Time: 5:45p
 * Updated in $/Neuroshare/DLLTester
 * Added the Neuroshare header.
*/
///////////////////////////////////////////////////////////////////////////////////////////////////


#if !defined(AFX_DLLTESTER_H__EC0BC29D_7C49_4E1C_BBE6_037C9A2F5FDE__INCLUDED_)
#define AFX_DLLTESTER_H__EC0BC29D_7C49_4E1C_BBE6_037C9A2F5FDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

/* Macro Definitions ------------------------------------------------------*/
/* Manifest Constant Definitions ------------------------------------------*/
/* Structures, Classes, & Typedefs ----------------------------------------*/
/* Externals --------------------------------------------------------------*/
/* Global Variables -------------------------------------------------------*/
/* Local Function Prototypes ----------------------------------------------*/

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterApp:
// See DLLTester.cpp for the implementation of this class
//

class CDLLTesterApp : public CWinApp
{
public:
    CDLLTesterApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDLLTesterApp)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

// Implementation

    //{{AFX_MSG(CDLLTesterApp)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLLTESTER_H__EC0BC29D_7C49_4E1C_BBE6_037C9A2F5FDE__INCLUDED_)
