///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: DLLTester.cpp $
//
// Description   : Defines the class behaviors for the application.
//
// Authors       : Almut Branner
//
// $Date: 1/22/03 11:14a $
//
/* $History: DLLTester.cpp $
// 
// *****************  Version 4  *****************
// User: Almut        Date: 1/22/03    Time: 11:14a
// Updated in $/Neuroshare/DLLTester
// - Settings of the test check boxes is now saved in the registry and
// pulled out everytime the program is run
// - The tester now also tests whether inputting NULL as a data pointer in
// event and segment entities will return the timestamp or not
 * 
 * *****************  Version 3  *****************
 * User: Almut        Date: 1/13/03    Time: 5:50p
 * Updated in $/Neuroshare/DLLTester
 * Included Neuroshare headers.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "DLLTester.h"
#include "DLLTesterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterApp

BEGIN_MESSAGE_MAP(CDLLTesterApp, CWinApp)
    //{{AFX_MSG_MAP(CDLLTesterApp)
        // NOTE - the ClassWizard will add and remove mapping macros here.
        //    DO NOT EDIT what you see in these blocks of generated code!
    //}}AFX_MSG
    ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterApp construction

CDLLTesterApp::CDLLTesterApp()
{
    // TODO: add construction code here,
    // Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDLLTesterApp object

CDLLTesterApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDLLTesterApp initialization

BOOL CDLLTesterApp::InitInstance()
{
    AfxEnableControlContainer();

    // Standard initialization
    // If you are not using these features and wish to reduce the size
    //  of your final executable, you should remove from the following
    //  the specific initialization routines you do not need.

#ifdef _AFXDLL
    Enable3dControls();         // Call this when using MFC in a shared DLL
#else
    Enable3dControlsStatic();   // Call this when linking to MFC statically
#endif

    // Set registry key later used to save the settings of the tests run
    SetRegistryKey(_T ("Neuroshare"));

    CDLLTesterDlg dlg;
    m_pMainWnd = &dlg;
    int nResponse = dlg.DoModal();
    if (nResponse == IDOK)
    {
        // TODO: Place code here to handle when the dialog is
        //  dismissed with OK
    }
    else if (nResponse == IDCANCEL)
    {
        // TODO: Place code here to handle when the dialog is
        //  dismissed with Cancel
    }

    // Since the dialog has been closed, return FALSE so that we exit the
    //  application, rather than start the application's message pump.
    return FALSE;
}
