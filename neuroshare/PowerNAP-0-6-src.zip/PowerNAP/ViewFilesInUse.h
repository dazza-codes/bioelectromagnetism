///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewFilesInUse.h $
//
// Description   : definition of the FilesInUseView class 
//
// Authors       : Kirk Korver
//
// $Date: 3/05/04 3:50p $
//
// $History: ViewFilesInUse.h $
// 
// *****************  Version 45  *****************
// User: Kkorver      Date: 3/05/04    Time: 3:50p
// Updated in $/Neuroshare/PowerNAP
// Added the ability to delete channels
// 
// *****************  Version 44  *****************
// User: Kkorver      Date: 3/01/04    Time: 12:29p
// Updated in $/Neuroshare/PowerNAP
// Using the arrow keys in the List will now update the current entity
// 
// *****************  Version 43  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:49p
// Updated in $/Neuroshare/PowerNAP
// Add the menu choice View | Playback
// 
// *****************  Version 42  *****************
// User: Kkorver      Date: 2/19/04    Time: 4:07p
// Updated in $/Neuroshare/PowerNAP
// There is an 'ADD' button on the library details. This button will set
// the correct settings in the registry so the DLL will be remembered
// 
// *****************  Version 41  *****************
// User: Abranner     Date: 10/31/03   Time: 6:06p
// Updated in $/Neuroshare/PowerNAP
// Removed buttons and rearranged interface.
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 10/28/03   Time: 5:09p
// Updated in $/Neuroshare/PowerNAP
// Implemented Sort All button with Progress Window.
// 
// *****************  Version 39  *****************
// User: Abranner     Date: 10/27/03   Time: 10:35a
// Updated in $/Neuroshare/PowerNAP
// Changed size of FIU dialog and removed non-functioning buttons.
// 
// *****************  Version 38  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 37  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// *****************  Version 36  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 35  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// *****************  Version 34  *****************
// User: Abranner     Date: 8/27/03    Time: 11:00a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 33  *****************
// User: Abranner     Date: 8/26/03    Time: 6:01p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 32  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 31  *****************
// User: Awang        Date: 8/15/03    Time: 1:19p
// Updated in $/Neuroshare/nsClassifier
// Added option in View menu choice to display ViewSortedInfo
// 
// *****************  Version 30  *****************
// User: Awang        Date: 8/05/03    Time: 3:37p
// Updated in $/Neuroshare/nsClassifier
// Display KMeans options view on menu selection
// 
// *****************  Version 29  *****************
// User: Kkorver      Date: 7/28/03    Time: 11:47a
// Updated in $/Neuroshare/nsClassifier
// Added OnFileSavedata()
// 
// *****************  Version 28  *****************
// User: Awang        Date: 6/30/03    Time: 3:58p
// Updated in $/Neuroshare/nsClassifier
// Added buttons in toolbars that access analoguous button pushes here.
// 
// *****************  Version 27  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// *****************  Version 26  *****************
// User: Kkorver      Date: 5/12/03    Time: 11:17a
// Updated in $/Neuroshare/nsClassifier
// Added OnFileAdddatafileadvanced() and OnPopupAdddatafileadvanced()
// 
// *****************  Version 25  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 5/02/03    Time: 8:54a
// Updated in $/Neuroshare/nsClassifier
// Fixed error after merging.
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 5/01/03    Time: 5:51p
// Updated in $/Neuroshare/nsClassifier
// Changed window titles.
// Changed the appearance of some things.
// Implemented capability to sort ListCtrls by columns (both text and
// numbers).
// Two new classes were implemented for this: CSortClass and
// CSortListCtrl.
// 
// *****************  Version 22  *****************
// User: Awang        Date: 5/01/03    Time: 1:29p
// Updated in $/Neuroshare/nsClassifier
// Added ViewPCA stuff
// 
// *****************  Version 21  *****************
// User: Abranner     Date: 4/30/03    Time: 6:05p
// Updated in $/Neuroshare/nsClassifier
// Implemented sorting for the list control but the numeric sorting does
// not work correctly.
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 4/30/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Only allow people to "remove" files if there are files to remove
// 
// *****************  Version 19  *****************
// User: Abranner     Date: 4/30/03    Time: 2:47p
// Updated in $/Neuroshare/nsClassifier
// Changed window positions.
// Changed the entity list to a list control.
// Fized a bug in the waveform view.
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 4/29/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Added OnCreate() that set's the title of the frame
// Made the toolbar visible for this view
// 
// *****************  Version 17  *****************
// User: Abranner     Date: 4/29/03    Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Added a view for Entity Infos
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 4/28/03    Time: 12:34p
// Updated in $/Neuroshare/nsClassifier
// Added capability to turn tooltips off.
// 
// *****************  Version 15  *****************
// User: Abranner     Date: 4/25/03    Time: 5:39p
// Updated in $/Neuroshare/nsClassifier
// Implemented tooltip support for all windows (hovering shows message).
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 4/24/03    Time: 9:21a
// Updated in $/Neuroshare/nsClassifier
// Added OnViewLibrarydetails()
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 4/22/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Renamed m_cboFilesList to m_lstFilesList
// Added  OnPopupRemoveFile() and OnFileDeleteDatafile()
// 
// *****************  Version 12  *****************
// User: Almut        Date: 4/18/03    Time: 5:43p
// Updated in $/Neuroshare/nsClassifier
// Added options for the training samples and removed options from the FIU
// view. Also changed Document to actually test the difference between two
// files.
// 
// *****************  Version 11  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 10  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 4/11/03    Time: 11:26a
// Updated in $/Neuroshare/nsClassifier
// Renamed more controls to use the IDC_FIU_XXX_ prefix
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 4/11/03    Time: 9:33a
// Updated in $/Neuroshare/nsClassifier
// Added UpdateGroupCounts()
// Added UpdateSampleCounts()
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:19p
// Updated in $/Neuroshare/nsClassifier
// Added the radio button for select all
// 
// *****************  Version 6  *****************
// User: Almut        Date: 4/10/03    Time: 11:05a
// Updated in $/Neuroshare/nsClassifier
// Added calls to VisitorAlignCheck.
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 4/09/03    Time: 1:54p
// Updated in $/Neuroshare/nsClassifier
// Renamed CFilesInUse to CViewFilesInUse
// 
// *****************  Version 4  *****************
// User: Angela       Date: 4/09/03    Time: 1:37p
// Updated in $/Neuroshare/nsClassifier
// Added OnSelchangeCboEntityID()
// 
// *****************  Version 3  *****************
// User: Angela       Date: 4/08/03    Time: 2:24p
// Updated in $/Neuroshare/nsClassifier
// Added waveform view button
// 
// *****************  Version 2  *****************
// User: Kirk         Date: 3/25/03    Time: 1:39p
// Updated in $/Neuroshare/nsClassifier
// Added popup menu choice to insert data files
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 3/25/03    Time: 11:25a
// Created in $/Neuroshare/nsClassifier
// This is the view for the files in use
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef FILESINUSE_H_INCLUDED
#define FILESINUSE_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SortListCtrl.h"
#include "ProgressWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CViewFilesInUse form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CDocPowerNAP;     // Forward declaration to avoid #include "DocPowerNAP.h"

class CViewFilesInUse : public CFormView
{
protected:
	CViewFilesInUse();          // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewFilesInUse)

    void UpdateGroupCounts();       // We are updating the counts of groups
    void UpdateSampleCounts();      // We are updating the sample counts

// Form Data
public:
	//{{AFX_DATA(CViewFilesInUse)
	enum { IDD = IDD_FILESINUSE_FORM };
	CSortListCtrl	m_lstEntityID;
	CButton	m_btnOptPop;
	CStatic	m_lblTotalSamples;
	CStatic	m_lblSamples;
	CButton	m_chkSaturationCheck;
	CButton	m_chkAlignPeaks;
	CButton	m_rdoSample;
    CButton m_rdoSelectAll;
	CListBox	m_lstFilesList;
	//}}AFX_DATA

// Attributes
public:
	CDocPowerNAP * GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilesInUse)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
    enum 
    { 
        // Timers for this window
        TMR_OPEN_FILE,          // Prompt to "open" a file
        TMR_UPDATE_ENTITY,      // Timeout before we "update" the current entity
        // Timeout values for these timers
        TMR_TIME_OPEN_FILE = 1000,  
        TMR_TIME_UPDATE_ENTITY = 200,
    };

protected:
	void ShowOptGeneral(int nView);
	void ShowOptSpkSort(int nView);
	virtual ~CViewFilesInUse();

    void DetermineTheActiveEntity();    // this is the top level function to set the active entity

    // Called by OnUpdate
	void UpdateFileList();
	void UpdateEntityList();
	void InitialColumnSort(CSortListCtrl *pListCtrl);


#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CViewFilesInUse)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnRdoSelectall();
	afx_msg void OnRdoSample();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnPopupAddFile();
	afx_msg void OnWfViewButton();
	afx_msg void OnAlignCheck();
	afx_msg void OnSaturationCheck();
	afx_msg void OnBTNOptPop();
	afx_msg void OnBTNOptAlign();
	afx_msg void OnBtnEntityinfo();
	afx_msg void OnPopupRemoveFile();
	afx_msg void OnFileAdddatafile();
	afx_msg void OnFileDeleteDatafile();
	afx_msg void OnFileAdddatafileadvanced();
	afx_msg void OnPopupAdddatafileadvanced();
	afx_msg void OnViewLibrarydetails();
	afx_msg void OnHelpTooltip();
	afx_msg void OnUpdatePopupRemoveFile(CCmdUI* pCmdUI);
	afx_msg void OnPcView();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBtnOptShy();
	afx_msg void OnViewWaveforms();
	afx_msg void OnViewPcProjections();
	afx_msg void OnViewEntInfo();
	afx_msg void OnFileSavedata();
	afx_msg void OnViewSortedInfo();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSortingOptions();
	afx_msg void OnGeneralOptions();
	afx_msg void OnBtnRaster();
	afx_msg void OnBtnSortAll();
	afx_msg void OnFileDlls();
	afx_msg void OnViewPlayback();
	afx_msg void OnLstEntityidItemchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPopupDeletechannel();
	afx_msg void OnUpdatePopupDeletechannel(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CToolTipCtrl m_tool;
};

#ifndef _DEBUG  // debug version in .cpp
inline CDocPowerNAP* CViewFilesInUse::GetDocument()
   { return (CDocPowerNAP*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // Include guard
