#include <complex>

/* namespace polution from <sys/sysmacros.h> */
#undef major
#undef minor
