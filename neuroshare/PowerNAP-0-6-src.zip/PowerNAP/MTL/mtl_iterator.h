#include <iterator>

#undef major
#undef minor
