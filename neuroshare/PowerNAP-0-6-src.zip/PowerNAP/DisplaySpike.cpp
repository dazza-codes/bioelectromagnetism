///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DisplaySpike.cpp $
//
// Description   : implementation of the Centroid List classes
//
// Authors       : Kirk Korver
//
// $Date: 3/11/04 1:00p $
//
// $History: DisplaySpike.cpp $
// 
// *****************  Version 49  *****************
// User: Kkorver      Date: 3/11/04    Time: 1:00p
// Updated in $/Neuroshare/PowerNAP
// Move the reject line on mouse down
// 
// *****************  Version 48  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:55p
// Updated in $/Neuroshare/PowerNAP
// Minor changes to improve speed
// 
// *****************  Version 47  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:45p
// Updated in $/Neuroshare/PowerNAP
// Added basic "clipping" functions
// 
// *****************  Version 46  *****************
// User: Abranner     Date: 3/05/04    Time: 11:15a
// Updated in $/Neuroshare/PowerNAP
// Changed to use char array for unit labels. Also added automated cursor
// changing.
// 
// *****************  Version 45  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:27p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 44  *****************
// User: Abranner     Date: 3/04/04    Time: 10:35a
// Updated in $/Neuroshare/PowerNAP
// Put check code back in because app crashed when file was removed and
// displays were present.
// 
// *****************  Version 43  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:51p
// Updated in $/Neuroshare/PowerNAP
// Added animation capability
// 
// *****************  Version 42  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:55p
// Updated in $/Neuroshare/PowerNAP
// Added DrawTheseSpikes()
// 
// *****************  Version 41  *****************
// User: Abranner     Date: 2/10/04    Time: 10:11a
// Updated in $/Neuroshare/PowerNAP
// Commented out TRACE commands.
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 2/03/04    Time: 12:44p
// Updated in $/Neuroshare/PowerNAP
// Made changes to doc to simplify data renewal operations.
// 
// *****************  Version 39  *****************
// User: Kkorver      Date: 10/21/03   Time: 5:40p
// Updated in $/Neuroshare/PowerNAP
// Force the threshold position to be re-calculated during "paint" as the
// screen may have been resized ( DrawSpikes() does it)
// 
// *****************  Version 38  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 37  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:19a
// Updated in $/Neuroshare/nsClassifier
// Removed dead code
// Separated out the different "mouse" states
// 
// *****************  Version 36  *****************
// User: Kkorver      Date: 10/17/03   Time: 1:32p
// Updated in $/Neuroshare/nsClassifier
// Moving the mouse now just slides the threshold line. Later, on Mouse
// up, the threshold is actually set
// 
// *****************  Version 35  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 34  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 33  *****************
// User: Abranner     Date: 10/15/03   Time: 6:02p
// Updated in $/Neuroshare/nsClassifier
// Fixed problems with merging.
// 
// *****************  Version 32  *****************
// User: Abranner     Date: 10/15/03   Time: 5:56p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 31  *****************
// User: Kkorver      Date: 10/15/03   Time: 4:08p
// Updated in $/Neuroshare/nsClassifier
// Added SetThresholdFromPoint()
// Cursor no longer needs to be "over" the threshold bar to adjust the
// threshold
// 
// *****************  Version 30  *****************
// User: Abranner     Date: 10/13/03   Time: 1:59p
// Updated in $/Neuroshare/nsClassifier
// Changed IsThisSegment() to IsActiveSegment().
// 
// *****************  Version 29  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 28  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 27  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 26  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 25  *****************
// User: Abranner     Date: 9/10/03    Time: 1:31p
// Updated in $/Neuroshare/nsClassifier
// Removed test code.
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 22  *****************
// User: Awang        Date: 8/28/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// OnUpdate clears centroid list if hint tells it new waveforms have been
// loaded
// 
// *****************  Version 21  *****************
// User: Awang        Date: 8/27/03    Time: 1:01p
// Updated in $/Neuroshare/nsClassifier
// Removed drawing of centroid waveforms
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 8/25/03    Time: 11:02a
// Updated in $/Neuroshare/nsClassifier
// Changed some variable names to conform with coding standard. Changed
// the toolbar and some tooltips.
// 
// *****************  Version 19  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 18  *****************
// User: Awang        Date: 8/18/03    Time: 3:22p
// Updated in $/Neuroshare/nsClassifier
// Changed name of ctrlist
// 
// *****************  Version 17  *****************
// User: Awang        Date: 8/05/03    Time: 2:01p
// Updated in $/Neuroshare/nsClassifier
// Reduce to 1 PC projection display
// Created CPCAMainFrame to deal with toolbar with custom controls
// 
// *****************  Version 16  *****************
// User: Awang        Date: 6/30/03    Time: 3:49p
// Updated in $/Neuroshare/nsClassifier
// Re-design of Displays with toolbars
// 
// *****************  Version 15  *****************
// User: Awang        Date: 6/18/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 14  *****************
// User: Awang        Date: 6/16/03    Time: 1:12p
// Updated in $/Neuroshare/nsClassifier
// New unit definitions
// 
// *****************  Version 13  *****************
// User: Awang        Date: 6/11/03    Time: 9:24a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 12  *****************
// User: Awang        Date: 6/10/03    Time: 5:08p
// Updated in $/Neuroshare/nsClassifier
// Hightlights selected waveform
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 5/05/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with the graph update. The scaling (or max voltage value)
// of all waveforms is now calculated in the document and not the graph
// window.
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 4/30/03    Time: 2:36p
// Updated in $/Neuroshare/nsClassifier
// Major overhaul so the drawing is done directly wihtout requiring the
// "bitblit"
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 4/29/03    Time: 5:06p
// Updated in $/Neuroshare/nsClassifier
// Threshold line now tracks and arrows work.
// 
// *****************  Version 8  *****************
// User: Awang        Date: 4/28/03    Time: 11:10a
// Updated in $/Neuroshare/nsClassifier
// Changed class name to CDisplaySpike
// 
// *****************  Version 7  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 6  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 5  *****************
// User: Angela       Date: 4/10/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Updates and no extra frames created
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:17p
// Updated in $/Neuroshare/nsClassifier
// Added NS header
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "MainFrameWaveforms.h"
#include "DisplaySpike.h"
#include <vector>
#include "CloneBitmap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDisplaySpike


CDisplaySpike::CDisplaySpike() : 
    m_pcActiveMouse(&m_icMouseRegular)
{
    m_icMouseRegular.SetParent(this);
    m_icMouseThreshold.SetParent(this);
    m_icMouseReject.SetParent(this);

    // The pen we use to draw grid lines
    m_penGrid.CreatePen(PS_DOT, 1, LT_GREEN);
    m_penRedThick.CreatePen(PS_SOLID, 2, RED);
    m_penRedThin.CreatePen(PS_DOT, 1, RED);
    m_penBlueThick.CreatePen(PS_SOLID, 2, CYAN);
 
    m_crBackColor  = BLACK;
    
    m_brushBack.CreateSolidBrush(m_crBackColor);
    
    m_dwPrevSelWF = 0;
}

CDisplaySpike::~CDisplaySpike()
{
}


BEGIN_MESSAGE_MAP(CDisplaySpike, CWnd)
    //{{AFX_MSG_MAP(CDisplaySpike)
    ON_WM_CREATE()
    ON_WM_PAINT()
    ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDisplaySpike message handlers

BOOL CDisplaySpike::PreCreateWindow(CREATESTRUCT& cs) 
{
    WNDCLASS wc;
    wc.style        = CS_OWNDC|CS_DBLCLKS; 
    wc.lpfnWndProc  = AfxWndProc;
    wc.cbClsExtra   = NULL;
    wc.cbWndExtra   = NULL;
    wc.hInstance    = AfxGetInstanceHandle(); 
    wc.hIcon        = NULL; 
    wc.hCursor      = (HICON) LoadImage(NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_DEFAULTCOLOR); 
    wc.hbrBackground= m_brushBack; 
    wc.lpszMenuName = NULL; 
    wc.lpszClassName= "SpikeDisplay";   

    if (!AfxRegisterClass( &wc )) 
        return FALSE;
    
    cs.lpszClass = "SpikeDisplay";
    
    return CWnd::PreCreateWindow(cs);
} // PreCreateWindow


int CDisplaySpike::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
    if (CWnd::OnCreate(lpCreateStruct) == -1)
        return -1;
    
    GetClientRect(&m_rectClient);
    m_nClientWidth = m_rectClient.Width();
    m_nClientHeight = m_rectClient.Height();

    // Get pointer to document
    CWnd *pWnd = GetParentFrame();
    m_pDoc = (CDocPowerNAP *)((CFrameWnd *)pWnd)->GetActiveDocument();
   
    for (int i = 1; i < UNITCOUNT; ++i)
    {
        HBITMAP hBmp;
        CCloneBitmap bmpClone;
        HCURSOR hCursor;
        hBmp = LoadBitmap(AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_CURSOR));

        if(hBmp != NULL)
        {
          bmpClone.Clone(hBmp);
          DeleteObject(hBmp);
          // change GRAY pixels to appropriate color.
          bmpClone.ChangeColor(IRGB(128, 128, 128), m_pDoc->m_icColorTable.dispunit[i]);
          // make icon, using WHITE color as transparent.
          hCursor = bmpClone.MakeCursor(IRGB(255, 255, 255));
        }

        m_hDrawingCursor[i] = hCursor;
    }

    return 0;
} // OnCreate


void CDisplaySpike::OnPaint() 
{
    CPaintDC dc(this); // device context for painting
    dc.SetBkColor (m_crBackColor);
    dc.FillRect(m_rectClient, &m_brushBack);

    // Draw the grid
    DrawGrid(dc);

    // Draw the waves
    DrawSpikes(dc);

    // Draw Centroid Waveform
//    DrawCtrWaveform(dc);

    // Draw the threshold if necessary
    if (m_pDoc->GetThresholding())
    {
        SwitchMouse(MSE_THRESHOLDING);
        // Update the threshold line if necessary
        m_nClientThresh = XfmWorldToScreenY(m_pDoc->GetThreshold(m_dwCurrEntity));
        DrawThresholdLine(dc);
    }
    else
    {
        SwitchMouse(MSE_REGULAR);
    }

    // And last, draw the labels
    SetLabels(dc);
}

// Author & Date:   Kirk Korver     05 Mar 2004
// Purpose: turn on/off the rejecting functions
// Inputs:
//  bOn - TRUE means make us "rejecting"; FALSE, not
void CDisplaySpike::SetRejecting(bool bOn)
{
    if (!bOn)
    {
        SwitchMouse(MSE_REGULAR);
    }
    else
    {
        m_nClientReject = 3;
        DrawRejectLine();
        SwitchMouse(MSE_REJECT);
    }
}


// Author & Date:   Kirk Korver     03 Mar 2004
// We are about to start animating, so erase the screen and only show this many waves
// while we animate.
// Inputs:
//  cbMaxSpikes - the maximum number of spikes to show at a time.
//  dTime - what time (in seconds) will animation begin?
void CDisplaySpike::AnimateBegin(UINT32 cbMaxSpikes, double dTime)
{
    CClientDC dc(this);
    AnimateClear(dc);   // clear the screen
    CalculateAllX();

    m_isAnimate.m_cnMaxSpikes = cbMaxSpikes;
    m_isAnimate.m_cnNumSpikes = 0;

    m_isAnimate.m_dwEntityID = m_pDoc->GetActiveEntity();
    
#pragma message ("CDisplaySpike::AnimateBegin only works with 1 file...")
    
    m_isAnimate.m_pcFile = &m_pDoc->m_icFileVector[0]->icFile;


    m_isAnimate.m_nLastVisibleIndex = 0;
    m_pDoc->GetIndexByTime(*m_isAnimate.m_pcFile, m_isAnimate.m_dwEntityID, dTime, ns_BEFORE, &m_isAnimate.m_nLastVisibleIndex);

    const Segments & rSeg = m_pDoc->GetActiveSegment();
    m_isAnimate.m_itSpike = rSeg.begin() + m_isAnimate.m_nLastVisibleIndex;
    m_isAnimate.m_itSpkEnd = rSeg.end();
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: Animate to this point in time
// Inputs:
//  dTime - do your animation until this point in time
void CDisplaySpike::AnimateToHere(double dTime)
{
    for (; m_isAnimate.m_itSpike != m_isAnimate.m_itSpkEnd; ++m_isAnimate.m_itSpike)
    {
        const DataSegment & rSeg = *m_isAnimate.m_itSpike;

        // is the time big enough? are we done?
        if (rSeg.GetTime() > dTime)
            return;

        // Is this one we would normally draw?
        DWORD dwUnitID = rSeg.GetUnitID();        // Get cluster ID
        if ((dwUnitID == m_enDrawUnit) || (m_enDrawUnit == UNIT_ALL_MASK))
        {
            CClientDC dc(this);

            // Is it time to "clear the background?"
            if (m_isAnimate.m_cnNumSpikes++ == m_isAnimate.m_cnMaxSpikes)
            {
                AnimateClear(dc);
                m_isAnimate.m_cnNumSpikes = 1;      // the spike I am about to draw
            }

            WAVEFORM aicWave;
            rSeg.GetWave(aicWave);
            
            DrawLine(dc, aicWave, *m_pDoc->GetBITUnitPen(dwUnitID));
        }
    }
}

// Author & Date:   Kirk Korver     03 Mar 2004
// purpose: redraw the background and get ready for waves to be added
void CDisplaySpike::AnimateClear(CDC & rcDC)
{
    rcDC.SetBkColor (m_crBackColor);

    rcDC.FillRect(m_rectClient, &m_brushBack);    // Erase the background
    DrawGrid(rcDC);                               // Draw the grid
}


// Author & Date:   Kirk Korver     26 Feb 2004
// Purpose: Erase and redraw the screen to only show these spikes (useful for animating)
// Inputs:
//  nSpkFirst - the index of the first waveform to display
//  nSpkLast  - 1 past the index of the last waveform to display
void CDisplaySpike::DrawTheseSpikes(UINT32 nSpkFirst, UINT32 nSpkLast)
{
    CClientDC dc(this); // device context for painting
    dc.SetBkColor (m_crBackColor);

    dc.FillRect(m_rectClient, &m_brushBack);    // Erase the background
    DrawGrid(dc);                               // Draw the grid
    DrawTheseSpikes(dc, nSpkFirst, nSpkLast);   // And the spikes
}


void CDisplaySpike::SetYAxis(CString strUnits)
{
    m_strYUnits = strUnits ;
    m_dYScaleFactor = m_nClientHeight / (m_dMaxY - m_dMinY);
        
    m_strMaxYLabel.Format("%4.1f %s", m_dMaxY, strUnits); 
    m_strMinYLabel.Format("%4.1f %s", m_dMinY, strUnits); 
} // SetYUnits


void CDisplaySpike::SetXAxis(double dMaxVal, double dMinVal, double dSampleRate, CString strUnits)
{
    m_strXUnits = strUnits ;
    m_dMaxX = dMaxVal;
    m_dMinX = dMinVal;

    m_dXScaleFactor = m_nClientWidth / (dMaxVal - dMinVal);

    m_strMaxXLabel.Format("%4.2f %s", 1000.* dMaxVal / dSampleRate , strUnits); 
} // SetXUnits


void CDisplaySpike::DrawGrid(CDC & rcDC)
{
    // Put the dashed pen in
    CPen * pcOldPen = rcDC.SelectObject(&m_penGrid);
    
    static const int NUM_OF_BOXES = 10;

    for (int i = 1; i < NUM_OF_BOXES; ++i)
    {
        // Draw  10 horizontal lines
        int nY = m_nClientHeight * i / NUM_OF_BOXES;
        rcDC.MoveTo(0, nY);
        rcDC.LineTo(m_nClientWidth, nY);

        // Draw 10 vertical lines
        int nX = m_nClientWidth * i / NUM_OF_BOXES;
        rcDC.MoveTo(nX, 0);
        rcDC.LineTo(nX, m_nClientHeight);
    }

    // Put the old pen back in
    rcDC.SelectObject(pcOldPen);
} // DrawGrid()


void CDisplaySpike::OnSize(UINT nType, int cx, int cy) 
{
    CWnd::OnSize(nType, cx, cy);    

    // NOTE: OnSize automatically gets called during the setup of the control
  
    GetClientRect(m_rectClient);

    // Set some member variables to avoid multiple function calls
    m_nClientHeight = m_rectClient.Height();
    m_nClientWidth  = m_rectClient.Width();
    
    // If we are thresholding, then we need to re-calculate its value
    if (IsWindowVisible())
    {
        m_nClientThresh = XfmWorldToScreenY(m_pDoc->GetThreshold(m_dwCurrEntity));
    }
} 

// Draw ALL of the spikes
void CDisplaySpike::DrawSpikes(CDC & rcDC)
{
    // Check if data file exists
    if ( (m_pDoc->m_icFileVector.empty()) || (!m_pDoc->IsActiveSegment()) )
        return;

    // Set current entity
    m_dwCurrEntity = m_pDoc->GetActiveEntity();

    FileInfo & isInfo = *m_pDoc->m_icFileVector[0];

    // Getting info from first selected data file
    ns_SEGMENTINFO isSegInfo;
    m_pDoc->GetSegmentInfo(isInfo.icFile, m_dwCurrEntity, isSegInfo);

    // Set horizontal axis, since we have ns_SEGMENTINFO available here 
    SetXAxis(m_nPtCount, 0, isSegInfo.dSampleRate, "msec");   
    SetYAxis(isSegInfo.szUnits);

    UINT32 nLast = m_pDoc->GetActiveSegment().size();
    DrawTheseSpikes(rcDC, 0, nLast);
}


// Author & Date:   Kirk Korver     26 Feb 2004
// Purpose: Draw SOME spikes onto the display
// Inputs:
//  rcDC - the DC to draw onto
//  nSpkFirst - the index (0 based) of the 1st Spike
//  nSpkLast - 1 past the index (0 based) of the last spike to draw
void CDisplaySpike::DrawTheseSpikes(CDC & rcDC, UINT32 nSpkFirst, UINT32 nSpkLast)
{
    // Check if data file exists
    if ( (m_pDoc->m_icFileVector.empty()) || (!m_pDoc->IsActiveSegment()) )
        return;

    ASSERT(nSpkFirst <= nSpkLast);
  
    const Segments & rSeg = m_pDoc->GetActiveSegment();

    ASSERT(nSpkLast <= rSeg.size());
    ASSERT(nSpkFirst <= nSpkLast);

    CalculateAllX();

    // Draw the waveform
    SEGMENTLIST::const_iterator it = rSeg.begin() + nSpkFirst;
    SEGMENTLIST::const_iterator itEnd = rSeg.begin() + nSpkLast; 
    for (; it != itEnd; ++it)
    {
        DrawThisSpike(rcDC, *it);
    }
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: Add this spike to the spike display if the correct unit is
//  currently selected
// Inputs:
//  rcDC - the Device Context to draw onto
//  rSpike - the spike we want to draw
// Outputs:
//  TRUE if the spike was actually drawn; FALSE, otherwise
bool CDisplaySpike::DrawThisSpike(CDC & rcDC, const DataSegment & rSpike)
{
    // Get cluster ID
    DWORD dwUnitID = rSpike.GetUnitID();
    
    if ((dwUnitID == m_enDrawUnit) || (m_enDrawUnit == UNIT_ALL_MASK))
    {
        WAVEFORM aicWave;
        rSpike.GetWave(aicWave);
        
        DrawLine(rcDC, aicWave, *m_pDoc->GetBITUnitPen(dwUnitID));
        return true;
    }
    return false;
}



void CDisplaySpike::DrawCtrWaveform(CDC & rcDC)
{
    // Check if centroid waveform exists
    if (m_pDoc->m_isSortInfo.m_icCtrWfList.empty())
        return;

    // Draw the waveform
    for (CTRWAVEFORMLIST::iterator it = m_pDoc->m_isSortInfo.m_icCtrWfList.begin(); 
         it != m_pDoc->m_isSortInfo.m_icCtrWfList.end(); ++it)
    {
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        DrawLine(rcDC, aicWave, m_penRedThick);
    } // Next waveform
} // DrawCtrWaveform()


void CDisplaySpike::DrawThreshold()
{
    CClientDC dc(this);

    DrawThresholdLine(dc);
} 


void CDisplaySpike::DrawThresholdLine(CDC & pDC)
{
    int x1 = 0;
    int x2 = (int) ((double) m_nPtCount * m_dXScaleFactor + 0.5);

    pDC.SelectObject(m_penRedThick);

    int nOldMode = pDC.SetROP2(R2_XORPEN);// only works on pens

    pDC.MoveTo(x1, m_nClientThresh);
    pDC.LineTo(x2, m_nClientThresh);

    pDC.SetROP2(nOldMode);
} // DrawThresholdLine


void CDisplaySpike::DrawRejectLine()
{
    CClientDC dc(this);
    DrawRejectLine(dc);
}

void CDisplaySpike::DrawRejectLine(CDC & rcDC)
{
    int x1 = 0;
    int x2 = (int) ((double) m_nPtCount * m_dXScaleFactor + 0.5);

    HGDIOBJ hOldPen = rcDC.SelectObject(m_penBlueThick);

    int nOldMode = rcDC.SetROP2(R2_XORPEN);// only works on pens

    rcDC.MoveTo(x1, m_nClientReject);
    rcDC.LineTo(x2, m_nClientReject);

    rcDC.SetROP2(nOldMode);
    rcDC.SelectObject(hOldPen);
}



void CDisplaySpike::SetLabels(CDC & rcDC)
{
    // Label axis ranges
    // Vertical: max and min (micro-volts)
    // Horizontal:  Max time span (sec)

    // Set font for text
    CFont font;
    CFont* pOldFont;
    const int nFontSize_Default = 90;
    
    font.CreatePointFont(nFontSize_Default,_T("MS San Serif"));
    pOldFont = rcDC.SelectObject(&font);
    rcDC.SetTextColor(WHITE);

    // Label X axis - time 
    CSize TextSize;
    TextSize = rcDC.GetTextExtent(m_strMaxXLabel);
    rcDC.DrawText(m_strMaxXLabel, -1, CRect(m_nClientWidth - TextSize.cx, m_nClientHeight-TextSize.cy,
                m_nClientWidth, m_nClientHeight), DT_SINGLELINE|DT_LEFT|DT_NOCLIP);
    
    // Label Y axis - voltage 
    // Upper Y value
    TextSize = rcDC.GetTextExtent(m_strMaxYLabel);
    rcDC.DrawText(m_strMaxYLabel, -1, CRect(0, 0, TextSize.cx, TextSize.cy),
                        DT_SINGLELINE|DT_LEFT|DT_NOCLIP);
    
    // Lower Y value
    TextSize = rcDC.GetTextExtent(m_strMinYLabel);
    rcDC.DrawText(m_strMinYLabel, -1, CRect(0, m_nClientHeight - TextSize.cy, TextSize.cx, m_nClientHeight),
                        DT_SINGLELINE|DT_LEFT|DT_NOCLIP);

    // Get old font
    rcDC.SelectObject(pOldFont);
} // DrawLabels()


void CDisplaySpike::DrawSelSpike(INT32 nSelWF)
{
    CClientDC dc(this);
    
    ErasePrevSelSpike(m_dwPrevSelWF);

    WAVEFORM aicWave;
    m_pDoc->GetActiveSegment()[nSelWF].GetWave(aicWave);

    DrawLine(dc, aicWave, m_penRedThin);

    // Save Selected WF index
    m_dwPrevSelWF = nSelWF;
}


void CDisplaySpike::ErasePrevSelSpike(INT32 nWFIndex)
{
    CClientDC dc(this);
    const Segments & rSeg = m_pDoc->GetActiveSegment();
  
    //Convert from Neuroshare units to our units
    DWORD dwUnitID = rSeg[nWFIndex].GetUnitID();     
    
    CPen *pOldPen = (CPen *) dc.SelectObject(m_pDoc->GetBITUnitPen(dwUnitID));

    WAVEFORM aicWave;
    rSeg[nWFIndex].GetWave(aicWave);

    DrawLine(dc, aicWave, *m_pDoc->GetBITUnitPen(dwUnitID));

    // Restore  previous drawing mode    
    dc.SelectObject(pOldPen);
}


// Author & Date:   Angela Wang     10 June 2003
// Purpose: Highlight selected waveform
// Inputs:  Index into SEGMENTLIST of selection
void CDisplaySpike::HilightSpike(INT32 nWFIndex)
{
    CClientDC dc(this);
    
    UnHilightSpike(m_dwPrevSelWF);    

    WAVEFORM aicWave;
    m_pDoc->GetActiveSegment()[nWFIndex].GetWave(aicWave);

    DrawLine(dc, aicWave, m_penRedThin);

    m_dwPrevSelWF = nWFIndex;
}


// Author & Date:   Angela Wang     10 June 2003
// Purpose: Return previously selected waveform to original state
// Inputs:  Index into SEGMENTLIST of previous selection

void CDisplaySpike::UnHilightSpike(INT32 nWFIndex)
{
    CClientDC dc(this);
    const Segments & rSeg = m_pDoc->GetActiveSegment();

    //Convert from Neuroshare units to our units
    DWORD dwUnitID = rSeg[nWFIndex].GetUnitID();     
  
    CPen *pOldPen = (CPen *) dc.SelectObject(m_pDoc->GetBITUnitPen(dwUnitID));

    WAVEFORM aicWave;
    rSeg[nWFIndex].GetWave(aicWave);

    DrawLine(dc, aicWave, *m_pDoc->GetBITUnitPen(dwUnitID));

    // Restore  previous drawing mode    
    dc.SelectObject(pOldPen);
} // UnHilightSpike


void CDisplaySpike::OnLButtonDown(UINT nFlags, CPoint point) 
{
    m_pcActiveMouse->OnLButtonDown(nFlags, point);
	CWnd::OnLButtonDown(nFlags, point);
}

void CDisplaySpike::OnLButtonUp(UINT nFlags, CPoint point) 
{
    m_pcActiveMouse->OnLButtonUp(nFlags, point);
    CWnd::OnLButtonUp(nFlags, point);
}

void CDisplaySpike::OnMouseMove(UINT nFlags, CPoint point) 
{
    m_pcActiveMouse->OnMouseMove(nFlags, point);
	CWnd::OnMouseMove(nFlags, point);
}


void CDisplaySpike::SetDrawUnit(UnitMasks enDrawUnit)
{
    m_enDrawUnit = enDrawUnit;

    // Redraw this display
    this->Invalidate();
} // SetDrawUnit
 

// Set min and max waveform values
void CDisplaySpike::SetMinMaxWfVal(double dMaxVal)
{
    m_dMaxY = dMaxVal;
    m_dMinY = -dMaxVal;
} // SetMinMaxWfVal


void CDisplaySpike::SetCurrEntity(uint32 dwEntity)
{
    m_dwCurrEntity = dwEntity;

    // Set initial threshold value and
    // Calculate client threshold for drawing
    m_nClientThresh = XfmWorldToScreenY(m_pDoc->GetThreshold(m_dwCurrEntity));
    m_nPtCount = m_pDoc->GetNumOfPointsPerWave();
    m_vPoints.resize(m_nPtCount);
}

// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: calculate all of the 'x' coordinates for the drawing vector
void CDisplaySpike::CalculateAllX()
{
    int nIndex = 0;
    for (VCTPOINTS::iterator it = m_vPoints.begin(); it != m_vPoints.end(); ++it, ++nIndex)
    {
        (*it).x = (int) ((double) nIndex * m_dXScaleFactor + 0.5);  // horizontal pixels
    }
}


// Purpose: draw a single waveform on the DC
// Inputs:
//  rcDC - the device context to draw onto
//  rcWave - the waveform to draw
//  rcPen - the pen to use
//     m_vPoints. This vector is used for speed reasons
void CDisplaySpike::DrawLine(CDC & rcDC, WAVEFORM & rcWave, CPen & rcPen)
{
    // Select red pen color
    rcDC.SelectObject(rcPen);

    ASSERT(m_nPtCount == rcWave.size());
    for (UINT32 nPt = 0; nPt < m_nPtCount; ++nPt)
    {
        m_vPoints[nPt].y = (int) (((double) m_nClientHeight / 2) - (rcWave[nPt] * m_dYScaleFactor)); 
    }
    rcDC.Polyline(&m_vPoints[0], m_nPtCount);  //plot points
}

void CDisplaySpike::SetThresholdFromPoint(CPoint point)
{
    // Update the threshold in the document
    // Convert client position to threshold value
    double dThreshVal = XfmScreenToWorldY(point.y);

    m_pDoc->SetThreshold(m_dwCurrEntity, dThreshVal);
    
    m_nClientThresh = point.y;

    // Set Threshold value in toolbar
    DisplayThresholdInToolbar(dThreshVal);
}

// Author & Date:   Kirk Korver     17 Oct 2003
// Purpose: convert from the "screen" threshold to the "real" threshold
double CDisplaySpike::XfmScreenToWorldY(int nValue) const
{
    // Update the threshold in the document
    // Convert client position to threshold value
    double dThreshVal = m_pDoc->m_dMaxWfVal * (1 - (2.0 * nValue / m_nClientHeight));

    return dThreshVal;
}

// Author & Date:   Kirk Korver     17 Oct 2003
// Purpose: convert from the "real" threshold to the "screen" threshold
int CDisplaySpike::XfmWorldToScreenY(double dValue) const
{
    // Calculate threshold from the client location
    int retVal = (int)(((double)m_nClientHeight / 2.0) - (dValue * m_dYScaleFactor));
    return retVal;
}


// Author & Date:   Kirk Korver     17 Oct 2003
// Purpose: move the threshld bar to this new location
// Inputs:
//  ptNew - the new location
//  rcDC - the DC to draw onto
void CDisplaySpike::MoveThresholdOnScreen(CPoint ptNew)
{
    DrawThreshold();                // Erase the old
    m_nClientThresh = ptNew.y;
    DrawThreshold();                // Now draw it in it's new location
}

void CDisplaySpike::MoveRejectOnScreen(CPoint ptNew)
{
    DrawRejectLine();                   // Erase the old
    m_nClientReject = ptNew.y;      // Save location for next call
    DrawRejectLine();                   // Now draw the new
}

void CDisplaySpike::SwitchMouse(MouseType enMouse)
{
    switch (enMouse)
    {
        case MSE_REGULAR:
//            TRACE("Mouse is now regular\n");
            m_pcActiveMouse = &m_icMouseRegular;
            break;

        case MSE_THRESHOLDING:
//            TRACE("Mouse is now thresholding\n");
            m_pcActiveMouse = &m_icMouseThreshold;
            break;

        case MSE_REJECT:
//            TRACE("Mouse is now Reject\n");
            m_pcActiveMouse = &m_icMouseReject;
            break;
    }
}

//////////////////////////////////////////////////////////////////////////////


void CDisplaySpike::MouseThreshold::OnLButtonUp(UINT nFlags, CPoint point)
{
//    TRACE("Threshold mouse up\n");

    // Release the mouse capture established at
    // the beginning of the mouse drag.
    ::ReleaseCapture();

    // End thresolding motion
    m_pParent->MoveThresholdOnScreen(point);
    m_pParent->SetThresholdFromPoint(point);   // Set the new threshold

    // This action invalidates all wave forms
    m_pParent->m_pDoc->RebuildSegListEntryAndUpdateViews(m_pParent->m_dwCurrEntity, HINT_USER_NEWDATA);

    CDSMState::OnLButtonUp(nFlags, point);
}

void CDisplaySpike::MouseThreshold::OnLButtonDown(UINT nFlags, CPoint point)
{
//    TRACE("Threshold mouse down\n");

    // Capture the mouse until button up.
    m_pParent->SetCapture();

    // Move the actual threshold line to this position
    m_pParent->MoveThresholdOnScreen(point);

    CDSMState::OnLButtonDown(nFlags, point);
}


void CDisplaySpike::MouseThreshold::OnDragging(UINT nFlags, CPoint point)
{
//    TRACE("Threshold mouse dragging\n");

    m_pParent->MoveThresholdOnScreen(point);

    double dThresh = m_pParent->XfmScreenToWorldY(point.y);
    m_pParent->DisplayThresholdInToolbar(dThresh);
}

// Author & Date:   Kirk Korver     05 Mar 2004
// Purpose: notify our parent that the "reject" value has changed
// Inputs:
//  dRejectVal - the new reject value
void CDisplaySpike::SendNotifyReject(double dRejectVal)
{
    m_isNotifyReject.dRejectValue = dRejectVal;

    m_isNotifyReject.hdr.code = NF_SPK_NEW_REJECT;
    m_isNotifyReject.hdr.hwndFrom = m_hWnd;
    m_isNotifyReject.hdr.idFrom = GetDlgCtrlID();

    GetParent()->PostMessage(WM_NOTIFY, m_isNotifyReject.hdr.idFrom, LPARAM(&m_isNotifyReject));
}

void CDisplaySpike::MouseReject::OnLButtonDown(UINT nFlags, CPoint point)
{
    m_pParent->SetCapture();                // send mouse messages here until mouse is up
    m_pParent->MoveRejectOnScreen(point);
    CDSMState::OnLButtonDown(nFlags, point);
}

void CDisplaySpike::MouseReject::OnLButtonUp(UINT nFlags, CPoint point)
{
    ::ReleaseCapture();     // No longer need the mouse
    double dVal = m_pParent->XfmScreenToWorldY(point.y);
    m_pParent->SendNotifyReject(dVal);
    CDSMState::OnLButtonUp(nFlags, point);
}

void CDisplaySpike::MouseReject::OnDragging(UINT nFlags, CPoint point)
{
    m_pParent->MoveRejectOnScreen(point);
}

void CDisplaySpike::DisplayThresholdInToolbar(double dRealThreshVal)
{
    CMainFrameWaveforms * pFrame = static_cast<CMainFrameWaveforms *>(GetParentFrame());
    CString szTemp;
    szTemp.Format("%3.0f", dRealThreshVal);
    pFrame->m_icLblThresh.SetWindowText(szTemp);
}

