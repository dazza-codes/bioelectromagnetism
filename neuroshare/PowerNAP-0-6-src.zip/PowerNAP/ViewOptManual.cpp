///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewOptManual.cpp $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/24/03 10:43a $
//
// $History: ViewOptManual.cpp $
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:43a
// Updated in $/Neuroshare/PowerNAP
// Overhaul of the PCA display
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 10/16/03   Time: 1:23p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 6  *****************
// User: Awang        Date: 8/28/03    Time: 11:32a
// Updated in $/Neuroshare/nsClassifier
// Removed useless menu from appearing.
// 
// *****************  Version 5  *****************
// User: Awang        Date: 8/26/03    Time: 2:21p
// Updated in $/Neuroshare/nsClassifier
// Cleaned up NOISEUNIT_OUT selection and removal
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/25/03    Time: 2:47p
// Updated in $/Neuroshare/nsClassifier
// Check if ViewPCA is already destroyed.
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/25/03    Time: 1:44p
// Updated in $/Neuroshare/nsClassifier
// Renamved MainFramePCA
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "ViewPCA.h"
#include "ViewOptManual.h"
#include "MainFramePCA.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewOptManual

IMPLEMENT_DYNCREATE(CViewOptManual, CFormView)

CViewOptManual::CViewOptManual()
	: CFormView(CViewOptManual::IDD)
{
	//{{AFX_DATA_INIT(CViewOptManual)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CViewOptManual::~CViewOptManual()
{
    //Set to default display mode

    m_nSelUnit = -1; // no unit selected for drawing polygon

    // If ViewPCA is still there, set default display mode
    CViewPCA *pPCAView;
    if ((CViewPCA *)pPCAView = GetViewPCAPtr())
    {
        m_pViewPCA->SetDisplayMode(DEFAULT, -1);

        // Set view pointer in mainframe to NULL;
        ((CMainFramePCA *)m_pViewPCA->GetParentFrame())->m_pViewOptManual = NULL;
        ((CMainFramePCA *)pPCAView->GetParentFrame())->ReleaseSortBtn();
    }


}

void CViewOptManual::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewOptManual)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewOptManual, CFormView)
	//{{AFX_MSG_MAP(CViewOptManual)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_MAN_RADIO1, OnManUnit1)
	ON_BN_CLICKED(IDC_MAN_RADIO2, OnManUnit2)
	ON_BN_CLICKED(IDC_MAN_RADIO3, OnManUnit3)
	ON_BN_CLICKED(IDC_MAN_RADIO4, OnManUnit4)
	ON_BN_CLICKED(IDC_MAN_RADIO5, OnManUnit5)
	ON_BN_CLICKED(IDC_MAN_RADIO6, OnManNoiseIn)
	ON_BN_CLICKED(IDC_MAN_RADIO7, OnManNoiseOut)
	ON_BN_CLICKED(IDC_MAN_REMOVE, OnRemove)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewOptManual diagnostics

#ifdef _DEBUG
void CViewOptManual::AssertValid() const
{
	CFormView::AssertValid();
}

void CViewOptManual::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}


CDocPowerNAP* CViewOptManual::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}





#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CViewOptManual message handlers

int CViewOptManual::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    // Set the title
    CMainFrame * pFrame = static_cast<CMainFrame *>(GetParentFrame());
    pFrame->SetTitle("Manual Cluster Cutting Options");
	
	
	return 0;
}


void CViewOptManual::OnInitialUpdate() 
{

    
    CFormView::OnInitialUpdate();
    


    
    // Set the title
    GetParentFrame()->SetTitle("Manual Cluster Cutting Options");
    GetParentFrame()->ModifyStyleEx(WS_EX_CLIENTEDGE, WS_EX_TOOLWINDOW, 0);
    
    // Size the window to be smaller
    // Hide the menu of the window.
    CMenu * pMenu = GetParentFrame()->GetMenu();
    pMenu->RemoveMenu(0, MF_BYPOSITION);
    pMenu->RemoveMenu(0, MF_BYPOSITION);
    pMenu->RemoveMenu(0, MF_BYPOSITION);
	
    // Size the window to match that of the form in the resource editor
    GetParentFrame()->RecalcLayout();
    ResizeParentToFit(false);
    ResizeParentToFit();
    
    // Get pointer to CViewPCA
    m_pViewPCA = GetViewPCAPtr();

    // Set unit buttons
    for (int nBtn = 0; nBtn < NOISE_OUT; ++nBtn)
    {
        CButton * pBtn = (CButton *)GetDlgItem( IDC_MAN_RADIO1 + nBtn);
        pBtn->SetIcon(AfxGetApp()->LoadIcon(IDI_ICON1 + nBtn));
    }
}


void CViewOptManual::OnManUnit1() 
{
    // Unit 1 selected
    m_nSelUnit = 1;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
}

void CViewOptManual::OnManUnit2() 
{
    // Unit 2 selected
    m_nSelUnit = 2;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
}

void CViewOptManual::OnManUnit3() 
{
    // Unit 3 selected
    m_nSelUnit = 3;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
}

void CViewOptManual::OnManUnit4() 
{
    // Unit 4 selected
    m_nSelUnit = 4;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
}

void CViewOptManual::OnManUnit5() 
{
    // Unit 5 selected
    m_nSelUnit = 5;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
}

void CViewOptManual::OnManNoiseIn() 
{
    // Noise inside cluster selected
    m_nSelUnit = NOISE;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
}

void CViewOptManual::OnManNoiseOut() 
{
    // Noise outside cluster selected
    m_nSelUnit = NOISE_OUT;

    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
}




void CViewOptManual::OnRemove() 
{
    // Remove selected unit	
    // Recolor the points of the currently selected cluster
    // to original unit definition
    if (m_nSelUnit )
    {
        
        if (m_nSelUnit == NOISE_OUT)
        {        
            // Reset current cluster in PCDATALIST to original file UNITID
            m_pViewPCA->SetOrigUnitDef(NOISE);   
        
            // Clear the old cluster information
            m_pViewPCA->m_icDisplayPC1.ClearClusters(NOISE_OUT);
        }
        else
        {
            // Reset current cluster in PCDATALIST to original file UNITID
            m_pViewPCA->SetOrigUnitDef(m_nSelUnit);   
        
            // Clear the old cluster information
            m_pViewPCA->m_icDisplayPC1.ClearClusters(m_nSelUnit);
        }


        // Clear currently selected cluster
        m_nSelUnit = 0;
        
        // Update views
        GetDocument()->UpdateAllViews(NULL);
    }		
}


// Get a pointer to ViewPCA
CViewPCA * CViewOptManual::GetViewPCAPtr()
{
    CViewPCA *pPCAView;

    // Default value
    pPCAView = NULL;

    POSITION pos = GetDocument()->GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetDocument()->GetNextView(pos);
        if (pView->IsKindOf(RUNTIME_CLASS(CViewPCA)))
        {
            pPCAView = (CViewPCA *) pView;
        }

    }

    return pPCAView;

}
