///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2004  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Kirk Korver
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  kkorver@cyberkineticsinc.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DlgPlayback.cpp $
//
// $Date: 3/03/04 4:50p $
//
// $History: DlgPlayback.cpp $
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:50p
// Updated in $/Neuroshare/PowerNAP
// Updated the dialog to have only 2 sliders
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:50p
// Created in $/Neuroshare/PowerNAP
// Added playback capabilities
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "powernap.h"
#include "ns_common.h"
#include "DlgPlayback.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPlayback dialog

static const double g_dANIMATE_TICK_TIME = double(CDlgPlayback::TMR_ANIMATE_TIME) / 1000.0;

// Inputs:
//  pDoc - pointer to the document class
CDlgPlayback::CDlgPlayback(CDocPowerNAP* pDoc) :
    m_pDoc(pDoc),
    m_pcPlayBack(&pDoc->m_icPlayBack)
{
}


void CDlgPlayback::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPlayback)
	DDX_Control(pDX, IDC_PB_BTN_PAUSE, m_btnPause);
	DDX_Control(pDX, IDC_PB_BTN_PLAY, m_btnPlay);
	DDX_Control(pDX, IDC_PB_SLD_SPEED, m_sldSpeed);
	DDX_Control(pDX, IDC_PB_SLD_POSITION, m_sldPosition);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPlayback, CDialog)
	//{{AFX_MSG_MAP(CDlgPlayback)
	ON_BN_CLICKED(IDC_PB_BTN_PLAY, OnBtnPlay)
	ON_BN_CLICKED(IDC_PB_BTN_PAUSE, OnBtnPause)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_PB_SLD_POSITION, OnSldPositionReleasedcapture)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_PB_SLD_SPEED, OnSldSpeedReleasedcapture)
	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_EN_CHANGE(IDC_PB_EDT_WAVEFORM_COUNT, OnChangeEdtWaveformCount)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPlayback message handlers

void CDlgPlayback::OnBtnPlay() 
{
    m_btnPlay.EnableWindow(false);
    m_btnPause.EnableWindow(true);
    m_pcPlayBack->m_enMode = CDocPowerNAP::PlayBack::PB_RUNNING;

    SetTimer(TIMER_ANIMATE, TMR_ANIMATE_TIME, NULL);
}

void CDlgPlayback::OnBtnPause() 
{
    m_btnPlay.EnableWindow(true);
    m_btnPause.EnableWindow(false);
    m_pcPlayBack->m_enMode = CDocPowerNAP::PlayBack::PB_PAUSED;


    KillTimer(TIMER_ANIMATE);
}


BOOL CDlgPlayback::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    // Set the # of stops for the sliders
    m_sldPosition.SetRange(0, MAX_SLD_POS);
    m_sldSpeed.SetRange(MIN_SLD_SPEED, MAX_SLD_SPEED);

    m_dTimeMax = m_pDoc->GetMaxTime();
    
    // First and foremost, we need to set the full width/time to show
    m_pcPlayBack->m_dTime = 0;
    m_pcPlayBack->m_bPlayBackActive = true;
    m_pcPlayBack->m_enMode = CDocPowerNAP::PlayBack::PB_PAUSED;
    m_dTimeStep = g_dANIMATE_TICK_TIME;

    UpdateSliders();
    UpdateEditBoxes();
    PostChange();
    m_btnPause.EnableWindow(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// This is here to prevent memory leaks
void CDlgPlayback::PostNcDestroy() 
{
	CDialog::PostNcDestroy();
    delete this;	
}

// Author & Date:   Kirk Korver     25 Feb 2004
// Purpose: update the edit boxes on the screen with our current values
void CDlgPlayback::UpdateEditBoxes()
{
    char szTemp[80];        // more than long enough for a float
    char szFormat[] = "%.2f";

    sprintf(szTemp, szFormat, m_pcPlayBack->m_dTime);
    SetDlgItemText(IDC_PB_EDT_TIMEOFFSET, szTemp);

    sprintf(szTemp, szFormat, m_dTimeStep / g_dANIMATE_TICK_TIME);
    SetDlgItemText(IDC_PB_EDT_SPEED, szTemp);

    SetDlgItemInt(IDC_PB_EDT_WAVEFORM_COUNT, m_pcPlayBack->m_nWaveformCount);
}

// Author & Date:   Kirk Korver     25 Feb 2004
// Purpose: update the sliders to match the current variables
void CDlgPlayback::UpdateSliders()
{
    int nPosPos = m_pcPlayBack->m_dTime * MAX_SLD_POS / m_dTimeMax;
    m_sldPosition.SetPos(nPosPos);

    double dRatio = m_dTimeStep / g_dANIMATE_TICK_TIME;
    int nPosSpeed = dRatio * UNITY_SLD_SPEED;
    m_sldSpeed.SetPos(nPosSpeed);
}


void CDlgPlayback::OnSldPositionReleasedcapture(NMHDR* pNMHDR, LRESULT* pResult) 
{
    int nPos = m_sldPosition.GetPos();
    m_pcPlayBack->m_dTime = nPos * m_dTimeMax  / MAX_SLD_POS;
    UpdateEditBoxes();
    PostChange();
	*pResult = 0;
}

void CDlgPlayback::OnSldSpeedReleasedcapture(NMHDR* pNMHDR, LRESULT* pResult) 
{
    double dRatio = double(m_sldSpeed.GetPos()) / UNITY_SLD_SPEED;
    m_dTimeStep = g_dANIMATE_TICK_TIME * dRatio;
    UpdateEditBoxes();
	*pResult = 0;
}


void CDlgPlayback::OnTimer(UINT nIDEvent) 
{
    if (nIDEvent == TIMER_ANIMATE)
    {
        double dNewTime = m_pcPlayBack->m_dTime + m_dTimeStep;
        if (dNewTime > m_dTimeMax)
        {
            dNewTime = m_dTimeMax;
            OnBtnPause();
        }
        m_pcPlayBack->m_dTime = dNewTime;

        UpdateSliders();
        UpdateEditBoxes();
        PostChange();
    }
	
	CDialog::OnTimer(nIDEvent);
}

void CDlgPlayback::PostChange()
{
    m_pDoc->UpdateAllViews(NULL, HINT_USER_ANIMATING);
}


// this is here because we want to ensure that a non-modal dialog
// box is actually deleted
void CDlgPlayback::OnClose() 
{
    m_pcPlayBack->m_bPlayBackActive = false;
    PostChange();
	CDialog::OnClose();
    DestroyWindow();
}

void CDlgPlayback::OnChangeEdtWaveformCount() 
{
    m_pcPlayBack->m_nWaveformCount = GetDlgItemInt(IDC_PB_EDT_WAVEFORM_COUNT, NULL, false);
    PostChange();
}
