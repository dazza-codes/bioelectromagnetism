///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorAlgorithms.h $
//
// Description   : interface for the VisitorAlgorithms classes.
//
// Authors       : Kirk Korver
//
// $Date: 3/09/04 2:42p $
//
// $History: VisitorAlgorithms.h $
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:42p
// Updated in $/Neuroshare/PowerNAP
// Added VisitorRejectCheck
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 2/09/04    Time: 11:43a
// Updated in $/Neuroshare/PowerNAP
// Changed variable names.
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:06p
// Updated in $/Neuroshare/nsClassifier
// VisitorThresholdCheck() now saves the entity it is looking for
// 
// *****************  Version 3  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 2  *****************
// User: Almut        Date: 4/09/03    Time: 5:20p
// Updated in $/Neuroshare/nsClassifier
// Added alignment and truncation of waveforms.
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 4/01/03    Time: 1:52p
// Created in $/Neuroshare/nsClassifier
// This defines all of the implementations of the algorithms used by the
// visitors
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef VISITORALGORITHMS_H_INCLUDED
#define VISITORALGORITHMS_H_INCLUDED


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Visitor.h"


class CDocPowerNAP;

class VisitorThresholdCheck :
    public BaseVisitor,          // required
    public Visitor<CDocPowerNAP, bool>
{
public:
    VisitorThresholdCheck(DWORD dwEntityID) : m_dwEntityID(dwEntityID) {};
    bool Visit(CDocPowerNAP & data);

private:
    DWORD m_dwEntityID;
};

// Used to remove segments that exceed the level
class VisitorRejectCheck :
    public BaseVisitor,          // required
    public Visitor<CDocPowerNAP, bool>
{
public:
    VisitorRejectCheck(DWORD dwEntityID, double dValue) : 
      m_dwEntityID(dwEntityID), m_dRejectVal(dValue) {};

    bool Visit(CDocPowerNAP & rDoc);

private:
    DWORD m_dwEntityID;
    double m_dRejectVal;
};

class VisitorClipCheck :
    public BaseVisitor,          // required
    public Visitor<CDocPowerNAP, bool>
{
public:
    bool Visit(CDocPowerNAP & data);
};

class VisitorAlignCheck :
    public BaseVisitor,          // required
    public Visitor<CDocPowerNAP, bool>
{
public:
    bool Visit(CDocPowerNAP & data);

private:
    bool Truncate(CDocPowerNAP & data, int nMaxShiftLeft, int nMaxShiftRight);
};


#endif // include guard
