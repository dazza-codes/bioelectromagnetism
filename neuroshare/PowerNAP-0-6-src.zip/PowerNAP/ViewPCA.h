///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewPCA.h $
//
// Description   :  
//
// Authors       : Angela Wang
//
// $Date: 2/19/04 5:26p $
//
// $History: ViewPCA.h $
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 2/19/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// PCA now uses floating point math for the conversion. The result is that
// BIG and small numbers will now be displayed properly
// 
// *****************  Version 21  *****************
// User: Abranner     Date: 10/31/03   Time: 6:07p
// Updated in $/Neuroshare/PowerNAP
// Fixed options property sheet.
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:43a
// Updated in $/Neuroshare/PowerNAP
// Overhaul of the PCA display
// 
// *****************  Version 19  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 17  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 9/02/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////


#ifndef VIEWPCA_H_INCLUDED
#define VIEWPCA_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "DisplayPCProj.h"
#include "MainFramePCA.h"


#include <vector>

/////////////////////////////////////////////////////////////////////////////
// Global data
typedef std::vector<CPoint> POINTVECTOR;
typedef std::vector<int> INTVECTOR;

typedef std::vector<double *> CENTROIDVECTOR;
typedef std::vector<double **> COVVECTOR; 


enum tagDrawMode 
{
    DEFAULT = 0,    
    SELECTMODE = 1,
    DRAWMODE,
    CLUSTERCUTTOOLS
};


/////////////////////////////////////////////////////////////////////////////
// CViewPCA form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


class CMainFrame;
class CToolBarViewPCA;

class CViewPCA : public CFormView
{
protected:
	CViewPCA();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewPCA)

// Form Data
public:
	//{{AFX_DATA(CViewPCA)
	enum { IDD = IDD_VIEWPCA_DIALOG };
	//}}AFX_DATA

    UINT32 m_nSortMode;
    double **m_apdMyWaves;
    double ** m_apdCtr;

    // the graphical window classes
    CDisplayPCProj		m_wndPCA;

    int m_nWFCount;
    int m_nPtCount;
    
    int m_nSortMethod;
    CMainFramePCA       * m_pMainFrame;
// Attributes
public:
    CStatusBar StatusBar;

// Operations
public:
	void SetSortMethod(int nMethod);
	void SetAxis(int nXAxis, int nYAxis);
	void CreatePCDataArray(void);
	void CleanPCDataPoints(void);
	void SetDisplayMode(const UINT32 nMode, const INT32 lClstr);
    
    void SetOrigUnitDef(const INT32 lSearchCluster);

    void LoadPCClientPoints(double **pPCData, const uint32 dwPtCount);
    void LoadCtr(void);
    void ClearCtr(void);

    CDocPowerNAP*  GetDocument(void);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewPCA)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);

	public:
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
protected:
	double FindMaxValue(double **pPCData);
	void ShowOptSpkSort(int nView);
	int m_nXAxis;
	int m_nYAxis;

    INT32 m_lCurrCluster;

    double m_dMin[3];
    double m_dMax[3];
    double m_dScale[3];

	virtual ~CViewPCA();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
    
    //////// Manually added message map functions
    afx_msg void UpdatePCViews(WPARAM wParam, LPARAM lParam);
    afx_msg void OnUserUnSelectWF(WPARAM wParam, LPARAM lParam);
    afx_msg void OnUserSelectWF(WPARAM wParam, LPARAM lParam);
    
    // Generated message map functions

	//{{AFX_MSG(CViewPCA)
	afx_msg void OnSortingOptions();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
