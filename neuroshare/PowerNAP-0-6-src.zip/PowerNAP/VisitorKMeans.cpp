///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorKMeans.cpp $
//
// Description   : implementation of the K Means class.
//
// Authors       : Angela Wang
//
// $Date: 3/03/04 4:33p $
//
// $History: VisitorKMeans.cpp $
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:33p
// Updated in $/Neuroshare/PowerNAP
// Use the new GetActiveSegment()
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:46p
// Updated in $/Neuroshare/PowerNAP
// GetWave() no longer needs the EntityID passed to it
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 10/16/03   Time: 1:23p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 8  *****************
// User: Awang        Date: 8/29/03    Time: 12:02p
// Updated in $/Neuroshare/nsClassifier
// Removed useless lines
// 
// *****************  Version 7  *****************
// User: Awang        Date: 8/29/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Removed function covcol
// Un comment lines to allow for variable # pc coord to be used for Kmeans
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 8/27/03    Time: 10:58a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 5  *****************
// User: Awang        Date: 8/25/03    Time: 2:48p
// Updated in $/Neuroshare/nsClassifier
// Removed temporary matrices
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/22/03    Time: 11:38a
// Updated in $/Neuroshare/nsClassifier
// Remove Centroid class
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/18/03    Time: 3:22p
// Updated in $/Neuroshare/nsClassifier
// Changed name of CtrList
// 
// *****************  Version 2  *****************
// User: Awang        Date: 8/18/03    Time: 11:40a
// Updated in $/Neuroshare/nsClassifier
// 
//////////////////////////////////////////////////////////////////////
//K-Means clustering

#include "stdafx.h"
#include <vector>
#include <algorithm>
#include <math.h>

#include "Visitor.h" 
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "VisitorKMeans.h"
#include "Centroid.h"
#include "ViewPCA.h"

#include "randomc.h"

   
// Author & Date:   Angela Wang     July 20, 2003
//
// Purpose: K means clustering
//
// Inputs:  rcData - reference to the data we need to process
//  
// Outputs: TRUE  - successful
//          FALSE - failed
//  
bool VisitorKMeans::Visit(GenericVisitable & data)
{
    // data.m_pcDoc is the document data
    m_pData = data.m_pcDoc;

    // number of waveforms or PC points
    const Segments & rSeg = m_pData->GetActiveSegment();;
    int n = rSeg.size();  

    // number of points in a waveform
    int m = m_pData->GetNumOfPointsPerWave();  

    // Copy the waveforms with all data points into a matrix
    Matrix Waveforms(n, m, 0.0);
    int nIdx = 0;


    for (SEGMENTLIST::const_iterator it = rSeg.begin(); it != rSeg.end(); ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        for (UINT nPt = 0; nPt < m; ++nPt)
        {
            Waveforms(nIdx, nPt) = aicWave[nPt];
        }
        ++nIdx;
    }
    
    Matrix mean(1, m, 0.0);

    // Calculate mean of columns 
    meancols(&mean, Waveforms);
    
    // Get KMeans options selected stored in document
    int nPCCnt;
   
    // # PC coords to use
    nPCCnt = m_pData->m_isSortInfo.nPCCnt;

    int nCtrCnt = m_pData->m_isSortInfo.K;    // # centroids
    int nIterCnt = m_pData->m_isSortInfo.nIterCnt; // # iterations

    
    ///////////////////////////////////////////////////////////////////////
    // Principal component analysis
    Matrix pc(m, m, 0.0); // principal component vectors
    Matrix score(n, m, 0.0);    // principal component values of waveform data

    // Do decomposition on Waveforms, return PC coordinates in score
    // pc contains eigen-vectors used.
    princomp(&pc, &score, Waveforms);
    
    // Copy the first few data points of the pc score into a matrix
    // This just reduces the size of the PC components to
    // use in further calculation. It does not erase data.
  
    score.resize(n, nPCCnt);
    Waveforms.resize(n, nPCCnt);
    Waveforms.null();

    Waveforms = score;
    
//    nPCCnt = m;
    Matrix Centers(nCtrCnt, nPCCnt, 0.0);
    Matrix CtrWaveform(nCtrCnt, nPCCnt, 0.0);
    
    if (nIterCnt == 0)
        nIterCnt = 100;// default
    
    
    /////////////////////////////////////////////////////////////////////////////////////    
    // Now call K Means sorting on PC data 

    KMeans(Centers, Waveforms, nIterCnt, nCtrCnt); 


    /////////////////////////////////////////////////////////////////////////////////////    
    // Save the centers in KMeansSortInfo structure
    // make sure the centroid list is cleared, new centroids are going
    // to be defined and saved in both PC space and waveform space
    
    m_pData->m_isSortInfo.m_icCtrPCList.clear();
    m_pData->m_isSortInfo.m_icCtrWfList.clear();    

    for (int nCtr = 0; nCtr < nCtrCnt; ++nCtr)
    {
        int nNsUnit = pow(2, nCtr + 1); 

        WAVEFORM icCtrWaveform;
        WAVEFORM icCtrCoord;
       
        // Transform centroid into waveform space
        for (int nPt = 0; nPt < nPCCnt; ++nPt)
		{
            icCtrCoord.push_back(Centers(nCtr, nPt));

            double dTemp = 0;
			for (int nn=0; nn<nPCCnt; nn++)
			{
                 dTemp += Centers[nCtr][nn] * pc[nPt][nn];
			}

            if (dTemp == 0)
                icCtrWaveform.push_back(0.0);
            else
                icCtrWaveform.push_back(dTemp + mean(0, nPt));	//in uVolts
		}
        
        // Save centroids in PC space in document
        Centroid CtrPC(nNsUnit, icCtrCoord);
        m_pData->m_isSortInfo.m_icCtrPCList.push_back(CtrPC);

        // Save centroid waveforms in document
        Centroid CtrWf(nNsUnit, icCtrWaveform);
        m_pData->m_isSortInfo.m_icCtrWfList.push_back(CtrWf);
    }//  next centroid

  
    /////////////////////////////////////////////////////////////////////////////////////    
    /////////////////////////////////////////////////////////////////////////////////////    
    // Estimate error covariance matrix for each centroid
    
 
    /////////////////////////////////////////////////////////////////////////////////////    
    /////////////////////////////////////////////////////////////////////////////////////    
    
    return true;
}//Visit


void VisitorKMeans::princomp(Matrix *pc, Matrix *score, Matrix data)
{
    // Finds the principal components of 'data'
    // returns the eigenvalues of 'data' in 'score'
    // 'pc' is nXn and contains the new orthogonal eigenvectors

    int m = data.rowno();
    int n = data.colno();

    Matrix avg(1, n, 0.0);
      
    // Calculate mean of columns 
    meancols(&avg, data);

    // Subtract column means from respective columns of the original data matrix
    Matrix centerx(m, n, 0.0);
    for (int i = 0; i < m; ++i)
    {
        centerx[i] = (Vector) data[i] - (Vector) avg[0];
    }

    // Now do SVD on centered data CenterX = UWZ(t)
    Matrix U = centerx;
    Vector W;  
    Matrix Z;

    U /= sqrt((double) m - 1);
    
    // Z is 48x48; W is 48 long
    // This SVD is defined as A = UWZ(t).  
    // U is mXn  and replaces A on completion
    // W is a diagonal matrix, diagonal elements are singular values
    // Z = matrix of eigenvectors = eigenvectors of correlation matrix.

    U.svd(Z, W);
        
    U.free();  // Since this is big and I don't need it, I am freeing the memory

    (*pc) = Z;
    (*score) = centerx * Z;
}



void VisitorKMeans::KMeans(Matrix &center, Matrix data, int nIterMax, int nClstrCnt)
{
//Description
//CENTRES = KMEANS(CENTRES, DATA, OPTIONS) uses the batch K-means
//algorithm to set the centres of a cluster model. The matrix DATA
//represents the data which is being clustered, with each row
//corresponding to a vector. The sum of squares error function is used.
//The point at which a local minimum is achieved is returned as
//CENTRES.  

    int nDataCnt = data.rowno();  // number of rows
    int nPtCnt = data.colno();    // number of columns
    int nPCCnt = data.colno();    // number of columns is # of PC score values used
        
    ///////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////
        
    // Set initial centers to random points

    InitCtrs(center, nClstrCnt, nPCCnt);
   
    // array to hold dist from data to centroid    
    Matrix dist(nClstrCnt, data.rowno(), 0.0);
    
    long double dPrevL2=0;
    long double dPresentL2=0;
    double dError = 0.01;
        
    // Main loop
    BOOL bConverged = FALSE;//reset convergence condition
    int nIter = 0;
    
    while ((bConverged == FALSE) && (nIter < nIterMax))
    {
        //Iterate if not converged or max number of iterations not yet reached
		nIter++;

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Step A:  Evaluation of dError using Euclidean L2 norm

        DistL2Norm(dist, center, data);        

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Step B:  compute total distortion with present centroids and check for convergence

        dPresentL2 = 0;
        for (int i = 0; i < nClstrCnt; ++i)
        {
            for (int j = 0; j < data.rowno(); ++j)
            {
                dPresentL2 = dPresentL2 + pow(dist(i, j), 2);
            }
        }

		if (((fabs((double)(dPresentL2 - dPrevL2)) / fabs((double)dPresentL2)) < dError) )
				bConverged = TRUE; 

		dPrevL2 = dPresentL2;   //save current L2 norm dError
		dPresentL2 = 0;         //clear current L2 norm
       
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Step C:  Reassign members of each cluster.  		
		
        //For each data pt, get closest centroid.  Assign this data pt as a member of that cluster
		long double dMinDist;
		int nClusterMember;
        
        double *pdClstrCount;
        pdClstrCount = new double [nClstrCnt];

        for (int n=0; n<nClstrCnt; ++n)
            pdClstrCount[n] = 0;

        //clear centroids and cluster count array
		center.null();
        
        for (int nPt=0; nPt<nDataCnt; nPt++)
		{
			dMinDist = dist(0, nPt);//initialize min to distance to 1st Centroid
		    nClusterMember = -1;
            for (int nCtr =0; nCtr<nClstrCnt; nCtr++)
			{
				double temp = dist(nCtr, nPt);
                if (dist(nCtr, nPt) <= dMinDist)
				{
                    //if distance from nPt to this center is smallest, 
                    //make this pt a member of this center
					dMinDist = dist(nCtr, nPt);
					nClusterMember = nCtr;      //assign pt to closest new cluster: 0-5;
                }
            }// next pt
            
            // Assign new unit ID to waveform list
            ///////////////////////////////////////////////////////////////////////////////
            // Set the unit ID for each channel
            
            m_pData->GetActiveSegment()[nPt].SetUnitID(m_pData->GetBITUnit(nClusterMember + 1));

            ///////////////////////////////////////////////////////////////////////////////
            
            //compute new mean for centroids
            for (int nPC=0; nPC<nPCCnt; nPC++)
			{
                //add PC values now, later take an average
               center(nClusterMember, nPC) += data(nPt, nPC);
           }

			pdClstrCount[nClusterMember] ++;
            
		}//nex pt

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
       //Step D: compute new Centroids and sigmas 
        for (int nCtr=0; nCtr<nClstrCnt; nCtr++)
		{
           for (int nPC=0; nPC<nPCCnt; nPC++)
			{
 				
                if (pdClstrCount[nCtr] == 0)
                    center(nCtr, nPC) = 0;
				else
                {
                     center(nCtr, nPC) /=  pdClstrCount[nCtr];//take an average
                }
			}
        }
    
        // Clean up
        delete [] pdClstrCount;

    }//end of while  - CONVERGED!!

    return;

}//KMeans




// Compute the mean of the columns of data matrix
// Input: data
// Output: meanc
//
void VisitorKMeans::meancols(Matrix *meanc, Matrix data)
{
    sumcols(meanc, data);

    *meanc /= data.rowno();
}

void VisitorKMeans::sumcols(Matrix *sumc, Matrix data)
{
    int rows = data.rowno();
    int cols = data.colno();

    (*sumc).null();

    ASSERT((*sumc).colno() == cols);

    for (int j = 0; j < cols; ++j)
    {
        for (int i = 0; i < rows; ++i)
        {
            (*sumc)(0, j) = (*sumc)(0, j) + data(i, j);
        }
    }
}


void VisitorKMeans::InitCtrs(Matrix &U, int nClstrCnt, int nDataCnt)
{
    Matrix col_sum(1, nDataCnt, 0.0);

    int i;
    int j;

    long int seed = time(0);  // random seed
  
    //initialize mean values of centers of clusters
    // choose one of the random number generators:
    TRanrotBGenerator rg(seed);  // make instance of random number generator
    double dRandom;

    U.null();
    
    for (i = 0; i < nClstrCnt; ++i)
    {
        for (j = 0; j < nDataCnt; ++j)
        {
            dRandom = rg.Random();
            U(i, j) = dRandom;
        }
    }

    sumcols(&col_sum, U);

    for (i = 0; i < nClstrCnt; ++i)
    {
        for (j = 0; j < nDataCnt; ++j)
        {
            U(i, j) = U(i, j) / col_sum(0, j);
        }
    }
}//InitCtrs


void VisitorKMeans::DistL2Norm(Matrix &Dist, Matrix center, Matrix data)
{
    // Calculate euclidean distance from center to data point
    
    Dist.null();

    ASSERT(Dist.rowno() == center.rowno());
    ASSERT(Dist.colno() == data.rowno());


    
    int i;
    int j;
    int k;
    double dTemp = 0;

    if (data.colno() > 1)
    {
        for (k = 0; k < center.rowno(); ++k)
        {
            for (i = 0; i < data.rowno(); ++i)
            {
                dTemp = 0;
                for (j = 0; j < data.colno(); ++j)
                {
                    dTemp = dTemp + pow((data(i, j) - center(k, j)), 2);
                 }
                Dist(k, i) = sqrt(dTemp);
            }
        }
    }
}


#define MIN(a, b)  (((a) < (b)) ? (a) : (b)) 


void VisitorKMeans::trace(Matrix mtrace)
{
    double temp;
    int maxx = MIN(mtrace.rowno(), 10);
    int maxy = MIN(mtrace.colno(), 10);

    for (int x = 0; x < maxx; ++x)
    {
        for (int y = 0; y < maxy; ++y)
        {
            temp = mtrace[x][y];
            TRACE("%4.4f  \t", temp);
        }
        TRACE("\n");
    }
}


