///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageShy.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 10/31/03 6:05p $
//
// $History: PropPageShy.cpp $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 6:05p
// Updated in $/Neuroshare/PowerNAP
// First working version of the spike sorting property sheets.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "powernap.h"
#include "DocPowerNAP.h"
#include "PropPageShy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageShy property page

IMPLEMENT_DYNCREATE(CPropPageShy, CPropertyPage)

CPropPageShy::CPropPageShy() : CPropertyPage(CPropPageShy::IDD)
{
    m_pDoc = NULL;

	//{{AFX_DATA_INIT(CPropPageShy)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPageShy::~CPropPageShy()
{
}


void CPropPageShy::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageShy)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageShy, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageShy)
	ON_BN_CLICKED(IDC_PPSHY_BTN_SORT, OnBtnSort)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageShy message handlers

void CPropPageShy::OnBtnSort() 
{
    m_pDoc->SortActiveChannel(TDISTRMETHOD);
}
