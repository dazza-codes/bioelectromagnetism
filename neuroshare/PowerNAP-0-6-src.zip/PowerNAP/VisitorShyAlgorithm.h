///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorShyAlgorithm.h $
//
// Description   : interface for the VisitorShyAlgorithm class.
//
// Authors       : Almut Branner
//
// $Date: 2/10/04 5:14p $
//
// $History: VisitorShyAlgorithm.h $
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 2/10/04    Time: 5:14p
// Updated in $/Neuroshare/PowerNAP
// Algorithm now only runs on subset and doesn't crash when no units are
// found.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 2/10/04    Time: 11:40a
// Updated in $/Neuroshare/PowerNAP
// Changed algorithm to allow processing of some units first and then all.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 2/09/04    Time: 11:44a
// Updated in $/Neuroshare/PowerNAP
// Algorithm now initialized with an EntityID and variable names changed
// to be more meaningful.
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/21/03    Time: 2:26p
// Updated in $/Neuroshare/nsClassifier
// Spike sorting now works and has been optimized for speed.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef VISITORSHYALGORITHM_H_INCLUDED
#define VISITORSHYALGORITHM_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Visitor.h"
#include "cmatrix"

//
// typedef for different matrix types
//
typedef techsoft::matrix<double> Matrix;
typedef std::valarray<double>    Vector;

//
// Using declarations. 
//
using techsoft::mslice;
using techsoft::gmslice;
using techsoft::DIAGONAL;
using techsoft::UTRIANG;
using techsoft::LTRIANG;
using techsoft::TRIDIAGONAL;
using techsoft::epsilon;
using techsoft::isVecEq;
using std::exception;

#ifdef _MSC_VER
using ::rand;
#else
using std::rand;
using std::size_t;
#endif



class CDocPowerNAP;         // forward declare to avoid include

class VisitorShyAlgorithm : 
	public BaseVisitor, 
	public Visitor<CDocPowerNAP, bool>  
{
public:
    VisitorShyAlgorithm(DWORD dwEntityID) : m_dwEntityID(dwEntityID) {};
    bool Visit(CDocPowerNAP & rcDoc);

private:
	double gamma(double x);
    double recipgamma(double x, double *odd, double *even);
    double loggamma(double x);
	double erf(double x);
	double digammas(double x);
	void digamma(Matrix *d, Matrix x);
    void princomp(Matrix *pc, Matrix *score, Matrix data);
	void sqrtm(Matrix *X, Matrix Y);
    void FuzzyCMeans(Matrix *center, Matrix *U, Vector *obj_fcn, Matrix data, int cluster_n, 
                     Vector options);

	void DistClusterCenters(Matrix *diffs, Matrix Waveforms, Matrix mu);
    void MahalanobisDistances(Matrix *M, Matrix *detSigma, Matrix diffs, double *Sigma);
	void UpdateProbabilities(Matrix *Prob, Matrix M, Matrix detSigma, double nu, int nNumOfPoints);
    void ResizeData(Matrix *Pj, Matrix *mu, Matrix *Prob, Matrix *Z, Matrix *U, Matrix *ZU, 
                    Matrix *M, double *Sigma, Vector ToKeep, int new_NumOfUnits);
	void UpdateSigma(double *Sigma, Matrix U, Matrix Diffs, Matrix Sum);

	bool sac_t_algorithm(Matrix *Pj, Matrix *mu, double *Sigma, double *nu, Matrix *Z, Matrix *U,
                         Matrix *M, int N, int max_iteration, CString method, Matrix waveforms);
	void stepfcm(Matrix *U_new, Matrix *center, double *obj_fcn, Matrix data, Matrix U, 
                 int cluster_n, int expo);
	void distfcm(Matrix *out, Matrix center, Matrix data);
	void initfcm(Matrix *U, int cluster_n, int data_n);

    void MeanCols(Matrix *meanc, Matrix data);
    void MeanRows(Matrix *meanr, Matrix data);
    void SumCols(Matrix *sumc, Matrix data);
    void SumRows(Matrix *sumr, Matrix data);
	void GetCurrentSigma(Matrix *CurrentSigma, double *Sigma, int WhichSigma, int d, int g);

	void trace(Matrix mtrace);

    DWORD m_dwEntityID;
};

#endif // include guard
