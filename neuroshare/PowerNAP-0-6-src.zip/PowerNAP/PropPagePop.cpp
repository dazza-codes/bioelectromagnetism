///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPagePop.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 2/09/04 11:42a $
//
// $History: PropPagePop.cpp $
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 2/09/04    Time: 11:42a
// Updated in $/Neuroshare/PowerNAP
// PropPage was updated wrong.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 1/30/04    Time: 3:54p
// Updated in $/Neuroshare/PowerNAP
// Streamlined data transfer.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "PropPagePop.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPagePop property page

IMPLEMENT_DYNCREATE(CPropPagePop, CPropertyPage)

CPropPagePop::CPropPagePop() : CPropertyPage(CPropPagePop::IDD)
{
	//{{AFX_DATA_INIT(CPropPagePop)
	m_nNumOfGroups = 0;
	m_nNumOfSamples = 0;
	m_nNumFiles = 0;
	m_nTtlNumSamples = 0;
	//}}AFX_DATA_INIT
}

CPropPagePop::~CPropPagePop()
{
}

void CPropPagePop::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPagePop)
	DDX_Control(pDX, IDC_EDT_SAMPLES, m_edtSamples);
	DDX_Control(pDX, IDC_EDT_GROUPS, m_edtGroups);
	DDX_Text(pDX, IDC_EDT_GROUPS, m_nNumOfGroups);
	DDX_Text(pDX, IDC_EDT_SAMPLES, m_nNumOfSamples);
	DDX_Text(pDX, IDC_EDT_FILES, m_nNumFiles);
	DDX_Text(pDX, IDC_EDT_TOTSAMPLES, m_nTtlNumSamples);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPagePop, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPagePop)
	ON_EN_CHANGE(IDC_EDT_GROUPS, OnChange)
	ON_EN_CHANGE(IDC_EDT_SAMPLES, OnChange)
	ON_EN_KILLFOCUS(IDC_EDT_GROUPS, OnKillfocus)
	ON_EN_KILLFOCUS(IDC_EDT_SAMPLES, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPagePop message handlers


void CPropPagePop::OnChange()
{
    SetModified(true);
}

void CPropPagePop::OnKillfocus() 
{
    UpdateTotalNumSamples();
}

void CPropPagePop::UpdateTotalNumSamples()
{
    UpdateData(true);

    m_nTtlNumSamples = m_nNumOfGroups * m_nNumOfSamples * m_nNumFiles;

    if (m_nNumFiles == 0)
        m_nTtlNumSamples = m_nNumOfGroups * m_nNumOfSamples;

    UpdateData(false);
}
