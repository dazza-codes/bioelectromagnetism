///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NumEdit.cpp $
//
// Authors       : Almut Branner
//
// $Date: 10/21/03 2:43p $
//
// $History: NumEdit.cpp $
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Almut        Date: 4/18/03    Time: 1:08p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anomaly #13.
// Thresholding now has a plus and minus button and a text box for editing
// the threshold.
// Also figured out how to recognize the return key in edit boxes and use
// it to make something happen.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NumEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// NumEdit

CNumEdit::CNumEdit()
{
}

CNumEdit::~CNumEdit()
{
}


BEGIN_MESSAGE_MAP(CNumEdit, CEdit)
	//{{AFX_MSG_MAP(CNumEdit)
    ON_WM_CHAR()
	ON_WM_GETDLGCODE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// NumEdit message handlers

void CNumEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
    if (((nChar >= _T ('0')) && (nChar <= _T ('9'))) || (nChar == VK_BACK) || (nChar == _T ('-')))
    	CEdit::OnChar(nChar, nRepCnt, nFlags);
    else if (nChar == _T ('\r')) // If 'return' was hit
        GetParentFrame()->SetFocus(); // This automatically calls OnKillfocus for the control
}

UINT CNumEdit::OnGetDlgCode() 
{
    // Change this to also return "Enter" and other keys in OnChar
	return DLGC_WANTALLKEYS;
}
