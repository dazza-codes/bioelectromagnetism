///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageKMeansCluster.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 10/31/03 5:48p $
//
// $History: PropPageKMeansCluster.cpp $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 5:48p
// Updated in $/Neuroshare/PowerNAP
// First working implementation of this class. Was also renamed to
// CPropPageKMeans.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "PropPageKMeans.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageKMeans property page

IMPLEMENT_DYNCREATE(CPropPageKMeans, CPropertyPage)

CPropPageKMeans::CPropPageKMeans() : CPropertyPage(CPropPageKMeans::IDD)
{
    m_pDoc = NULL;

	//{{AFX_DATA_INIT(CPropPageKMeans)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPageKMeans::~CPropPageKMeans()
{
}

void CPropPageKMeans::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageKMeans)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageKMeans, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageKMeans)
	ON_BN_CLICKED(IDC_KSEL_1, On1)
	ON_BN_CLICKED(IDC_KSEL_2, On2)
	ON_BN_CLICKED(IDC_KSEL_3, On3)
	ON_BN_CLICKED(IDC_KSEL_4, On4)
	ON_BN_CLICKED(IDC_KSEL_5, On5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageKMeans message handlers


void CPropPageKMeans::On1() 
{
    // Find 1 centroid
    m_pDoc->m_isSortInfo.K = 1;
    m_pDoc->SortActiveChannel(KMEANSMETHOD);	
}

void CPropPageKMeans::On2() 
{
    // Find 2 centroid
    m_pDoc->m_isSortInfo.K = 2;
    m_pDoc->SortActiveChannel(KMEANSMETHOD);	
}

void CPropPageKMeans::On3() 
{
    // Find 3 centroid
    m_pDoc->m_isSortInfo.K = 3;
    m_pDoc->SortActiveChannel(KMEANSMETHOD);	
}

void CPropPageKMeans::On4() 
{
    // Find 4 centroid
    m_pDoc->m_isSortInfo.K = 4;
    m_pDoc->SortActiveChannel(KMEANSMETHOD);	
}

void CPropPageKMeans::On5() 
{
    // Find 5 centroid
    m_pDoc->m_isSortInfo.K = 5;
    m_pDoc->SortActiveChannel(KMEANSMETHOD);	
}
