///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DocPowerNAP.h $
//
// Description   : interface of the CDocPowerNAP class
//
// Authors       : Kirk Korver
//
// $Date: 3/11/04 12:53p $
//
// $History: DocPowerNAP.h $
// 
// *****************  Version 72  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:53p
// Updated in $/Neuroshare/PowerNAP
// Added ability to delete units and reclassify units
// 
// *****************  Version 71  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:49p
// Updated in $/Neuroshare/PowerNAP
// Added basic "clipping" functions
// 
// *****************  Version 70  *****************
// User: Kkorver      Date: 3/05/04    Time: 3:59p
// Updated in $/Neuroshare/PowerNAP
// Added the ability to delete channels
// 
// *****************  Version 69  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 68  *****************
// User: Kkorver      Date: 3/04/04    Time: 9:39a
// Updated in $/Neuroshare/PowerNAP
// Create new GetEntity()
// Rename GetEntityIndex() to GetIdxEntity()
// 
// *****************  Version 67  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:40p
// Updated in $/Neuroshare/PowerNAP
// Renamed GetTimeSpan() to GetMaxTime()
// Renamed GetSegment() to GetIdxSegment()
// Renamed GetActiveSegment() to GetIdxActiveSegment() , etc.
// Added new GetSegment() and GetActiveSegment(), etc.
// 
// *****************  Version 66  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:52p
// Updated in $/Neuroshare/PowerNAP
// Added playback capabilities
// Added GetTimeSpan()
// 
// *****************  Version 65  *****************
// User: Abranner     Date: 2/10/04    Time: 11:41a
// Updated in $/Neuroshare/PowerNAP
// Added colors and pens for additional units.
// 
// *****************  Version 64  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 63  *****************
// User: Abranner     Date: 2/03/04    Time: 12:44p
// Updated in $/Neuroshare/PowerNAP
// Made changes to doc to simplify data renewal operations.
// 
// *****************  Version 62  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 61  *****************
// User: Abranner     Date: 1/26/04    Time: 4:00p
// Updated in $/Neuroshare/PowerNAP
// Made calling and updating the PropSheetSpkSorting easier.
// 
// *****************  Version 60  *****************
// User: Abranner     Date: 10/31/03   Time: 6:02p
// Updated in $/Neuroshare/PowerNAP
// Changed window positions and the way spike sorting is initiated.
// 
// *****************  Version 59  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:46a
// Updated in $/Neuroshare/PowerNAP
// Made it so newly opened windows would all be arranged
// 
// *****************  Version 58  *****************
// User: Kkorver      Date: 10/22/03   Time: 11:16a
// Updated in $/Neuroshare/PowerNAP
// RebuildAllLists() renamed to RebuildAllListsAndUpdateViews() and now
// calls UpdateAllViews() at the end
// 
// *****************  Version 57  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 56  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:17a
// Updated in $/Neuroshare/nsClassifier
// Added RebuildSegListAndUpdate
// 
// *****************  Version 55  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:55a
// Updated in $/Neuroshare/nsClassifier
// Moved all of the Datas to their own file
// 
// *****************  Version 54  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 53  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 52  *****************
// User: Abranner     Date: 10/15/03   Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// Moved pens and colors to the document and added functions
// GetBITUnitColor(), GetBITUnit() and GetBITUnitPen().
// 
// *****************  Version 51  *****************
// User: Kkorver      Date: 10/15/03   Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Saving data now prompts
// 
// *****************  Version 50  *****************
// User: Kkorver      Date: 10/14/03   Time: 10:44a
// Updated in $/Neuroshare/nsClassifier
// Added SaveAnalogs()
// 
// *****************  Version 49  *****************
// User: Abranner     Date: 10/13/03   Time: 2:00p
// Updated in $/Neuroshare/nsClassifier
// Added functions IsSegment(), AreThereAnalogs(), IsActiveAnalog() and
// IsAnalog().
// 
// *****************  Version 48  *****************
// User: Abranner     Date: 9/12/03    Time: 1:25p
// Updated in $/Neuroshare/nsClassifier
// Added search functions for analog entities and fixed some bugs.
// 
// *****************  Version 47  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 46  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 45  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 44  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 43  *****************
// User: Kkorver      Date: 9/11/03    Time: 7:08a
// Updated in $/Neuroshare/nsClassifier
// Added SaveData() and SaveSegments()
// 
// *****************  Version 42  *****************
// User: Abranner     Date: 9/10/03    Time: 1:32p
// Updated in $/Neuroshare/nsClassifier
// Changed BuildWaveformList to BuildSegmentList and changed logic that
// waveform list is assumed in GetActive... functions.
// 
// *****************  Version 41  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 39  *****************
// User: Awang        Date: 8/28/03    Time: 1:55p
// Updated in $/Neuroshare/nsClassifier
// GetCurrentEntity() checks for valid entity number and returns -1 for
// invalid or unselected entities
// 
// *****************  Version 38  *****************
// User: Awang        Date: 8/28/03    Time: 9:14a
// Updated in $/Neuroshare/nsClassifier
// Removed Templateinfo class
// 
// *****************  Version 37  *****************
// User: Awang        Date: 8/27/03    Time: 2:26p
// Updated in $/Neuroshare/nsClassifier
// Removed TemplateInfo class
// 
// *****************  Version 36  *****************
// User: Awang        Date: 8/26/03    Time: 2:26p
// Updated in $/Neuroshare/nsClassifier
// Removed unused function UpdateTemplate()
// 
// *****************  Version 35  *****************
// User: Awang        Date: 8/22/03    Time: 10:43a
// Updated in $/Neuroshare/nsClassifier
// Removed Centroid class
// 
// *****************  Version 34  *****************
// User: Awang        Date: 8/18/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// changed names of centroid lists
// 
// *****************  Version 33  *****************
// User: Awang        Date: 8/15/03    Time: 1:20p
// Updated in $/Neuroshare/nsClassifier
// Added ViewSortedInfo and Eigenvector list 
// 
// *****************  Version 32  *****************
// User: Awang        Date: 8/05/03    Time: 2:09p
// Updated in $/Neuroshare/nsClassifier
// Added Centroid class
// KMeans sorting parameters 
// Change CreateOrActivateView to return pointer to view
// 
// *****************  Version 31  *****************
// User: Awang        Date: 7/17/03    Time: 10:27a
// Updated in $/Neuroshare/nsClassifier
// Changed comments
// 
// *****************  Version 30  *****************
// User: Awang        Date: 6/30/03    Time: 3:53p
// Updated in $/Neuroshare/nsClassifier
// EntityInfoView added 
// 
// *****************  Version 29  *****************
// User: Awang        Date: 6/18/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 28  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// *****************  Version 27  *****************
// User: Awang        Date: 6/10/03    Time: 4:31p
// Updated in $/Neuroshare/nsClassifier
// Post messages for highlighting a selected waveform, changing unit
// colors on data points.
// 
// *****************  Version 26  *****************
// User: Awang        Date: 5/30/03    Time: 12:02p
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 25  *****************
// User: Kkorver      Date: 5/12/03    Time: 11:13a
// Updated in $/Neuroshare/nsClassifier
// Added DlgAdvancedOpen class
// Added AddDataFileUsingThisDLLPrompt()
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 5/05/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with the graph update. The scaling (or max voltage value)
// of all waveforms is now calculated in the document and not the graph
// window.
// 
// *****************  Version 22  *****************
// User: Abranner     Date: 4/28/03    Time: 5:28p
// Updated in $/Neuroshare/nsClassifier
// Added one more option to align peaks.
// 
// *****************  Version 21  *****************
// User: Abranner     Date: 4/28/03    Time: 12:34p
// Updated in $/Neuroshare/nsClassifier
// Added capability to turn tooltips off.
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 4/25/03    Time: 2:12p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// *****************  Version 19  *****************
// User: Kkorver      Date: 4/22/03    Time: 5:53p
// Updated in $/Neuroshare/nsClassifier
// Added GetTotalEntityItemCount()
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 4/22/03    Time: 5:11p
// Updated in $/Neuroshare/nsClassifier
// Added RemoveFile()
// 
// *****************  Version 17  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 16  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 4/11/03    Time: 11:00a
// Updated in $/Neuroshare/nsClassifier
// AddDataFile() now returns true/false
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 4/11/03    Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Added EraseWaveForms()
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:18p
// Updated in $/Neuroshare/nsClassifier
// Added the variables for the processing options displayed in the FIU
// class
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 4/09/03    Time: 4:32p
// Updated in $/Neuroshare/nsClassifier
// Added GetNumOfPointsPerWave()
// 
// *****************  Version 11  *****************
// User: Angela       Date: 4/09/03    Time: 1:33p
// Updated in $/Neuroshare/nsClassifier
// Added 2nd MDIDocTemplate
// make waveforms view appear
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 4/03/03    Time: 11:28a
// Updated in $/Neuroshare/nsClassifier
// Added the comparison operators to EntityInfoType
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 4/03/03    Time: 10:49a
// Updated in $/Neuroshare/nsClassifier
// We are now able to read/write the document class to a file
// 
// *****************  Version 8  *****************
// User: Kirk         Date: 4/01/03    Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// The document is now visitable
// Upgraded to use the STL for the new wavelist
// 
// *****************  Version 7  *****************
// User: Kirk         Date: 3/27/03    Time: 1:53p
// Updated in $/Neuroshare/nsClassifier
// Untabified
// Updated to allow multiple data files
// 
// *****************  Version 6  *****************
// User: Kirk         Date: 3/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Rename the NsFile iterators
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 3/25/03    Time: 1:42p
// Updated in $/Neuroshare/nsClassifier
// Added popup menu choice to insert data files
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/25/03    Time: 11:20a
// Updated in $/Neuroshare/nsClassifier
// Added NsFile to the document
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef DOCPOWERNAP_H_INCLUDED
#define DOCPOWERNAP_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning ( disable : 4786 )

#include "NsFile.h"
#include "Centroid.h"
#include "MainFrm.h"
#include "Visitor.h"
#include "ViewPCA.h"
#include "DataAnalog.h"
#include "DataSegment.h"
#include "Datas.h"
#include "PropSheetSpkSorting.h"

#include <algorithm>
#include <vector>
#include <list>

#include <boost/shared_ptr.hpp>


///////////////////////////////////////////////////////////////////////////////////////////
// Forward declares to avoid includes

struct IWriteNSN;


///////////////////////////////////////////////////////////////////////////////////////////

struct FileInfo
{
    CString strFilePathName;        // Fully qualified name of the file
    ns_FILEINFO isFileInfo;         // FileInfo read from the file
    NsFile icFile;                  // The actual data file to read
};


struct EntityInfo
{
    DWORD dwEntityIndex;            // The index of this entity in the file
    ns_ENTITYINFO isEntityInfo;     // Information about the current entity

    //Flags for sorting information
    bool m_bRulesDefined;

    // Comparison operators
    bool operator == (EntityInfo const & rhs);
    bool operator != (EntityInfo const & rhs);
};

// SP means SharedPointer
typedef boost::shared_ptr<FileInfo> SPFileInfo;
typedef boost::shared_ptr<Analogs>  SPAnalogs;
typedef boost::shared_ptr<Segments> SPSegments;

typedef std::vector <SPFileInfo>    FILEINFOLIST;
typedef std::vector <SPAnalogs>     ANALOGENTITYLIST;
typedef std::vector <SPSegments>    SEGMENTENTITYLIST;
typedef std::vector <EntityInfo>    ENTITYINFOLIST;

typedef std::vector <Centroid> CTRPCLIST;
typedef std::vector <Centroid> CTRWAVEFORMLIST;


// Structure to hold K Means sorting parameters and
// centroid information
struct KMeansSortInfo
{
    int K;                  // # of centers to calculate    
    int nPCCnt;             // # of PC coordinates used in K Means computation        
    int nIterCnt;           // Max # of  iterations    

    CTRPCLIST       m_icCtrPCList;  // List of Centroids in PC coordinates 
    CTRWAVEFORMLIST m_icCtrWfList;  // List of Centroids in V-t coordinates

//    Matrix &Cov;
};

enum tagSortMethod 
{
    TDISTRMETHOD = 0,
    KMEANSMETHOD,
    MANUALMETHOD
};


///////////////////////////////////////////////////////////////////////////////////////////


class CDocPowerNAP : public CDocument, public BaseVisitable <bool>
{
protected: // create from serialization only
    CDocPowerNAP();
    DECLARE_DYNCREATE(CDocPowerNAP)

    // This is the version of the file we are writing out. It needs to be set to 1 once
    // We have a "semi" official version
    enum { FILE_MAJOR_VERSION = 0 };
    
// Attributes
public:
    virtual ~CDocPowerNAP();

    DEFINE_VISITABLE();                     // needed by the visitors
    
    FILEINFOLIST m_icFileVector;            // List of files we have open
    ENTITYINFOLIST m_icEntityInfoVector;    // cached copy of the entity infos - use GetIdxEntity() or GetActiveEntityIndex()
    SEGMENTENTITYLIST m_icSegmentList;      // list of the segment entities - Access it using GetSegment() or GetIdxActiveSegment()
    ANALOGENTITYLIST m_icAnalogList;        // list of analog entities - use GetIdxAnalog() or GetIdxActiveAnalog()

    void ShowPropSheetSpkSorting(tagSortMethod nMethod);

    void RemoveFile(int nIndex);            // Remove this file from the list (0 based)

    DWORD GetNumOfPointsPerWave();          // Tell me how many data points each wave form contains

    /////////////////////////////////////
    // Functions for updating lists
    
    void RebuildAllListsAndUpdateViews();   // Erase and rebuild all lists (Entities, Segments etc.), 
                                            //   then make all views update
    void AppendDataLists(FileInfo & rsFileInfo);   // Append data lists (Segments etc.)
    void AppendSegList(FileInfo & rsFileInfo);     // Append segment list
    void AppendAnaList(FileInfo & rsFileInfo);     // Append analog lists
    void RebuildDataLists();                // Erase and rebuild all data lists (Segments etc.)
    void RebuildDataListsAndUpdateViews();  // Erase and rebuild all data lists (Segments etc.),
                                            //   then make all views update
    void RebuildSegListAndUpdateViews();    // Erase and rebuild the segment data list and update
    void RebuildSegList();                  // Erase and rebuild the segment data list
    void RebuildAnaListAndUpdateViews();    // Erase and rebuild the analog data list and update
    void RebuildAnaList();                  // Erase and rebuild the analog data list

    // Erase and rebuild the segment list for to this entry, then update with this hint
    void RebuildSegListEntryAndUpdateViews(DWORD dwEntityID, DWORD nHint = HINT_USER_NONE);

    /////////////////////////////////////

    // Call this to get the min and max voltage values of all waveforms.
    void SetMinMaxWfValues();               

    // Get the maximum time of anything visible
    double GetMaxTime();       


    std::vector <uint32> UnitList;  // Temporary list to hold unitID's of currently loaded entity 
    
    COLORTABLE m_icColorTable;
    CBrush m_wndbkBrush;    // The brush for the "background" of all windows
    CPen m_penUnitColor[13]; //array of pen colors for units. 1 unsorted, 8 sorted colors                

    int GetBITUnitColor(uint32 dwUnitID);
    CPen * GetBITUnitPen(uint32 dwUnitID);
    uint32 GetBITUnit(int nUnitID);

    // Highlighting of waveforms
    void SetUnSelWF(UINT32 uSelIndex);
    void SetSelWF(UINT32 nSelIndex);
    UINT32 m_dwPrevSelIndex;

    // Setting of flags for sorting rules    
    void SetSorted(bool bRulesDefined);

    BOOL DestroyView(CView *pView);

        
    //////////////// These all correspond to options on the FilesInUse View
    int m_nActiveEntity;                    // What is the currently selected entity.
                                            // It does map directly to entity ID

    BOOL m_bSampleData;                     // TRUE means that we intend to sample data; FALSE, use all data
    UINT m_nNumOfSamples;                   // How many samples are there in each group
    UINT m_nNumOfGroups;                    // How many groups are there

    BOOL m_bRemoveSaturatedSpikes;          // TRUE means we should remove all spikes that reach the maximum
    BOOL m_bAlignPeaks;                     // TRUE means we should make all peaks align at the same point.
                                            // A peak is either an up OR a down.
    BOOL m_bAlignMeanPt;                    // TRUE means that peaks are aligned to the mean location of
                                            // all peaks; FALSE means that m_nAlignPt is used.
    UINT m_nAlignPt;                        // The peaks are going to be aligned to this point
    BOOL m_bTooltips;                       // TRUE means user wants to show tooltips; FALSE, not
    int m_nWhatPeaks;                       // 0:allPeaks, 1:posPeaks, 2:negPeaks
    double m_dMaxWfVal;                     // Maximum voltage value in all waveforms

    // Variables required by Shys spike sorting algorithm
    int m_nPenaltyFactor;                   
    int m_nNumPCA;

    BOOL m_bDiscardEmptyEntities;           // Determines whether empty entities are removed

    // Getting and Setting the focus index to the Entity list
    void SetActiveEntity(int32 nEntityID);
    int32 GetActiveEntity();
    int32 GetActiveEntityIndex();
    int32 GetFileIndex(NsFile & rcFile);
    int32 GetIdxEntity(int32 dwEntityID);
    int32 GetIdxActiveSegment();
    int32 GetIdxSegment(int32 dwEntityID);
    int32 GetIdxActiveAnalog();
    int32 GetIdxAnalog(int32 dwEntityID);

    EntityInfo & GetEntity(int32 dwEntityID);// Get the Entity associated with this entity ID
    Segments & GetActiveSegment();          // Get the "segment" that is currently selected
    Segments & GetSegment(int32 dwEntityID);// Get this "segment"
    Analogs & GetActiveAnalog();            // Get the active segment when it is an ANALOG
    Analogs & GetAnalog(int32 dwEntityID);  // Get this "analog"

    KMeansSortInfo m_isSortInfo;

    //////////////////
    // This grouping is done for convience. These are the settings dealing with playback
    // The actual work is tightly integrated with the CViewPlayback class
    class PlayBack
    {
    public:
        PlayBack() : m_bPlayBackActive(false), m_nWaveformCount(100) {}

    public:
        enum PbMode 
        { 
            PB_PAUSED,              // The playback isn't "moving" at this moment -- aka "Jumped here"
            PB_RUNNING,             // Playback is actively moving forward
        };

        bool m_bPlayBackActive;     // TRUE means we are trying to playback right now; FALSE, regular view
        PbMode m_enMode;            // What "mode" of playback are we doing?

        double m_dTime;             // This is the point in time we want are at
        UINT m_nWaveformCount;      // How many waveforms should we display (PCA + Waveform Views)
    } m_icPlayBack;


// Operations
public:

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDocPowerNAP)
	public:
    virtual void Serialize(CArchive& ar);
    virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
    virtual void OnCloseDocument();
    virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
    CView * CreateOrActivateView(const CRuntimeClass * pClass);
    CViewPCA * GetViewPCAPtr();

    bool AddDataFile(LPCSTR szPathName);   // Add this data file to the list    
    void AddDataFilePrompt();
    bool AddDataFileUsingThisDLLPrompt();  // Add a data file to the list. Both the name 
                                           // of the DLL and the name of the data fill 
                                           // will be prompted for stating which DLL to use.

    bool DeleteEntity(uint32 dwEntityID);   // remove this entity from our document
    void DeleteUnitFromActiveSegment(UnitMasks enUnit); // remove this unit from the active segments
    void CompactUnitsFromActiveSegment();   // remove "holes" in the unit classifications
    void ReclassifyActiveSegment(UnitMasks enFrom, UnitMasks enTo); // convert every "from" unit to the "to" unit


    bool GetThresholding();         // TRUE means that the data is being modified with a threshold
    void SetThresholding(bool bOn); // Force the thresholding on/off
    double GetThreshold(DWORD dwEntity);    // Get the current threshold value for this channel
    void SetThreshold(DWORD dwEntity, double dThreshold);

    void RejectActiveEntity(double dRejectVal);         // remove indices with spikes that touch this value



    bool AreThereSegments();
    bool IsActiveSegment();
    bool IsSegment(int32 dwEntityID);
    bool AreThereAnalogs();
    bool IsActiveAnalog();
    bool IsAnalog(int32 dwEntityID);

    void SortActiveChannel(tagSortMethod nMethod, bool bRefresh = true);

    void SetTrainingPopulation(FileInfo & rsFileInfo, Segments & rcList, uint32 dwGroupCount,
                               uint32 dwTrainCount);

    bool DiscardEmptyEntities();

    //////////////////////////////////////////////////////////////////////////
    // These are all of the Neuroshare functions. Use these for smart testing
    ns_RESULT GetLibraryInfo(NsFile & rcFile, ns_LIBRARYINFO & LibraryInfo) const;
    ns_RESULT OpenFile(NsFile & rcFile, LPCSTR szDataName);
    ns_RESULT CloseFile(NsFile & rcFile);
    ns_RESULT GetFileInfo(NsFile & rcFile, ns_FILEINFO & FileInfo) const;
    ns_RESULT GetEntityInfo(NsFile & rcFile, uint32 dwEntityID, ns_ENTITYINFO & EntityInfo) const;
    ns_RESULT GetEventInfo(NsFile & rcFile, uint32 dwEntityID, ns_EVENTINFO & EventInfo) const;
    ns_RESULT GetEventData(NsFile & rcFile, uint32 dwEntityID, uint32 nIndex, double *pdTimeStamp, void *pData, uint32 dwDataSize, uint32 *pdwDataRetSize) const;
    ns_RESULT GetAnalogInfo(NsFile & rcFile, uint32 dwEntityID, ns_ANALOGINFO & AnalogInfo) const;
    ns_RESULT GetAnalogData(NsFile & rcFile, uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, uint32 *pdwContCount, double *pData) const;
    ns_RESULT GetSegmentInfo(NsFile & rcFile, uint32 dwEntityID, ns_SEGMENTINFO & SegmentInfo) const;
    ns_RESULT GetSegmentSourceInfo(NsFile & rcFile, uint32 dwEntityID, uint32 dwSourceID, ns_SEGSOURCEINFO & SourceInfo) const;
    ns_RESULT GetSegmentData(NsFile & rcFile, uint32 dwEntityID, int32 nIndex, double *pdTimeStamp, double *pdData, uint32 dwDataBufferSize, uint32 *pdwSampleCount, uint32 *pdwUnitID) const;
    ns_RESULT GetNeuralInfo(NsFile & rcFile, uint32 dwEntityID, ns_NEURALINFO & NeuralInfo) const;
    ns_RESULT GetNeuralData(NsFile & rcFile, uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, double *pdData) const;
    ns_RESULT GetIndexByTime(NsFile & rcFile, uint32 dwEntityID, double dTime, int32 nFlag, uint32 *pdwIndex) const;
    ns_RESULT GetTimeByIndex(NsFile & rcFile, uint32 dwEntityID, uint32 dwIndex, double *pdTime) const;
    ns_RESULT GetLastErrorMsg(NsFile & rcFile, char *pszMsgBuffer, uint32 dwMsgBufferSize) const;
    void ShowLastNsErrorMsg(NsFile & rcFile) const;


    // Save the current data to a NSN file
    bool SaveDataNoPrompt(LPCSTR szName);
    bool SaveDataPrompt();


#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

// Attributes
protected:
    CPropSheetSpkSorting m_icPropSheetSpkSorting;

    bool m_bThreshold;                      // TRUE means we should threshold the data; FALSE, not
    double m_dThreshold[256];               // Array of the threshold values of all entities
                                            // TODO: This should eventually be changed to something variable length (like a vector)
// Generated message map functions
protected:
    void GetTotalEntityItemCount();         // Re-read from disk to recreate the total number of items

    void SaveSegments(IWriteNSN & I);   // Save the current segments into this file
    void SaveAnalogs(IWriteNSN & I);    // Save the current analog types into this file

    bool AddDataFileUsingThisDLL(LPCSTR szDataPathName, LPCSTR szDllPathName);
    bool AppendToFileList(SPFileInfo psInfo);   // Add this data file to the list

    void BuildDataFilter(CString & rcFilter);   // Create the filter for all of the data files we use
                                                // Use this as a parameter for a file-open dialog
    
	CDocTemplate * GetTemplateFromClass(const CRuntimeClass * pClass);
	CPoint MakePointOnScreen(CPoint ptTest);

    void ThresholdThisEntity(DWORD dwEntity, bool bRebuildIfNecessary = false);
    void AppendSegmentListEntry(FileInfo & rsFileInfo, Segments & rcList);
    void AppendAnalogListEntry(FileInfo & rsFileInfo, Analogs & rcList);

    bool UpdateAllLists(FileInfo & rsFileInfo);   // Update all of the entity info and other lists
    void BuildEntityAndDataLists(FileInfo & rsFileInfo);  // Start building lists from scratch

    bool AppendEntityList(NsFile & rcFile, ENTITYINFOLIST::iterator & it, int32 nType);
    bool CompareEntityHeaders(NsFile & rcFileOld, NsFile & rcFileNew, int32 nType);

    void DeleteDataLists();
    bool DeleteEntityData(uint32 dwEntityID);

    CMainFrame *m_pMainFrm;

    ////////////////////////////// TypeIterator ////////////////////////

    class EntityInfoByTypeIterator
    {
    public:
        EntityInfoByTypeIterator(CDocPowerNAP * pDoc, ENTITYINFOLIST::iterator const & it, DWORD dwType) :
            m_pDoc(pDoc),
            m_it(it),
            m_dwType(dwType)
        {
            FindFirstMatch();
        }

        void operator ++ ()             // Advance to next
        {
            ++m_it; // Move off the current match
            FindFirstMatch();
        }
        ns_ENTITYINFO const & operator () () { return (*m_it).isEntityInfo; } // return the current value
        operator const void * () const { return m_it != m_pDoc->m_icEntityInfoVector.end() ? (void *)1 : (void *)0; }  // typecast operator: are we done yet? 0 = we are done

        DWORD GetCurrentIndex() { return (*m_it).dwEntityIndex; }

    private:
        CDocPowerNAP * m_pDoc;
        ENTITYINFOLIST::iterator m_it;  // The internal iterator we will use
        DWORD m_dwType;                 // The type we are looking for

        void FindFirstMatch()       // Advance to the first of the type we want
        {
            for (; m_it != m_pDoc->m_icEntityInfoVector.end(); ++m_it)
                if ((*m_it).isEntityInfo.dwEntityType == m_dwType)
                    return;
        }
    };

    ////////////////////////////// Dealing with the storing and retrieving of data files //////////

    // This is the file header
    class FileHeader : public CObject
    {
    public:
        BYTE m_byVersion;
        BYTE m_byFlavor;

        virtual void Serialize(CArchive & ar);
    };

    // This is data, that doesn't change on a per-file basis
    class GlobalData : public CObject
    {
    public:
        BYTE m_bySaturationCheck;       // TRUE means to saturation check; FALSE, not

        virtual void Serialize(CArchive & ar);
    };


// I really want this protected, but then 'serialize elements' won't work 'cuz it's a global
// function and I wouldn't be able to access a protected class.
public:

    class PerFileData : public CObject	    
    {
    public:
        PerFileData() {}
        PerFileData(PerFileData const & rhs);
        PerFileData & operator = (PerFileData const & rhs);

        CString m_strFilePathName;

        virtual void Serialize(CArchive & ar);
    };
    

    //{{AFX_MSG(CDocPowerNAP)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


class CDocPowerNAP;
class CViewPCA;

class GenericVisitable: public BaseVisitable <bool>
{
public:
    GenericVisitable(CDocPowerNAP * pDoc, CView * pView)
    {
        m_pcDoc = pDoc;
        m_pcView = pView;
    };

    DEFINE_VISITABLE();                     // needed by the visitors

    CDocPowerNAP * m_pcDoc;
//    CViewPCA * m_pcView;
//    CDocument * m_pcDoc;
    CView * m_pcView;
};



/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
