///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorKMeans.h $
//
// Description   : interface for the VisitorKMeans class.
//
// Authors       : Angela Wang
//
// $Date: 10/21/03 2:43p $
//
// $History: VisitorKMeans.h $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/29/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Removed function covcol
// Un comment lines to allow for variable # pc coord to be used for Kmeans
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/25/03    Time: 2:48p
// Updated in $/Neuroshare/nsClassifier
// Removed temporary matrices
// 
// *****************  Version 2  *****************
// User: Awang        Date: 8/18/03    Time: 11:40a
// Updated in $/Neuroshare/nsClassifier
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef VISITORKMEANS_H_INCLUDED
#define VISITORKMEANS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Visitor.h"
#include "DocPowerNAP.h"
#include "cmatrix"

class CDocPowerNAP;         // forward declare to avoid include

//
// typedef for different matrix types
//
typedef techsoft::matrix<double> Matrix;
typedef std::valarray<double>    Vector;



class VisitorKMeans :
    public BaseVisitor,          // required
    public Visitor<GenericVisitable, bool>
//    public Visitor<CDocPowerNAP, bool>
{
public:

//    bool Visit(CDocPowerNAP & data);
    bool Visit(GenericVisitable & data);

    void KMeans(Matrix &center, Matrix data, int nIterMax, int nClstrCnt);
    void InitCtrs(Matrix &U, int nClstrCnt, int nDataCnt);
    void DistL2Norm(Matrix &Dist, Matrix center, Matrix data);
    void trace(Matrix mtrace);



    void princomp(Matrix *pc, Matrix *score, Matrix data);
    void meancols(Matrix *meanc, Matrix data);
    void sumcols(Matrix *sumc, Matrix data);


    CDocPowerNAP * m_pData;


private:
    void FillWaves(double ** apdWaves, int nNumberOfWaves, int nNumOfPointsPerWave, CDocPowerNAP & rcDoc);
};


#endif // VISITORKMEANS_H_INCLUDED