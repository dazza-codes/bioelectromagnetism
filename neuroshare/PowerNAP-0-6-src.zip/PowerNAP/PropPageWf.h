///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageWf.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 1/30/04 3:54p $
//
// $History: PropPageWf.h $
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 1/30/04    Time: 3:54p
// Updated in $/Neuroshare/PowerNAP
// Streamlined data transfer.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPPAGEWF_H_INCLUDED
#define PROPPAGEWF_H_INCLUDED

#include "NumEdit.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropPageWf dialog

class CPropPageWf : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageWf)

// Construction
public:
	CPropPageWf();
	~CPropPageWf();

    BOOL m_bAlignMeanPt;
    int m_nWhatPeaks;

// Dialog Data
	//{{AFX_DATA(CPropPageWf)
	enum { IDD = IDD_PROPPAGE_WF };
	CEdit	m_lblNumPt;
	CStatic	m_lblNumPtTxt;
	CButton	m_rdoNegPeaks;
	CButton	m_rdoPosPeaks;
	CButton	m_rdoAllPeaks;
	CStatic	m_lblAlignPt;
	CButton	m_rdoMeanPeak;
	CButton	m_rdoAlignPt;
	CEdit   m_AlignPt;
	UINT	m_nAlignPt;
	UINT	m_nNumPt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPageWf)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPageWf)
	afx_msg void OnRdoAlignpoint();
	afx_msg void OnRdoMeanpeak();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg void OnRdoAllPeaks();
	afx_msg void OnRdoNegPeaks();
	afx_msg void OnRdoPosPeaks();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
