// (c) Copyright 2003 Cyberkinetics, Inc.
//
// $Workfile: nsNSNLibrary.h $
// $Archive: /Neuroshare/nsNSNLibrary/nsNSNLibrary.h $
// $Revision: 4 $
// $Date: 9/10/03 3:34p $
// $Author: Kkorver $
//
// $History: nsNSNLibrary.h $
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 9/10/03    Time: 3:34p
// Updated in $/Neuroshare/nsNSNLibrary
// BeginEntitySegment now accepts a single pointer, not a double pointer
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 9/10/03    Time: 2:19p
// Updated in $/Neuroshare/nsNSNLibrary
// Renamed Open...()  and Close...()  to Begin...() and End...()
// respectively
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 9/10/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Removed unneeded include file
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 9/04/03    Time: 5:10p
// Created in $/Neuroshare/nsNSNLibrary
// Renamed Interfaces.h to nsNSNLibrary.h
// 
// $NoKeywords: $
//  
//////////////////////////////////////////////////////////////////////////////

#ifndef NSNSNLIBRARY_H_INCLUDED       // include guards
#define NSNSNLIBRARY_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include "NsAPITypes.h"




enum InterfaceTypes
{
    IUNKNOWN,
    IWRITE_NSN,
};

struct IUnKnown
{
    virtual void AddRef() = 0;
    virtual void Release() = 0;
};




enum NsnTags
{
    NSN_ENTITY_UNKNOWN      = ns_ENTITY_UNKNOWN,
    NSN_ENTITY_EVENT        = ns_ENTITY_EVENT,
    NSN_ENTITY_ANALOG       = ns_ENTITY_ANALOG,
    NSN_ENTITY_SEGMENT      = ns_ENTITY_SEGMENT,
    NSN_ENTITY_NEURALEVENT  = ns_ENTITY_NEURALEVENT,
    NSN_INFO_FILE           = 5,  // File information
};

struct IWriteNSN : public IUnKnown
{
    virtual bool OpenFile(LPCSTR szFilename, bool bOverwrite) = 0;
    virtual void CloseFile(void) = 0;

    // To use these functions, Open an entity of the type you want, add data (below), then
    // Close the entity. Repeat as required. You CANNOT have more than 1 entity type open at a time

    virtual bool BeginEntityEvent(LPCSTR szLabel, LPCSTR szDescription, uint32 nEventType) = 0;
    virtual bool AddDataEvent(uint32 nEventType, void * pData, uint32 cbLength, double dTimeStamp) = 0;
    virtual void EndEntityEvent() = 0;

    virtual bool BeginEntityAnalog(LPCSTR szLabel, ns_ANALOGINFO * pcAnalogInfo) = 0;
    virtual bool AddDataAnalog(double dStartTime, uint32 nCount, double * pData) = 0;
    virtual bool AppendDataAnalog(uint32 nCount, double * pData) = 0;   // use this if you can't add all the data with AddDataAnalog
    virtual void EndEntityAnalog() = 0;

    virtual bool BeginEntityNeuralEvent(LPCSTR szLabel, ns_NEURALINFO * pcNeuralEventInfo) = 0;
    virtual bool AddDataNeuralEvent(uint32 nCount, double * pTimeStamps) = 0;
    virtual void EndEntityNeuralEvent() = 0;

    virtual bool BeginEntitySegment(LPCSTR szLabel, uint32 dwSourceCount, double dSampleRate, LPCSTR szUnits, ns_SEGSOURCEINFO * pcSegSourceInfo) = 0;
    virtual bool AddDataSegment(double dTimeStamp, uint32 dwUnitID, uint32 nSampleCount, double * aadData) = 0;
    virtual void EndEntitySegment() = 0;
};

extern "C" IUnKnown * WINAPI QueryInterface(InterfaceTypes enType);



template <class T>
class InterfaceClient
{
public:
    InterfaceClient(InterfaceTypes enType) { m_pInterface = dynamic_cast<T *>(QueryInterface(enType)); }
    ~InterfaceClient() { if (m_pInterface) m_pInterface->Release(); }

    operator T * () { return m_pInterface; }

protected:
    T * m_pInterface;
};






            
#endif  // Include Guards
