///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: HtmlFrameWnd.cpp $
//
// Description   : implementation of the CHtmlFrameWnd class
//
// Authors       : Almut Branner
//
// $Date: 10/21/03 2:43p $
//
// $History: HtmlFrameWnd.cpp $
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 5/14/03    Time: 8:26a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 4/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "HtmlFrameWnd.h"
#include "hlp\PowerNAPHelp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const DWORD CHtmlFrameWnd::m_nHelpIDs[] = 
{
    IDC_BTN_THRESHPLUS, IDH_BTN_THRESHPLUS,
    0, 0
};

/////////////////////////////////////////////////////////////////////////////
// CHtmlFrameWnd

IMPLEMENT_DYNCREATE(CHtmlFrameWnd, CFrameWnd)

CHtmlFrameWnd::CHtmlFrameWnd()
{
}

CHtmlFrameWnd::~CHtmlFrameWnd()
{
}


BEGIN_MESSAGE_MAP(CHtmlFrameWnd, CFrameWnd)
	//{{AFX_MSG_MAP(CHtmlFrameWnd)
    ON_COMMAND(ID_DEFAULT_HELP, OnHelpFinder)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlFrameWnd message handlers

void CHtmlFrameWnd::OnHelpFinder() 
{
    CString szDir = ((CAppPowerNAP*)AfxGetApp())->GetAppPath() + "\\PowerNAP.chm::/html\\afxc0wc8.htm";
    
    HtmlHelp(NULL, szDir, HH_DISPLAY_TOPIC, 0);
}

BOOL CHtmlFrameWnd::OnHelpInfo(HELPINFO* pHelpInfo) 
{
    CString szDir = ((CAppPowerNAP*)AfxGetApp())->GetAppPath() + "\\PowerNAP.chm::/PowerNAPHelp.txt";
    
    if (pHelpInfo->iContextType == HELPINFO_WINDOW)
    {
        return HtmlHelp((HWND)pHelpInfo->hItemHandle, szDir, HH_TP_HELP_WM_HELP, 
            (DWORD)(LPVOID)m_nHelpIDs) != NULL;
    }
    return TRUE;
}

