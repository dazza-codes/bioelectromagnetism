// (c) Copyright 2002, 2003 Cyberkinetics, Inc.
//
// $Workfile: DlgChooser.cpp $
// $Archive: /Neuroshare/nsClassifier/DlgChooser.cpp $
// $Revision: 2 $
// $Date: 10/07/03 9:37a $
// $Author: Abranner $
//
// $History: DlgChooser.cpp $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 9/15/03    Time: 5:48p
// Created in $/Neuroshare/nsClassifier
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 5/28/03    Time: 12:01p
// Created in $/Cerebus/WindowsApps/Raster
// Initial checkin of the "Chooser" window 
// 
// $NoKeywords: $
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ViewRaster.h"
#include "DlgChooser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CDlgChooser dialog


CDlgChooser::CDlgChooser(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChooser::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChooser)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CDlgChooser::FillCommonList(const CListBox & lstList, bool bChosen)
{
    for (int i = 0; i < lstList.GetCount(); ++i)
    {
        CString strLabel;

        DWORD id = lstList.GetItemData(i);
        lstList.GetText(i, strLabel);
        AddEntry(strLabel, id, bChosen);
    }
}

void CDlgChooser::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	//{{AFX_DATA_MAP(CDlgChooser)
	DDX_Control(pDX, IDC_BTN_REMOVE_ALL_FROM_SELECTED, m_btnRemoveAllFromSelected);
	DDX_Control(pDX, IDC_BTN_ADD_ALL_TO_SELECTED, m_btnAddAllToSelected);
	DDX_Control(pDX, IDC_BTN_REMOVE_FROM_SELECTED, m_btnRemoveFromSelected);
	DDX_Control(pDX, IDC_BTN_ADD_TO_SELECTED, m_btnAddToSelected);
	DDX_Control(pDX, IDC_LST_SELECTED, m_lstSelected);
	DDX_Control(pDX, IDC_LST_NOT_SELECTED, m_lstNotSelected);
	//}}AFX_DATA_MAP

    // If loading the dialog box
    if (pDX->m_bSaveAndValidate)
    {
        // Out with the old
        m_icList.clear();

        // First fill the chosen
        FillCommonList(m_lstSelected, true);

        // Now the non-chosen
        FillCommonList(m_lstNotSelected, false);
    }
    else
    {
        CHOSENLIST::iterator it;
        for (it = m_icList.begin(); it != m_icList.end(); ++it)
        {
            CListBox & lb = it->bChosen ? m_lstSelected : m_lstNotSelected;

            int nEntry = lb.AddString(it->strLabel);
            lb.SetItemData(nEntry, it->dwID);
        }
    }
}


// Author & Date:   Kirk Korver     23 May 2003
// Purpose: Add an element into the "chosen" list
// Inputs:  szLabel - the string to display
//          dwID - unique identifier for the label
//          bChosen - TRUE means it is chosen; FALSE, it is not chosen
void CDlgChooser::AddEntry(LPCSTR szLabel, DWORD dwID, bool bChosen)
{
    ChosenElement e(CString(szLabel), dwID, bChosen);
    m_icList.push_back(e);
}



BEGIN_MESSAGE_MAP(CDlgChooser, CDialog)
	//{{AFX_MSG_MAP(CDlgChooser)
	ON_LBN_SETFOCUS(IDC_LST_NOT_SELECTED, OnLstNotSelectedSetFocus)
	ON_LBN_SETFOCUS(IDC_LST_SELECTED, OnLstSelectedSetfocus)
	ON_BN_CLICKED(IDC_BTN_ADD_TO_SELECTED, OnBtnAddToSelected)
	ON_BN_CLICKED(IDC_BTN_REMOVE_FROM_SELECTED, OnBtnRemoveFromSelected)
	ON_BN_CLICKED(IDC_BTN_REMOVE_ALL_FROM_SELECTED, OnBtnRemoveAllFromSelected)
	ON_BN_CLICKED(IDC_BTN_ADD_ALL_TO_SELECTED, OnBtnAddAllToSelected)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChooser message handlers

void CDlgChooser::OnLstNotSelectedSetFocus() 
{
    m_lstSelected.SelItemRange(false, 0, m_lstSelected.GetCount() - 1);
    m_btnAddToSelected.EnableWindow(true);
    m_btnRemoveFromSelected.EnableWindow(false);
}

void CDlgChooser::OnLstSelectedSetfocus() 
{
    m_lstNotSelected.SelItemRange(false, 0, m_lstNotSelected.GetCount() - 1);
    m_btnAddToSelected.EnableWindow(false);
    m_btnRemoveFromSelected.EnableWindow(true);
}

void CDlgChooser::OnBtnAddToSelected() 
{
    MoveSelections(m_lstSelected, m_lstNotSelected);
}

void CDlgChooser::OnBtnRemoveFromSelected() 
{
    MoveSelections(m_lstNotSelected, m_lstSelected);
}

void CDlgChooser::MoveSelections(CListBox & lstTo, CListBox & lstFrom)
{
    int nCount = lstFrom.GetSelCount();

    std::vector <int> apIndex(nCount);

    lstFrom.GetSelItems(nCount, apIndex.begin() );

    std::vector <int>::iterator it;


    // Copy to the new
    for (it = apIndex.begin(); it != apIndex.end(); ++it)
    {
        int nIndex = *it;

        CString strLabel;

        DWORD id = lstFrom.GetItemData(nIndex);
        lstFrom.GetText(nIndex, strLabel);
 
        int nEntry = lstTo.AddString(strLabel);
        lstTo.SetItemData(nEntry, id);
    }

    // Remove from the old
    // This is done in backwards order so that I don't have to worry about
    // the re-ordering as things are being deleted
    std::vector<int>::reverse_iterator rit;
    for (rit = apIndex.rbegin(); rit != apIndex.rend(); ++rit)
    {
        lstFrom.DeleteString(*rit);
    }
}

void CDlgChooser::MoveAll(CListBox & lstTo, CListBox & lstFrom)
{
    int nCount = lstFrom.GetCount();

    // Copy to the new
    for (int nIndex = 0; nIndex < nCount; ++nIndex)
    {
        CString strLabel;

        DWORD id = lstFrom.GetItemData(nIndex);
        lstFrom.GetText(nIndex, strLabel);
 
        int nEntry = lstTo.AddString(strLabel);
        lstTo.SetItemData(nEntry, id);
    }

    // Remove from the old
    lstFrom.ResetContent();
}


void CDlgChooser::OnBtnRemoveAllFromSelected() 
{
    MoveAll(m_lstNotSelected, m_lstSelected);
}

void CDlgChooser::OnBtnAddAllToSelected() 
{
    MoveAll(m_lstSelected, m_lstNotSelected);
}

BOOL CDlgChooser::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    m_icToolTip.Create(this);

    //                                Control ID                          String table entry
    m_icToolTip.AddTool(GetDlgItem(IDC_BTN_ADD_TO_SELECTED),            IDC_BTN_ADD_TO_SELECTED);
    m_icToolTip.AddTool(GetDlgItem(IDC_BTN_REMOVE_FROM_SELECTED),       IDC_BTN_REMOVE_FROM_SELECTED);
    m_icToolTip.AddTool(GetDlgItem(IDC_BTN_ADD_ALL_TO_SELECTED),        IDC_BTN_ADD_ALL_TO_SELECTED);
    m_icToolTip.AddTool(GetDlgItem(IDC_BTN_REMOVE_ALL_FROM_SELECTED),   IDC_BTN_REMOVE_ALL_FROM_SELECTED);

    m_icToolTip.Activate(true);
    
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgChooser::PreTranslateMessage(MSG* pMsg) 
{
    // We need to let the tool tips have a chance to display
    m_icToolTip.RelayEvent(pMsg);
	
	return CDialog::PreTranslateMessage(pMsg);
}
