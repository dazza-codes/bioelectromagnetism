// (c) Copyright 2003 Cyberkinetics, Inc.
//
// $Workfile: FileVersion.cpp $
// $Archive: /Cerebus/WindowsApps/Central/FileVersion.cpp $
// $Revision: 2 $
// $Date: 4/22/03 9:40a $
// $Author: Kkorver $
//
// $History: FileVersion.cpp $
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 4/22/03    Time: 9:40a
// Updated in $/Cerebus/WindowsApps/Central
// Added GetVersionString()
// On Construction, if the filename is NULL, then the version info is read
// from the current application
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 3/07/03    Time: 5:00p
// Created in $/Cerebus/WindowsApps/Central
// This class deals with finding the version of a file
// 
// 
// $NoKeywords: $
//
// FileVersion.cpp: implementation of the FileVersion class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FileVersion.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

FileVersion::FileVersion(LPCSTR szFileName /* = NULL */) :
    m_bIsOK(false)
{
    // Clear out the array by default
    memset(m_anVersions, 0, sizeof m_anVersions);
    
    if (szFileName)
    {
        DWORD dwHandle;         // needed for API calls below
        BYTE * pbyData = NULL;  // The data for the file version info
        DWORD cbLen;            // The lengthe of the buffer above
        
        if (!szFileName)
            return;
        
        cbLen = ::GetFileVersionInfoSize(const_cast<char *>(szFileName), &dwHandle);
        if (cbLen)
        {
            pbyData = new BYTE [cbLen];
        
            if (0 != ::GetFileVersionInfo(const_cast<char *>(szFileName), dwHandle, cbLen, pbyData))
                ReadVersions(pbyData);

            delete [] pbyData;

        }
    }
    else    
    {
        // in this case, we want to get the version info from the current file

        // Get the Resource handle
        HRSRC hVersionInfoResourceBlock = FindResource(NULL, (const char *)VS_VERSION_INFO, RT_VERSION);
    
        // If the resource block exists, put on the version information
        if (hVersionInfoResourceBlock)
        {
            // Get handle to the Version Info resource
            HGLOBAL hVersionInfoResource = LoadResource(NULL, hVersionInfoResourceBlock);
            UINT dwVersionInfoResourceSize = SizeofResource( NULL, hVersionInfoResourceBlock);
        
            // Get pointer to the resource data
            LPVOID pvVersionInfoData = LockResource(hVersionInfoResource);
        
            ReadVersions(pvVersionInfoData);
        }
    }
}

FileVersion::~FileVersion()
{
}


void FileVersion::ReadVersions(LPVOID pvData)
{
    UINT cbLen;
    void * pVoid;
    if (!pvData ||
        0 == ::VerQueryValue(pvData, "\\", &pVoid, &cbLen))
    {
        // In the case where we can't figure anything out, set the versions to 0
        m_anVersions[MAJOR] = 0;
        m_anVersions[MINOR] = 0;
        m_anVersions[RELEASE] = 0;
        m_anVersions[BUILD] = 0;
    }
    else    // Ok, this is what to do if we found data
    {
        VS_FIXEDFILEINFO * pInfo = reinterpret_cast<VS_FIXEDFILEINFO *>(pVoid);

        m_anVersions[MAJOR] = HIWORD(pInfo->dwFileVersionMS);
        m_anVersions[MINOR] = LOWORD(pInfo->dwFileVersionMS);
        m_anVersions[RELEASE] = HIWORD(pInfo->dwFileVersionLS);
        m_anVersions[BUILD] = LOWORD(pInfo->dwFileVersionLS);
        
        m_bIsOK = true;
    }
}

// Author & Date:   Kirk Korver     Apr 22, 2003
// Get the version information in "string" format
// e.g.  1.3.34.5
// This will overwrite any string 
void FileVersion::GetVersionString(CString & strVersion)
{
    strVersion.Format("%i.%i.%i.%i", 
                       m_anVersions[MAJOR],
                       m_anVersions[MINOR],
                       m_anVersions[RELEASE],
                       m_anVersions[BUILD]);
}



