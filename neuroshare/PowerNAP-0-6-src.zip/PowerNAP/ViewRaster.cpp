///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003, 2004  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Kirk Korver
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  kkorver@cyberkineticsinc.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewRaster.cpp $
//
// Description   : interface of the CMainFrameRaster class
//
// Authors       : Almut Branner
//
// $Date: 3/04/04 5:26p $
//
// $History: ViewRaster.cpp $
// 
// *****************  Version 23  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:35p
// Updated in $/Neuroshare/PowerNAP
// Added Animation for playback
// Added XfmWorldToScreenX()
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:48p
// Updated in $/Neuroshare/PowerNAP
// GetTime() no longer needs the EntityID passed to it
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 2/24/04    Time: 1:52p
// Updated in $/Neuroshare/PowerNAP
// Prevent divide by 0 errors
// 
// *****************  Version 19  *****************
// User: Kkorver      Date: 2/24/04    Time: 1:25p
// Updated in $/Neuroshare/PowerNAP
// Bug fix: need to adjust the sign of the largest number
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 2/24/04    Time: 12:59p
// Updated in $/Neuroshare/PowerNAP
// The raster view now scales based upon the input. Additionally, it will
// now handle "gaps"
// 
// *****************  Version 17  *****************
// User: Abranner     Date: 2/10/04    Time: 10:17a
// Updated in $/Neuroshare/PowerNAP
// Changed unit selection to UINT instead of BYTE to include more units.
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 10/27/03   Time: 10:36a
// Updated in $/Neuroshare/PowerNAP
// Only channels with activity on them are now shown.
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 10/17/03   Time: 4:01p
// Updated in $/Neuroshare/nsClassifier
// Chopped out unnecessary code.
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 10/17/03   Time: 2:06p
// Updated in $/Neuroshare/nsClassifier
// Fix analog channel view. Fixed problems with multiline mode.
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 10/17/03   Time: 1:03p
// Updated in $/Neuroshare/nsClassifier
// Turned raster combo box to change rate into buttons. Partially fixed
// single-to-multiline mode. Updating sorting algorithms.
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:51a
// Updated in $/Neuroshare/nsClassifier
// updated the AnalogData to match the new Data format
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 10/16/03   Time: 2:09p
// Updated in $/Neuroshare/nsClassifier
// Removed unnecessary code.
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 10/15/03   Time: 6:07p
// Updated in $/Neuroshare/nsClassifier
// Changed how units are drawn and the initialization of the view to deal
// with updating the view when necessary.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/08/03   Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with scrolling (don't override PreCreateWindow()). Also
// fixed unit selection (Have to call OnPrepareDC() before using DPtoLP
// and so on). Removed code not needed.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 9/15/03    Time: 11:13a
// Updated in $/Neuroshare/nsClassifier
// Adjusted the Debug/Release versions of GetDocument()
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include <search.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "MainFrameRaster.h"
#include "ViewRaster.h"
#include "DlgChooser.h"
#include "ns_common.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Channel Iterators


// Author & Date:   Kirk Korver     27 May 2003
// Inputs:
//  pChannelList - array of channels that are available for use 
//  nChannelCount - the number of entries in the list
CViewRaster::ChannelIterator::ChannelIterator(UINT * pChannelList, UINT nChannelCount) :
    m_nIndex(0),
    m_pChannels(pChannelList),
    m_nChannelCount(nChannelCount)
{
}

// Author & Date:   Kirk Korver     27 May 2003
CViewRaster::ChannelIterator::~ChannelIterator()
{
}


// Author & Date:   Kirk Korver     27 May 2003
// Purpose: Get the number of the current channel (1 based)
UINT CViewRaster::ChannelIterator::GetChannelNum()
{
    ASSERT(m_nIndex < m_nChannelCount);

    return m_pChannels[m_nIndex];
}


// Author & Date:   Kirk Korver     27 May 2003
// Purpose: Are we done?
// Outputs:
//  TRUE means there is still more; FALSE, means we are done
CViewRaster::ChannelIterator::operator const bool () const
{
    return m_nIndex < m_nChannelCount;
}

// Author & Date:   Kirk Korver     27 May 2003
// Purpose: Advance to the next
void CViewRaster::ChannelIterator::operator++()
{
    ++m_nIndex;
}


/////////////////////////////////////////////////////////////////////////////
// CViewRaster

IMPLEMENT_DYNCREATE(CViewRaster, QZoomView)

CViewRaster::CViewRaster()
{
    m_pToolBar = NULL;

    // create a font for the frame display
    m_fntLabel.CreateFont(-6, -6, 0, 0, FW_THIN, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEVICE_PRECIS, 
        CLIP_DEFAULT_PRECIS, PROOF_QUALITY, VARIABLE_PITCH, "RasterFont" );
}

CViewRaster::~CViewRaster()
{
}


BEGIN_MESSAGE_MAP(CViewRaster, QZoomView)
	//{{AFX_MSG_MAP(CViewRaster)
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_REFRESHSCREEN, OnBtnRefreshScreen)
	ON_COMMAND(ID_DELETE, OnBtnDelete)
	ON_COMMAND(ID_UP, OnBtnUp)
	ON_COMMAND(ID_DOWN, OnBtnDown)
	ON_COMMAND(ID_MULTILINEMODE, OnBtnMultiLineMode)
	ON_COMMAND(ID_SINGLELINEMODE, OnBtnSingleLineMode)
	ON_COMMAND(ID_CHOOSER, OnBtnChooser)
	ON_COMMAND(ID_CLEARALL, OnBtnClearAll)
	ON_COMMAND(ID_ADDALL, OnBtnAddAll)
	ON_COMMAND(ID_MIN, OnBtnMin)
	ON_COMMAND(ID_MAX, OnBtnMax)
	ON_COMMAND(ID_EVENTS, OnBtnEvents)
	ON_COMMAND(ID_CONT, OnBtnCont)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_BIGGER, OnBtnBigger)
	ON_COMMAND(ID_SMALLER, OnBtnSmaller)
	ON_COMMAND(ID_SORT, OnBtnSort)
	ON_COMMAND(ID_SORT_CHANNEL, OnBtnSortChannel)
	ON_COMMAND(ID_SORT_MODE, OnBtnSortMode)
	ON_COMMAND(ID_SORT_UNITS, OnBtnSortUnits)
	ON_COMMAND(ID_EDIT_SELECT_ALL, OnBtnSelectAll)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_ZOOMFULL, OnViewZoomfull)
	ON_COMMAND(ID_VIEW_ZOOMIN, OnZoomIn)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMIN, OnUpdateZoomIn)
	ON_COMMAND(ID_ZOOMINONE, OnZoomInOne)
	ON_COMMAND(ID_VIEW_ZOOMOUT, OnZoomOut)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMOUT, OnUpdateZoomOut)
	ON_COMMAND(ID_ZOOMOUTONE, OnZoomOutOne)
	ON_COMMAND(ID_ZOOMTOWINDOW, OnZoomToWindow)
	ON_COMMAND(ID_HAND, OnHand)
	ON_UPDATE_COMMAND_UI(ID_HAND, OnUpdateHand)
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_NARROWER, OnBtnNarrower)
	ON_COMMAND(ID_WIDER, OnBtnWider)
	ON_COMMAND(ID_EDIT_DELETE, OnBtnDelete)
	ON_COMMAND(ID_ZOOMIN, OnZoomIn)
	ON_UPDATE_COMMAND_UI(ID_ZOOMIN, OnUpdateZoomIn)
	ON_COMMAND(ID_ZOOMOUT, OnZoomOut)
	ON_UPDATE_COMMAND_UI(ID_ZOOMOUT, OnUpdateZoomOut)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CViewRaster diagnostics

#ifdef _DEBUG
void CViewRaster::AssertValid() const
{
	QZoomView::AssertValid();
}

void CViewRaster::Dump(CDumpContext& dc) const
{
	QZoomView::Dump(dc);
}

CDocPowerNAP* CViewRaster::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*) m_pDocument;
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CViewRaster message handlers


int CViewRaster::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (QZoomView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    m_pToolBar = &((CMainFrameRaster *) GetParentFrame())->m_wndToolBar;
    ((CMainFrameRaster *) GetParentFrame())->m_pwndView = (CViewRaster *) this;
    
	// Load the cursors
	UINT idCursors[] = 
	{
		IDC_LOUPE, IDC_LOUPEPLUS, IDC_LOUPEMINUS, IDC_GRIPOPEN, IDC_GRIPCLOSED
	};
	for (int i = 0; i < sizeof(idCursors) / sizeof(UINT); i++)
		VERIFY(LoadCursor(i, idCursors[i]));

	// Optionally, set another list of zoom presets than the default.
	float PresetZoomFactors[] =
	{
		0.35f, 0.5f, 0.7f, 1.0f, 1.4f, 2.0f, 2.8f, 4.0f, 5.6f, 8.0f
	};
	int nPresets(sizeof(PresetZoomFactors) / sizeof(float));
	SetPresets(PresetZoomFactors, nPresets);

    SetZoomMode(ZoomViewOff);

    // By default, we are checked
    m_bSingleLineFormat = true;

    // Initialize the frame period
    m_uFrameWidth = ENUMWIDTH_20;

    m_bInitialized = false;

	return 0;
}


// Author & Date:   Kirk Korver     01 Mar 2004
// Purpose: time to update the screen, and it is because it
//  is time to do a "normal" screen redraw...as opposed to animation
// Inputs:
//  see OnUpdate()
void CViewRaster::OnUpdateNormal(CView* pSender, LPARAM lHint, CObject* pHint)
{
    bool bSingleLineFormat = m_bSingleLineFormat;
    m_bSingleLineFormat = true;

    ResetData();  // Initialize all variables associated with channels

    UpdateChannelsAvailable();  // Update available channels list

    InitLines();
    m_bSingleLineFormat = bSingleLineFormat;

    if (m_bSingleLineFormat)
        RestartRasterPlot();
    else
        OnChangeLineMode();
    
    m_bInitialized = true;
}

// Author & Date:   Kirk Korver     01 Mar 2004
// Purpose: time to update the screen, and it is because we
//  are now "animating"
// Inputs:
//  see OnUpdate()
void CViewRaster::OnUpdateAnimate(CView* pSender, LPARAM lHint, CObject* pHint)
{
    // Ok, if animate isn't active, then it is because we are done animating
    if (GetDocument()->m_icPlayBack.m_bPlayBackActive == false)
    {
        OnUpdateNormal(pSender, lHint, pHint);
        m_isAnimate.m_bIsLineVisible = false;
    }
    else
    {
        m_isAnimate.m_bDrawAnimate = true;
        Invalidate(false);
    }
}

// Author & Date:   Kirk Korver     01 Mar 2004
// Purpose: draw the vertical time bar used for animation
// Inputs:
//  rcDC - the DC to draw onto
//  dTime - the time where this bar is to be drawn
//  nRasterOps - the raster operations to use (see SetROP2 )
void CViewRaster::DrawAnimateLine(CDC & rcDC, double dTime, int nRasterOps)
{
    int nX = XfmWorldToScreenX(dTime);
    COLORREF & rClr = GetDocument()->m_icColorTable.dispchansel[2];
    rcDC.SetROP2(nRasterOps);

    CPen icPen(PS_SOLID, 1, rClr);
    HGDIOBJ hOldPen = rcDC.SelectObject(icPen);
    if (m_isAnimate.m_bIsLineVisible)                       // if the line was visible, we need 
    {                                                       // to erase it
        rcDC.MoveTo(m_isAnimate.m_nLastX, 0);
        rcDC.LineTo(m_isAnimate.m_nLastX, m_uTotalHeight);
    }
    rcDC.MoveTo(nX, 0);
    rcDC.LineTo(nX, m_uTotalHeight);

    rcDC.SelectObject(hOldPen);

    m_isAnimate.m_nLastX = nX;
    m_isAnimate.m_bIsLineVisible = true;
}

// Author & Date:   Almut Branner   14 Oct 2003
void CViewRaster::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
    if (lHint == HINT_USER_ANIMATING)
        OnUpdateAnimate(pSender, lHint, pHint);
    else
        OnUpdateNormal(pSender, lHint, pHint);
}


// Author & Date:   Almut Branner   17 Sept 2003
// Purpose: This function is required for CSrollView, similar function as OnPaint
void CViewRaster::OnDraw(CDC* pDC) 
{
    if (m_isAnimate.m_bDrawAnimate)
    {
        m_isAnimate.m_bDrawAnimate = false;
        DrawAnimateLine(*pDC, GetDocument()->m_icPlayBack.m_dTime, R2_XORPEN);
    }
    else
    {
        CRect rect;
        pDC->GetClipBox(&rect);

#define MIN(x, y) ( x < y ? x : y)
#define MAX(x, y) ( x > y ? x : y)

        int nStartLine = GetLine(rect.top);
        int nStopLine = GetLine(rect.bottom);
        PaintFrameDisplay(*pDC, MAX(0, nStartLine), MIN(m_uLineCount - 1, nStopLine));

        if (m_isAnimate.m_bIsLineVisible)
        {
            TRACE("Here\n");
            DrawAnimateLine(*pDC, GetDocument()->m_icPlayBack.m_dTime, R2_COPYPEN);
        }
#undef MIN
#undef MAX

    }
}


// Author & Date:   Almut Branner   23 July 2003
// Purpose: Get the line to a particular position.
// Input:   nPos - the current y position in the DC
// Output:  The line corresponding to the position
int CViewRaster::GetLine(UINT nPos)
{
    for (UINT nLine = 0; nLine < m_uLineCount; ++nLine)
    {
        if ( (nPos >= (m_uLineOffsetY[nLine] - (m_uLineSize[nLine] >> 1)))
           &&(nPos <= (m_uLineOffsetY[nLine] + (m_uLineSize[nLine] >> 1))) )
        {
            return nLine;
        }
    }
    return -1;
}


// Author & Date:   Almut Branner   11 July 2003
// Purpose: Repaint specific lines on the screen
void CViewRaster::PaintFrameDisplay(CDC & rcDC, UINT nStartLine, UINT nStopLine)
{
    CRect rect;
    rcDC.GetClipBox(&rect);
    CDocPowerNAP * pDoc = GetDocument();

    if (m_uLineCount != 0)
    {
        // Repaint the labels and the data
        rcDC.SelectObject(&m_fntLabel);

        for (UINT nLine = nStartLine; nLine <= nStopLine; ++nLine)
        {
            // create a RECT structure for fitting the label in the frame buffer
            DrawLabel(rcDC, nLine);

            if (rect.right >= FRAME_LABELWIDTH - 1)
            {
                int diff = rect.right - (m_uTotalWidth - MARGINRIGHT);
                if (diff >= 0)
                    rcDC.FillSolidRect(FRAME_LABELWIDTH - 1, m_uLineOffsetY[nLine], 
                        rect.right - FRAME_LABELWIDTH + 1 - diff, 1, 
                        pDoc->m_icColorTable.dispgridmin);
                else
                    rcDC.FillSolidRect(FRAME_LABELWIDTH - 1, m_uLineOffsetY[nLine], 
                        rect.right - FRAME_LABELWIDTH + 1, 1, pDoc->m_icColorTable.dispgridmin);

                DrawLine(rcDC, nLine);
            }
        }
    }
    else
        rcDC.FillSolidRect(rect.left, rect.top, rect.right, rect.bottom, 
            pDoc->m_icColorTable.dispback);
}


HCURSOR CViewRaster::OnQueryDragIcon() 
{
    return (HCURSOR) m_hIcon;
}


// Author & Date:   Almut Branner   18 Sept 2003
// Purpose: Top level, clear and restart the painting with the current settings
inline void CViewRaster::RestartRasterPlot()
{
    // Re-Initilialize and Re-paint the Raster Display
    InitRasterDisplay();
    Invalidate();
    if (m_bInitialized)
        OnChangeChannels();
}


// Author & Date:   Almut Branner   16 Sept 2003
// Purpose: Find all available channels
void CViewRaster::UpdateChannelsAvailable()
{
    // initialize the available channel variables
    m_uChanAvailCount = 0;

    CDocPowerNAP * pDoc = GetDocument();
    for (SEGMENTENTITYLIST::iterator sit = pDoc->m_icSegmentList.begin();
         sit < pDoc->m_icSegmentList.end(); ++sit)
    {
        // add this channel to the available channel list
        m_uChanAvailList[m_uChanAvailCount++] = (*sit)->GetEntityID();
    }

    for (ANALOGENTITYLIST::iterator ait = pDoc->m_icAnalogList.begin();
         ait < pDoc->m_icAnalogList.end(); ++ait)
    {
        // add this channel to the available channel list
        m_uChanAvailList[m_uChanAvailCount++] = (*ait)->GetEntityID();
    }

    // if channels are available set the position to the first channel
    if (m_uChanAvailCount)
        OnChangeChannels();
}


// Author & Date:   Almut Branner     11 July 2003
// Purpose: Initialize Raster, meaning reset data and calculate offsets for lines.
// Inputs:  rcDC - reference to the DC we are supposed to draw onto
void CViewRaster::InitRasterDisplay()
{
    UINT uTopOffset = TOPOFFSET;

    // create the label fields and initialize the line size/position variables
    for (int nLine = 0; nLine < m_uLineCount; ++nLine)
    {
        // compute the vertical offsets for the line and udpate the running offset
        // (Note: the raster line sizes (height of the fields) are all odd values)
        m_uLineSize[nLine] = enumlinesizeval[m_uIDSizeID[m_uLine2ID[nLine]]];

        m_uLineOffsetY[nLine] = uTopOffset + (m_uLineSize[nLine]/2); 
        uTopOffset += m_uLineSize[nLine];
    }

    m_uTotalHeight = m_uLineOffsetY[m_uLineCount - 1] + (m_uLineSize[m_uLineCount - 1] >> 1)
                     + TOPOFFSET;
    m_uTotalWidth = GetMaxWidth();

    SetScrollSizes(MM_TEXT, CSize(m_uTotalWidth, m_uTotalHeight), CSize(70, 70), CSize(7, 7));
}

struct MinIgnoreSign
{
    bool operator()(const double lhs, const double rhs)
    {
        return fabs(lhs) < ::fabs(rhs);
    }
};

// Author & Date:   Almut Branner   15 July 2003
// Purpose: Draw data for a particular line
// Inputs:  nLine - Line to draw
void CViewRaster::DrawLine(CDC & rcDC, UINT nLine)
{
    UINT nChannel = GetChannel4Line(nLine);

    // TODO: Maybe add drawing of gridmin
//    rcDC.FillSolidRect(nTimepoint + FRAME_LABELWIDTH - 1, m_uLineOffsetY[nLine],
//        1, 1, m_icColorTable.dispgridmin);

    // iterate through the entities on this channel
    CDocPowerNAP * pDoc = GetDocument();
    if (pDoc->IsSegment(nChannel))
    {
        Segments & seg = pDoc->GetSegment(nChannel);
        // What unit is this line?
        DWORD dwLineUnitID = GetBITUnit(GetUnit4Line(nLine));

        for (SEGMENTLIST::iterator sit = seg.begin(); sit != seg.end(); ++sit)
        {
            // What unit is the current segment?
            DWORD dwUnitID = (*sit).GetUnitID();

            // Does it match the line?
            if ((m_bSingleLineFormat) || (dwLineUnitID == dwUnitID))
            {
                double dTimeStamp = (*sit).GetTime();  // Time in seconds
                int nColor = pDoc->GetBITUnitColor(dwUnitID);

                UINT nTimepoint = (int) (dTimeStamp * 1000) / enumwidthval[m_uFrameWidth];

                DrawLineEvents(rcDC, nTimepoint, nLine, nColor);
            }
        }
    }
    else if (pDoc->IsAnalog(nChannel))
    {
        Analogs & ana = pDoc->GetAnalog(nChannel);
        for (ANALOGLIST::iterator ait = ana.begin(); ait != ana.end(); ++ait)
        {
            double dSampleRate = ana.GetSampleRate();
            UINT nTimepoint = 0;

            WAVEFORM aicWave;
            (*ait).GetWave(aicWave);

            // Adjust the scaling of this channel based upon the min/max values dispalyed
            double dMax = ::fabs(*std::max_element(aicWave.begin(), aicWave.end(), MinIgnoreSign()));
            dMax += 1.0;        // Don't let divide by 0 happen, also prevents clipping
            m_nChanScale[nChannel] = int(dMax);
            
            // Figure out maximum positive and negative values for this timepoint (for the "bars")
            INT16 nMin = *aicWave.begin();
            INT16 nMax = *aicWave.begin();

            int nCount = 1;
            for (WAVEFORM::iterator it = aicWave.begin() + 1; it != aicWave.end(); ++it)
            {
                bool bTimeChanged = false;
                double dTimeStamp = (*ait).GetTimeByIndex(nCount);

                UINT nCurrentTimepoint = (int) (dTimeStamp * 1000) / enumwidthval[m_uFrameWidth];

                // We are moving on to the next timepoint
                if (nTimepoint != nCurrentTimepoint)
                {
                    // Draw the last timepoint and then move on
                    DrawLineContinuous(rcDC, nTimepoint, nLine, nMin, nMax);
                    nTimepoint = nCurrentTimepoint;
                    bTimeChanged = true;
                }

                // Reset values
                if (bTimeChanged)
                {
                    nMin = *(it - 1);
                    nMax = *(it - 1);
                }
        
                if (*it < nMin)
                    nMin = *it;
                if (*it > nMax)
                    nMax = *it;

                ++nCount;
            }
        }
    }
}


// Author & Date:   Almut Branner   22 May 2003
// Purpose: Draw the continuous waveforms right here
// Inputs:  rcDC - reference to the DC we are supposed to draw onto
//          nTimepoint - which timepoint to draw
//          nLine - which scanline on the display to draw
void CViewRaster::DrawLineContinuous(CDC & rcDC, UINT nTimepoint, UINT nLine, INT16 nContMin, INT16 nContMax)
{
    int rng  = m_uLineSize[nLine] >> 1;

    int nScaling = m_nChanScale[GetChannel4Line(nLine)];

    // clip to the space we got
    int ymin = clip((int) nContMin * rng / nScaling, -rng, rng );
    int ymax = clip((int) nContMax * rng / nScaling, -rng, rng );

    int y = m_uLineOffsetY[nLine] - ymax;
    int cy = ymax - ymin + 1;

    rcDC.FillSolidRect(nTimepoint + FRAME_LABELWIDTH - 1, y, 1, cy, GetDocument()->m_icColorTable.dispwave);
}


// Author & Date:   Kirk Korver     02 Mar 2004
// Purpose: convert the X-coordinate from world units, to screen units
// Inputs:
//  dTime - the time we want converted (in seconds)
// Outputs:
//  the X value of this position
inline int CViewRaster::XfmWorldToScreenX(double dTime)
{
    int nTimepoint = (dTime * 1000) / enumwidthval[m_uFrameWidth];
    nTimepoint += FRAME_LABELWIDTH;
    return nTimepoint;
}


// Author & Date:   Almut Branner   22 May 2003
// Purpose: draw the events onto the line
// Inputs:  rcDC - reference to the DC we are supposed to draw onto
//          nTimepoint - which timepoint to draw
//          nLine - which scanline on the display to draw
//          nColor - which color to draw the event in
void CViewRaster::DrawLineEvents(CDC & rcDC, UINT nTimepoint, UINT nLine, int nColor)
{
    UINT32 nYPos = m_uLineOffsetY[nLine];
    register UINT32 nHeight = m_uLineSize[nLine] >> 1;
    nYPos -= nHeight >> 1; // divided by 2

    // We want to have 2 pixels between each scan line
    rcDC.FillSolidRect(nTimepoint + FRAME_LABELWIDTH - 1, nYPos, 1, nHeight, nColor);
}


// Author & Date:   Almut Branner     25 June 2003
// Purpose: Update unit selection on all channels
void CViewRaster::UpdateUnitSelections()
{
    // Invalidate all visible channel labels
    CRect rect;
    CClientDC dc (this);

    OnPrepareDC(& dc);
    GetClientRect(rect);
    dc.DPtoLP(&rect);
    rect.right = FRAME_LABELWIDTH - 1;
    dc.LPtoDP(&rect);

    InvalidateRect(rect, false);
}


// Author & Date:   Almut Branner     25 June 2003
// Purpose: Select a unit on a channel
void CViewRaster::SelectUnit(int nChannel, Units enUnit)
{
    // Select all units
    if (enUnit == ALL)
        m_anUnitSelections[nChannel] = UNIT_ALL_MASK;
    else if (enUnit < MAXLINESPERCHANS)
        m_anUnitSelections[nChannel] |= GetBITUnit(enUnit);

    if (m_nLastSelElec != nChannel)
    {
        m_nPrevSelElec = m_nLastSelElec;
        m_nLastSelElec = nChannel;
    }
    if (m_nLastSelUnit != enUnit)
        m_nLastSelUnit = enUnit;
}


// Author & Date:   Almut Branner     25 June 2003
// Purpose: Unselect a unit on a channel
void CViewRaster::UnselectUnit(int nChannel, Units enUnit)
{
    // Unselect unit
    if (enUnit == ALL)
        m_anUnitSelections[nChannel] = 0;
    else if (enUnit < MAXLINESPERCHANS)
        m_anUnitSelections[nChannel] ^= GetBITUnit(enUnit);
}


// Author & Date:   Almut Branner     1 July 2003
// Purpose: Select a line
void CViewRaster::SelectLine(int nLine)
{
    UINT nChannel = GetChannel4Line(nLine);
    Units enUnit = GetUnit4Line(nLine);

    // Select units
    if (enUnit == ALL)
        m_anUnitSelections[nChannel] = UNIT_ALL_MASK;
    else if (enUnit < MAXLINESPERCHANS)
        m_anUnitSelections[nChannel] |= GetBITUnit(enUnit);

    if (m_nLastSelElec != nChannel)
    {
        m_nPrevSelElec = m_nLastSelElec;
        m_nLastSelElec = nChannel;
    }
    if (m_nLastSelUnit != enUnit)
        m_nLastSelUnit = enUnit;
}


// Author & Date:   Almut Branner     1 July 2003
// Purpose: Unselect a line
void CViewRaster::UnselectLine(int nLine)
{
    UINT nChannel = GetChannel4Line(nLine);
    Units enUnit = GetUnit4Line(nLine);

    // Unselect unit
    if (enUnit == ALL)
        m_anUnitSelections[nChannel] = 0;
    else if (enUnit < MAXLINESPERCHANS)
        m_anUnitSelections[nChannel] ^= GetBITUnit(enUnit);
}


// Author & Date:   Almut Branner     01 July 2003
// Purpose: Call this if the selected channels have changed
void CViewRaster::OnChangeChannels()
{
    enum { UNDECIDED = -2, START, UNCHECKED, CHECKED };
    UINT size;
    int nEvents = START;
    int nCont = START;
    int nScale = START;
    int nChanScale = START;
    int nStep = 1;
    bool bCont = false;
    bool bEvent = false;
    bool bDigSer = false;

    if (m_bSingleLineFormat)
        nStep = MAXLINESPERCHANS;

    // get the current selection
    for (UINT nID = 0; nID <= cbMAXCHANS * MAXLINESPERCHANS; nID += nStep)
    {
        if (m_nID2Line[nID] != -1)
        {
            UINT nChannel = GetChannel4ID(nID);
            Units enUnit = GetUnit4ID(nID);

            if ((m_anUnitSelections[nChannel] & GetBITUnit(enUnit)) != 0)
            {
                if ((enUnit == CONT) && (!bCont))
                    bCont = true;
                else if ((enUnit != CONT) && (!bEvent))
                    bEvent = true;

                if ((m_bChanDigSer[nChannel]) && (!bDigSer))
                    bDigSer = true;

                size = m_uIDSizeID[nID];

                if (size != ENUMLINESIZE_NONE)
                {
                    if (nEvents == START)
                    {
                        if ((m_bIDEvents[nID]) && (enUnit != CONT))
                            nEvents = CHECKED;
                        else
                            nEvents = UNCHECKED;
                    }
                    else if ( ((nEvents == UNCHECKED) && ((m_bIDEvents[nID]) && (enUnit != CONT))) ||
                              ((nEvents == CHECKED) && ((!m_bIDEvents[nID]) || 
                                                       ((m_bIDEvents[nID]) && (enUnit == CONT)))) )
                    {
                        nEvents = UNDECIDED;
                    }

                    if (nCont == START)
                    {
                        if ((m_bChanCont[nChannel]) && ((enUnit == ALL) || (enUnit == CONT)))
                            nCont = CHECKED;
                        else
                            nCont = UNCHECKED;
                    }
                    else if ( ((nCont == UNCHECKED) && (m_bChanCont[nChannel])) ||
                              ((nCont == CHECKED) && (!m_bChanCont[nChannel])) )
                    {
                        nCont = UNDECIDED;
                    }

                    if (nScale == START)
                        nScale = CHECKED;

                    if (nChanScale == START)
                        nChanScale = m_nChanScale[nChannel];
                    else if (nChanScale != m_nChanScale[nChannel])
                        nChanScale = UNDECIDED;
                }
            }
        }
    }

    if (m_bInitialized)
    {
        CToolBarCtrl &rTBC = m_pToolBar->GetToolBarCtrl();
        // Set Events check box
        switch (nEvents)
        {
            case UNCHECKED:
                rTBC.Indeterminate(ID_EVENTS, false);
                rTBC.CheckButton(ID_EVENTS, false);
                rTBC.EnableButton(ID_EVENTS, true);
                break;
            case CHECKED:
                rTBC.Indeterminate(ID_EVENTS, false);
                rTBC.CheckButton(ID_EVENTS, true);
                rTBC.EnableButton(ID_EVENTS, true);
                break;
            case START:
                rTBC.Indeterminate(ID_EVENTS, false);
                rTBC.CheckButton(ID_EVENTS, false);
                rTBC.EnableButton(ID_EVENTS, false);
                break;
            default:
                rTBC.Indeterminate(ID_EVENTS, true);
                rTBC.EnableButton(ID_EVENTS, true);
        }

        // Set CONT check box
        switch (nCont)
        {
            case UNCHECKED:
                rTBC.Indeterminate(ID_CONT, false);
                rTBC.CheckButton(ID_CONT, false);
                rTBC.EnableButton(ID_CONT, true);
                break;
            case CHECKED:
                rTBC.Indeterminate(ID_CONT, false);
                rTBC.CheckButton(ID_CONT, true);
                rTBC.EnableButton(ID_CONT, true);
                break;
            case START:
                rTBC.Indeterminate(ID_CONT, false);
                rTBC.CheckButton(ID_CONT, false);
                rTBC.EnableButton(ID_CONT, false);
                break;
            default:
                rTBC.Indeterminate(ID_CONT, true);
                rTBC.EnableButton(ID_CONT, true);
        }
    
        // Digital and serial channels cannot display continuous data
        if (bDigSer)
            rTBC.EnableButton(ID_CONT, false);

        // Only show available options in multiline mode
        if ((bCont) && (!m_bSingleLineFormat))
            rTBC.EnableButton(ID_EVENTS, false);
   
        if ((bEvent) && (!m_bSingleLineFormat))
            rTBC.EnableButton(ID_CONT, false);
    
        // Set edit scale window
    /*    if (nScale == START)
        {
            m_edtScale.SetWindowText("");
            m_edtScale.EnableWindow(false);
        }
        else
        {
            if (nChanScale == UNDECIDED)
            {
                m_edtScale.SetWindowText("");
                m_edtScale.EnableWindow(true);
            }
            else
            {
                char number[8];

                m_edtScale.SetWindowText(itoa(nChanScale, number, 10));
                m_edtScale.EnableWindow(true);
            }
        }*/
    }
}


// Author & Date:       Almut Branner     26 June 2003
// Purpose: Called when we want to change the size of selected channels
void CViewRaster::OnChangeLineSize(int nSize)
{
    BOOL bChangedChannels = false;

    // Get all the selected channels and change them all
    int nStep = 1;

    if (m_bSingleLineFormat)
        nStep = MAXLINESPERCHANS;

    // get the current selection
    for (UINT nID = 0; nID <= cbMAXCHANS * MAXLINESPERCHANS; nID += nStep)
    {
        if (m_nID2Line[nID] != -1)
        {
            UINT nChannel = GetChannel4ID(nID);
            Units enUnit = GetUnit4ID(nID);

            if ((m_anUnitSelections[nChannel] & GetBITUnit(enUnit)) != 0)
            {
                // update everything only if the channel's size has changed (it will have if it was added)
                if ((nSize > ENUMLINESIZE_NONE) && (m_uIDSizeID[nID] != (UINT) nSize))
                {
                    if (!bChangedChannels)
                        bChangedChannels = true;
            
                    // set the channels size id
                    m_uIDSizeID[nID] = nSize;
                }
                // make size smaller
                else if (nSize == -1)
                {
                    if (--m_uIDSizeID[nID] <= 0)
                        m_uIDSizeID[nID] = 1;
                    else
                    {
                        if (!bChangedChannels)
                            bChangedChannels = true;
                    }
                }
                // make size bigger
                else if (nSize == -2)
                {
                    if (++m_uIDSizeID[nID] >= ENUMLINESIZE_COUNT)
                        m_uIDSizeID[nID] = ENUMLINESIZE_COUNT - 1;
                    else
                    {
                        if (!bChangedChannels)
                            bChangedChannels = true;
                    }
                }
                else if (nSize == ENUMLINESIZE_NONE)
                {
                    if (IsUnitVisible(nChannel, enUnit) == true)
                    {
                        // if the channel is currently enabled, disable it, otherwise do nothing
                        HideUnit(nChannel, enUnit);

                        if (!bChangedChannels)
                            bChangedChannels = true;
                    }
                }
            }  // if ((m_abyUnitSelections[nChannel]
        }  // if (m_nID2Line[nID] != -1)
    }  // for (UINT nID

    if (bChangedChannels)
    {
        // Re-Initilialize and Re-paint the Raster Display
        RestartRasterPlot();

        // call the combo change function to update the other control buttons
        OnChangeChannels();
    }
}


// Author & Date:       Almut Branner     30 June 2003
// Purpose: Hide a channel if it is visible
// Inputs:
//  nChannel - the channel id (1 based) that we want to hide now
void CViewRaster::HideChannel(UINT nChannel)
{
    ASSERT(IsChannelVisible(nChannel) == true);

    if (m_bSingleLineFormat)
        HideUnit(nChannel, ALL);
    else
    {
        for (UINT u = 1; u <= MAXLINESPERCHANS; ++u)
            HideUnit(nChannel, (Units) u);
    }
}


// Author & Date:       Almut Branner     30 June 2003
// Purpose: Hide a unit of a particular channel
// Inputs:
//  nChannel - the channel id (1 based) that we want to hide now
//  enUnit - the unit id that we want to hide
void CViewRaster::HideUnit(UINT nChannel, Units enUnit)
{
    m_uIDSizeID[GetID(nChannel) + enUnit] = ENUMLINESIZE_NONE;   // set it to disabled

    // scan through the lines after line of the channel and scoot them down
    m_uLineCount--;
    for (UINT l = m_nID2Line[GetID(nChannel) + enUnit]; l < m_uLineCount; ++l) 
    {
        m_uLine2ID[l] = m_uLine2ID[l + 1];
        m_nID2Line[m_uLine2ID[l]] = l;
    }
    m_nID2Line[GetID(nChannel) + enUnit] = -1;
}


// Author & Date:       Almut Branner     30 June 2003
// Purpose: Unhide a channel and add it to the bottom
// Inputs:
//  nChannel - the channel id (1 based) that we want to make visible now
void CViewRaster::UnHideChannel(UINT nChannel)
{
    ASSERT(IsChannelVisible(nChannel) == false);

    if (m_bSingleLineFormat)
        UnHideUnit(nChannel, ALL);
    else
    {
        for (UINT u = 1; u <= MAXLINESPERCHANS; ++u)
            UnHideUnit(nChannel, (Units) u);
    }
}


// Author & Date:       Almut Branner     30 June 2003
// Purpose: Unhide a unit of a particular channel
// Inputs:
//  nChannel - the channel id (1 based) that we want to make visible now
//  enUnit - the unit id that we want to make visible
void CViewRaster::UnHideUnit(UINT nChannel, Units enUnit)
{
    m_nID2Line[GetID(nChannel) + enUnit] = m_uLineCount;
    m_uLine2ID[m_uLineCount] = GetID(nChannel) + enUnit;
    ++m_uLineCount;
}


// Author & Date:       Almut Branner     30 June 2003
// Purpose: Unhide a unit of a particular channel and set size
// Inputs:
//  nChannel - the channel id (1 based) that we want to make visible now
//  enUnit - the unit id that we want to make visible
void CViewRaster::UnHideUnitAndSetSize(UINT nChannel, Units enUnit, UINT nSize)
{
    m_nID2Line[GetID(nChannel) + enUnit] = m_uLineCount;
    m_uLine2ID[m_uLineCount] = GetID(nChannel) + enUnit;
    m_uIDSizeID[GetID(nChannel) + enUnit] = nSize;
    ++m_uLineCount;
}


// Author & Date:       Kirk Korver     27 May 2003
// Purpose: Unhide a channel, add it to the bottom + set size
// Inputs:
//  nChannel - the channel id (1 based) that we want to make visible now
//  nSize - the size to set the new channel to
void CViewRaster::UnHideChannelAndSetSize(UINT nChannel, UINT nSize)
{
    UINT nID = GetID(nChannel);
    if (m_bSingleLineFormat)
    {
        UnHideUnit(nChannel, ALL);
        m_uIDSizeID[nID + ALL] = nSize;
    }
    else
        for (UINT u = 1; u <= MAXLINESPERCHANS; ++u)
        {
            UnHideUnit(nChannel, (Units) u);
            m_uIDSizeID[nID + u] = nSize;
        }
}


void CViewRaster::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (GetZoomMode() == ZoomViewOff)
    {
        CClientDC dc (this);
        OnPrepareDC(& dc);
        dc.DPtoLP(&point);

        // Get offset into the buffer window
        UINT bufferoffset = point.y;

        // Scan through to find the channel with the line that's set
        for (UINT nLine = 0; nLine < m_uLineCount; ++nLine)
        {
            if ( (bufferoffset >= (m_uLineOffsetY[nLine] - (m_uLineSize[nLine] >> 1)))
               &&(bufferoffset <= (m_uLineOffsetY[nLine] + (m_uLineSize[nLine] >> 1))) )
            {
                UINT nChannel = GetChannel4Line(nLine);
                Units enUnit = GetUnit4Line(nLine);

                if (IsChannelVisible(nChannel))
                {
                    ((CMainFrameRaster *) GetParent())->m_icLblChannel.SetWindowText("Multiple");

                    if (nFlags & MK_CONTROL)
                    {
                        // Don't have to do anything. Just continue selecting channels.
                    }
                    else if (nFlags & MK_SHIFT)
                    {
                        if (m_nLastSelElec != 0)
                        {
                            // Unselect all channels
                            UnselectAllChannels();

                            // Get last electrode and select everything in between
                            int startline = m_nID2Line[GetID(m_nLastSelElec)];

                            if (!m_bSingleLineFormat)
                                startline = m_nID2Line[GetID(m_nLastSelElec) + m_nLastSelUnit];

                            int stopline = nLine;
                            int sline = 1;

                            if (startline > stopline)
                                sline = -1;

                            // Loops can be either increasing or decreasing
                            // The last channel will be selected outside of this loop
                            for (int i = startline; i * sline <  stopline * sline; i += sline)
                                SelectLine(i);

                        }  // if (m_nLastSelElec
                    }
                    else
                    {
                        UnselectAllChannels();
                        CString szLabel = GetLabel(nChannel, GetUnit4Line(nLine));
                        ((CMainFrameRaster *) GetParent())->m_icLblChannel.SetWindowText(szLabel);
                    }

                    if ( ((m_anUnitSelections[nChannel] & GetBITUnit(enUnit)) != 0) ||
                         ((nChannel == m_nLastSelElec) && (enUnit == m_nLastSelUnit)) )
                    {
                        UnselectLine(nLine);
                        m_nLastSelElec = m_nPrevSelElec;
                    }
                    else
                        SelectLine(nLine);

                    CClientDC pDC (this);
                    UpdateUnitSelections();

                    // Tell the other appliations about our selections

                    OnChangeChannels();
                    break;
                }  // if (IsChannelVisible(selectedChan))
            }  // if ( (bufferoffset
        }  // for (UINT nLine = 0
    }
    
	QZoomView ::OnLButtonDown(nFlags, point);
    return;
}

void CViewRaster::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	QZoomView ::OnLButtonDblClk(nFlags, point);
}

// Author & Date:       Almut Branner     26 June 2003
// Purpose: Unselect all electrodes
void CViewRaster::UnselectAllChannels()
{
    memset(m_anUnitSelections, 0, cbMAXCHANS);
}


// Author & Date:   Almut Branner   26 June 2003
// Purpose: Select all electrodes
void CViewRaster::SelectAllChannels()
{
    memset(m_anUnitSelections, UNIT_ALL_MASK, cbMAXCHANS);
}


// Author & Date:       Kirk Korver     27 May 2003
// Purpose: tell me if this channel is currently visible
// Inputs:  nChannel - the channel ID that we care about (1 based)
// Outputs: TRUE means visible; FALSE, hidden
bool CViewRaster::IsChannelVisible(UINT nChannel)
{
    // Is it currently visible?
    if (m_bSingleLineFormat)
        return IsUnitVisible(nChannel, ALL) ? true : false;
    else
    {
        for (UINT u = 1; u <= MAXLINESPERCHANS; ++u)
            if (IsUnitVisible(nChannel, (Units) u))
                return true;
    }

    return false;
}


// Author & Date:       Almut Branner     1 July 2003
// Purpose: tell me if this unit is currently visible
// Inputs:
//  nChannel - the channel ID that we care about (1 based)
//  enUnit - the unit we care about
// Outputs:
//  TRUE means visible; FALSE, hidden
bool CViewRaster::IsUnitVisible(UINT nChannel, Units enUnit)
{
    // Is it currently visible?
    return (m_nID2Line[GetID(nChannel) + enUnit] >= 0) ? true : false;
}


// Author & Date:       Almut Branner     30 Jun 2003
// Purpose: Get the channel for a particular line depending on whether we
//          have multiline or single line mode.
// Input:   nLine - the line for which to get the channel
// Output:  The channel.
UINT CViewRaster::GetChannel4Line(UINT nLine)
{
    return GetChannel4ID(m_uLine2ID[nLine]);
}


// Author & Date:       Almut Branner     10 July 2003
// Purpose: Get the channel for a particular ID depending on whether we
//          have multiline or single line mode.
// Input:   nID - the ID for which to get the channel
// Output:  The channel.
UINT CViewRaster::GetChannel4ID(UINT nID)
{
    UINT nChan;

    if (m_bSingleLineFormat)
        nChan = nID / MAXLINESPERCHANS;
    else
        nChan = (nID - 1) / MAXLINESPERCHANS;

    return nChan;
}


// Author & Date:       Almut Branner     30 Jun 2003
// Purpose: Get the unit for a particular line depending on whether we
//          have multiline or single line mode.
// Input:   nLine - the line for which to get the unit
// Output:  The unit.
CViewRaster::Units CViewRaster::GetUnit4Line(UINT nLine)
{
    return GetUnit4ID(m_uLine2ID[nLine]);
}


// Author & Date:       Almut Branner     10 July 2003
// Purpose: Get the unit for a particular ID depending on whether we
//          have multiline or single line mode.
// Input:   nID - the ID for which to get the unit
// Output:  The unit.
CViewRaster::Units CViewRaster::GetUnit4ID(UINT nID)
{
    Units enUnit;

    if (m_bSingleLineFormat)
        enUnit = ALL;
    else
        enUnit = (Units) (nID - GetChannel4ID(nID) * MAXLINESPERCHANS);

    return enUnit;
}


// Author & Date:       Almut Branner     30 Jun 2003
// Purpose: Get the ID for a particular channel depending on whether we
//          have multiline or single line mode.
// Input:   nChannel - the channel for which to get the ID
// Output:  The ID.
UINT CViewRaster::GetID(UINT nChannel)
{
    UINT nID;

    nID = (nChannel) * MAXLINESPERCHANS;

    return nID;
}

// Author & Date:       Almut Branner     30 Jun 2003
// Purpose: Reset the raster plot to single line mode.
void CViewRaster::ResetSingleLineRaster()
{
    // Have to set this to false to make GetChannel4Line() work
    m_bSingleLineFormat = false;

    UINT uLineCount = 0;
    BOOL bChannels[cbMAXCHANS + 1];  // Tells me whether an electrode is present or not

    memset(bChannels, false, sizeof(bChannels));

    // Figure out which channels are currently displayed
    for (UINT nLine = 0; nLine <= m_uLineCount - 1; ++nLine)
    {
        // TODO: Maybe convert this into temporary arrays and not the real ones
        UINT nChannel = GetChannel4Line(nLine);
        UINT nOldID = m_uLine2ID[nLine];
        UINT nID = GetID(nChannel);

        // Make sure that we only show each channel once
        if (nChannel <= cbMAXCHANS)
        {
            if (!bChannels[nChannel])
            {
                bChannels[nChannel] = true;
                m_uLine2ID[uLineCount] = nID;
                m_uLineSize[uLineCount] = m_uLineSize[nLine];
                m_uIDSizeID[nID] = m_uIDSizeID[nOldID];
                m_nID2Line[nID] = uLineCount;

                // Enable units on single line when any unit is turned on in multiline display
                if (m_bChanDigSer[nChannel])
                {
                    m_bIDEvents[nID] = m_bIDEvents[nOldID];
                }
                else
                {
                    if ( (m_bIDEvents[nID + UNCLASSIFIED]) || (m_bIDEvents[nID + UNIT1]) ||
                         (m_bIDEvents[nID + UNIT2]) || (m_bIDEvents[nID + UNIT3]) ||
                         (m_bIDEvents[nID + UNIT4]) || (m_bIDEvents[nID + UNIT5]) ||
                         (m_bIDEvents[nID + NOISE]))
                        m_bIDEvents[nID] = true;
                    else
                        m_bIDEvents[nID] = false;
                }

                ++uLineCount;
            }

            // Reset old arrays
            for (UINT nUnit = 1; nUnit < MAXLINESPERCHANS; ++nUnit)
            {
                m_nID2Line[nID + nUnit]  = -1;                   // set to disabled
                m_uIDSizeID[nID + nUnit] = ENUMLINESIZE_NONE;    // set to smallest size
            }
        }
    }

    m_uLineCount = uLineCount;

    // Set this back to true
    m_bSingleLineFormat = true;
}


// Author & Date:       Almut Branner     1 July 2003
// Purpose: Convert the internal Unit IDs to the bits used by the cbhwlib.
int CViewRaster::GetBITUnit(Units enUnit)
{
    switch (enUnit)
    {
    case UNCLASSIFIED:
        return UNIT_UNCLASS_MASK;
    case UNIT1:
        return UNIT_1_MASK;
    case UNIT2:
        return UNIT_2_MASK;
    case UNIT3:
        return UNIT_3_MASK;
    case UNIT4:
        return UNIT_4_MASK;
    case UNIT5:
        return UNIT_5_MASK;
    case NOISE:
        return UNIT_NOISE_MASK;
    case CONT:
        return CONTINUOUS_MASK;
    case ALL:
        return UNIT_ALL_MASK;
    default:
        return 0;
    }
}


// Author & Date:       Almut Branner     3 July 2003
// Purpose: Draw the label on a particular line.
void CViewRaster::DrawLabel(CDC & rcDC, UINT nLine)
{
    RECT textrect;

    textrect.top    = m_uLineOffsetY[nLine] - (m_uLineSize[nLine]/2);
    textrect.bottom = m_uLineOffsetY[nLine] + (m_uLineSize[nLine]/2);
    textrect.left   = 0;
    textrect.right  = FRAME_LABELWIDTH - 5;
    
    // Get the channel label
    CString szLabel;
    UINT nChannel = GetChannel4Line(nLine);
    Units enUnit = GetUnit4Line(nLine);
    
    if (nChannel <= cbMAXCHANS)
    {
        szLabel = GetLabel(nChannel, enUnit);

        CDocPowerNAP * pDoc = GetDocument();
        rcDC.SetBkColor(pDoc->m_icColorTable.dispback);

        if ((m_anUnitSelections[nChannel] & GetBITUnit(enUnit)) != 0)
            rcDC.SetTextColor(pDoc->m_icColorTable.dispchansel[2]);
        else
            rcDC.SetTextColor(pDoc->m_icColorTable.dispchansel[1]);

#define MIN(x, y) ( x < y ? x : y)
#define MAX(x, y) ( x > y ? x : y)
        
        rcDC.DrawText(szLabel, MIN(strlen(szLabel),16), &textrect, 
            DT_SINGLELINE | DT_RIGHT | DT_VCENTER | DT_NOCLIP);

#undef MIN
#undef MAX
    }
}


// Author & Date:       Almut Branner     3 July 2003
// Purpose: Get the label for a certain channel.
CString CViewRaster::GetLabel(UINT nChannel, Units enUnit)
{
    // Get the channel label
    CString szLabel;
    CString szUnit;

    CDocPowerNAP * pDoc = GetDocument();
    if (pDoc->IsSegment(nChannel))
        szLabel = pDoc->GetSegment(nChannel).GetLabel();
    else if (pDoc->IsAnalog(nChannel))
        szLabel = pDoc->GetAnalog(nChannel).GetLabel();

    if ((m_bSingleLineFormat) || (m_bChanDigSer[nChannel]))
        szUnit = "";
    else if (enUnit == UNCLASSIFIED)
        szUnit = " Unclass";
    else if (enUnit == CONT)
        szUnit = " Cont";
    else if (enUnit == NOISE)
        szUnit = " Noise";
    else if (enUnit < MAXLINESPERCHANS)
        szUnit.Format(" Unit %d", enUnit - 1);

    return szLabel + szUnit;

    return CString("");
}


// Author & Date:       Almut Branner     21 July 2003
// Purpose: Reset all the data and mapping structures.
void CViewRaster::ResetData()
{
    // Clear out all of the channel options arrays
    for (int nChannel = 0; nChannel <= cbMAXCHANS; ++nChannel)
    {
        m_bChanUnits[nChannel]    = false;                // set to disabled
        m_bChanCont[nChannel]     = false;                // set to disabled
        m_bChanDigSer[nChannel]   = false;                // set to disabled
        m_nChanScale[nChannel]    = 511;                  // set to unity
        m_anUnitSelections[nChannel] = 0;                // Unselect all channels
    }

    for (UINT nID = 0; nID <= cbMAXCHANS * MAXLINESPERCHANS; ++nID)
    {
        m_bIDEvents[nID]   = false;                // spikes enabled flag for each channelid
        m_nID2Line[nID]  = -1;                   // set to disabled
        m_uIDSizeID[nID] = ENUMLINESIZE_NONE;    // set to smallest size
    }

    for (UINT nLine = 0; nLine < MAXLINECOUNT; ++nLine)
    {
        m_uLine2ID[nLine] = 0;
        m_uLineOffsetY[nLine] = 0;
        m_uLineSize[nLine] = 0;
    }

    m_nPrevSelElec = 0;
    m_nLastSelElec = 0;
    m_nLastSelUnit = 0;
}


// Author & Date:       Almut Branner     21 July 2003
// Purpose: Screen is refreshed when button is pushed.
void CViewRaster::OnBtnRefreshScreen() 
{
    bool bSingleLineFormat = m_bSingleLineFormat;

    m_bSingleLineFormat = true;
    ResetData();
    UpdateChannelsAvailable();  // Update available channels list
    InitLines();
    m_bSingleLineFormat = bSingleLineFormat;
    ScrollToPosition(CPoint(0, 0));

    if (m_bSingleLineFormat)
        RestartRasterPlot();
    else
        OnChangeLineMode();
}


// Author & Date:       Almut Branner     21 July 2003
// Purpose: Called to delete selected channels.
void CViewRaster::OnBtnDelete() 
{
    OnChangeLineSize(ENUMLINESIZE_NONE);
}


// Author & Date:       Almut Branner     21 July 2003
// Purpose: Called to move selected channels up.
void CViewRaster::OnBtnUp()
{
    OnChangePos(true);
}


// Author & Date:       Almut Branner     21 July 2003
// Purpose: Called to move selected channels down.
void CViewRaster::OnBtnDown() 
{
    OnChangePos(false);
}


// Author & Date:       Almut Branner     21 July 2003
// Purpose: Called when channels are either moved up or down.
void CViewRaster::OnChangePos(bool bUp)
{
    // Defaults for up button clicked
    int factor = 1;
    int startID = 0;
    int stopID = cbMAXCHANS * MAXLINESPERCHANS;
    int nStep = 1;
    bool bChanChanged = false;

    if (m_bSingleLineFormat)
        nStep = MAXLINESPERCHANS;

    if (!bUp) // check for down button clicked
    {
        factor = -1;
        startID = stopID;
        stopID = 0;
    }

    // Get all the selected channels and change them all
    for (int nID = startID; nID * factor <= stopID * factor; nID = nID + factor * nStep)
    {
        int nLine = m_nID2Line[nID];

        if (nLine >= 0)
        {
            UINT nChannel = GetChannel4ID(nID);
            Units enUnit = GetUnit4ID(nID);

            if ((nChannel <= cbMAXCHANS) && ((m_anUnitSelections[nChannel] & GetBITUnit(enUnit)) != 0))
            {
                // if the channel is enabled and not at the maximum position, 
                // swap it's line position with the channel above it
                if ( ((!bUp) && (nLine < ((int) m_uLineCount - 1))) ||
                     ((bUp) && (nLine > 0)) )
                {
                    if (!bChanChanged)
                        bChanChanged = true;

                    UINT nTempID = m_uLine2ID[nLine];
                    m_uLine2ID[nLine] = m_uLine2ID[nLine - factor];
                    m_uLine2ID[nLine - factor] = nTempID;
                    m_nID2Line[m_uLine2ID[nLine]] = nLine;
                    m_nID2Line[m_uLine2ID[nLine - factor]] = nLine - factor;
                }
                // If one electrode (bottom or top) hits the margin stop
                else
                    break;
            }
        }
    }

    // Re-Initilialize and Re-paint the Raster Display
    if (bChanChanged)
        RestartRasterPlot();
}


// Author & Date:   Almut Branner     21 June 2003
// Purpose: message handler required for tooltips on custom toolbar items
BOOL CViewRaster::OnToolTipNotify(UINT id, NMHDR* pTTTStruct, LRESULT* pResult)
{
    TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pTTTStruct;
    UINT nID =pTTTStruct->idFrom;

    if (pTTT->uFlags & TTF_IDISHWND)
    {
        // idFrom is actually the HWND of the tool
        nID = ::GetDlgCtrlID((HWND)nID);
        if(nID)
        {
            pTTT->lpszText = MAKEINTRESOURCE(nID);
            pTTT->hinst = AfxGetResourceHandle();
            return true;
        }
    }
    return false;
}


// Author & Date:   Almut Branner     22 June 2003
// Purpose: User pushed multi line mode button
void CViewRaster::OnBtnMultiLineMode() 
{
    CToolBarCtrl &rTBC = m_pToolBar->GetToolBarCtrl();
    if (rTBC.IsButtonChecked(ID_MULTILINEMODE))
    {
        m_bSingleLineFormat = false;
        (CMainFrame *) GetParent()->PostMessage(WM_USER_CHANGELINEMODE, 1, 0);
        OnChangeLineMode();
    }
    else
        rTBC.CheckButton(ID_MULTILINEMODE, true);
}


// Author & Date:   Almut Branner     22 June 2003
// Purpose: User pushed single line mode button
void CViewRaster::OnBtnSingleLineMode() 
{
    CToolBarCtrl &rTBC = m_pToolBar->GetToolBarCtrl();
    if (rTBC.IsButtonChecked(ID_SINGLELINEMODE))
    {
        m_bSingleLineFormat = true;
        (CMainFrame *) GetParent()->PostMessage(WM_USER_CHANGELINEMODE, 0, 0);
        OnChangeLineMode();
    }
    else
        rTBC.CheckButton(ID_SINGLELINEMODE, true);
}


// Author & Date:   Almut Branner     22 June 2003
// Purpose: Line mode has changed
void CViewRaster::OnChangeLineMode()
{
    if (m_uLineCount != 0)
    {
        if (m_bSingleLineFormat)
        {
            ResetSingleLineRaster();
        }
        else
        {
            // Need to change this to make GetChannel4Line to work
            m_bSingleLineFormat = true;

            // Create temporary arrays to make sure we are not overriding the old arrays
            UINT uLine2ID[MAXLINECOUNT];
            UINT uLineSize[MAXLINECOUNT];
            UINT uIDSizeID[cbMAXCHANS * MAXLINESPERCHANS + 1];
            INT  nID2Line[cbMAXCHANS * MAXLINESPERCHANS + 1];
            BOOL bIDEvents[cbMAXCHANS * MAXLINESPERCHANS + 1];

            // Set some default values
            memset(uLine2ID, 0, sizeof(uLine2ID));
            memset(uLineSize, 0, sizeof(uLineSize));
            memset(uIDSizeID, 0, sizeof(uIDSizeID));
            memset(nID2Line, -1, sizeof(nID2Line));
            memcpy(bIDEvents, m_bIDEvents, sizeof(bIDEvents));

            UINT uLineCount = 0;

            for (int nLine = 0; nLine < m_uLineCount; ++nLine)
            {
                UINT nID = m_uLine2ID[nLine];
                UINT nChannel = GetChannel4Line(nLine);
                BOOL bEvents = m_bIDEvents[nID];

                if (nChannel > cbMAXCHANS)
                    break;

                if (m_bChanDigSer[nChannel])
                {
                    uLine2ID[uLineCount] = nID + 1;
                    uLineSize[uLineCount] = m_uLineSize[nLine];
                    uIDSizeID[nID + 1] = m_uIDSizeID[nID];
                    nID2Line[nID + 1] = uLineCount;
                    bIDEvents[nID + 1] = bEvents;
                    ++uLineCount;
                }
                else
                {
                    for (UINT nUnit = 1; nUnit < MAXLINESPERCHANS; ++nUnit)
                    {
                        if ( ((nUnit == CONT) && (m_bChanCont[nChannel])) ||
                             ((nUnit < CONT) && (nUnit > UNCLASSIFIED) && (bEvents) && (UnitInData(nChannel, (Units) nUnit))) ||
                             ((nUnit == UNCLASSIFIED) && (bEvents) && (UnitInData(nChannel, (Units) nUnit))) )
                        {
                            uLine2ID[uLineCount] = nID + nUnit;
                            uLineSize[uLineCount] = m_uLineSize[nLine];
                            uIDSizeID[nID + nUnit] = m_uIDSizeID[nID];
                            nID2Line[nID + nUnit] = uLineCount;
                            if (nUnit != CONT)
                                bIDEvents[nID + nUnit] = bEvents;
                            ++uLineCount;
                        }
                    }
                }
                nID2Line[nID] = -1;
            }

            // Now copy everything into the real arrays
            m_uLineCount = uLineCount;
            memcpy(m_uLine2ID, uLine2ID, sizeof(m_uLine2ID));
            memcpy(m_uLineSize, uLineSize, sizeof(m_uLineSize)); 
            memcpy(m_uIDSizeID, uIDSizeID, sizeof(m_uIDSizeID));
            memcpy(m_nID2Line, nID2Line, sizeof(m_nID2Line));
            memcpy(m_bIDEvents, bIDEvents, sizeof(m_bIDEvents));

            m_bSingleLineFormat = false;
        }
    }

    // Re-Initilialize and Re-paint the Raster Display
    RestartRasterPlot();
}


// Author & Date:       Almut Branner     22 July 2003
// Purpose: Call chooser window.
void CViewRaster::OnBtnChooser() 
{
    CDlgChooser dlg(this);

    // Fill the "chooser" list
    for (ChannelIterator it(m_uChanAvailList, m_uChanAvailCount); it; ++it)
    {
        UINT nChannel = it.GetChannelNum();
        UINT nID = GetID(nChannel);

        if (m_bSingleLineFormat)
        {
            bool bVisible = IsChannelVisible(nChannel);
            dlg.AddEntry(GetLabel(nChannel, ALL), nID + ALL, bVisible);
        }
        else
        {
            if (m_bChanDigSer[nChannel])
            {
                bool bVisible = IsChannelVisible(nChannel);
                dlg.AddEntry(GetLabel(nChannel, UNCLASSIFIED), nID + UNCLASSIFIED, bVisible);
            }
            else
            {
                for (UINT nUnit = 1; nUnit < MAXLINESPERCHANS; ++nUnit)
                {
                    bool bVisible = IsUnitVisible(nChannel, (Units) nUnit);
                    dlg.AddEntry(GetLabel(nChannel, (Units) nUnit), nID + nUnit, bVisible);
                }
            }
        }  // if (m_bSingleLineFormat) ... else
    }

    if (IDOK == dlg.DoModal())
    {
        const CHOSENLIST & rcList = dlg.GetList();

        // Update who is visible and who is not
        CHOSENLIST::const_iterator it;

        int size = rcList.size();

        for (it = rcList.begin(); it != rcList.end(); ++it)
        {
            UINT nID = (*it).dwID;
            UINT nChannel = GetChannel4ID(nID);
            Units enUnit = GetUnit4ID(nID);

            if ((*it).bChosen)
            {
                // We only need to do anything if this is not visible, and it should be
                if (IsUnitVisible(nChannel, enUnit) == false)
                    UnHideUnitAndSetSize(nChannel, enUnit, ENUMLINESIZE_7PIX);
            }
            else
            {
                if (IsUnitVisible(nChannel, enUnit) == true)
                    HideUnit(nChannel, enUnit);
            }
        }

        // Now update the screens

        // call the combo change function to update the other control buttons
        OnChangeChannels();
    
        // Re-Initilialize and Re-paint the Raster Display
        RestartRasterPlot();
    }  // if (IDOK == dlg.DoModal())
}


// Author & Date:       Almut Branner     22 July 2003
// Purpose: Remove all channels from display.
void CViewRaster::OnBtnClearAll() 
{
    // For each channel
    for (int nID = 0; nID < ARRAY_SIZE(m_nID2Line); ++nID)
    {
        // unmap it
        m_nID2Line[nID] = -1;

        // Make it 0 sized
        m_uIDSizeID[nID] = ENUMLINESIZE_NONE;
    }
    m_uLineCount = 0;

    // call the combo change function to update the other control buttons
    OnChangeChannels();

    // Re-Initilialize and Re-paint the Raster Display
    RestartRasterPlot();
}


// Author & Date:       Almut Branner     22 July 2003
// Purpose: Add all channels to display.
void CViewRaster::OnBtnAddAll() 
{
    // For each valid ID
    UINT nStartID = 0;
    UINT nStep = MAXLINESPERCHANS;

    if (!m_bSingleLineFormat)
    {
        nStartID = 0;
        nStep = 1;
    }

    for (int nID = nStartID; nID <= cbMAXCHANS * MAXLINESPERCHANS; nID += nStep)
    {
        UINT nChannel = GetChannel4ID(nID);
        Units enUnit = GetUnit4ID(nID);

        // If it currently is not mapped, then map it
        if ( (m_nID2Line[nID] == -1) && 
             (((!m_bSingleLineFormat) && (nID % MAXLINESPERCHANS != 0)) || (m_bSingleLineFormat)) )
        {
            // but only map it if it is an analog or digital input
            m_nID2Line[nID] = m_uLineCount;
            m_uLine2ID[m_uLineCount] = nID;
            ++m_uLineCount;

            // Only set a size, if none is selected (don't overwrite previous settings)
            if (m_uIDSizeID[nID] == ENUMLINESIZE_NONE)
                m_uIDSizeID[nID] = ENUMLINESIZE_7PIX;
        }
    }

    // Re-Initilialize and Re-paint the Raster Display
    RestartRasterPlot();
}

// Author & Date:       Almut Branner     29 July 2003
// Purpose: Make all selected lines one size bigger.
void CViewRaster::OnBtnBigger() 
{
    OnChangeLineSize(-2);
}

// Author & Date:       Almut Branner     29 July 2003
// Purpose: Make all selected lines one size smaller.
void CViewRaster::OnBtnSmaller() 
{
    OnChangeLineSize(-1);
}

// Author & Date:       Almut Branner     22 July 2003
// Purpose: Minimize all selected lines.
void CViewRaster::OnBtnMin() 
{
    OnChangeLineSize(1);
}


// Author & Date:       Almut Branner     22 July 2003
// Purpose: Maximize all selected lines.
void CViewRaster::OnBtnMax() 
{
    OnChangeLineSize(ENUMLINESIZE_COUNT - 1);
}


// Author & Date:       Almut Branner     22 July 2003
// Purpose: Show events.
void CViewRaster::OnBtnEvents() 
{
    CToolBarCtrl &rTBC = m_pToolBar->GetToolBarCtrl();
    if (rTBC.IsButtonIndeterminate(ID_EVENTS))
    {
        rTBC.Indeterminate(ID_EVENTS, false);
        rTBC.CheckButton(ID_EVENTS, true);
    }

    // Get all the selected channels and change them all
    int nStep = 1;

    if (m_bSingleLineFormat)
        nStep = MAXLINESPERCHANS;

    // get the current selection
    for (UINT nID = 0; nID <= cbMAXCHANS * MAXLINESPERCHANS; nID += nStep)
    {
        if (m_nID2Line[nID] != -1)
        {
            UINT nChannel = GetChannel4ID(nID);
            Units enUnit = GetUnit4ID(nID);

            if ((nChannel <= cbMAXCHANS) && ((m_anUnitSelections[nChannel] & GetBITUnit(enUnit)) != 0))
                m_bIDEvents[nID] = rTBC.IsButtonChecked(ID_EVENTS);
        }  // if (m_nID2Line[nID] != -1)
    }  // for (UINT nID = 0
}


// Author & Date:       Almut Branner     22 July 2003
// Purpose: Show continuous data.
void CViewRaster::OnBtnCont() 
{
    CToolBarCtrl &rTBC = m_pToolBar->GetToolBarCtrl();
    if (rTBC.IsButtonIndeterminate(ID_CONT))
    {
        rTBC.Indeterminate(ID_CONT, false);
        rTBC.CheckButton(ID_CONT, true);
    }

    // Get all the selected channels and change them all
    for (UINT nChannel = 1; nChannel <= cbMAXCHANS; ++nChannel)
    {
        if ((m_anUnitSelections[nChannel] & CONTINUOUS_MASK) != 0)
            m_bChanCont[nChannel] = rTBC.IsButtonChecked(ID_CONT);
    }
}


// Author & Date:       Almut Branner     1 Aug 2003
// Purpose: Initialize all lines.
void CViewRaster::InitLines()
{
    // reset the channel line mappings
    m_uLineCount = 0;

    ASSERT(m_uChanAvailCount <= cbMAXCHANS + 1);
    
    for(UINT c = 0; c < m_uChanAvailCount; ++c)
    {
        // the the channel id from the available channel list
        UINT32 chan = m_uChanAvailList[c];

        // check for analog input capabilities
        INT32 ContScale = 1;
        UINT nID = GetID(chan);

        // set up the mappings between the channel and this line and set channel options
        m_nID2Line[nID] = m_uLineCount;
        m_uLine2ID[m_uLineCount++] = nID;
        m_uIDSizeID[nID] = ENUMLINESIZE_7PIX;
        m_nChanScale[chan] = ContScale;

        CDocPowerNAP * pDoc = GetDocument();
        if (pDoc->IsSegment(chan))
            m_bIDEvents[nID] = m_bChanUnits[chan] = TRUE;
        else
            m_bIDEvents[nID] = m_bChanUnits[chan] = FALSE;
            
        if (pDoc->IsAnalog(chan))
        {
            m_bChanCont[chan] = TRUE;
        }
        else
            m_bChanCont[chan] = FALSE;
    }
}


// Author & Date:       Almut Branner     1 Aug 2003
// Purpose: Sort using default method.
void CViewRaster::OnBtnSort() 
{
    OnBtnSortChannel();
}


// Author & Date:   Kirk Korver     10 Oct 2003
// Purpose: use with std::sort() to sort by unit ID.
struct LessByUnit : 
    public binary_function<CViewRaster::LineInfo, CViewRaster::LineInfo, bool>
{
    operator() (const CViewRaster::LineInfo & lhs, const CViewRaster::LineInfo & rhs)
    {
        if (lhs.bIsDigital)
            return false;
        else
        {
            if (rhs.bIsDigital)
                return true;
            else
                return lhs.enUnit < rhs.enUnit;
        }
    }
};


// Author & Date:   Kirk Korver     10 Oct 2003
// Purpose: use with std::sort() to sort by channel number
struct LessByChannel : 
    public binary_function<CViewRaster::LineInfo, CViewRaster::LineInfo, bool>
{
    operator() (const CViewRaster::LineInfo & lhs, const CViewRaster::LineInfo & rhs)
    {
        return lhs.nChannel < rhs.nChannel;
    }
};

// Author & Date:   Kirk Korver     10 Oct 2003
// Purpose: use with std::sort() to sort by type
struct LessByType : 
    public binary_function<CViewRaster::LineInfo, CViewRaster::LineInfo, bool>
{
    operator() (const CViewRaster::LineInfo & lhs, const CViewRaster::LineInfo & rhs)
    {
        return lhs.nType < rhs.nType;
    }
};


// Author & Date:   Kirk Korver     10 Oct 2003
// Purpose: convert from our standard format into the line format needed for sorting
// Output:
//  rLine - the (empty) lines grouping 
void CViewRaster::BuildVisibleLineInfo(VECT_LINEINFO & rLines)
{
    rLines.resize(m_uLineCount);

    // These are all of the types
    enum { SPIKES, CONTINUOUS, DIGITAL };

    // i is the "Line Number"
    for (int i = 0; i < m_uLineCount; ++i)
    {
        DWORD nID = m_uLine2ID[i];
        rLines[i].uIDSizeID = m_uIDSizeID[nID];

        Units enUnit = GetUnit4Line(i);
        rLines[i].nID = m_uLine2ID[i];
        rLines[i].enUnit = enUnit;

        DWORD nChan = GetChannel4Line(i);
        rLines[i].nChannel = nChan;
        rLines[i].bIsDigital = m_bChanDigSer[nChan] ? true : false;

        if (m_bChanCont[nChan])
            rLines[i].nType = CONTINUOUS;
        else if (m_bChanDigSer[nChan])
            rLines[i].nType = DIGITAL;
        else 
            rLines[i].nType = SPIKES;


        ASSERT(IsUnitVisible(GetChannel4Line(i), rLines[i].enUnit) == true);
    }
}

// Author & Date:   Kirk Korver     10 Oct 2003
// Purpose: now that this temp format is sorted, update all of our local variables
//  so that they will match what the sorted order
// Inputs:
//  rLines - the local line structure that is in the "line" order we want displayed
// Outputs:
//  Our local variables will be updated so that the line ordering will match
void CViewRaster::BuildArrays(const VECT_LINEINFO & rLines)
{
    ASSERT(rLines.size() == m_uLineCount);

    for (int i = 0; i < m_uLineCount; ++i)
    {
        DWORD nID = rLines[i].nID;

        m_uLine2ID[i] = nID;
        m_nID2Line[nID] = i;
        m_uIDSizeID[nID] = rLines[i].uIDSizeID;
        m_uLineSize[i] = enumlinesizeval[m_uIDSizeID[nID]];
    }
}


// Author & Date:       Almut Branner     1 Aug 2003
// Purpose: Sort by channel IDs.
void CViewRaster::OnBtnSortChannel() 
{
    // The main reason this works is that the number of channels that are still visible hasn't changed

    // Build a temporary showing of what it looks like, sort it, then update our local vars
    VECT_LINEINFO vLineInfo;
    BuildVisibleLineInfo(vLineInfo);
    std::stable_sort(vLineInfo.begin(), vLineInfo.end(), LessByChannel());
    BuildArrays(vLineInfo);   // now sorted, update our vars

    RestartRasterPlot();
}


// Author & Date:       Almut Branner     1 Aug 2003
// Purpose: Sort by recording mode.
void CViewRaster::OnBtnSortMode() 
{
    // The main reason this works is that the number of channels that are still visible hasn't changed

    // Build a temporary showing of what it looks like, sort it, then update our local vars
    VECT_LINEINFO vLineInfo;
    BuildVisibleLineInfo(vLineInfo);
    std::stable_sort(vLineInfo.begin(), vLineInfo.end(), LessByType());
    BuildArrays(vLineInfo);   // now sorted, update our vars

    // And restart it all
    RestartRasterPlot();
}


// Author & Date:       Almut Branner     1 Aug 2003
// Purpose: Sort by recording mode and unit IDs.
void CViewRaster::OnBtnSortUnits() 
{
    if (m_bSingleLineFormat)
    {
        OnBtnSortMode();
        return;
    }

    // The main reason this works is that the number of channels that are still visible hasn't changed

    // Build a temporary showing of what it looks like, sort it, then update our local vars
    VECT_LINEINFO vLineInfo;
    BuildVisibleLineInfo(vLineInfo);
    std::stable_sort(vLineInfo.begin(), vLineInfo.end(), LessByUnit());
    BuildArrays(vLineInfo);   // now sorted, update our vars

    // And restart it all
    RestartRasterPlot();
}


// Author & Date:       Almut Branner     1 Aug 2003
// Purpose: Select all lines.
void CViewRaster::OnBtnSelectAll() 
{
	SelectAllChannels();
    CClientDC pDC (this);
    UpdateUnitSelections();
}


void CViewRaster::OnZoomIn() 
{
	// Toggle zoomin mode
	CWnd *pWin = ((CWinApp *) AfxGetApp())->m_pMainWnd;
	if (GetZoomMode() == ZoomViewZoomIn) 
    {
		SetZoomMode(ZoomViewOff);
		// Clear the statusbar
        ((CMainFrameRaster *) GetParent())->m_wndStatusBar.SetPaneText(0, (LPCTSTR)"", true);
	}
    else 
    {
		SetZoomMode(ZoomViewZoomIn);
		// Give instructions in the statusbar
        ((CMainFrameRaster *) GetParent())->m_wndStatusBar.SetPaneText(0, 
            (LPCTSTR)"Click to zoom in on point or drag a zoom box.", true);
	}
}

void CViewRaster::OnUpdateZoomIn(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetZoomMode() == ZoomViewZoomIn);
}

void CViewRaster::OnZoomInOne() 
{
	ZoomIn();
}

void CViewRaster::OnZoomOut() 
{
	// Toggle zoomout mode
	CWnd *pWin = ((CWinApp *) AfxGetApp())->m_pMainWnd;
	if (GetZoomMode() == ZoomViewZoomOut) 
    {
		SetZoomMode(ZoomViewOff);
		// Clear the statusbar
        ((CMainFrameRaster *) GetParent())->m_wndStatusBar.SetPaneText(0, (LPCTSTR)"", true);
	}
    else
    {
		SetZoomMode(ZoomViewZoomOut);
		// Give instructions in the statusbar
        ((CMainFrameRaster *) GetParent())->m_wndStatusBar.SetPaneText(0, 
            (LPCTSTR)"Click to zoom out on point.", true);
    }
}

void CViewRaster::OnUpdateZoomOut(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetZoomMode() == ZoomViewZoomOut);
}

void CViewRaster::OnZoomOutOne() 
{
	ZoomOut();
}

void CViewRaster::OnZoomToWindow() 
{
	ZoomToWindow();
}

void CViewRaster::OnHand() 
{
	// Toggle zoomout mode
	CWnd *pWin = ((CWinApp *) AfxGetApp())->m_pMainWnd;
	if (GetZoomMode() == ZoomViewDrag) 
    {
		SetZoomMode(ZoomViewOff);
		// Clear the statusbar
        ((CMainFrameRaster *) GetParent())->m_wndStatusBar.SetPaneText(0, (LPCTSTR)"", true);
	}
    else
    {
	    SetZoomMode(ZoomViewDrag);
		// Give instructions in the statusbar
        ((CMainFrameRaster *) GetParent())->m_wndStatusBar.SetPaneText(0, 
            (LPCTSTR)"Click to drag view.", true);
    }
}

void CViewRaster::OnUpdateHand(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetZoomMode() == ZoomViewDrag);
}

void CViewRaster::OnViewZoomfull() 
{
//	DoZoomFull();  // Call QZoomView member to zoom full scale
}


// Author & Date:   Almut Branner   Oct 8, 2003
// Purpose: Make sure that the background is always black. This way we don't have to redraw
//          it constantly and this should reduce flicker.
BOOL CViewRaster::OnEraseBkgnd(CDC* pDC) 
{
    CRect rect;
    GetClientRect(rect);
    pDC->FillRect(&rect, &(GetDocument()->m_wndbkBrush));
	
	return true;
}


// Author & Date:   Almut Branner   Oct 13, 2003
// Purpose: Calculate the maximum screen width. Use the timestamps as a basis
UINT CViewRaster::GetMaxWidth()
{
#if 1
    double dTime = GetDocument()->GetMaxTime();
    UINT nWidth = XfmWorldToScreenX(dTime);
    nWidth += MARGINRIGHT;
    return nWidth;
#else
    UINT uTotalWidth = 0;

    for (UINT nLine = 0; nLine < m_uLineCount; ++nLine) 
    {
        UINT nChannel = GetChannel4Line(nLine);
        double dTimeStamp = 0;

        // Figure out what type this line is and get the last timepoint
        CDocPowerNAP * pDoc = GetDocument();
        if (pDoc->IsSegment(nChannel))
        {
            Segments & seg = pDoc->GetSegment(nChannel);
            DWORD dwEntityID = seg.GetEntityID();

            dTimeStamp = seg.back().GetTime();
        }
        else if (pDoc->IsAnalog(nChannel))
        {
            Analogs & ana = pDoc->GetAnalog(nChannel);
            dTimeStamp = ana.back().GetTimeLast();
        }

        // Convert the timestamp into logical pixels
        UINT uTimePoint = (int) (dTimeStamp * 1000) / enumwidthval[m_uFrameWidth] + 
                              FRAME_LABELWIDTH - 1;

        if (uTotalWidth < uTimePoint)
            uTotalWidth = uTimePoint;
    }

    return uTotalWidth + MARGINRIGHT;
#endif
}


// Author & Date:   Almut Branner   Oct 17, 2003
// Purpose: Decrease the width of the display
void CViewRaster::OnBtnNarrower() 
{
	OnChangeWidth(-1);
}


// Author & Date:   Almut Branner   Oct 17, 2003
// Purpose: Increase the width of the display
void CViewRaster::OnBtnWider() 
{
	OnChangeWidth(-2);
    // OnChangeWidth(1) for min
    // OnChangeWidth(ENUMWIDTH_COUNT - 1) for max
}


// Author & Date:   Almut Branner   Oct 17,, 2003
// Purpose: Change the size of the display
void CViewRaster::OnChangeWidth(int nSize)
{
    bool bChanged = false;

    if ((nSize == -1) && (m_uFrameWidth > 1))  // make narrower
    {
        --m_uFrameWidth;
        bChanged = true;
    }
    else if ((nSize == -2) && (m_uFrameWidth < ENUMWIDTH_COUNT - 1))  // make wider
    {
        ++m_uFrameWidth;
        bChanged = true;
    }
    else if ((nSize > 0) && (nSize != m_uFrameWidth))
    {
        m_uFrameWidth = nSize;
        bChanged = true;
    }

    if (bChanged)
    {
        m_uTotalWidth = GetMaxWidth();
        SetScrollSizes(MM_TEXT, CSize(m_uTotalWidth, m_uTotalHeight), CSize(70, 70), CSize(7, 7));

        Invalidate();
    }
}


// Author & Date:   Almut Branner   Oct 17, 2003
// Purpose: Find out whether a unit exists in the data
bool CViewRaster::UnitInData(int nChannel, Units enUnit)
{
    CDocPowerNAP * pDoc = GetDocument();

    if (pDoc->IsSegment(nChannel))
    {
        Segments & seg = pDoc->GetSegment(nChannel);
        // What unit am I looking for?
        DWORD dwSearchUnitID = GetBITUnit(enUnit);

        for (SEGMENTLIST::iterator sit = seg.begin(); sit != seg.end(); ++sit)
        {
            // What unit is the current segment?
            DWORD dwUnitID = (*sit).GetUnitID();

            // Found it?
            if (dwSearchUnitID == dwUnitID)
                return true;
        }
    }

    return false;
}
