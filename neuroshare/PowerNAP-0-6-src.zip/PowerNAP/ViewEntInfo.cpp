///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewEntInfo.cpp $
//
// Description   :  
//
// Authors       : 
//
// $Date: 3/04/04 5:26p $
//
// $History: ViewEntInfo.cpp $
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "ViewEntInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewEntInfo

IMPLEMENT_DYNCREATE(CViewEntInfo, CFormView)

CViewEntInfo::CViewEntInfo()
	: CFormView(CViewEntInfo::IDD)
{
    SetDefaults();
}

CViewEntInfo::~CViewEntInfo()
{
}

void CViewEntInfo::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewEntInfo)
	DDX_Control(pDX, IDC_ENTINFO_SOURCECBO, m_cboSourceLabel);
	DDX_Control(pDX, IDC_ENTINFO_ENTLABELCBO, m_cboEntLabel);
	DDX_Text(pDX, IDC_ENTINFO_TEXTWFCOUNT, m_uWfCount);
	DDV_MinMaxUInt(pDX, m_uWfCount, 0, 65535);
	DDX_Text(pDX, IDC_ENTINFO_TEXTPTCOUNT, m_sPtCount);
	DDV_MaxChars(pDX, m_sPtCount, 16);
	DDX_Text(pDX, IDC_ENTINFO_TEXTRATE, m_dSampleRate);
	DDX_Text(pDX, IDC_ENTINFO_TEXTUNIT, m_sUnits);
	DDV_MaxChars(pDX, m_sUnits, 8);
	DDX_Text(pDX, IDC_ENTINFO_TEXTINMIN, m_dInMinVal);
	DDX_Text(pDX, IDC_ENTINFO_TEXTINMAX, m_dInMaxVal);
	DDX_Text(pDX, IDC_ENTINFO_TEXTRES, m_dResolution);
	DDX_Text(pDX, IDC_ENTINFO_TEXTX, m_dXLoc);
	DDX_Text(pDX, IDC_ENTINFO_TEXTY, m_dYLoc);
	DDX_Text(pDX, IDC_ENTINFO_TEXTZ, m_dZLoc);
	DDX_Text(pDX, IDC_ENTINFO_TEXTLOCINFO, m_dUserLoc);
	DDX_Text(pDX, IDC_ENTINFO_TEXTUNIT2, m_sUnits2);
	DDV_MaxChars(pDX, m_sUnits2, 8);
	DDX_Text(pDX, IDC_ENTINFO_TEXTF1FREQ, m_dF1Freq);
	DDX_Text(pDX, IDC_ENTINFO_TEXTF2FREQ, m_dF2Freq);
	DDX_Text(pDX, IDC_ENTINFO_TEXTF1ORDER, m_dF1Order);
	DDX_Text(pDX, IDC_ENTINFO_TEXTF1TYPE, m_sF1Type);
	DDX_Text(pDX, IDC_ENTINFO_TEXTF2TYPE, m_sF2Type);
	DDX_Text(pDX, IDC_ENTINFO_TEXTF2ORDER, m_dF2Order);
	DDX_Text(pDX, IDC_ENTINFO_TEXTPRBINFO, m_sProbeInfo);
	DDX_Text(pDX, IDC_ENTINFO_TXTSORTSTATUS, m_sSortStatus);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewEntInfo, CFormView)
	//{{AFX_MSG_MAP(CViewEntInfo)
	ON_CBN_SELCHANGE(IDC_ENTINFO_ENTLABELCBO, OnSelchangeEntity)
	ON_CBN_SELCHANGE(IDC_ENTINFO_SOURCECBO, OnSelchangeSource)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewEntInfo diagnostics

#ifdef _DEBUG
void CViewEntInfo::AssertValid() const
{
	CFormView::AssertValid();
}

void CViewEntInfo::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}


CDocPowerNAP* CViewEntInfo::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}

#endif //_DEBUG



/////////////////////////////////////////////////////////////////////////////
// CViewEntInfo message handlers

void CViewEntInfo::OnInitialUpdate() 
{
 	CFormView::OnInitialUpdate();
	
    // Size the window to the dialog
    GetParentFrame()->RecalcLayout();
    ResizeParentToFit(false);

    // Set the title
    CMainFrame * pFrame = static_cast<CMainFrame *>(GetParentFrame());
    pFrame->SetTitle("Entity Information");
}


void CViewEntInfo::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
    // If no data, nothing to fill in - return
    CDocPowerNAP * pDoc = GetDocument();

    if (pDoc->m_icFileVector.empty())
    {
        SetDefaults();
        m_cboEntLabel.ResetContent();
    }
    else
    {
        FillEntityLabelList();
        
        // Select entity selected
        m_nSelEntity = pDoc->GetActiveEntityIndex();
        
        m_cboEntLabel.SetCurSel(m_nSelEntity);
        
        FillGeneralInfo();
        
        FillSegmentSourceList();
        
        // Set source to first one in  list
        m_nSelSource = 0;
        m_cboSourceLabel.SetCurSel(m_nSelSource);
        
        FillSegmentSourceInfo();
    }
	
    // Initialize the dialog
    UpdateData(FALSE);	
}


void CViewEntInfo::FillGeneralInfo()
{
    CString str;
    EntityInfo icEntityInfo;
    CDocPowerNAP * pDoc = GetDocument();

    icEntityInfo = pDoc->m_icEntityInfoVector[m_nSelEntity];

    // Fill sort status
    if (icEntityInfo.m_bRulesDefined == true)
        m_sSortStatus.Format("Rules defined");
    else
        m_sSortStatus.Empty();


    // Fill # of wavefoms
    m_uWfCount = icEntityInfo.isEntityInfo.dwItemCount;

    // Fill Pt #
    ns_SEGMENTINFO isSInfo;
    m_isFileInfo = *pDoc->m_icFileVector[0];
    
    pDoc->GetSegmentInfo(m_isFileInfo.icFile, m_nSelEntity, isSInfo);
    int nMinNumPt = isSInfo.dwMinSampleCount;
    int nMaxNumPt = isSInfo.dwMaxSampleCount;
    if (isSInfo.dwMinSampleCount == isSInfo.dwMaxSampleCount)
        m_sPtCount.Format("%d", nMaxNumPt);
    else
        m_sPtCount.Format("%d - %d", nMinNumPt, nMaxNumPt);
 

    // Fill sampling rate
    m_dSampleRate =  isSInfo.dSampleRate;

    
    // Fill units of measurement
    m_sUnits = isSInfo.szUnits;
    m_sUnits2 = isSInfo.szUnits;

    // Save source count for filling in source info later
    m_uSegSourceCount = isSInfo.dwSourceCount;

    // If only one source don't allow selection in combobox
    if ( m_uSegSourceCount <= 1)
        m_cboSourceLabel.EnableWindow(FALSE);
    else
        m_cboSourceLabel.EnableWindow(TRUE);
}


// Fill the segment source list box for the selected entity
void CViewEntInfo::FillSegmentSourceList()
{
    //Clear the combobox
    m_cboSourceLabel.ResetContent();
    
    //Fill with new sources
    CString str;
    for (int n = 1; n <= m_uSegSourceCount; ++n)
    {
        str.Format("source %d", n);
        m_cboSourceLabel.AddString(str); 
    }
}


void CViewEntInfo::FillSegmentSourceInfo()
{
    CString str;
    
    ns_SEGSOURCEINFO isSSInfo;
    CDocPowerNAP * pDoc = GetDocument();
    pDoc->GetSegmentSourceInfo(m_isFileInfo.icFile, m_nSelEntity, m_nSelSource, isSSInfo);

    m_dInMinVal = isSSInfo.dMinVal;
    m_dInMaxVal = isSSInfo.dMaxVal;

    m_dResolution = isSSInfo.dResolution;;

    m_dXLoc = isSSInfo.dLocationX;
    m_dYLoc = isSSInfo.dLocationY;
    m_dZLoc = isSSInfo.dLocationZ;

    m_dUserLoc = isSSInfo.dLocationUser;
    
    // Filter 1 = Low corner frequency filter
    // Filter 2 = High corne frequency filter
    m_dF2Freq = isSSInfo.dHighFreqCorner;
    m_dF1Freq = isSSInfo.dLowFreqCorner;

    m_dF2Order = isSSInfo.dwHighFreqOrder;
    m_dF1Order =  isSSInfo.dwLowFreqOrder;

    m_sF2Type = isSSInfo.szHighFilterType;
    m_sF1Type = isSSInfo.szLowFilterType;
    
    m_sProbeInfo = isSSInfo.szProbeInfo;
}

void CViewEntInfo::FillEntityLabelList()
{
    CDocPowerNAP * pDoc = GetDocument();

    // First 0 out the entities
    ENTITYINFOLIST::iterator eit;
    FILEINFOLIST::iterator fit;
    
    ns_ENTITYINFO isEInfo;   // put out here for performance reasons
    
    // Fill in entity list
    // For each entity, and for each file
    for (eit = pDoc->m_icEntityInfoVector.begin(); eit != pDoc->m_icEntityInfoVector.end(); ++eit)
    {
        for (fit = pDoc->m_icFileVector.begin(); fit != pDoc->m_icFileVector.end(); ++fit)
        {
            if (ns_OK == pDoc->GetEntityInfo((*fit)->icFile, (*eit).dwEntityIndex, isEInfo))
            {
                
                if (isEInfo.dwEntityType == ns_ENTITY_SEGMENT)
                {
                    // It is a segment entity
                    // Set label
                    m_cboEntLabel.AddString( &isEInfo.szEntityLabel[0]);
                }
            }
            
            
        }//next file
    }//next entity
}


// Entity has changed, update info
void CViewEntInfo::OnSelchangeEntity() 
{
	// TODO: Add your control notification handler code here
    m_nSelEntity = m_cboEntLabel.GetCurSel();

    FillGeneralInfo();
    
    FillSegmentSourceList();

    // Set source to first one in  list aas default
    m_nSelSource = 0;
    m_cboSourceLabel.SetCurSel(m_nSelSource);

 
    FillSegmentSourceInfo();
	
    // Initialize the dialog
    UpdateData(FALSE);	
}

// Source has changed update info
void CViewEntInfo::OnSelchangeSource() 
{
    m_nSelSource = m_cboEntLabel.GetCurSel();

    FillSegmentSourceInfo();
	
    // Initialize the dialog
    UpdateData(FALSE);		
}

void CViewEntInfo::SetDefaults()
{
    m_nSelSource = -1;
    m_nSelEntity  = -1;   
    
    //{{AFX_DATA_INIT(CViewEntInfo)
	m_uWfCount = 0;
	m_sPtCount = _T("");
	m_dSampleRate = 0.0;
	m_sUnits = _T("");
	m_dInMinVal = 0.0;
	m_dInMaxVal = 0.0;
	m_dResolution = 0.0;
	m_dXLoc = 0.0;
	m_dYLoc = 0.0;
	m_dZLoc = 0.0;
	m_dUserLoc = 0.0;
	m_sUnits2 = _T("");
	m_dF1Freq = 0.0;
	m_dF2Freq = 0.0;
	m_dF1Order = 0.0;
	m_F2Order = 0.0;
	m_sF1Type = _T("");
	m_sF2Type = _T("");
	m_dF2Order = 0.0;
	m_sProbeInfo = _T("");
	m_sSortStatus = _T("");
	//}}AFX_DATA_INIT
}
