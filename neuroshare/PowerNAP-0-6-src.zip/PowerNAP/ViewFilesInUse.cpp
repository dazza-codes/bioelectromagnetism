///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewFilesInUse.cpp $
//
// Description   : implementation of the FilesInUseView class 
//
// Authors       : Kirk Korver
//
// $Date: 3/11/04 12:53p $
//
// $History: ViewFilesInUse.cpp $
// 
// *****************  Version 86  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:53p
// Updated in $/Neuroshare/PowerNAP
// Entity counts now show you how many units are visible
// 
// *****************  Version 85  *****************
// User: Kkorver      Date: 3/09/04    Time: 3:46p
// Updated in $/Neuroshare/PowerNAP
// Now display both how many entities exist and how many are visible
// 
// *****************  Version 84  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:44p
// Updated in $/Neuroshare/PowerNAP
// Fixed UpdateEntityList(), so that it resores the last selection
// 
// *****************  Version 83  *****************
// User: Kkorver      Date: 3/05/04    Time: 3:51p
// Updated in $/Neuroshare/PowerNAP
// Added the ability to delete channels
// 
// *****************  Version 82  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 81  *****************
// User: Kkorver      Date: 3/01/04    Time: 12:29p
// Updated in $/Neuroshare/PowerNAP
// Using the arrow keys in the List will now update the current entity
// 
// *****************  Version 80  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:49p
// Updated in $/Neuroshare/PowerNAP
// Add the menu choice View | Playback
// 
// *****************  Version 79  *****************
// User: Kkorver      Date: 2/19/04    Time: 4:07p
// Updated in $/Neuroshare/PowerNAP
// There is an 'ADD' button on the library details. This button will set
// the correct settings in the registry so the DLL will be remembered
// 
// *****************  Version 78  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 77  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 76  *****************
// User: Abranner     Date: 1/30/04    Time: 3:57p
// Updated in $/Neuroshare/PowerNAP
// Simplified initialization of property sheets.
// 
// *****************  Version 75  *****************
// User: Abranner     Date: 10/31/03   Time: 6:06p
// Updated in $/Neuroshare/PowerNAP
// Removed buttons and rearranged interface.
// 
// *****************  Version 74  *****************
// User: Abranner     Date: 10/29/03   Time: 9:56a
// Updated in $/Neuroshare/PowerNAP
// Fixed title of property sheets.
// 
// *****************  Version 73  *****************
// User: Abranner     Date: 10/28/03   Time: 5:09p
// Updated in $/Neuroshare/PowerNAP
// Implemented Sort All button with Progress Window.
// 
// *****************  Version 72  *****************
// User: Abranner     Date: 10/27/03   Time: 10:35a
// Updated in $/Neuroshare/PowerNAP
// Changed size of FIU dialog and removed non-functioning buttons.
// 
// *****************  Version 71  *****************
// User: Kkorver      Date: 10/22/03   Time: 11:17a
// Updated in $/Neuroshare/PowerNAP
// RebuildAllLists() renamed to RebuildAllListsAndUpdateViews() and now
// calls UpdateAllViews() at the end
// 
// *****************  Version 70  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 69  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 68  *****************
// User: Kkorver      Date: 10/15/03   Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Saving data now prompts
// 
// *****************  Version 67  *****************
// User: Kkorver      Date: 9/15/03    Time: 12:44p
// Updated in $/Neuroshare/nsClassifier
// Removed dead code
// 
// *****************  Version 66  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// *****************  Version 65  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 64  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 63  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 62  *****************
// User: Kkorver      Date: 9/11/03    Time: 7:09a
// Updated in $/Neuroshare/nsClassifier
// Renamed Interfaces.h to nsNSNLibrary.h
// 
// *****************  Version 61  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 60  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 59  *****************
// User: Awang        Date: 8/29/03    Time: 12:35p
// Updated in $/Neuroshare/nsClassifier
// Inactivate ViewSortedInfo menu item
// 
// *****************  Version 58  *****************
// User: Awang        Date: 8/29/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Save #PC coordinates saved correctly from combobox
// 
// *****************  Version 57  *****************
// User: Awang        Date: 8/28/03    Time: 1:53p
// Updated in $/Neuroshare/nsClassifier
// Error message box pops up when KMeans sort button is clicked and there
// is no data.
// 
// *****************  Version 56  *****************
// User: Awang        Date: 8/28/03    Time: 1:42p
// Updated in $/Neuroshare/nsClassifier
// Allow ViewWaveform to open without data 
// 
// *****************  Version 55  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 54  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// *****************  Version 53  *****************
// User: Abranner     Date: 8/27/03    Time: 11:00a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 52  *****************
// User: Abranner     Date: 8/26/03    Time: 6:01p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 51  *****************
// User: Awang        Date: 8/26/03    Time: 2:47p
// Updated in $/Neuroshare/nsClassifier
// Entity list selection remains on the selected entity after sorting
// 
// *****************  Version 50  *****************
// User: Abranner     Date: 8/25/03    Time: 11:27a
// Updated in $/Neuroshare/nsClassifier
// Commented out test code for file saving.
// 
// *****************  Version 49  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 48  *****************
// User: Awang        Date: 8/22/03    Time: 4:05p
// Updated in $/Neuroshare/nsClassifier
// When new entity is selected, its "setsorted" flag is reset to false
// 
// *****************  Version 47  *****************
// User: Awang        Date: 8/15/03    Time: 1:19p
// Updated in $/Neuroshare/nsClassifier
// Added option in View menu choice to display ViewSortedInfo
// 
// *****************  Version 46  *****************
// User: Awang        Date: 8/05/03    Time: 3:55p
// Updated in $/Neuroshare/nsClassifier
// Added ViewOptKMeans
// 
// *****************  Version 45  *****************
// User: Awang        Date: 8/05/03    Time: 3:37p
// Updated in $/Neuroshare/nsClassifier
// Display KMeans options view on menu selection
// 
// *****************  Version 44  *****************
// User: Kkorver      Date: 7/28/03    Time: 11:48a
// Updated in $/Neuroshare/nsClassifier
// Added OnFileSavedata(). It is just a test class right now
// 
// *****************  Version 43  *****************
// User: Awang        Date: 6/30/03    Time: 3:58p
// Updated in $/Neuroshare/nsClassifier
// Added buttons in toolbars that access analoguous button pushes here.
// 
// *****************  Version 42  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// *****************  Version 41  *****************
// User: Kkorver      Date: 5/12/03    Time: 11:18a
// Updated in $/Neuroshare/nsClassifier
// Added OnFileAdddatafileadvanced() and OnPopupAdddatafileadvanced()
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 39  *****************
// User: Abranner     Date: 5/06/03    Time: 9:57a
// Updated in $/Neuroshare/nsClassifier
// Hid non-functional buttons.
// Added screen to ask user to load a file in the beginning.
// 
// *****************  Version 38  *****************
// User: Abranner     Date: 5/02/03    Time: 4:36p
// Updated in $/Neuroshare/nsClassifier
// Fixed bug with number of samples per group and changed global variable
// m_nNumOfSamples to mean number of samples per group and file.
// 
// *****************  Version 37  *****************
// User: Abranner     Date: 5/02/03    Time: 2:45p
// Updated in $/Neuroshare/nsClassifier
// Included number of files in CViewOptPop and added increase in number of
// samples when a file is added (to avoid non integer numbers).
// 
// *****************  Version 36  *****************
// User: Abranner     Date: 5/02/03    Time: 12:23p
// Updated in $/Neuroshare/nsClassifier
// Fixed the autosizing of the header to always include the arrows and the
// size of the individual items.
// 
// *****************  Version 35  *****************
// User: Awang        Date: 5/02/03    Time: 9:10a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 34  *****************
// User: Abranner     Date: 5/02/03    Time: 8:54a
// Updated in $/Neuroshare/nsClassifier
// Fixed error after merging.
// 
// *****************  Version 33  *****************
// User: Abranner     Date: 5/01/03    Time: 5:50p
// Updated in $/Neuroshare/nsClassifier
// Changed window titles.
// Changed the appearance of some things.
// Implemented capability to sort ListCtrls by columns (both text and
// numbers).
// Two new classes were implemented for this: CSortClass and
// CSortListCtrl.
// 
// *****************  Version 32  *****************
// User: Awang        Date: 5/01/03    Time: 1:30p
// Updated in $/Neuroshare/nsClassifier
// Added ViewPCA stuff
// 
// *****************  Version 31  *****************
// User: Abranner     Date: 4/30/03    Time: 6:05p
// Updated in $/Neuroshare/nsClassifier
// Implemented sorting for the list control but the numeric sorting does
// not work correctly.
// 
// *****************  Version 30  *****************
// User: Kkorver      Date: 4/30/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Only allow people to "remove" files if there are files to remove
// 
// *****************  Version 29  *****************
// User: Abranner     Date: 4/30/03    Time: 2:47p
// Updated in $/Neuroshare/nsClassifier
// Changed window positions.
// Changed the entity list to a list control.
// Fized a bug in the waveform view.
// 
// *****************  Version 28  *****************
// User: Kkorver      Date: 4/29/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Added OnCreate() that set's the title of the frame
// Made the toolbar visible for this view
// 
// *****************  Version 27  *****************
// User: Abranner     Date: 4/29/03    Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Added a view for Entity Infos
// 
// *****************  Version 26  *****************
// User: Abranner     Date: 4/28/03    Time: 12:59p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with tooltips.
// 
// *****************  Version 25  *****************
// User: Abranner     Date: 4/28/03    Time: 12:34p
// Updated in $/Neuroshare/nsClassifier
// Added capability to turn tooltips off.
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 4/25/03    Time: 5:39p
// Updated in $/Neuroshare/nsClassifier
// Implemented tooltip support for all windows (hovering shows message).
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 4/25/03    Time: 2:24p
// Updated in $/Neuroshare/nsClassifier
// Option windows can now be opened without a data file loaded.
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 4/24/03    Time: 9:22a
// Updated in $/Neuroshare/nsClassifier
// Added OnViewLibrarydetails()
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 4/23/03    Time: 10:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed the files FilesInUseView to ViewFilesInUse and
// WaveformsView to ViewWaveforms
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 4/22/03    Time: 5:13p
// Updated in $/Neuroshare/nsClassifier
// Renamed m_cboFilesList to m_lstFilesList
// Added  OnPopupRemoveFile() and OnFileDeleteDatafile()
// 
// *****************  Version 19  *****************
// User: Almut        Date: 4/21/03    Time: 5:09p
// Updated in $/Neuroshare/nsClassifier
// Changed class names and the size of the views for (options pop and
// align).
// 
// *****************  Version 18  *****************
// User: Almut        Date: 4/18/03    Time: 5:43p
// Updated in $/Neuroshare/nsClassifier
// Added options for the training samples and removed options from the FIU
// view. Also changed Document to actually test the difference between two
// files.
// 
// *****************  Version 17  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 16  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 15  *****************
// User: Angela       Date: 4/11/03    Time: 1:52p
// Updated in $/Neuroshare/nsClassifier
// reposition waveform views display to show up adjacent to filesinused
// display
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 4/11/03    Time: 11:38a
// Updated in $/Neuroshare/nsClassifier
// Make debug/release versions look the appropriate location for the
// default file to open
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 4/11/03    Time: 11:26a
// Updated in $/Neuroshare/nsClassifier
// Renamed more controls to use the IDC_FIU_XXX_ prefix
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 4/11/03    Time: 9:33a
// Updated in $/Neuroshare/nsClassifier
// Added UpdateGroupCounts()
// Added UpdateSampleCounts()
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 4/10/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Renamed the IDC_ identifiers so that they have a common prefix
// 
// *****************  Version 10  *****************
// User: Angela       Date: 4/10/03    Time: 2:43p
// Updated in $/Neuroshare/nsClassifier
// Changes to updatewaveforms
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:19p
// Updated in $/Neuroshare/nsClassifier
// Added the radio button for select all
// Now read/store the settings in the DOC class. 
// 
// *****************  Version 8  *****************
// User: Almut        Date: 4/10/03    Time: 11:05a
// Updated in $/Neuroshare/nsClassifier
// Added calls to VisitorAlignCheck.
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 4/09/03    Time: 1:54p
// Updated in $/Neuroshare/nsClassifier
// Renamed CFilesInUse to CViewFilesInUse
// 
// *****************  Version 6  *****************
// User: Angela       Date: 4/09/03    Time: 11:10a
// Updated in $/Neuroshare/nsClassifier
// Resize frame to fit form
// 
// *****************  Version 5  *****************
// User: Angela       Date: 4/08/03    Time: 2:24p
// Updated in $/Neuroshare/nsClassifier
// Added waveform view button
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/27/03    Time: 1:50p
// Updated in $/Neuroshare/nsClassifier
// Untabified
// Updated to allow multiple data files
// 
// *****************  Version 3  *****************
// User: Kirk         Date: 3/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Rename the NsFile iterators
// 
// *****************  Version 2  *****************
// User: Kirk         Date: 3/25/03    Time: 1:39p
// Updated in $/Neuroshare/nsClassifier
// Added popup menu choice to insert data files
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 3/25/03    Time: 11:25a
// Created in $/Neuroshare/nsClassifier
// This is the view for the files in use
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DisplaySpike.h"
#include "DocPowerNAP.h"
#include "NsFileIterators.h"

#include "ViewFilesInUse.h"
#include "ViewWaveforms.h"
#include "PropSheetSpkSort.h"
#include "PropSheetGeneral.h"
#include "ViewLibDetails.h"
#include "ViewEntInfo.h"
#include "ViewPCA.h"
#include "ViewRaster.h"
#include "DlgPlayback.h"
#include "SortClass.h"
#include "Splash.h"

#include "VisitorAlgorithms.h"
#include "VisitorShyAlgorithm.h"
#include "nsNSNLibrary.h"
#include "ViewSortedInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef HDF_SORTUP 
#define HDF_SORTUP 0x0400 
#endif 

#ifndef HDF_SORTDOWN 
#define HDF_SORTDOWN 0x0200 
#endif 


/////////////////////////////////////////////////////////////////////////////
// CViewFilesInUse

IMPLEMENT_DYNCREATE(CViewFilesInUse, CFormView)

CViewFilesInUse::CViewFilesInUse() :
    CFormView(CViewFilesInUse::IDD)
{
    //{{AFX_DATA_INIT(CViewFilesInUse)
    //}}AFX_DATA_INIT
}

CViewFilesInUse::~CViewFilesInUse()
{

}

void CViewFilesInUse::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CViewFilesInUse)
    DDX_Control(pDX, IDC_FIU_LST_ENTITYID, m_lstEntityID);
    DDX_Control(pDX, IDC_FIU_BTN_OPTPOP, m_btnOptPop);
    DDX_Control(pDX, IDC_FIU_LBL_TTLSAMPLES, m_lblTotalSamples);
    DDX_Control(pDX, IDC_FIU_LBL_SAMPLES, m_lblSamples);
    DDX_Control(pDX, IDC_FIU_CHK_SATURATION, m_chkSaturationCheck);
    DDX_Control(pDX, IDC_FIU_CHK_ALIGN, m_chkAlignPeaks);
    DDX_Control(pDX, IDC_FIU_RDO_SAMPLE, m_rdoSample);
    DDX_Control(pDX, IDC_FIU_RDO_SELECTALL, m_rdoSelectAll);
    DDX_Control(pDX, IDC_FIU_LST_FILES, m_lstFilesList);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewFilesInUse, CFormView)
    //{{AFX_MSG_MAP(CViewFilesInUse)
    ON_WM_CREATE()
    ON_BN_CLICKED(IDC_FIU_RDO_SELECTALL, OnRdoSelectall)
    ON_BN_CLICKED(IDC_FIU_RDO_SAMPLE, OnRdoSample)
    ON_WM_CONTEXTMENU()
    ON_COMMAND(ID_FL_POPUP_ADD_FILE, OnPopupAddFile)
    ON_BN_CLICKED(IDC_FIU_BTN_WFVIEW, OnWfViewButton)
    ON_BN_CLICKED(IDC_FIU_CHK_ALIGN, OnAlignCheck)
    ON_BN_CLICKED(IDC_FIU_CHK_SATURATION, OnSaturationCheck)
    ON_BN_CLICKED(IDC_FIU_BTN_OPTPOP, OnBTNOptPop)
    ON_BN_CLICKED(IDC_FIU_BTN_OPTALIGN, OnBTNOptAlign)
    ON_BN_CLICKED(IDC_FIU_BTN_ENTITYINFO, OnBtnEntityinfo)
    ON_COMMAND(ID_FL_POPUP_REMOVE_FILE, OnPopupRemoveFile)
    ON_COMMAND(ID_FILE_ADDDATAFILE, OnFileAdddatafile)
    ON_COMMAND(ID_FILE_DELETEDATAFILE, OnFileDeleteDatafile)
    ON_COMMAND(ID_FILE_ADDDATAFILEADVANCED, OnFileAdddatafileadvanced)
    ON_COMMAND(ID_FL_POPUP_ADDDATAFILEADVANCED, OnPopupAdddatafileadvanced)
    ON_COMMAND(ID_VIEW_LIBRARYDETAILS, OnViewLibrarydetails)
    ON_COMMAND(ID_HELP_TOOLTIP, OnHelpTooltip)
    ON_UPDATE_COMMAND_UI(ID_FL_POPUP_REMOVE_FILE, OnUpdatePopupRemoveFile)
    ON_BN_CLICKED(IDC_FIU_BTN_PCPROJVIEW, OnPcView)
    ON_WM_TIMER()
    ON_BN_CLICKED(IDC_FIU_BTN_OPTSHY, OnBtnOptShy)
    ON_COMMAND(ID_VIEW_WAVEFORMS, OnViewWaveforms)
    ON_COMMAND(ID_VIEW_PCPROJECTIONS, OnViewPcProjections)
    ON_COMMAND(ID_VIEW_ENTITYDETAILS, OnViewEntInfo)
    ON_COMMAND(ID_FILE_SAVEDATA, OnFileSavedata)
    ON_COMMAND(ID_VIEW_SORTEDNFO, OnViewSortedInfo)
    ON_WM_SIZE()
    ON_COMMAND(ID_SORTINGOPTIONS, OnSortingOptions)
    ON_COMMAND(ID_GENERALOPTIONS, OnGeneralOptions)
    ON_BN_CLICKED(IDC_FIU_BTN_RASTER, OnBtnRaster)
    ON_BN_CLICKED(IDC_FIU_BTN_SORTALL, OnBtnSortAll)
    ON_COMMAND(ID_FILE_DLLS, OnFileDlls)
    ON_COMMAND(ID_VIEW_PLAYBACK, OnViewPlayback)
    ON_NOTIFY(LVN_ITEMCHANGED, IDC_FIU_LST_ENTITYID, OnLstEntityidItemchanged)
	ON_COMMAND(ID_POPUP_DELETECHANNEL, OnPopupDeletechannel)
	ON_UPDATE_COMMAND_UI(ID_POPUP_DELETECHANNEL, OnUpdatePopupDeletechannel)
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewFilesInUse diagnostics

#ifdef _DEBUG
void CViewFilesInUse::AssertValid() const
{
    CFormView::AssertValid();
}

void CViewFilesInUse::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}

CDocPowerNAP* CViewFilesInUse::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CViewFilesInUse message handlers


void CViewFilesInUse::UpdateFileList()
{
    /////////// Out with the old
    m_lstFilesList.ResetContent();

    /////////// In with the new
    FILEINFOLIST & v = GetDocument()->m_icFileVector;
    FILEINFOLIST::iterator it;
    for (it = v.begin(); it != v.end(); ++it)
    {
        // get the short name
        CString strShortName((*it)->strFilePathName );
        int nCharPos = strShortName.ReverseFind('\\');
        strShortName = strShortName.Right(strShortName.GetLength() - nCharPos - 1);

        // Add it to the list
        m_lstFilesList.AddString(strShortName);
    }

    // Select the most recent addition (last in list)
    m_lstFilesList.SetCurSel(m_lstFilesList.GetCount() - 1);
}


void CViewFilesInUse::UpdateEntityList()
{
    POSITION Pos = m_lstEntityID.GetFirstSelectedItemPosition();
    int nSel = m_lstEntityID.GetNextSelectedItem(Pos);

    //////////// Out with the old
    m_lstEntityID.DeleteAllItems();
    m_lstEntityID.UpdateWindow();
    // Autosize the columns to the label and arrows in the header
    m_lstEntityID.AutoSizeColumns(-2);

    //////////// In with the new
    ENTITYINFOLIST::iterator it;
    ENTITYINFOLIST & List = GetDocument()->m_icEntityInfoVector;

    // Don't continue if no file was loaded
    if (List.empty())
        return;

    int nCount = 0;
    for (it = List.begin(); it != List.end(); ++it) 
    {
        EntityInfo & rsInfo = *it;
        CString strEntityText;

        strEntityText.Format("%4d", rsInfo.dwEntityIndex);  
        m_lstEntityID.InsertItem(nCount, strEntityText);

        strEntityText.Format("%s", rsInfo.isEntityInfo.szEntityLabel);  
        m_lstEntityID.SetItemText(nCount, 1, strEntityText);

        if (GetDocument()->IsSegment(rsInfo.dwEntityIndex))
        {
            DWORD dwCount = GetDocument()->GetSegment(rsInfo.dwEntityIndex).size();
            strEntityText.Format("%d / %d", dwCount, rsInfo.isEntityInfo.dwItemCount);
        }
        else
        {
            strEntityText.Format("%d", rsInfo.isEntityInfo.dwItemCount);
        }
        m_lstEntityID.SetItemText(nCount++, 2, strEntityText);
    }

    // Autosize again to check whether the columns need to get wider to accomodate the items
    m_lstEntityID.AutoSizeColumns(-1);

    if (nCount == nSel)     // in case we have deleted the "last" item in the list
        --nSel;

    m_lstEntityID.SetItemState(nSel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
    m_lstEntityID.EnsureVisible(nSel, false);
    m_lstEntityID.UpdateWindow();

    InitialColumnSort(&m_lstEntityID);
}

void CViewFilesInUse::OnInitialUpdate() 
{
    // The document (for convenience)
    CDocPowerNAP & rcDoc = *(GetDocument());

    if (m_tool.m_hWnd == NULL)
        m_tool.Create(this);

    // Add tooltip to the control
    m_tool.AddTool(GetDlgItem(IDC_FIU_RDO_SAMPLE), IDC_FIU_RDO_SAMPLE); 
    m_tool.AddTool(GetDlgItem(IDC_FIU_RDO_SELECTALL), IDC_FIU_RDO_SELECTALL); 

    // TRUE to show tooltips,FALSE to disable tooltips
    if (rcDoc.m_bTooltips)
        m_tool.Activate(true);
    else
        m_tool.Activate(false);

    CFormView::OnInitialUpdate();


    // Size frame to fit the formview
    CFrameWnd* pParentFrame = GetParentFrame();
    pParentFrame->RecalcLayout();
    pParentFrame->SetWindowPos(NULL, 0, 0, 840, 170, SWP_NOMOVE | SWP_NOZORDER);
//    ResizeParentToFit(false);
//    ResizeParentToFit();

    // Initialize list control
    m_lstEntityID.SetExtendedStyle(LVS_EX_FULLROWSELECT);
    // Size of the columns don't matter since we are autosizing anyway
    m_lstEntityID.InsertColumn(0, "", LVCFMT_LEFT, 0, 0);
    m_lstEntityID.InsertColumn(1, "Label", LVCFMT_LEFT, 0, 0);
    m_lstEntityID.InsertColumn(2, "#", LVCFMT_LEFT, 0, 0);
    m_lstEntityID.InsertColumn(3, "", LVCFMT_LEFT, 0, 0);

    if (rcDoc.m_bSampleData)
        this->m_rdoSample.SetCheck(1);
    else
        this->m_rdoSelectAll.SetCheck(1);

    this->m_chkSaturationCheck.SetCheck(rcDoc.m_bRemoveSaturatedSpikes ? 1 : 0);
    this->m_chkAlignPeaks.SetCheck(rcDoc.m_bAlignPeaks ? 1 : 0);
}


void CViewFilesInUse::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
    // We don't care if we are animating or not.
    if (lHint == HINT_USER_ANIMATING)
        return;

    // Ok..First we have to Add to the 'files being edited box'
    UpdateFileList();

    // Now scroll through and set all of the entities
    UpdateEntityList();

    // All this was moved here from OnInitialUpdate().
    //     Things need to update when UpdateAllViews is called. (Almut)
    // The document (for convenience)
    CDocPowerNAP & rcDoc = *(GetDocument());

    CString strTemp;

    if (!rcDoc.m_icFileVector.empty())
        strTemp.Format("%i", rcDoc.m_nNumOfSamples * rcDoc.m_nNumOfGroups * 
                             rcDoc.m_icFileVector.size());
    else
        strTemp.Format("%i", rcDoc.m_nNumOfSamples * rcDoc.m_nNumOfGroups);

    m_lblTotalSamples.SetWindowText(strTemp);
}



BOOL CViewFilesInUse::PreTranslateMessage(MSG* pMsg) 
{
    m_tool.RelayEvent(pMsg);

    return CFormView::PreTranslateMessage(pMsg);
}


void CViewFilesInUse::OnRdoSelectall() 
{
    m_lblSamples.EnableWindow(false);
    m_lblTotalSamples.EnableWindow(false);
    m_btnOptPop.EnableWindow(false);

    // Save the setting in the doc
    GetDocument()->m_bSampleData = false;

    // Invalidates all wave forms, and update views
    GetDocument()->RebuildSegListAndUpdateViews();
}


void CViewFilesInUse::OnRdoSample() 
{
    m_lblSamples.EnableWindow();
    m_lblTotalSamples.EnableWindow();
    m_btnOptPop.EnableWindow();

    // Save the setting in the doc
    GetDocument()->m_bSampleData = true;

    // This action invalidates all wave forms
    GetDocument()->RebuildSegListAndUpdateViews();
}

void CViewFilesInUse::OnContextMenu(CWnd* pWnd, CPoint point) 
{
    CMenu icMenu;
    icMenu.LoadMenu(IDR_POPUP_FILE_LIST);
    CMenu * pcContextMenu = icMenu.GetSubMenu(0);

    pcContextMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON, 
                                  point.x, point.y, AfxGetMainWnd());
}

void CViewFilesInUse::OnPopupAddFile()
{
    GetDocument()->AddDataFilePrompt();
}

void CViewFilesInUse::OnFileAdddatafile() 
{
    GetDocument()->AddDataFilePrompt();
}


void CViewFilesInUse::OnPopupRemoveFile() 
{
    OnFileDeleteDatafile();
}

void CViewFilesInUse::OnFileDeleteDatafile() 
{
    // Only try to remove from the list, if there are some in the list
    if (m_lstFilesList.GetCount() > 0)
    {
        // Find out which is selected
        int nSelected = m_lstFilesList.GetCurSel();

        ASSERT(nSelected >= 0);

        // Remove it from the list
        GetDocument()->RemoveFile(nSelected);

        // Force the list to be recreated

         // Ok..First we have to Add to the 'files being edited box'
        UpdateFileList();

        // Now scroll through and set all of the entities
        UpdateEntityList();
    }
}


void CViewFilesInUse::OnWfViewButton() 
{
    // Display the selected training waveforms in CWaveformsView form view
    GetDocument()->CreateOrActivateView(RUNTIME_CLASS( CViewWaveforms ));
}    

void CViewFilesInUse::OnSaturationCheck() 
{
    bool bClipIfRequired = m_chkSaturationCheck.GetCheck() ? true : false;

    // Save it in the doc
    GetDocument()->m_bRemoveSaturatedSpikes = bClipIfRequired;

    // This action invalidates all wave forms
    GetDocument()->RebuildSegListAndUpdateViews();
}
    
void CViewFilesInUse::OnAlignCheck() 
{
    bool bAlignPeaks = m_chkAlignPeaks.GetCheck() ? true : false;

    // Save it in the doc
    GetDocument()->m_bAlignPeaks = bAlignPeaks;

    // This action invalidates all wave forms
    GetDocument()->RebuildSegListAndUpdateViews();
}

void CViewFilesInUse::OnBTNOptPop() 
{
    ShowOptGeneral(0);
}

void CViewFilesInUse::OnBTNOptAlign() 
{
    ShowOptGeneral(1);
}


void CViewFilesInUse::OnViewLibrarydetails() 
{
    GetDocument()->CreateOrActivateView(RUNTIME_CLASS(CViewLibDetails));
}


void CViewFilesInUse::OnHelpTooltip() 
{
    CMenu* pSubMenu = AfxGetApp()->m_pMainWnd->GetMenu()->GetSubMenu(4);

    UINT state = pSubMenu->GetMenuState(ID_HELP_TOOLTIP, MF_BYCOMMAND);
    ASSERT(state != 0xFFFFFFFF);

    if (state & MF_CHECKED)
    {
        pSubMenu->CheckMenuItem(ID_HELP_TOOLTIP, MF_UNCHECKED | MF_BYCOMMAND);
        GetDocument()->m_bTooltips = false;
        m_tool.Activate(false);
    }
    else
    {
        pSubMenu->CheckMenuItem(ID_HELP_TOOLTIP, MF_CHECKED | MF_BYCOMMAND);
        GetDocument()->m_bTooltips = true;
        m_tool.Activate(true);
    }

    // Get other views up to date
    GetDocument()->UpdateAllViews(this);
}

void CViewFilesInUse::OnBtnEntityinfo() 
{
    //GetDocument()->CreateOrActivateView(RUNTIME_CLASS(CViewEntityInfo));
    ShowOptGeneral(0);
}

int CViewFilesInUse::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
    if (CFormView::OnCreate(lpCreateStruct) == -1)
        return -1;

    // TODO: Add your specialized creation code here
    CMainFrame * pFrame = static_cast<CMainFrame *>(GetParentFrame());

    pFrame->SetTitle("Files In Use");

    // CG: The following line was added by the Splash Screen component...
    // and then moved here by me (Almut) because we don't want it to show up everytime a window opens
    CSplashWnd::ShowSplashScreen(this);

    // This timer HAS to be longer than the timer of the splash screen or the app dies
    SetTimer(TMR_OPEN_FILE, TMR_TIME_OPEN_FILE, NULL);

    return 0;
}

void CViewFilesInUse::OnPcView()
{
    GetDocument()->CreateOrActivateView(RUNTIME_CLASS( CViewPCA ));
}

void CViewFilesInUse::OnUpdatePopupRemoveFile(CCmdUI* pCmdUI) 
{
    bool bEnable = m_lstFilesList.GetCount() > 0 ? true : false;

    pCmdUI->Enable(bEnable);
}


void CViewFilesInUse::InitialColumnSort(CSortListCtrl *pListCtrl)
{
    HDITEM HeaderItem;
    CHeaderCtrl* HeaderCtrl = pListCtrl->GetHeaderCtrl();

    HeaderItem.mask = HDI_FORMAT | HDI_BITMAP;
    HeaderCtrl->GetItem(0, &HeaderItem);

    if (HeaderItem.hbm != 0)
    {
        DeleteObject(HeaderItem.hbm);
        HeaderItem.hbm = 0;
    }

    HeaderItem.fmt |= HDF_BITMAP | HDF_BITMAP_ON_RIGHT;
    HeaderItem.hbm = (HBITMAP)LoadImage(AfxGetInstanceHandle(), 
        MAKEINTRESOURCE(true ? IDB_UP : IDB_DOWN), IMAGE_BITMAP, 0, 0, 
        LR_LOADMAP3DCOLORS);

    HeaderCtrl->SetItem(0, &HeaderItem);

    CSortClass csc(pListCtrl, 0, false);
    csc.Sort(true);
}


void CViewFilesInUse::OnTimer(UINT nIDEvent) 
{
    switch (nIDEvent)
    {
    case TMR_OPEN_FILE:
        KillTimer(nIDEvent);
        if (AfxMessageBox("Would you like to load a data file?", 
            MB_YESNO | MB_ICONQUESTION, 0) == IDYES)
            GetDocument()->AddDataFilePrompt();
        break;

    case TMR_UPDATE_ENTITY:
        KillTimer(nIDEvent);
        DetermineTheActiveEntity();
        break;
    }
}

void CViewFilesInUse::OnFileAdddatafileadvanced() 
{
    GetDocument()->AddDataFileUsingThisDLLPrompt();
}

void CViewFilesInUse::OnPopupAdddatafileadvanced() 
{
    OnFileAdddatafileadvanced();
}

void CViewFilesInUse::OnBtnOptShy() 
{
    ShowOptSpkSort(0);
}


// Show waveform display 
// This is selected from tool bar
void CViewFilesInUse::OnViewWaveforms() 
{
    OnWfViewButton();   
}


// Show PC projection display
// This is selected from tool bar
void CViewFilesInUse::OnViewPcProjections() 
{
    OnPcView(); 
}


void CViewFilesInUse::OnViewEntInfo() 
{
    GetDocument()->CreateOrActivateView(RUNTIME_CLASS(CViewEntInfo));
    
}

void CViewFilesInUse::OnFileSavedata() 
{
    // This is how to save the data
    GetDocument()->SaveDataPrompt();
}

void CViewFilesInUse::OnViewSortedInfo()
{
// Can't inactivate this menu choice by greying out the menu item
// so, comment this out for now, until fully functional
//    GetDocument()->CreateOrActivateView(RUNTIME_CLASS(CViewSortedInfo));


}//OnViewSortedInfo


void CViewFilesInUse::OnSize(UINT nType, int cx, int cy) 
{
    CFormView::OnSize(nType, cx, cy);
    
    SetScrollRange(SB_HORZ, 0, 0);
    SetScrollRange(SB_VERT, 0, 0);
}


void CViewFilesInUse::ShowOptSpkSort(int nView)
{
    CDocPowerNAP *pDocument = GetDocument();

    CPropSheetSpkSort icPropSheetSpkSort("Automatic Spike Sorting", NULL, nView, pDocument);

    icPropSheetSpkSort.DoModal();  // Property sheet handles updating the doc and views
}

void CViewFilesInUse::ShowOptGeneral(int nView)
{
    CDocPowerNAP *pDocument = GetDocument();

    CPropSheetGeneral icPropSheetGeneral("General", NULL, nView, pDocument);

    icPropSheetGeneral.DoModal();  // Property sheet handles updating the doc and views
}

void CViewFilesInUse::OnSortingOptions() 
{
    ShowOptSpkSort(0);
}

void CViewFilesInUse::OnGeneralOptions() 
{
    ShowOptGeneral(0);
}

void CViewFilesInUse::OnBtnRaster() 
{
    GetDocument()->CreateOrActivateView(RUNTIME_CLASS( CViewRaster ));
}

void CViewFilesInUse::OnBtnSortAll() 
{
    if (GetDocument()->m_icFileVector.empty())
    {
        AfxMessageBox(IDS_ERROR_MUST_HAVE_DATA, MB_ICONEXCLAMATION, 0);
    }
    else
    {
        CDocPowerNAP * pDoc = GetDocument();
        int nEntityID = pDoc->GetActiveEntity();

        // Activate progress window
        CProgressWnd wndProgress(this, "Sorting All Channels", TRUE);
        wndProgress.GoModal();
        wndProgress.SetWindowSize(1, 300);
        wndProgress.SetRange(0, pDoc->m_icSegmentList.size());
        wndProgress.SetText("Please Wait...");

        for (SEGMENTENTITYLIST::iterator sit = pDoc->m_icSegmentList.begin();
             sit < pDoc->m_icSegmentList.end(); ++sit)
        {
            if (!wndProgress.Cancelled())
            {
                pDoc->SetActiveEntity((*sit)->GetEntityID());

                pDoc->SortActiveChannel(TDISTRMETHOD, false);

                wndProgress.StepIt();
                wndProgress.PeekAndPump();
            }
            else
                break;
        }
        
        pDoc->UpdateAllViews(this);
        pDoc->SetActiveEntity(nEntityID);
    }
}

void CViewFilesInUse::OnFileDlls() 
{
    GetDocument()->CreateOrActivateView(RUNTIME_CLASS(CViewLibDetails));
}

void CViewFilesInUse::OnViewPlayback() 
{
    CDlgPlayback * pDlg = new CDlgPlayback(GetDocument());
    pDlg->Create(CDlgPlayback::IDD, NULL);
    pDlg->ShowWindow(SW_SHOW);
}



void CViewFilesInUse::OnLstEntityidItemchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
    //NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

    // this function is called every time an item changes...including 
    // a "click" or an "arrow key". Several of these occur in quick
    // succession of one another. So what we've done here is to put a 
    // little delay to wait for all of the items to change before we 
    // actually do any of the work.
    KillTimer(TMR_UPDATE_ENTITY);                               // stop the last one
    SetTimer(TMR_UPDATE_ENTITY, TMR_TIME_UPDATE_ENTITY, NULL);  // begin anew

    *pResult = 0;
}

// Author & Date:       01 Mar 2004
// Purpose: this is the top level function to set the active entity
void CViewFilesInUse::DetermineTheActiveEntity()
{
    int nOldEntity = GetDocument()->GetActiveEntity();

    POSITION Pos = m_lstEntityID.GetFirstSelectedItemPosition();
    int nSel = m_lstEntityID.GetNextSelectedItem(Pos);
    CString strEntityLabel;

    strEntityLabel = m_lstEntityID.GetItemText(nSel, 0);

    // The only reason this works is because the entity is the first part of the label
    int nEntity = atoi(strEntityLabel);

    if (nEntity == nOldEntity)  // if nothing has changed, then we don't need to update
        return;

    GetDocument()->SetActiveEntity(nEntity);
 
    // Reset sorting status unless saved    
    GetDocument()->SetSorted(false);

    // Get other views up to date
    GetDocument()->UpdateAllViews(this);
}

void CViewFilesInUse::OnPopupDeletechannel() 
{
    // Because of OnUpdatePopupDeletechannel(), we are guaranteed
    // that we have an active entity
    int32 nEntity = GetDocument()->GetActiveEntity();
    GetDocument()->DeleteEntity(nEntity);
}

void CViewFilesInUse::OnUpdatePopupDeletechannel(CCmdUI* pCmdUI) 
{
    int32 nIdx = GetDocument()->GetActiveEntityIndex();
    pCmdUI->Enable(nIdx == -1 ? false : true);
}

