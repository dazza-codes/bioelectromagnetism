///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DisplaySpike.h $
//
// Authors       : Angela Wang
//
// $Date: 3/11/04 12:55p $
//
// $History: DisplaySpike.h $
// 
// *****************  Version 28  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:55p
// Updated in $/Neuroshare/PowerNAP
// Minor improvements for speed reasons
// 
// *****************  Version 27  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:45p
// Updated in $/Neuroshare/PowerNAP
// Added basic "clipping" functions
// 
// *****************  Version 26  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:30p
// Updated in $/Neuroshare/PowerNAP
// Added AnimateBegin() and AnimateToHere()
// 
// *****************  Version 25  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:54p
// Updated in $/Neuroshare/PowerNAP
// Added DrawTheseSpikes()
// 
// *****************  Version 24  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 23  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:18a
// Updated in $/Neuroshare/nsClassifier
// Removed dead code
// Separated out the different "mouse" states
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 10/17/03   Time: 1:32p
// Updated in $/Neuroshare/nsClassifier
// Moving the mouse now just slides the threshold line. Later, on Mouse
// up, the threshold is actually set
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:52a
// Updated in $/Neuroshare/nsClassifier
// WAVEFORM is now in CommonTypes.h
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 19  *****************
// User: Abranner     Date: 10/15/03   Time: 6:02p
// Updated in $/Neuroshare/nsClassifier
// Fixed problems with merging.
// 
// *****************  Version 18  *****************
// User: Abranner     Date: 10/15/03   Time: 5:56p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 17  *****************
// User: Kkorver      Date: 10/15/03   Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Added SetThresholdFromPoint()
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 15  *****************
// User: Awang        Date: 8/18/03    Time: 3:22p
// Updated in $/Neuroshare/nsClassifier
// Changed name of ctrlist
// 
// *****************  Version 14  *****************
// User: Awang        Date: 8/05/03    Time: 2:01p
// Updated in $/Neuroshare/nsClassifier
// Reduce to 1 PC projection display
// Created CPCAMainFrame to deal with toolbar with custom controls
// 
// *****************  Version 13  *****************
// User: Awang        Date: 6/30/03    Time: 3:49p
// Updated in $/Neuroshare/nsClassifier
// Re-design of Displays with toolbars
// 
// *****************  Version 12  *****************
// User: Awang        Date: 6/18/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 11  *****************
// User: Awang        Date: 6/16/03    Time: 1:12p
// Updated in $/Neuroshare/nsClassifier
// New unit definitions
// 
// *****************  Version 10  *****************
// User: Awang        Date: 6/10/03    Time: 5:09p
// Updated in $/Neuroshare/nsClassifier
// Hightlights selected waveform
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 4/30/03    Time: 2:36p
// Updated in $/Neuroshare/nsClassifier
// Major overhaul so the drawing is done directly wihtout requiring the
// "bitblit"
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 4/29/03    Time: 5:06p
// Updated in $/Neuroshare/nsClassifier
// Threshold line now tracks and arrows work.
// 
// *****************  Version 7  *****************
// User: Awang        Date: 4/28/03    Time: 11:10a
// Updated in $/Neuroshare/nsClassifier
// Changed class name to CDisplaySpike
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 4/25/03    Time: 2:12p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef DISPLAYSPIKE_H_INCLUDED
#define DISPLAYSPIKE_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DocPowerNAP.h"
#include "CommonTypes.h"
#include "MouseState.h"
#include <vector>

// Used by the on notify 
static const int NF_SPK_NEW_REJECT;
struct SPK_NEW_REJECT 
{
    NMHDR hdr;          // needed to make windows happy
    double dRejectValue;// the new "reject" value
};


/////////////////////////////////////////////////////////////////////////////
// CDisplaySpike window

class CDisplaySpike : public CWnd
{
// Construction
public:
    CDisplaySpike();
    virtual ~CDisplaySpike();

    CDocPowerNAP *m_pDoc;

// Attributes
public:
    uint32  m_dwCurrEntity;
    UnitMasks m_enDrawUnit;         // the neuroshare (bit masks) of the unit to display
    
    int     m_nPtCount;    
    
    COLORREF m_crBackColor;        // background color
    COLORREF m_crGridColor;        // grid color
    COLORREF m_crPlotColor;        // data color  
 
    CRect  m_rectClient;
    CBrush m_brushBack;

    int m_nClientHeight;
    int m_nClientWidth;

    double m_dMaxY, m_dMinY;
    double m_dMaxX, m_dMinX;
    double m_dYScaleFactor;
    double m_dXScaleFactor;

    CString m_strYUnits;
    CString m_strXUnits;

    CString m_strMaxYLabel, m_strMinYLabel; 
    CString m_strMaxXLabel; 
    
    HCURSOR m_hDrawingCursor[UNITCOUNT];
    HCURSOR m_hArrowCursor;

    typedef std::vector<CPoint> POINTVECTOR;
    typedef std::vector<POINTVECTOR> LISTOFPOINTVECTORS;

    POINTVECTOR m_icOnePolyPts;
    LISTOFPOINTVECTORS m_icPolyList[UNITCOUNT]; 
    
    // Operations
public:

    void SetRejecting(bool bOn);       // turn on/off the rejecting functions
    bool GetRejecting()             // tell me if we are "rejecting" TRUE = yes; FALSE, no
        { return m_pcActiveMouse == &m_icMouseReject; }

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDisplaySpike)
    protected:
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    //}}AFX_VIRTUAL

public:
	CRect m_rectThreshTab;
	UINT32 m_dwPrevSelWF;

public:
	void SetCurrEntity(uint32 dwEntity);
    void SetMinMaxWfVal(double dMaxVal);
	void SetDrawUnit(UnitMasks enDrawUnit);
    UnitMasks GetDrawUnit() { return m_enDrawUnit; }


	void UnHilightSpike(INT32 nWFIndex);
	void HilightSpike(INT32 nWFIndex);
	void ErasePrevSelSpike(INT32 nWFIndex);
	void DrawSelSpike(INT32 nSelWF);

    void SetYAxis(CString strUnits);   
    void SetXAxis(double dMaxVal, double dMinVal, double dSampleRate, CString strUnits);   

    void DrawThreshold();

    // Erase and redraw the screen to only show these waves (useful for animating)
    void DrawTheseSpikes(UINT32 nSpkFirst, UINT32 nSpkLast);

    // We are about to start animating, so erase the screen and only show this many waves
    // while we animate.
    // Inputs:
    //  cbMaxSpikes - the maximum number of spikes to show at a time.
    void AnimateBegin(UINT32 cbMaxSpikes, double dTime);

    // Purpose: Animate to this point in time
    // Inputs:
    //  dTime - do your animation until this point in time
    void AnimateToHere(double dTime);

protected:
    CPen m_penGrid;         // The pen we use to draw grid lines
    CPen m_penRedThin;         
    CPen m_penRedThick;
    CPen m_penBlueThick;

    typedef std::vector <CPoint> VCTPOINTS;
    VCTPOINTS m_vPoints;            // common storage area for drawing points. This is done for speed reasons

    void CalculateAllX();           // calculate all of the 'x' coordinates for the points vector

    int     m_nClientThresh;        // The 'y' value of the threshold (in pixels)
    int     m_nClientReject;        // the 'y' value of the reject line (in pixels)
    SPK_NEW_REJECT m_isNotifyReject;// used for the "notify" mechanism (CANNOT BE ON THE STACK)

    // Purpose: notify our parent that the "reject" value has changed
    // Inputs:
    //  dRejectVal - the new reject value
    void SendNotifyReject(double dRejectVal);
    
    typedef MouseState <CDisplaySpike> CDSMState;   // CDisplayMouseState

    class MouseRegular : public CDSMState
    {
    } m_icMouseRegular;
    friend class MouseRegular;

    class MouseThreshold : public CDSMState
    {
        virtual void OnLButtonDown(UINT nFlags, CPoint point);
        virtual void OnLButtonUp(UINT nFlags, CPoint point);
        virtual void OnDragging(UINT nFlags, CPoint point);
    } m_icMouseThreshold;
    friend class MouseThreshold;

    class MouseReject : public CDSMState
    {
        virtual void OnLButtonDown(UINT nFlags, CPoint point);
        virtual void OnLButtonUp(UINT nFlags, CPoint point);
        virtual void OnDragging(UINT nFlags, CPoint point);
    } m_icMouseReject;
    friend class MouseReject;


    enum MouseType { MSE_REGULAR, MSE_THRESHOLDING, MSE_REJECT};
    void SwitchMouse(MouseType enMouse);
    CDSMState * m_pcActiveMouse;

    struct Animate
    {
        uint32 m_nLastVisibleIndex;     // the Index of the last visible waveform
        UINT32 m_cnNumSpikes;           // How many spikes are currently visible
        UINT32 m_cnMaxSpikes;           // How many spikes are maximally visible

        // These are cached for performance reasons
        NsFile * m_pcFile;                  // the file to read from
        UINT32 m_dwEntityID;                // the entity we are animating
        SEGMENTLIST::const_iterator m_itSpike;    // Our current spike to draw (will point to 1st valid spike to draw, or end of list)
        SEGMENTLIST::const_iterator m_itSpkEnd;   // STL end of the spike list
    } m_isAnimate;

protected:
    // purpose: redraw the background and get ready for waves to be added
    void AnimateClear(CDC & rcDC);

	void DisplayThresholdInToolbar(double dRealThreshVal);
	void SetThresholdFromPoint(CPoint point);
    int GetThresholdFromScreen(CPoint point);
    void MoveThresholdOnScreen(CPoint ptNew);
    void MoveRejectOnScreen(CPoint ptNew);

    int    XfmWorldToScreenY(double dValue) const;
    double XfmScreenToWorldY(int nValue) const;

    void DrawThresholdLine(CDC & pDC);
    void DrawRejectLine();
    void DrawRejectLine(CDC & rcDC);        // draw the reject line


        
    void DrawSpikes(CDC & rcDC);        // Draws ALL spikes
    void DrawTheseSpikes(CDC & rcDC, UINT32 nSpkFirst, UINT32 nSpkLast);    // draws SOME spikes
    bool DrawThisSpike(CDC & rcDC, const DataSegment & rSpike);             // draw this spike
    void DrawGrid(CDC & rcDC);
    void SetLabels(CDC & rcDC);
    void DrawCtrWaveform(CDC & rcDC);
    void DrawLine(CDC & rcDC, WAVEFORM & rcWave, CPen & rcPen);



    // Generated message map functions
    //{{AFX_MSG(CDisplaySpike)
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnPaint();
    afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
