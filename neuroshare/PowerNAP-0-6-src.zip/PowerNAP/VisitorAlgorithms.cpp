///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorAlgorithms.cpp $
//
// Description   : implementation of the VisitorAlgorithms classes.
//
// Authors       : Kirk Korver
//
// $Date: 3/09/04 2:42p $
//
// $History: VisitorAlgorithms.cpp $
// 
// *****************  Version 25  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:42p
// Updated in $/Neuroshare/PowerNAP
// Added VisitorRejectCheck
// 
// *****************  Version 24  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:25p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 23  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:33p
// Updated in $/Neuroshare/PowerNAP
// Use the new GetSegment() and GetActiveSegment()
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:47p
// Updated in $/Neuroshare/PowerNAP
// GetWave() no longer needs the EntityID passed to it
// 
// *****************  Version 21  *****************
// User: Abranner     Date: 2/09/04    Time: 11:43a
// Updated in $/Neuroshare/PowerNAP
// Changed variable names.
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 19  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Minor Logic change in ExceedsLimit
// 
// *****************  Version 17  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 16  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:06p
// Updated in $/Neuroshare/nsClassifier
// VisitorThresholdCheck() now saves the entity it is looking for
// 
// *****************  Version 15  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 14  *****************
// User: Abranner     Date: 9/11/03    Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// Fixed indeces to m_dThreshold.
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 4/28/03    Time: 5:28p
// Updated in $/Neuroshare/nsClassifier
// Added one more option to align peaks.
// 
// *****************  Version 8  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 7  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 4/11/03    Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Fixed clipping algorithm
// 
// *****************  Version 5  *****************
// User: Almut        Date: 4/10/03    Time: 3:16p
// Updated in $/Neuroshare/nsClassifier
// Added calculation for the mean peak and align data to that.
// 
// *****************  Version 4  *****************
// User: Almut        Date: 4/10/03    Time: 2:04p
// Updated in $/Neuroshare/nsClassifier
// Fixed memory leak of allocated variables.
// 
// *****************  Version 3  *****************
// User: Almut        Date: 4/10/03    Time: 11:33a
// Updated in $/Neuroshare/nsClassifier
// Debugged align and truncate algorithm
// 
// *****************  Version 2  *****************
// User: Almut        Date: 4/09/03    Time: 5:20p
// Updated in $/Neuroshare/nsClassifier
// Added alignment and truncation of waveforms.
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 4/01/03    Time: 1:52p
// Created in $/Neuroshare/nsClassifier
// This contains all of the implementations of the algorithms used by the
// visitors
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DocPowerNAP.h"
#include "VisitorAlgorithms.h"

#include <functional>

using namespace std;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Tell me if a waveform exceeds this value or not
// Outputs:
//  TRUE means exceeds; FALSE, never exceeds
class ExceedsLimit : public unary_function <DataSegment, bool> 
{
public:
    ExceedsLimit(double dThreshold) : 
      m_dThreshold(dThreshold) {};

    bool operator () (const DataSegment & rData) const
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        rData.GetWave(aicWave);

        // Look to see if it goes too high
        for (int nPt = 0; nPt < aicWave.size(); ++nPt)
        {
            if ((m_dThreshold >= 0) && (aicWave[nPt] >= m_dThreshold))
                return true;
            else if ((m_dThreshold < 0) && (aicWave[nPt] <= m_dThreshold))
                return true;
        }
        return false;
    }

private:
    double m_dThreshold;
};



// Author & Date:   Almut Branner     April 17, 2003
// Purpose: Redo thresholding 
// Inputs:  rcData - reference to the data we need to process
// Outputs: TRUE  - successful
//          FALSE - failed
bool VisitorThresholdCheck::Visit(CDocPowerNAP & rcData)
{
    double dThreshold = rcData.GetThreshold(m_dwEntityID);

    if (dThreshold != 0.0)
    {
        SEGMENTLIST & rSegs = rcData.GetSegment(m_dwEntityID).GetList();

        // Remove all that exceed the threshold
        rSegs.erase(remove_if(rSegs.begin(), rSegs.end(), not1(ExceedsLimit(dThreshold))), rSegs.end());

        TRACE("VisitorThresholdCheck Seg Size is now %i\n", rSegs.size());
    }

    return true;
} 


// Author & Date:   Kirk Korver     05 Mar 2004
// Purpose: remove all segments that exceed the reject level
// Inputs:
//  rDoc - the document to work upon
bool VisitorRejectCheck::Visit(CDocPowerNAP & rDoc)
{
    SEGMENTLIST & rSegs = rDoc.GetSegment(m_dwEntityID).GetList();
    
    // Remove all that exceed the threshold
    rSegs.erase(remove_if(rSegs.begin(), rSegs.end(), ExceedsLimit(m_dRejectVal)), rSegs.end());
    
    TRACE("VisitorRejectCheck Seg Size is now %i\n", rSegs.size());
    return true;
}


// Author & Date:   Angela Wang     Mar 17, 2003
// Purpose: Mark clipped waveforms as artifacts 
// Inputs:  rcData - reference to the data we need to process
// Outputs: TRUE  - successful
//          FALSE - failed
bool VisitorClipCheck::Visit(CDocPowerNAP & rcData)
{
    // Get max and min possible value of input signal
    ns_SEGSOURCEINFO isSSInfo;
    int32 nEntity = rcData.GetActiveEntity();
    if (nEntity == -1)
        nEntity = 0;

    FileInfo & isInfo = *rcData.m_icFileVector[0];

    if (ns_OK != rcData.GetSegmentSourceInfo(isInfo.icFile, nEntity, 0, isSSInfo))
        return false;


    // Get max and min possible value of input signal
    double dMaxVal = isSSInfo.dMaxVal;
    double dMinVal = isSSInfo.dMinVal;

    Segments & rSeg = rcData.GetActiveSegment();
    DWORD dwEntityID = rSeg.GetEntityID();

    for (SEGMENTLIST::iterator it = rSeg.begin(); it != rSeg.end(); )
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        bool bClipped = false;

        // Look to see if it goes too high
        for (int nPt = 0; nPt < aicWave.size(); ++nPt)
        {
            if (aicWave[nPt] >= dMaxVal)
            {
                bClipped = true;
                break;
            }

            if (aicWave[nPt] <= dMinVal)
            {
                bClipped = true;
                break;
            }
        }

        // Either I remove the current node, or 
        if (bClipped)
            it = rSeg.erase(it);
        else
            ++it;

    }
    return true;
} 

// Author & Date:   Almut Branner, 4/15/2003
// Purpose: Aling waveforms to peaks
// Inputs:  rcData - reference to the data we need to process
// Outputs: TRUE  - successful
//          FALSE - failed
bool VisitorAlignCheck::Visit(CDocPowerNAP &rcData)
{
    // Get max and min possible value of input signal
    ns_SEGSOURCEINFO isSSInfo;
    uint32 nEntity = rcData.GetActiveEntity();

    FileInfo &isInfo = *rcData.m_icFileVector[0];

    if (ns_OK != rcData.GetSegmentSourceInfo(isInfo.icFile, nEntity, 0, isSSInfo))
        return false;

    double dMaxPossVal = isSSInfo.dMaxVal;
    double dMinPossVal = isSSInfo.dMinVal;
    int nMaxShiftLeft = 0;
    int nMaxShiftRight = 0;
    DWORD dwNumPt = rcData.GetNumOfPointsPerWave();

    // Find out how many waveforms there are and allocate arrays for peaks 
    UINT nNumWaveforms = rcData.m_icSegmentList.size();
    UINT *nHiPeakPt = new UINT[nNumWaveforms];
    UINT *nLoPeakPt = new UINT[nNumWaveforms];

    for (int nWave = 0; nWave < nNumWaveforms; ++nWave)
    {
        nHiPeakPt[nWave] = 0;
        nLoPeakPt[nWave] = 0;
    }

    // Go through all waveforms and find their peaks
    nWave = 0;

    Segments & rSeg = rcData.GetActiveSegment();
    DWORD dwEntityID = rSeg.GetEntityID();

    for (SEGMENTLIST::iterator it = rSeg.begin(); it != rSeg.end(); ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        bool bMaxPeak = false;
        bool bMinPeak = false;
        bool bPeakFound = false;
        double dMaxVal = dMinPossVal;
        double dMinVal = dMaxPossVal;

        // Look to see if it goes too high
        // Start at point NumWaveform/5 (after threshold crossing for NEV files)
        for (UINT nPt = (UINT) ((double) dwNumPt / 5); nPt < dwNumPt; ++nPt)
        {
            if ((nLoPeakPt[nWave] == 0) && (aicWave[nPt] - aicWave[nPt - 1] > 0) && 
                (aicWave[nPt] > dMaxVal) && ((rcData.m_nWhatPeaks == 0) || 
                (rcData.m_nWhatPeaks == 1)))
            {
                nHiPeakPt[nWave] = nPt;
                dMaxVal = aicWave[nPt];
            }
            else if ((nHiPeakPt[nWave] == 0) && (aicWave[nPt] - aicWave[nPt - 1] < 0) && 
                     (aicWave[nPt] < dMinVal) && ((rcData.m_nWhatPeaks == 0) || 
                     (rcData.m_nWhatPeaks == 2)))
            {
                nLoPeakPt[nWave] = nPt;
                dMinVal = aicWave[nPt];
            }
            else if (((aicWave[nPt] >= dMinVal) && (nLoPeakPt[nWave] > 0)) || 
                    ((aicWave[nPt] <= dMaxVal) && (nHiPeakPt[nWave] > 0)))
            {
                bPeakFound = true;
                break;
            }
        } // Next data point
        ++nWave;
    } // Next waveform

    // Find the mean location of all peaks. This will be used as the point to align to.
    UINT nMeanPeakPt = 0;
    if (rcData.m_bAlignMeanPt == TRUE)
    {
        for (nWave = 0; nWave < nNumWaveforms; ++nWave)
        {
            nMeanPeakPt = nMeanPeakPt + nHiPeakPt[nWave] + nLoPeakPt[nWave];
        }
        nMeanPeakPt = nMeanPeakPt / nNumWaveforms;
    }
    else
        nMeanPeakPt = rcData.m_nAlignPt;

    // Align all waveforms
    rSeg = rcData.GetActiveSegment();
    dwEntityID = rSeg.GetEntityID();

    nWave = 0;
    for (it = rSeg.begin(); it != rSeg.end(); ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        // Calculate shift
        int nShift = 0;  

        if ((nHiPeakPt[nWave] != 0) && (nLoPeakPt[nWave] == 0)) // For high peaks
        {
            nShift = nMeanPeakPt - nHiPeakPt[nWave];
        }
        else if ((nLoPeakPt[nWave] != 0) && (nHiPeakPt[nWave] == 0)) // For low peaks
        {
            nShift = nMeanPeakPt - nLoPeakPt[nWave];
        }
        else nShift = 0;

        // Do something if shift is too large
        if (nShift > (int) ((double) dwNumPt / 4))
        {
            nShift = 0;
        }

        // Calculate maximum shift
        if (nShift > nMaxShiftRight)
        {
            nMaxShiftRight = nShift;
        }
        else if (nShift < nMaxShiftLeft)
        {
            nMaxShiftLeft = nShift;
        }

        // Shift waveform if ok
        // Could do these loops much simpler with tempWave by initializing to zero and just filling in

        double *adTempWave = new double[dwNumPt];
        int nPt;

        if (nShift > 0) // Waveform is shifted to the right
        {
            for (nPt = (int) dwNumPt - 1; nPt > nShift - 1; --nPt)
            {
                adTempWave[nPt] = aicWave[nPt - nShift];
            }
            for (nPt = 0; nPt < nShift; ++nPt)
            {
                adTempWave[nPt] = 0;
            }
            // Copy temporary waveform into actual waveform
            memcpy(&aicWave[0], adTempWave, dwNumPt * sizeof(double));
        }
        else if (nShift < 0) // Waveform is shifted to the left
        {
            for (nPt = 0; nPt < (int) dwNumPt + nShift; ++nPt)
            {
                adTempWave[nPt] = aicWave[nPt - nShift];
            }
            for (nPt = (int) dwNumPt + nShift; nPt < (int) dwNumPt; ++nPt)
            {
                adTempWave[nPt] = 0;
            }
            // Copy temporary waveform into actual waveform
            memcpy(&aicWave[0], adTempWave, dwNumPt * sizeof(double));
        }

        delete [] adTempWave;
        ++nWave;
    } // Next waveform

    delete [] nHiPeakPt;
    delete [] nLoPeakPt;

    // Truncate waveforms
    //Truncate(rcData, nMaxShiftLeft, nMaxShiftRight);

    return true;
} 

// Author & Date:   Almut Branner, 4/9/2003
// Purpose: Truncate waveforms after alignment
//
// Inputs:  rcData - reference to the data we need to process
//          nMaxShiftLeft - maximum data points a waveform was shifted to the left
//          nMaxShiftRight - maximum data points a waveform was shifted to the right
// Outputs: TRUE  - successful
//          FALSE - failed
bool VisitorAlignCheck::Truncate(CDocPowerNAP & rcData, int nMaxShiftLeft, int nMaxShiftRight)
{
    DWORD dwNumPt = rcData.GetNumOfPointsPerWave();

    Segments & rSeg = rcData.GetActiveSegment();
    DWORD dwEntityID = rSeg.GetEntityID();

    // Go through all waveforms and truncate them
    for (SEGMENTLIST::iterator it = rSeg.begin(); it != rSeg.end(); ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);
        // Define temporary waveform
        double *adTempWave = new double[dwNumPt - nMaxShiftLeft - nMaxShiftRight];
        
        for (int nPt = nMaxShiftRight; nPt < (int) dwNumPt - nMaxShiftLeft; ++nPt)
        {
            adTempWave[nPt - nMaxShiftRight] = aicWave[nPt];
        }
        
        // Copy temporary waveform into actual waveform
        // TODO: This does not work this way!! Have to create a new list. 
        memcpy(&aicWave[0], adTempWave, (dwNumPt - nMaxShiftLeft - nMaxShiftRight) * sizeof(double));

        delete [] adTempWave;
    } // Next waveform

    return true;
}
