// SortListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "PowerNAP.h"
#include "SortListCtrl.h"
#include "SortClass.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef HDF_SORTUP 
#define HDF_SORTUP 0x0400 
#endif 

#ifndef HDF_SORTDOWN 
#define HDF_SORTDOWN 0x0200 
#endif 


/////////////////////////////////////////////////////////////////////////////
// CSortListCtrl

CSortListCtrl::CSortListCtrl()
{
    m_nCurrentSortItem = 0; 
    m_bSortAscending = true; 
}

CSortListCtrl::~CSortListCtrl()
{
}


BEGIN_MESSAGE_MAP(CSortListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CSortListCtrl)
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnclick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSortListCtrl message handlers

void CSortListCtrl::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here

    LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

    HDITEM HeaderItem;
    HeaderItem.mask = HDI_FORMAT | HDI_BITMAP;
    CHeaderCtrl* HeaderCtrl = GetHeaderCtrl();
    int nSortedCol = pNMLV->iSubItem;

    if(nSortedCol == m_nCurrentSortItem)
        m_bSortAscending = !m_bSortAscending;
    else
    {
        m_bSortAscending = TRUE;
        HeaderCtrl->GetItem(m_nCurrentSortItem, &HeaderItem);
        HeaderItem.fmt &= ~(HDF_BITMAP | HDF_BITMAP_ON_RIGHT);
        if (HeaderItem.hbm != 0)
        {
            DeleteObject(HeaderItem.hbm);
            HeaderItem.hbm = 0;
        }
        HeaderCtrl->SetItem(m_nCurrentSortItem, &HeaderItem);
        m_nCurrentSortItem = nSortedCol;
    }

    HeaderCtrl->GetItem(nSortedCol, &HeaderItem);

    if (HeaderItem.hbm != 0)
    {
        DeleteObject(HeaderItem.hbm);
        HeaderItem.hbm = 0;
    }

    HeaderItem.fmt = HDF_BITMAP | HDF_BITMAP_ON_RIGHT | HDF_STRING;
    HeaderItem.hbm = (HBITMAP)LoadImage(AfxGetInstanceHandle(), 
        MAKEINTRESOURCE(m_bSortAscending ? IDB_UP : IDB_DOWN), IMAGE_BITMAP, 0, 0, 
        LR_LOADMAP3DCOLORS);

    HeaderCtrl->SetItem(nSortedCol, &HeaderItem);


    // Do the sorting
    ///////////////////////////
    bool bIsNumeric = true;

    // User clicked on header using left mouse button
    if (nSortedCol == 1)
        bIsNumeric = false;
    else if ((nSortedCol == 0) || (nSortedCol == 2))
        bIsNumeric = true;

	CSortClass csc(this, nSortedCol, bIsNumeric);
	csc.Sort(m_bSortAscending);

    *pResult = 0;
}


void CSortListCtrl::AutoSizeColumns(int nCol)
{
    // All channels will be sorted for values smaller than zero
    // (-2) means that it will not check whether the size gets bigger

    // The function also assumes that an extra dummy column was added
    //     to have the last column resize correctly

    int mincol = nCol < 0 ? 0 : nCol;
    int maxcol = nCol < 0 ? GetHeaderCtrl()->GetItemCount() - 2 : nCol;
    int MinColWidth = 10;

    for (int col = mincol; col <= maxcol; ++col)
    {
        int wc1 = GetColumnWidth(col);

        SetColumnWidth(col, LVSCW_AUTOSIZE_USEHEADER);
        int wc2 = GetColumnWidth(col);

        int wc;

        if (nCol == -2)
            // Add 20 points to accomodate the sorting arrows which are not automatically
            //     included when you autosize
            wc = max(MinColWidth, wc2 + 20);
        else
            // only change the column width when it gets bigger
            wc = max(MinColWidth, max(wc1, wc2));

        SetColumnWidth(col, wc);
    }

    Invalidate();
}
