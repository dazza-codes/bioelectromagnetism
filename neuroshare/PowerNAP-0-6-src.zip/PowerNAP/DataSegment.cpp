///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: DataSegment.cpp $
//
// Description   : 
//
// Authors       : Almut Branner
//
// $Date: 3/11/04 12:57p $
//
// $History: DataSegment.cpp $
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:57p
// Updated in $/Neuroshare/PowerNAP
// Minor improvements for speed reasons
// 
// *****************  Version 17  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:28p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 16  *****************
// User: Kkorver      Date: 2/27/04    Time: 2:14p
// Updated in $/Neuroshare/PowerNAP
// GetTime() and other function no longer need the EntityID passed
// GetWave() now uses the "max" to get the wave size
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:57p
// Updated in $/Neuroshare/PowerNAP
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:53a
// Updated in $/Neuroshare/nsClassifier
// Moved all of the GetInfo()'s to here
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 10/16/03   Time: 1:01p
// Updated in $/Neuroshare/nsClassifier
// Added "const" to functions that don't modify variables
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 10/15/03   Time: 2:21p
// Updated in $/Neuroshare/nsClassifier
// Changed constructor to either accept dwUnitID or read it from the file.
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/14/03   Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Updated data class to no longer hold "type"
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 9/11/03    Time: 2:57p
// Updated in $/Neuroshare/nsClassifier
// Added function headers and made DataAnalog functions working.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 9/11/03    Time: 9:54a
// Updated in $/Neuroshare/nsClassifier
// Changed Get... and SetUnitID().
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 9/11/03    Time: 7:03a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 9/10/03    Time: 11:56a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/09/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 9/03/03    Time: 11:16a
// Created in $/Neuroshare/nsClassifier
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "DataSegment.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Inputs:
//  dwIdxFile - the index of the file in the document's file vector
//  dwIdxEntity - in the correct type, this is the "offset" into that types entity vector
//  dwIndex - the index (or 1st index if a collection) that corresponds to this data
DataSegment::DataSegment(FileInfo * pcFile, Segments * pcSegments, DWORD dwIndex) : 
    Data(pcFile, dwIndex),
    m_pcSegments(pcSegments)
{
    GetSegmentData(NULL, NULL, 0, NULL, (uint32 *)(&m_dwUnitID) );
}

DataSegment::~DataSegment()
{

}

// Author & Date:   Kirk Korver     25 Feb 2004
// Purpose: Get data about this segment
// Inputs:
//  cbDataBufferSize - the number of bytes for the "pdData" field
// Outputs:
//  pdTimeStamp - the time of this segment (can be NULL)
//  pdData - The actual data of the wave form (can be NULL)
//  pdwSampleCount - how many samples were actually returned (in # of doubles)
//  pdwUnitID - unit classification code
ns_RESULT DataSegment::GetSegmentData(double *pdTimeStamp, 
                                      double *pdData, uint32 cbDataBufferSize, uint32 *pdwSampleCount, 
                                      uint32 *pdwUnitID)
{
    return m_pDoc->GetSegmentData(GetFile(), GetEntityID(), m_dwIndex, 
            pdTimeStamp, pdData, cbDataBufferSize, pdwSampleCount, pdwUnitID);
}


inline DWORD DataSegment::GetEntityID() const
{
    return m_pcSegments->GetEntityID();
}


//////////////////////////////////////////////////////////////////////
// Functions
//////////////////////////////////////////////////////////////////////

// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Function to retrieve the timestamp of this segment entity
// Outputs: The timestamp
double DataSegment::GetTime() const
{
    return GetTimeByIndex(GetEntityID(), m_dwIndex);
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Function to retrieve the entity's unit ID
// Outputs: The unit ID
DWORD DataSegment::GetUnitID() const
{
    return m_dwUnitID;
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Function to set the entity's unit ID
// Inputs:  The unit ID
void DataSegment::SetUnitID(DWORD dwUnitID)
{ 
    // Save the unit ID 
    m_dwUnitID = dwUnitID;
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Function to retrieve the segment waveform
// Inputs:  Reference to the vector receiving the waveform
void DataSegment::GetWave(WAVEFORM & rvWaveform) const
{ 
    DWORD dwEntityID = GetEntityID();
    double dTimeStamp;
    uint32 dwSampleCount;
    uint32 dwUnitID;

    ns_SEGMENTINFO isSegInfo;
    NsFile & rcFile = GetFile();
    if (ns_OK != m_pDoc->GetSegmentInfo(rcFile, dwEntityID, isSegInfo))
        return;
    rvWaveform.resize(isSegInfo.dwMaxSampleCount);

    if (ns_OK == m_pDoc->GetSegmentData(rcFile, dwEntityID, 
            m_dwIndex, &dTimeStamp, &rvWaveform[0], isSegInfo.dwMaxSampleCount * sizeof (double), 
            &dwSampleCount, &dwUnitID))
    {
        rvWaveform.resize(dwSampleCount);
    }
    else
    {
        rvWaveform.clear();
    }
    return;
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Function to retrieve the number of data points in a waveform
// Outputs: The number of data points in a waveform
DWORD DataSegment::GetNumOfPoints() const
{
    DWORD dwEntityID = GetEntityID();
    ns_SEGMENTINFO isSegInfo;
    DWORD dwNumPoints = 0;

    if (ns_OK == m_pDoc->GetSegmentInfo(GetFile(), GetEntityID(), isSegInfo))
        dwNumPoints = isSegInfo.dwMaxSampleCount;

    return dwNumPoints;
}


