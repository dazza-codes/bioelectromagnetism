// (c) Copyright 2003 Cyberkinetics, Inc.
//
// $Workfile: FileVersion.h $
// $Archive: /Cerebus/WindowsApps/Central/FileVersion.h $
// $Revision: 2 $
// $Date: 4/22/03 9:39a $
// $Author: Kkorver $
//
// $History: FileVersion.h $
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 4/22/03    Time: 9:39a
// Updated in $/Cerebus/WindowsApps/Central
// Added GetVersionString()
// On Construction, if the filename is NULL, then the version info is read
// from the current application
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 3/07/03    Time: 4:59p
// Created in $/Cerebus/WindowsApps/Central
// This class deals with finding the version of a file
// 
// 
// $NoKeywords: $
//
// FileVersion.h: interface for the FileVersion class.
//
//////////////////////////////////////////////////////////////////////

#ifndef FILEVERSION_H_INCLUDED
#define FILEVERSION_H_INCLUDED


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class FileVersion
{
public:
    // Get the version information from the named file
    // Inputs: 
    //  szFileName - the name of the file to open. IF NULL, then use current application
    FileVersion(LPCSTR szFileName = NULL);
    ~FileVersion();

    // Tell me if the version information was read properly
    // Outputs:
    //  TRUE means that the verison stuff is good; FALSE, not good
    bool IsOK() { return m_bIsOK; }

    // Get the version information out of the file. In our current
    DWORD GetVersionMajor()     { return m_anVersions[0]; }
    DWORD GetVersionMinor()     { return m_anVersions[1]; }
    DWORD GetVersionRelease()   { return m_anVersions[2]; }
    DWORD GetVersionBuild()     { return m_anVersions[3]; }
    
    // Get the version information in "string" format
    // e.g.  1.3.34.5
    // This will overwrite any string 
    void GetVersionString(CString & strVersion);


private:
    DWORD m_anVersions[4];  // The place to store the versions
    bool m_bIsOK;           // TRUE means that the verison stuff is good; FALSE, not good

    void ReadVersions(LPVOID pbyData);

    enum VersionList
    {
        MAJOR,
        MINOR,
        RELEASE,
        BUILD,
    };
    

    /// Prevent copying and assignment
    FileVersion(const FileVersion & rhs);
    FileVersion & operator = (const FileVersion & rhs);
};



#endif