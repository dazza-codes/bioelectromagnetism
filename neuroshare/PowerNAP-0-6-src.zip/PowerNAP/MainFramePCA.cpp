///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFramePCA.cpp $
//
// Description   : interface of the CMainFramePCA class
//
// Authors       : 
//
// $Date: 10/31/03 6:03p $
//
// $History: MainFramePCA.cpp $
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 10/31/03   Time: 6:03p
// Updated in $/Neuroshare/PowerNAP
// Changed toolbars, removed combo box for spike sorting, and how that is
// called.
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:44a
// Updated in $/Neuroshare/PowerNAP
// Bug Fix: Switching from Manual-Mode to T-Distribution-Mode would cause
// an exception
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 10  *****************
// User: Awang        Date: 8/29/03    Time: 12:35p
// Updated in $/Neuroshare/nsClassifier
// Revised comments
// 
// *****************  Version 9  *****************
// User: Awang        Date: 8/28/03    Time: 1:43p
// Updated in $/Neuroshare/nsClassifier
// When no data is present, the buttons in toolbar will do nothing
// 
// *****************  Version 8  *****************
// User: Awang        Date: 8/28/03    Time: 11:42a
// Updated in $/Neuroshare/nsClassifier
// Changed "Shy" to "T distribution.
// Set previous option view ptr to Null when new sort method selected.
// 
// *****************  Version 7  *****************
// User: Awang        Date: 8/28/03    Time: 9:19a
// Updated in $/Neuroshare/nsClassifier
// Set status bar messages remain the same for OnIdle message
// 
// *****************  Version 6  *****************
// User: Awang        Date: 8/27/03    Time: 12:13p
// Updated in $/Neuroshare/nsClassifier
// Clears centroids from a previous sort
// 
// *****************  Version 5  *****************
// User: Awang        Date: 8/27/03    Time: 10:17a
// Updated in $/Neuroshare/nsClassifier
// Fixed - when mainframe closes, the options views also close without
// assertions
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/25/03    Time: 2:49p
// Updated in $/Neuroshare/nsClassifier
// On destruction, close all option views
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/25/03    Time: 1:36p
// Updated in $/Neuroshare/nsClassifier
// Re-worked toolbar so buttons are all shown in toolbar resource
// 
///////////////////////////////////////////////////////////////////////////////////////////////////


// MainFramePCA.cpp : implementation file
//

#include "stdafx.h"
#include "PowerNAP.h"
#include "MainFrm.h"

#include "DocPowerNAP.h"
#include "VisitorShyAlgorithm.h"
#include "MainFramePCA.h"
#include <afxpriv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFramePCA

IMPLEMENT_DYNCREATE(CMainFramePCA, CFrameWnd)

CMainFramePCA::CMainFramePCA()
{
    m_pDoc = NULL;
    m_bHiliteBtnDown = false;
    m_bSortBtnDown = false;

    m_nXAxis = 0;   //PC1    
    m_nYAxis = 1;   //PC2

    m_bProgCreated = FALSE;
}


CMainFramePCA::~CMainFramePCA()
{
}


BEGIN_MESSAGE_MAP(CMainFramePCA, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFramePCA)
	ON_MESSAGE(WM_SETMESSAGESTRING, OnSetMessageString)
	ON_UPDATE_COMMAND_UI(ID_VIEWPCA_STATUSBAR, OnUpdateViewStatusbar)
	ON_COMMAND(ID_VIEWPCA_STATUSBAR, OnViewStatusbar)
	ON_UPDATE_COMMAND_UI(ID_VIEWPCA_TOOLBAR, OnUpdateViewToolbar)
	ON_COMMAND(ID_VIEWPCA_TOOLBAR, OnViewToolbar)
    ON_WM_CREATE()
    ON_CBN_SELCHANGE(ID_PCATB_COMBOX, OnCboAxis)
	ON_COMMAND(ID_PCATB_HILITEBTN, OnBtnHilite)
    ON_COMMAND(ID_PCATB_SORTBTN, OnBtnSort)
	ON_UPDATE_COMMAND_UI(ID_PCATB_HILITEBTN, OnUpdateBtnHilite)
	ON_UPDATE_COMMAND_UI(ID_PCATB_SORTBTN, OnUpdateBtnSort)
	ON_WM_SIZE()
    ON_CBN_SELCHANGE(ID_PCATB_COMBOY, OnCboAxis)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//Status Bar
static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_PROGRESS_PANE,
};
/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFramePCA::AssertValid() const
{
    //CMainFrame::AssertValid();
    CFrameWnd::AssertValid();
}

void CMainFramePCA::Dump(CDumpContext& dc) const
{
     //CMainFrame::Dump(dc);
   CFrameWnd::Dump(dc);
}

#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CMainFramePCA message handlers

int CMainFramePCA::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

    InitToolbar();

    /////////////////////////////////////////////////////////////////////////////////////////////////////////    
    // Status Bar
    if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

    //Create progress bar control in position 1 of status bar
    CRect rectProg;
    m_wndStatusBar.GetItemRect(1, &rectProg);
    if (m_bProgCreated == FALSE)
	{
		//Create the progress control
		m_wndProgBar.Create(WS_VISIBLE|WS_CHILD, rectProg, &m_wndStatusBar, 1); 

		m_wndProgBar.SetRange(0,100);   //Set the range to between 0 and 100
		m_wndProgBar.SetStep(1);        // Set the step amount
        
		m_bProgCreated = TRUE;
	}
  
    return TRUE;
}

void CMainFramePCA::InitToolbar()
{
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_VIEWPCA_TOOLBAR))
	{
		TRACE0("Failed to create toolbar\n");
		return;      // fail to create
	}
    
   // X Axis text and combo 
    CreateXAxisTextBox();   // change to text box   
    CreateXAxisCombo();     // change to combo box   
    
    // Y Axis   
    CreateYAxisTextBox();   // change to text box   
    CreateYAxisCombo();     // change to combo box   
   
    m_wndToolBar.SetHeight(30);   
   
   // TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
}

void CMainFramePCA::OnUpdateFrameTitle(BOOL bAddToTitle)
{
    // We do the "false" because we only want the "title" and
    // Not the app name as well
	CFrameWnd::OnUpdateFrameTitle(false);	
}


bool CMainFramePCA::CreateXAxisCombo()
{
	// Create the combo box to select X axiz
	m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_PCATB_COMBOX),
        ID_PCATB_COMBOX, TBBS_SEPARATOR, 80);
    
    CRect rect;
	m_wndToolBar.GetItemRect(m_wndToolBar.CommandToIndex(ID_PCATB_COMBOX), &rect);
	const int nDropHeight = 220;
    rect.bottom = rect.top + nDropHeight;

    if (!m_cboBoxX.Create( WS_CHILD | CBS_DROPDOWNLIST|WS_VISIBLE|WS_TABSTOP,
			rect, &m_wndToolBar, ID_PCATB_COMBOX))
	{
		TRACE0("Failed to create combo-box\n");
		return false;
	}

    //  Fill the units combo box
    CString strUnit[8]  = 
                {   "PC1",
                    "PC2",
                    "PC3" }; 
    
    for (int n = 0; n < 3; ++n)
        m_cboBoxX.AddString(strUnit[n]);

    // Set default X Axis to PC1
    m_cboBoxX.SetCurSel(m_nXAxis);
    
    return true;
}

bool CMainFramePCA::CreateYAxisCombo()
{
	// Create the combo box to select Y axis
	m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_PCATB_COMBOY),
        ID_PCATB_COMBOY, TBBS_SEPARATOR, 80);
    
    CRect rect;
	m_wndToolBar.GetItemRect(m_wndToolBar.CommandToIndex(ID_PCATB_COMBOY), &rect);
	const int nDropHeight = 220;
	rect.bottom = rect.top + nDropHeight;

    if (!m_cboBoxY.Create( WS_CHILD | CBS_DROPDOWNLIST|WS_VISIBLE|WS_TABSTOP,
			rect, &m_wndToolBar, ID_PCATB_COMBOY))
	{
		TRACE0("Failed to create combo-box\n");
		return false;
	}

    //  Fill the units combo box
    CString strUnit[8]  = 
                {   "PC1",
                    "PC2",
                    "PC3" }; 
    
    for (int n = 0; n < 3; ++n)
        m_cboBoxY.AddString(strUnit[n]);

    // Set default Y Axis to PC2
    m_cboBoxY.SetCurSel(m_nYAxis);

    return true;
}

bool CMainFramePCA::CreateXAxisTextBox()
{
    CRect rectCtrl;

    // Create the static text box display threshold value
	m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_PCATB_XAXISTEXT), ID_PCATB_XAXISTEXT, TBBS_SEPARATOR, 20);

	m_wndToolBar.GetItemRect(m_wndToolBar.CommandToIndex(ID_PCATB_XAXISTEXT), &rectCtrl);
    rectCtrl.top += 2;
    rectCtrl.bottom -= 2;

    // Create Text box to display the threshold value
    if (!m_textXAxis.Create("X:",WS_CHILD | WS_VISIBLE | SS_CENTER, rectCtrl,
                        &m_wndToolBar, ID_PCATB_XAXISTEXT))
    {
		TRACE0("Failed to create static control\n");
		return FALSE;
	}
        
    ShowWindow(SW_SHOW);
 
    return true;
}

bool CMainFramePCA::CreateYAxisTextBox()
{
    CRect rectCtrl;

    // Create the static text box display threshold value
	m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_PCATB_YAXISTEXT), ID_PCATB_YAXISTEXT, TBBS_SEPARATOR, 20);

	m_wndToolBar.GetItemRect(m_wndToolBar.CommandToIndex(ID_PCATB_YAXISTEXT), &rectCtrl);
    rectCtrl.top += 2;
    rectCtrl.bottom -= 2;

    // Create Text box to display the threshold value
    if (!m_textYAxis.Create("Y:",WS_CHILD | WS_VISIBLE | SS_CENTER, rectCtrl,
                        &m_wndToolBar, ID_PCATB_YAXISTEXT))
    {
		TRACE0("Failed to create static control\n");
		return FALSE;
	}

    ShowWindow(SW_SHOW);

    return true;
}


// Do the sorting algorithm selected
void CMainFramePCA::OnBtnSort()
{
    // Sort the training data NOW with the selected method
    // Sort the data with the selected Classification method and parameters
    // Default is Shy's method.

    CString str;
    
    // Change button states
    m_bHiliteBtnDown = false;
    m_bSortBtnDown = true;

    // Is Sort button pressed or released?
    CToolBarCtrl &TBCtrl = m_wndToolBar.GetToolBarCtrl();
    BOOL bChk = TBCtrl.IsButtonChecked(ID_PCATB_SORTBTN);
    if (bChk)
    {
        // Do the selected SORT now
        // Get document pointer
        m_pDoc = (CDocPowerNAP *) GetActiveDocument();

        // Starting a new sort, no rules defined yet
        int32 nCurrEntIndex = m_pDoc->GetActiveEntityIndex();
        if (nCurrEntIndex >= 0)
            m_pDoc->m_icEntityInfoVector[nCurrEntIndex].m_bRulesDefined = false;
        else
        {
            // Release the sort button
            // Button is down
            m_bSortBtnDown = false;
            return;
        }
        
        // Clear centroids and view pointers from previous sorts
        ClearPrevSort();

        if (m_pDoc->m_icFileVector.empty())
        {   // No data
            return;
        }
        else
        {
            // We need to have a waveform list before doing anything
            if (m_pDoc->m_icSegmentList.empty())
                return;
        
            m_pDoc->ShowPropSheetSpkSorting((tagSortMethod) m_nSortMethod);
        }
    }
    else
    {
       // Button is up
        m_bSortBtnDown = false;
    }
}  //OnBtnSort


// Select and highlight one of the PC data points
void CMainFramePCA::OnBtnHilite()
{
    // Clear currently selected cluster
    m_lCurrCluster = -1;

    // Set toolbar button states
    m_bHiliteBtnDown = true;
    m_bSortBtnDown = false;
    
    INT32 nCurrEnt = ((CDocPowerNAP *)GetActiveDocument())->GetActiveEntity();
    if (nCurrEnt < 0)
    {
        m_bHiliteBtnDown = false;
        return;
    }
    
    //Set mode for select and highlight one point
    ((CViewPCA *)GetActiveView())->SetDisplayMode(SELECTMODE, m_lCurrCluster);
}


// One of the x- or y- axis projections has changed
void CMainFramePCA::OnCboAxis()
{
    // PCA Toolbar - Either the  X or Y axis coordinate selection
    // changed in the combobox
    int nSelY = m_cboBoxY.GetCurSel();
    int nSelX = m_cboBoxX.GetCurSel();

    ((CViewPCA *)GetActiveView())->SetAxis(nSelX, nSelY);
}


void CMainFramePCA::OnUpdateBtnHilite(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_bHiliteBtnDown);	
}


void CMainFramePCA::OnUpdateBtnSort(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_bSortBtnDown);	
}


void CMainFramePCA::ReleaseSortBtn()
{
    // Release the currently pressed SORT button
    m_lCurrCluster = -1;
    
    m_bSortBtnDown = false;
    
    CToolBarCtrl &TBCtrl = m_wndToolBar.GetToolBarCtrl();
    TBCtrl.CheckButton(ID_PCATB_SORTBTN, false);
}


void CMainFramePCA::OnSize(UINT nType, int cx, int cy) 
{
    CFrameWnd::OnSize(nType, cx, cy);	

    if (IsWindow(m_wndStatusBar.m_hWnd) &&
                IsWindow(m_wndProgBar.m_hWnd))
    {
        RECT rc;
        m_wndStatusBar.GetItemRect(1, &rc);

	    // Reposition the progress control correctly!
	    m_wndProgBar.SetWindowPos(&wndTop, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, 0);
    }
}


// Hide or display  toolbar
void CMainFramePCA::OnViewToolbar() 
{
    ShowControlBar(&m_wndToolBar, (m_wndToolBar.GetStyle() & WS_VISIBLE) == 0, FALSE);
}

// Check whether  toolbar is visible
void CMainFramePCA::OnUpdateViewToolbar(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck((m_wndToolBar.GetStyle () & WS_VISIBLE) ? 1 : 0);
}

// Hide or display  statusbar
void CMainFramePCA::OnViewStatusbar() 
{
    ShowControlBar(&m_wndStatusBar, (m_wndStatusBar.GetStyle() & WS_VISIBLE) == 0, FALSE);
}

// Check whether toolbar is visible
void CMainFramePCA::OnUpdateViewStatusbar(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck ((m_wndStatusBar.GetStyle () & WS_VISIBLE) ? 1 : 0);
}

void CMainFramePCA::ClearPrevSort()
{
    //  Remove centroids from display defined from previous sorting
    ((CViewPCA *)GetActiveView())->ClearCtr();
}


/////////////////////////////////////////////////////////////////////////////////
// Set idle status bar message
// This prevents the default on-idle message from posting whenever the menu bar
// is clicked. 
LRESULT CMainFramePCA::OnSetMessageString(WPARAM wParam, LPARAM lParam)
{
	UINT nIDLast = m_nIDLastMessage;
	m_nFlags &= ~WF_NOPOPMSG;

	CWnd* pMessageBar = GetMessageBar();
	if (pMessageBar != NULL)
	{
		CString sMsg;
		CString strMessage;

		// set the message bar text
		if (lParam != 0)
		{
			ASSERT(wParam == 0);    // can't have both an ID and a string
            m_szStatusBarString = (LPCTSTR)lParam;
            sMsg = m_szStatusBarString;
		}
		else if (wParam != 0)
		{
			// map SC_CLOSE to PREVIEW_CLOSE when in print preview mode
			if (wParam == AFX_IDS_SCCLOSE && m_lpfnCloseProc != NULL)
				wParam = AFX_IDS_PREVIEW_CLOSE;

            // get message associated with the ID indicated by wParam
            if (wParam == AFX_IDS_IDLEMESSAGE)
                sMsg = m_szStatusBarString;
            else
            {
                GetMessageString(wParam, strMessage);
                sMsg = strMessage;
            }
        }
        
		pMessageBar->SetWindowText(sMsg);

		// update owner of the bar in terms of last message selected
		CFrameWnd* pFrameWnd = pMessageBar->GetParentFrame();
		if (pFrameWnd != NULL)
		{
			m_nIDLastMessage = (UINT)wParam;
			m_nIDTracking = (UINT)wParam;
		}
	}

	m_nIDLastMessage = (UINT)wParam;    	// new ID (or 0)
	m_nIDTracking = (UINT)wParam;       	// so F1 on toolbar buttons work

	return nIDLast;
}

//////////////////////////////////////////////////////////////////////////////////
// Sets the status bar message
void CMainFramePCA::StatusBarMessage(LPCTSTR fmt)
{
	TCHAR buffer[256]= _T("");

	CStatusBar* pStatus = (CStatusBar*) 
		GetDescendantWindow(AFX_IDW_STATUS_BAR);

	va_list argptr;
	va_start(argptr, fmt);

	_vsnprintf(buffer, 256, fmt, argptr);
	va_end(argptr);

   	m_szStatusBarString = buffer;
    
    SetMessageText((LPCTSTR) m_szStatusBarString);
    return;
}



