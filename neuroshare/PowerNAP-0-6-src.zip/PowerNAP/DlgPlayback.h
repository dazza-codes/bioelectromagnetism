///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2004  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Kirk Korver
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  kkorver@cyberkineticsinc.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DlgPlayback.h $
//
// $Date: 3/03/04 4:50p $
//
// $History: DlgPlayback.h $
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:50p
// Updated in $/Neuroshare/PowerNAP
// Updated the dialog to have only 2 sliders
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:50p
// Created in $/Neuroshare/PowerNAP
// Added playback capabilities
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef DLGPLAYBACK_H_INCLUDED
#define DLGPLAYBACK_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPlayback.h : header file
//

#include "DocPowerNAP.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgPlayback dialog

class CDlgPlayback : public CDialog
{
// Construction
public:
	CDlgPlayback(CDocPowerNAP * pDoc);       // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgPlayback)
	enum { IDD = IDD_DLG_PLAYBACK };
	CButton	m_btnPause;
	CButton	m_btnPlay;
	CSliderCtrl	m_sldSpeed;
	CSliderCtrl	m_sldPosition;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgPlayback)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
    enum { TMR_ANIMATE_TIME = 15 };             // In "wall time", how much time between ticks?

protected:

    CDocPowerNAP * m_pDoc;                      // Pointer to the document class

    enum { MAX_SLD_POS = 100 };
    enum { TIMER_ANIMATE };

    CDocPowerNAP::PlayBack * m_pcPlayBack;      // done for convenience
    double m_dTimeMax;                          // total amount of time we could display
    double m_dTimeStep;                         // How much time to advance each "tick"

    enum { MIN_SLD_SPEED = 1, UNITY_SLD_SPEED = 10, MAX_SLD_SPEED = 100 };

protected:
    void PostChange();                          // Tell everyone else that something has changed
    void UpdateEditBoxes();                     // Update the edit boxes based upon the current values
    void UpdateSliders();                       // Update the sliders


	// Generated message map functions
	//{{AFX_MSG(CDlgPlayback)
	afx_msg void OnBtnPlay();
	afx_msg void OnBtnPause();
	virtual BOOL OnInitDialog();
	afx_msg void OnSldPositionReleasedcapture(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSldSpeedReleasedcapture(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	afx_msg void OnChangeEdtWaveformCount();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
