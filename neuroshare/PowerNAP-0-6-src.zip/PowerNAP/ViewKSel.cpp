///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewKSel.cpp $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/21/03 3:20p $
//
// $History: ViewKSel.cpp $
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 6  *****************
// User: Awang        Date: 8/28/03    Time: 11:31a
// Updated in $/Neuroshare/nsClassifier
// On destruction, set previous optview  ptr in mainframe to null.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/25/03    Time: 2:46p
// Updated in $/Neuroshare/nsClassifier
// Check if ViewPCA is there when closing
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/25/03    Time: 1:40p
// Updated in $/Neuroshare/nsClassifier
// Renamed MainFramePCA
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "ViewKSel.h"
#include "DocPowerNAP.h"
#include "MainFramePCA.h"
#include "VisitorKMeans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewKSel



IMPLEMENT_DYNCREATE(CViewKSel, CFormView)

CViewKSel::CViewKSel()
	: CFormView(CViewKSel::IDD)
{
	//{{AFX_DATA_INIT(CViewKSel)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CViewKSel::~CViewKSel()
{

    // If ViewPCA is still there, set default display mode
    CViewPCA *pPCAView;
    if ((CViewPCA *)pPCAView = GetViewPCAPtr())
    {
        pPCAView->SetDisplayMode(DEFAULT, -1);

        // Set view pointer in mainframe to NULL;
        ((CMainFramePCA *)pPCAView->GetParentFrame())->m_pViewKSel = NULL;
        
        // Release the Sort btn on toolbar
        ((CMainFramePCA *)pPCAView->GetParentFrame())->ReleaseSortBtn();

        // Clear the previous opened options view pointer
        ((CMainFramePCA *)pPCAView->GetParentFrame())->ClearPrevSort();

    }
}

void CViewKSel::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewKSel)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewKSel, CFormView)
	//{{AFX_MSG_MAP(CViewKSel)
	ON_BN_CLICKED(IDC_KSEL_1, On1)
	ON_BN_CLICKED(IDC_KSEL_2, On2)
	ON_BN_CLICKED(IDC_KSEL_3, On3)
	ON_BN_CLICKED(IDC_KSEL_4, On4)
	ON_BN_CLICKED(IDC_KSEL_5, On5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewKSel diagnostics

#ifdef _DEBUG
void CViewKSel::AssertValid() const
{
	CFormView::AssertValid();
}

void CViewKSel::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}


CDocPowerNAP* CViewKSel::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}



#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CViewKSel message handlers

void CViewKSel::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

    GetParentFrame()->SetTitle("K Means Cluster Selection");
    GetParentFrame()->ModifyStyleEx(WS_EX_CLIENTEDGE, WS_EX_TOOLWINDOW, 0);

    // Hide the menu of the window.
    CMenu * pMenu = GetParentFrame()->GetMenu();
    pMenu->RemoveMenu(0, MF_BYPOSITION);
    pMenu->RemoveMenu(0, MF_BYPOSITION);
    pMenu->RemoveMenu(0, MF_BYPOSITION);
	
    // Size the window to match that of the form in the resource editor
    GetParentFrame()->RecalcLayout();
    ResizeParentToFit(false);
    ResizeParentToFit();
}


void CViewKSel::On1() 
{
    // Find 1 centroid
    GetDocument()->m_isSortInfo.K = 1;
    DoKMeans();	
}

void CViewKSel::On2() 
{
    // Find 2 centroids
    GetDocument()->m_isSortInfo.K = 2;
    DoKMeans();	
}

void CViewKSel::On3() 
{
     // Find 3 centroids
   GetDocument()->m_isSortInfo.K = 3;
    DoKMeans();	
	
}

void CViewKSel::On4() 
{
    // Find 4 centroids
    GetDocument()->m_isSortInfo.K = 4;
    DoKMeans();	
	
}

void CViewKSel::On5() 
{
    // Find 5 centroids
    GetDocument()->m_isSortInfo.K = 5;
    DoKMeans();	
	
}

void CViewKSel::DoKMeans()
{
    // Do the K Means sorting algorithm
    
    
    VisitorKMeans v;
    GenericVisitable gv(GetDocument(), this);
    gv.Accept(v);
    
    
    // Set rules defined for this entity 
    GetDocument()->SetSorted(true);

    
    GetDocument()->UpdateAllViews(NULL);

}


// Get a pointer to ViewPCA
CViewPCA * CViewKSel::GetViewPCAPtr()
{
    CViewPCA *pPCAView;

    // Default value
    pPCAView = NULL;

    POSITION pos = GetDocument()->GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetDocument()->GetNextView(pos);
        if (pView->IsKindOf(RUNTIME_CLASS(CViewPCA)))
        {
            pPCAView = (CViewPCA *) pView;
        }

    }

    return pPCAView;

}


