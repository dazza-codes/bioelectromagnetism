///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003, 2004  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Kirk Korver
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  kkorver@cyberkineticsinc.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: Data.cpp $
//
// Description   : 
//
// Authors       : Almut Branner
//
// $Date: 3/04/04 5:29p $
//
// $History: Data.cpp $
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:29p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 2/27/04    Time: 2:04p
// Updated in $/Neuroshare/PowerNAP
// Made GetFile() a const function
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:45p
// Updated in $/Neuroshare/PowerNAP
// Added GetFile() and some comments
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 2/24/04    Time: 3:45p
// Updated in $/Neuroshare/PowerNAP
// Added check for return value
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 2/24/04    Time: 12:53p
// Updated in $/Neuroshare/PowerNAP
// Added GetTimeByIndex()
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 10/14/03   Time: 10:51a
// Updated in $/Neuroshare/nsClassifier
// Reformatted some things.
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 10/14/03   Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Updated data class to no longer hold "type"
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 9/11/03    Time: 2:57p
// Updated in $/Neuroshare/nsClassifier
// Added function headers and made DataAnalog functions working.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/09/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "Data.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CDocPowerNAP * Data::m_pDoc = NULL;


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Inputs:
//  dwIdxFile - the index of the file in the document's file vector
//  dwIndex - the index (or 1st index if a collection) that corresponds to this data
Data::Data(FileInfo * pcFile, DWORD dwIndex) :
    m_pcFile(pcFile),
    m_dwIndex(dwIndex)
{
}

Data::~Data()
{

}

//////////////////////////////////////////////////////////////////////
// Functions
//////////////////////////////////////////////////////////////////////


// Author & Date:   Kirk Korver     24 Feb 2004
// Purpose: find the time of a particular index here
// Inputs:
//  dwEntityID - the global entityID we are interested in
//  dwIndex - which index do we want to find out about?
// Ouputs
//  the time (in seconds) at which this index occurs
double Data::GetTimeByIndex(DWORD dwEntityID, DWORD dwIndex) const
{
    double dTimeStamp = 0;

    ns_RESULT ret = m_pDoc->GetTimeByIndex(GetFile(), dwEntityID, dwIndex, &dTimeStamp);
    ASSERT(ret == ns_OK);
    return dTimeStamp;
}

// Author & Date:   Kirk Korver     25 Feb 2004
// Purpose: Get the file class. Needed for many fxns.
NsFile & Data::GetFile() const
{
    return m_pcFile->icFile;
}
