///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewKSel.h $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/21/03 3:20p $
//
// $History: ViewKSel.h $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////


#ifndef VIEWKSEL_H_INCLUDED
#define VIEWKSEL_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ViewKSel.h : header file
//


class CDocPowerNAP;



/////////////////////////////////////////////////////////////////////////////
// CViewKSel form view
class CViewPCA;




#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CViewKSel : public CFormView
{
protected:
	CViewKSel();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewKSel)

// Form Data
public:
	//{{AFX_DATA(CViewKSel)
	enum { IDD = IDD_OPT_KCLUSTER };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
    CViewPCA * m_pViewPCA;
    CDocPowerNAP * GetDocument();

// Operations
public:
	CViewPCA * GetViewPCAPtr();
	void DoKMeans(void);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewKSel)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CViewKSel();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CViewKSel)
	afx_msg void On1();
	afx_msg void On2();
	afx_msg void On3();
	afx_msg void On4();
	afx_msg void On5();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()



};

#ifndef _DEBUG // debug version in .cpp
    inline CDocPowerNAP* CViewKSel::GetDocument()
    { return (CDocPowerNAP*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
