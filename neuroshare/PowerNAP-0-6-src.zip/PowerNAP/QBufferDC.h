///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: QBufferDC.h $
//
// Description   : interface of the QBufferDC class
//
// Authors       : Almut Branner
//
// $Date: 10/07/03 9:37a $
//
// $History: QBufferDC.h $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

///////////////////////////////////////////////////
// QBufferDC
//
// A versatile MFC-class implementing flickerfree, buffered drawing.
// Derived from class CDC and supports all it's operations.
//
// However, all drawing is done to a memory bitmap in stead of to the screen.
// At destruction time, the resulting bitmap is blt'ed to the screen.
//
// Feature: it makes use of 'bounding accumulation' to determine which
// parts of the screen need updating.
//
// Compatible with all mapping modes.
// Compatible with GDI+.
//
// If memory is insufficient to create the buffer bitmap, QBufferDC
// behaves like a normal CDC, without buffered drawing.
//
// QBufferDC's constructor has two parameters:
// pDC			points to the mother device context. At destruction time,
//				QBufferDC copies the graphics output to this DC;
// dwRopCode	the 'ternary raster operation' used for bitblt'ing the
//				graphics to the screen. The default just copies; for advanced
//				uses, dwRopCode may have another value like SRCINVERT.
//
// QBufferDC clears the buffer bitmap to the background color of the mother DC.
//
// If QBUFFER_DEMO is defined, a special version of this class is compiled.
// It has one extra static member variable, m_bDemoMode. If m_bDemoMode is TRUE
// (default), the background color is slightly and randomly modified, showing
// which parts of the screen are updated.
// QBUFFER_DEMO might be entered as a 'Preprocessor definition' in the project settings.
// In normal use, QBUFFER_DEMO should not be defined.
////////////////////////////////////////////////////
//
// (c) Sjaak Priester, Amsterdam, 2003.
// www.sjaakpriester.nl
////////////////////////////////////////////////////


// Microsoft defined for 17 of the 255 possible 'ternary raster operations' a mnemonic
// name like SRCCOPY or PATINVERT. They really should have defined this one too,
// because it goes well with the R2_NOTXORPEN secondary raster operation, which
// comes in handy for rubber banding applications. It might be used as dwRopCode
// in constructing a QBufferDC.
#ifndef NOTSRCINVERT
#define NOTSRCINVERT	0x00990066		// DSxn => Destination, Source, xor, not
#endif



class QBufferDC : public CDC
{
public:
// Construction
	QBufferDC(CDC * pDC, DWORD dwRopCode = SRCCOPY);

	virtual ~QBufferDC();

protected:
// Implementation
	
	CDC *m_pDC;			// The mother DC
	DWORD m_RopCode;	// The rop code used for bitblt'ing the final result

private:
	CBitmap *m_pOldBitmap;

	// Helper class
	static class BufferBitmap
	{
	public:
		BOOL ReserveBitmap(CDC * pDC, CSize sz);
		BOOL IsValid() const		{ return m_Bitmap.GetSafeHandle() != NULL; }
		CBitmap m_Bitmap;
	} m_BufferBitmap;

#ifdef QBUFFER_DEMO
public:
	static BOOL m_bDemoMode;
#endif
};
