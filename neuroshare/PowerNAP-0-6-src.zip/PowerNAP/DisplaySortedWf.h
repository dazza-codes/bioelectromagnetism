///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DisplaySortedWf.h $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/21/03 2:43p $
//
// $History: DisplaySortedWf.h $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/16/03   Time: 1:23p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef DISPLAYSORTEDWF_H_INCLUDED
#define DISPLAYSORTEDWF_H_INCLUDED

#include "DocPowerNAP.h"    // Added by ClassView
#include "nsAPItypes.h"	    // Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DisplaySortedWf.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDisplaySortedWf window

class CDisplaySortedWf : public CWnd
{
// Construction
public:
	CDisplaySortedWf();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplaySortedWf)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	CDocPowerNAP *m_pDoc;

    ns_SEGMENTINFO  m_isSegInfo;
    ns_SEGSOURCEINFO m_isSegSourceInfo;
//	uint32          m_dwCurrEntity;
    uint32           m_dwCurrUnit;

    
    virtual ~CDisplaySortedWf();
	void SetAxisScaling(double dYMax, double dXMax);
	void DrawWaveform(CDC &rDC);
    void SetCurrEntity(uint32 dwEntity);
    void SetDrawUnit(uint32 dwUnit);

    // Generated message map functions
protected:
    CPen    m_penGrid;         // The pen we use to draw grid lines
    CPen    m_penRedThin;         
    CPen    m_penRedThick;    
	CBrush  m_brushBack;
    COLORREF    m_crBackColor;

    double m_dYScaleFactor;
    double m_dXScaleFactor;
    
	CRect   m_rectClient;
	int     m_nClientHeight;
	int     m_nClientWidth;
    //{{AFX_MSG(CDisplaySortedWf)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
