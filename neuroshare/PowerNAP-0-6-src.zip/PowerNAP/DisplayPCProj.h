///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DisplayPCProj.h $
//
// Description   :  
//
// Authors       : 
//
// $Date: 2/19/04 5:26p $
//
// $History: DisplayPCProj.h $
// 
// *****************  Version 16  *****************
// User: Kkorver      Date: 2/19/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// PCA now uses floating point math for the conversion. The result is that
// BIG and small numbers will now be displayed properly
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:43a
// Updated in $/Neuroshare/PowerNAP
// Overhaul of the PCA display
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:52a
// Updated in $/Neuroshare/nsClassifier
// WAVEFORM is now in CommonTypes.h
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 10/16/03   Time: 1:18p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 10  *****************
// User: Awang        Date: 8/26/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Fixed NOISEUNIT_OUT region
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef DISPLAYPCPROJ_H_INCLUDED
#define DISPLAYPCPROJ_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DisplayPCProj.h : header file
//
#include "PowerNAP.h"

class CDocPowerNAP;

#include <vector>
#include <list>

#include "CommonTypes.h"
#include "MouseState.h"

// Disable warning C4768
#pragma warning(push)
#pragma warning(disable : 4786)

typedef std::vector<CPoint> POINTVECTOR;
typedef std::vector<POINTVECTOR> LISTOFPOINTVECTORS;

/////////////////////////////////////////////////////////////////////////////
// Class to store 3 dimensional coordinates x, y, z of data point
class NsPoint3D
{
public:
   double x, y, z;
   NsPoint3D () { x = y = z = 0; }
   
   NsPoint3D (double d1, double d2, double d3)
   {
      x = d1;
      z = d2;
      y = d3;
   }

   NsPoint3D& operator=(const NsPoint3D& pt)
   {
      x = pt.x;
      z = pt.z;
      y = pt.y;
      return *this;
   }
 
   NsPoint3D (const NsPoint3D& pt)
   {
      *this = pt;
   }
};



/////////////////////////////////////////////////////////////////////////////
// Class for storing information on PC client coordinates of
// the data and the cluster it belongs to.
// This class is iterated by the segmentlist index

class NsPCData
{
public:
    NsPCData() {};
    NsPCData(NsPCData const & rhs);       // Copy constructor
    NsPCData(UINT32 uWFIndx, INT32 lClstrID, NsPoint3D ptData);
 
    ~NsPCData();

    NsPCData & operator = (NsPCData const & rhs);

    UINT32 GetWFIndex() {return m_uWFIndex;}
    void SetWFIndex( UINT32 uWFIndex) {m_uWFIndex = uWFIndex; }

    DWORD GetClstrID() { return m_lClstrID; } 
    void SetClstrID(INT32 lClstrID) { m_lClstrID = lClstrID;}

    NsPoint3D GetPCPt() { return m_ptPCClient; }
    void SetPCPt( NsPoint3D &ptData) { m_ptPCClient = ptData; }


protected:
    // The unit ID vector list contains:
    // Index to waveform list
    UINT32 m_uWFIndex;
 
    // Cluster ID of this point
    INT32 m_lClstrID;

    // The PC data point in client coordinates for drawing.  
    NsPoint3D m_ptPCClient;
};


typedef std::vector <NsPCData> PCDATALIST;



class CDisplayPCProj : public CWnd
{
// Construction
public:
	CDisplayPCProj();
    virtual ~CDisplayPCProj();

// Attributes
public:
    CDocPowerNAP *m_pDoc;
    PCDATALIST m_vPCData;          // stores WF index, unitID and client coordinates PC data
    PCDATALIST m_vPCCtr;           // unitID and client coordinates for the Centroid

    CRect  m_rectClient;
    int m_nClientHeight;
    int m_nClientWidth;
    
    HCURSOR m_hDrawingCursor[UNITCOUNT];
    HCURSOR m_hArrowCursor;

    LISTOFPOINTVECTORS m_icPolyList[UNITCOUNT]; 
    POINTVECTOR m_vOnePolyPts;


    INT32  m_lCurrClstr;

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayPCProj)
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
    bool    m_bReadyToDraw;
    
    bool    m_bHitAPt;
    INT32   m_lSelWfIndex;
    CPoint  m_ptSelected;
    CRect   m_rectSelection;
    CRect   m_rectPrev;

public:
	void DefOutsidePts(UINT32 lClstr);
    void MouseMoveProcessing(UINT nFlags, CPoint point);
	void SetDrawMode(int nDrawMode);
	void DefInsidePts(UINT32 lClstr);
    void ClearSelections(void);
    void HilightWF(INT32 lPrevWFIndex, INT32 lWFIndex);
    void UnHilightWF(INT32 lPrevWFIndex, INT32 lSelWFIndex);
     
	void SetAxis(int nXAxis, int nYAxis);
    void ClearClusters(INT32 lClstr);
    
	void ChangePtColor(NsPoint3D &rptData, INT32 lClstr);
	void SetWorkingClstr(INT32 lClusterIndex);
    
    void ErasePoly(void);
    void SetMaxValue(double dMaxValue);


protected:
    CPen    m_penGrid;      // The pen we use to draw grid lines
    CPen    m_penCur;
    CPen    m_penRed;
    CPen*   m_pOldPen;

	CPoint  m_ptPrev;       // the last mouse pt in the stroke in progress
    CPoint  m_ptFirst;      // the very first point of stroke

    int m_nXAxis;
    int m_nYAxis;
    double m_dMaxValue;       // The maximum value to be displayed on the screen

    bool m_flag_mouse_inside;

protected:
    struct CFloatPoint
    {
        double x;
        double y;

        CFloatPoint() {}
        CFloatPoint(double initX, double initY) : x(initX), y(initY) {}
    };

	CPoint XfmWorldToScreen(CFloatPoint point);
	CFloatPoint XfmScreenToWorld(CPoint point);
	void DrawAxes(CDC & rcDC);
    void DrawLabels(CDC & rcDC, const int nXProj, const int nYProj);
    void DrawPCPoints(CDC & rcDC, const int nX, const int nY);
	void DrawCtr(CDC & rcDC, const int nXProj, const int nYProj);
    void DrawRectSel(CDC & rcDC);           // Draw the selection rectangle
    void RemoveRectSel(CDC & rcDC);         // Undraw the selection rectangle
    bool HitTestPCPoint(CPoint ptCursor);   // tell me if I have got a winner here


    ////////// Beginning of Mouse State processing
    typedef MouseState <CDisplayPCProj> CDPCPState;   // CDisplayPCProj

    class MouseRegular : public CDPCPState      // normal mouse...doesn't do much
    {
    } m_icMouseRegular;
    friend class MouseRegular;

    class MouseDrawing : public CDPCPState      // Drawing the circles
    {
        virtual void OnLButtonDown(UINT nFlags, CPoint point);
        virtual void OnLButtonUp(UINT nFlags, CPoint point);
        virtual void OnDragging(UINT nFlags, CPoint point);
    } m_icMouseDrawing;
    friend class MouseDrawing;

    class MouseSelecting : public CDPCPState    // click-and-select
    {
        virtual void OnLButtonDown(UINT nFlags, CPoint point);
    } m_icMouseSelecting;
    friend class MouseSelecting;

                   // for the types...look above at class definitions
    enum MouseType {MSE_REGULAR, MSE_DRAWING, MSE_SELECTING};
    void SwitchMouse(MouseType enMouse);
    CDPCPState * m_pcActiveMouse;           // Our current mouse


    //{{AFX_MSG(CDisplayPCProj)
    afx_msg LRESULT OnMouseLeave(WPARAM wParam, LPARAM lParam);   
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

 #pragma warning(pop)

#endif // include guard


