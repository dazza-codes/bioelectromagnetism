///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropSheetGeneral.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 2/02/04 6:17p $
//
// $History: PropSheetGeneral.h $
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 1/30/04    Time: 3:55p
// Updated in $/Neuroshare/PowerNAP
// Added option for discarding empty entities and streamlined data
// transfer.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPSHEETGENERAL_H_INCLUDED
#define PROPSHEETGENERAL_H_INCLUDED

#include "PropPagePop.h"
#include "PropPageWf.h"
#include "PropPageData.h"

class CDocPowerNAP;     // forward declare to avoid #include "DocPowerNAP.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropSheetGeneral

class CPropSheetGeneral : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropSheetGeneral)

// Construction
public:
	CPropSheetGeneral(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0,
                      CDocPowerNAP* pDoc = NULL);
	CPropSheetGeneral(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0,
                      CDocPowerNAP* pDoc = NULL);

// Attributes
public:
    CPropPagePop m_icPropPagePop;
    CPropPageWf m_icPropPageWf;
    CPropPageData m_icPropPageData;
    CDocPowerNAP* m_pDoc;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropSheetGeneral)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropSheetGeneral();

	// Generated message map functions
protected:
    void InitializePropPages();
    void UpdateDoc();

	//{{AFX_MSG(CPropSheetGeneral)
	//}}AFX_MSG
    afx_msg void OnApply ();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
