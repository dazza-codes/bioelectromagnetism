///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFrameRaster.h $
//
// Description   : interface of the CMainFrameRaster class
//
// Authors       : Almut Branner
//
// $Date: 10/17/03 1:03p $
//
// $History: MainFrameRaster.h $
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/17/03   Time: 1:03p
// Updated in $/Neuroshare/nsClassifier
// Turned raster combo box to change rate into buttons. Partially fixed
// single-to-multiline mode. Updating sorting algorithms.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/08/03   Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with scrolling (don't override PreCreateWindow()). Also
// fixed unit selection (Have to call OnPrepareDC() before using DPtoLP
// and so on). Removed code not needed.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MAINFRAMERASTER_H_INCLUDED
#define MAINFRAMERASTER_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ViewRaster.h"

enum LineSize
{
    ENUMLINESIZE_NONE, 
    ENUMLINESIZE_7PIX,
    ENUMLINESIZE_13PIX,
    ENUMLINESIZE_19PIX,
    ENUMLINESIZE_25PIX,
    ENUMLINESIZE_37PIX,
    ENUMLINESIZE_49PIX,
    ENUMLINESIZE_61PIX,
    ENUMLINESIZE_85PIX,
    ENUMLINESIZE_200PIX,
    ENUMLINESIZE_COUNT,
};

enum Width
{
    ENUMWIDTH_250,
    ENUMWIDTH_200, 
    ENUMWIDTH_150, 
    ENUMWIDTH_100, 
    ENUMWIDTH_80, 
    ENUMWIDTH_50,  
    ENUMWIDTH_30,  
    ENUMWIDTH_20,   
    ENUMWIDTH_10, 
    ENUMWIDTH_5,
    ENUMWIDTH_2,
    ENUMWIDTH_1,
    ENUMWIDTH_COUNT
};

extern UINT enumlinesizeval[ENUMLINESIZE_COUNT];
extern UINT enumwidthval[ENUMWIDTH_COUNT];

/////////////////////////////////////////////////////////////////////////////
// CMainFrameRaster frame

class CMainFrameRaster : public CFrameWnd
{
	DECLARE_DYNCREATE(CMainFrameRaster)
protected:
	CMainFrameRaster();           // protected constructor used by dynamic creation

// Attributes
public:
    CViewRaster *   m_pwndView;
	CToolBar        m_wndToolBar;
	CStatusBar      m_wndStatusBar;
    CEdit           m_icLblChannel;    // edit box for the channel label
    CButton         m_icBtnStatus;


// Operations
public:

// Overrides
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);

    // ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrameRaster)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
    CFont           m_fntToolbar;      // font used for the toolbar

    void InitToolbar();
	virtual ~CMainFrameRaster();

    void OnChangeLineMode(UINT wParam, LONG lParam);

	// Generated message map functions
	//{{AFX_MSG(CMainFrameRaster)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnToolbarDropDown(NMTOOLBAR* pnmh, LRESULT* plRes);
	afx_msg void OnEditCopy();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
