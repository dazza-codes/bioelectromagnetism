///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewEntInfo.h $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/21/03 3:20p $
//
// $History: ViewEntInfo.h $
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/20/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Added source safe headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////


#ifndef VIEWENTINFO_H_INCLUDED
#define VIEWENTINFO_H_INCLUDED

#include "nsAPItypes.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ViewEntInfo.h : header file
//


class CDocPowerNAP;     // forware declare to avoid #include "DocPowerNAP.h"

/////////////////////////////////////////////////////////////////////////////
// CViewEntInfo form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CViewEntInfo : public CFormView
{
protected:
	CViewEntInfo();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewEntInfo)

// Form Data
public:
	//{{AFX_DATA(CViewEntInfo)
	enum { IDD = IDD_DLG_ENTITY_INFO };
	CComboBox	m_cboSourceLabel;
	CComboBox	m_cboEntLabel;
	UINT	m_uWfCount;
	CString	m_sPtCount;
	double	m_dSampleRate;
	CString	m_sUnits;
	double	m_dInMinVal;
	double	m_dInMaxVal;
	double	m_dResolution;
	double	m_dXLoc;
	double	m_dYLoc;
	double	m_dZLoc;
	double	m_dUserLoc;
	CString	m_sUnits2;
	double	m_dF1Freq;
	double	m_dF2Freq;
	double	m_dF1Order;
	double	m_F2Order;
	CString	m_sF1Type;
	CString	m_sF2Type;
	double	m_dF2Order;
	CString	m_sProbeInfo;
	CString	m_sSortStatus;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	CDocPowerNAP *GetDocument();
    void FillEntityLabelList();
    void FillGeneralInfo();
    void FillSegmentSourceList();
    void FillSegmentSourceInfo();
   
    
    int m_nSelEntity;
    int m_nSelSource;
    uint32 m_uSegSourceCount;

    FileInfo m_isFileInfo;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewEntInfo)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetDefaults();
	virtual ~CViewEntInfo();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CViewEntInfo)
	afx_msg void OnSelchangeEntity();
	afx_msg void OnSelchangeSource();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#ifndef _DEBUG  // debug version in the .cpp
inline CDocPowerNAP* CViewEntInfo::GetDocument()
   { return (CDocPowerNAP*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
