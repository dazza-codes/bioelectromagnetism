///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewWaveforms.h $
//
// Authors       : Angela Wang
//
// $Date: 3/11/04 12:52p $
//
// $History: ViewWaveforms.h $
// 
// *****************  Version 34  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:52p
// Updated in $/Neuroshare/PowerNAP
// Added ability to delete units and reclassify units
// 
// *****************  Version 33  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Added basic "clipping" functions
// 
// *****************  Version 32  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:34p
// Updated in $/Neuroshare/PowerNAP
// Update to the animation to remove flickering
// 
// *****************  Version 31  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:47p
// Updated in $/Neuroshare/PowerNAP
// Added Playback capabilities
// 
// *****************  Version 30  *****************
// User: Abranner     Date: 2/10/04    Time: 10:16a
// Updated in $/Neuroshare/PowerNAP
// Added additional units to combo box.
// 
// *****************  Version 29  *****************
// User: Abranner     Date: 10/31/03   Time: 6:06p
// Updated in $/Neuroshare/PowerNAP
// Added status bar messages.
// 
// *****************  Version 28  *****************
// User: Kkorver      Date: 10/21/03   Time: 5:37p
// Updated in $/Neuroshare/PowerNAP
// Added OnUpdateWftbThresholdbtn(), The threshold button now tracks the
// "state" of thresholding in the system
// 
// *****************  Version 27  *****************
// User: Kkorver      Date: 10/21/03   Time: 4:31p
// Updated in $/Neuroshare/PowerNAP
// Moved ReplaceWindowControl() to the common area
// 
// *****************  Version 26  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 25  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 24  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:15a
// Updated in $/Neuroshare/nsClassifier
// Removed dead code
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 22  *****************
// User: Abranner     Date: 8/27/03    Time: 10:57a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet and removed CViewOptKMeans.
// 
// *****************  Version 21  *****************
// User: Abranner     Date: 8/25/03    Time: 11:02a
// Updated in $/Neuroshare/nsClassifier
// Changed some variable names to conform with coding standard. Changed
// the toolbar and some tooltips.
// 
// *****************  Version 20  *****************
// User: Awang        Date: 8/05/03    Time: 3:16p
// Updated in $/Neuroshare/nsClassifier
// New toolbar buttons
// 
// *****************  Version 19  *****************
// User: Awang        Date: 6/30/03    Time: 3:59p
// Updated in $/Neuroshare/nsClassifier
// Local control removed to toolbars in ViewPCA and ViewWaveform
// 
// *****************  Version 18  *****************
// User: Awang        Date: 6/18/03    Time: 2:30p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 17  *****************
// User: Awang        Date: 6/10/03    Time: 4:42p
// Updated in $/Neuroshare/nsClassifier
// Highlighting of selected waveforms
// 
// *****************  Version 16  *****************
// User: Kkorver      Date: 4/30/03    Time: 2:35p
// Updated in $/Neuroshare/nsClassifier
// Added ReplaceWindowControl()
// 
// *****************  Version 15  *****************
// User: Abranner     Date: 4/29/03    Time: 5:09p
// Updated in $/Neuroshare/nsClassifier
// Threshold line now tracks and arrows work.
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 4/29/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Added OnCreate() that set's the title of the frame
// 
// *****************  Version 13  *****************
// User: Awang        Date: 4/28/03    Time: 11:53a
// Updated in $/Neuroshare/nsClassifier
// Changed name of class CDisplaySpike
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 4/25/03    Time: 5:39p
// Updated in $/Neuroshare/nsClassifier
// Implemented tooltip support for all windows (hovering shows message).
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 4/25/03    Time: 1:54p
// Updated in $/Neuroshare/nsClassifier
// HTML help now works.
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 4/25/03    Time: 9:30a
// Updated in $/Neuroshare/nsClassifier
// Check in before changing all kinds of things to help. Not all help is
// functional here.
// 
// *****************  Version 9  *****************
// User: Almut        Date: 4/22/03    Time: 3:22p
// Updated in $/Neuroshare/nsClassifier
// Basic help support works now.
// 
// *****************  Version 8  *****************
// User: Almut        Date: 4/22/03    Time: 10:27a
// Updated in $/Neuroshare/nsClassifier
// Added help support to the project but no messages are setup yet.
// 
// *****************  Version 7  *****************
// User: Almut        Date: 4/18/03    Time: 1:08p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anomaly #13.
// Thresholding now has a plus and minus button and a text box for editing
// the threshold.
// Also figured out how to recognize the return key in edit boxes and use
// it to make something happen.
// 
// *****************  Version 6  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 4/11/03    Time: 11:24a
// Updated in $/Neuroshare/nsClassifier
// Added the release version of GetDocument()
// 
// *****************  Version 4  *****************
// User: Angela       Date: 4/10/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Updates and no extra frames created
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:16p
// Updated in $/Neuroshare/nsClassifier
// Added NS Header
// Renamed class to CViewWaveforms
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////
#ifndef WAVEFORMSVIEW_H_INCLUDED
#define WAVEFORMSVIEW_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NumEdit.h"

#include "DisplaySpike.h"

class CViewFilesInUse;
class CDocPowerNAP;     // forward declare to avoid #include "DocPowerNAP.h"

/////////////////////////////////////////////////////////////////////////////
// CViewWaveforms form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


class CViewWaveforms : public CFormView
{

protected:
	CViewWaveforms();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewWaveforms)

    //graphical window classes
    CDisplaySpike m_wndSpikes;  // This window is where the spikes are drawn

// Form Data
public:

    //{{AFX_DATA(CViewWaveforms)
	enum { IDD = IDD_WFVIEW_DIALOG };
	//}}AFX_DATA

// Attributes
public:
	CDocPowerNAP * GetDocument();
    CViewFilesInUse *m_pFIUView;

    // Operations
public:
	CViewFilesInUse * GetFIUPtr(void);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewWaveforms)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL
    void OnNotifyNewReject(NMHDR *pNMHDR, LRESULT *pResult);

// Implementation
protected:
    bool m_bAnimateIsRunning;       // TRUE means we are in ANIMATE - paused, FALSE means ANIMATE - RUNNING

protected:
	virtual ~CViewWaveforms();
	void ChangeDisplayedUnits();
	void ShowOptSpkSort(int nView);

    void OnUpdateNormal(CView* pSender, LPARAM lHint, CObject* pHint);  // normal drawing
    void OnUpdateAnimate(CView* pSender, LPARAM lHint, CObject* pHint); // trying to animate
    void OnUpdateAnimatePaused(CView* pSender, LPARAM lHint, CObject* pHint); // animate as "paused"
    void OnUpdateAnimateRunning(CView* pSender, LPARAM lHint, CObject* pHint); // animate as "running"
    

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

    // Generated message map functions
    //{{AFX_MSG(CViewWaveforms)
    afx_msg void OnBtnToolBarThresh();
	afx_msg void OnSelchangeWfCombo();
	afx_msg void OnViewWfToolbar();
	afx_msg void OnUpdateViewWfToolbar(CCmdUI* pCmdUI);
	afx_msg void OnSortingOptions();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnUpdateWftbThresholdbtn(CCmdUI* pCmdUI);
	afx_msg void OnWftbClip();
	afx_msg void OnWftbClipUpdate(CCmdUI* pCmdUI);
	afx_msg void OnEditDeletecurrentunit();
	afx_msg void OnUpdateEditDeletecurrentunit(CCmdUI* pCmdUI);
	afx_msg void OnEditCompactunits();
	//}}AFX_MSG
	afx_msg void OnEditDeleteunitUnitX(UINT nID);
    afx_msg void OnEditReclassifyUnitX(UINT nID);
    afx_msg void OnUpdateReclassifyUnitX(CCmdUI* pCmdUI);
    afx_msg UINT32 HilightWF( WPARAM wParam, LPARAM lParam);
    afx_msg void UnHilightWF( WPARAM wParam, LPARAM lParam);

    DECLARE_MESSAGE_MAP()

private:
	CToolTipCtrl m_tool;
};


#ifndef _DEBUG  // debug version in .cpp
inline CDocPowerNAP* CViewWaveforms::GetDocument()
   { return (CDocPowerNAP*)m_pDocument; }
#endif


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
