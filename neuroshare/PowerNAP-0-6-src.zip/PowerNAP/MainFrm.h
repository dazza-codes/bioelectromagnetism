///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFrm.h $
//
// Description   : interface of the CMainFrame class
//
// Authors       : Kirk Korver
//
// $Date: 8/26/03 5:59p $
//
// $History: MainFrm.h $
// 
// *****************  Version 17  *****************
// User: Abranner     Date: 8/26/03    Time: 5:59p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 8/25/03    Time: 11:02a
// Updated in $/Neuroshare/nsClassifier
// Changed some variable names to conform with coding standard. Changed
// the toolbar and some tooltips.
// 
// *****************  Version 15  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 14  *****************
// User: Awang        Date: 8/12/03    Time: 10:47a
// Updated in $/Neuroshare/nsClassifier
// CViewPCA has its own mainframe CPCAMainFrame
// 
// *****************  Version 13  *****************
// User: Awang        Date: 8/05/03    Time: 2:04p
// Updated in $/Neuroshare/nsClassifier
// Removed PCA Toolbar from this mainframe to its own mainframe
// 
// *****************  Version 12  *****************
// User: Awang        Date: 6/30/03    Time: 3:49p
// Updated in $/Neuroshare/nsClassifier
// Create toolbars for ViewWaveform and ViewPCA
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 4/29/03    Time: 3:19p
// Updated in $/Neuroshare/nsClassifier
// Made the MainFrame not display the application name by default,
// Also the Frame will not automatically load any toolbar
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 4/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 4/25/03    Time: 9:30a
// Updated in $/Neuroshare/nsClassifier
// Check in before changing all kinds of things to help. Not all help is
// functional here.
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 4/23/03    Time: 10:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed the files FilesInUseView to ViewFilesInUse and
// WaveformsView to ViewWaveforms
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 4/22/03    Time: 2:02p
// Updated in $/Neuroshare/nsClassifier
// Major changes...we no longer use MDI, but rather a SDI with lots of
// windows open at the same time
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 4/10/03    Time: 1:36p
// Updated in $/Neuroshare/nsClassifier
// Removed  SortEntity() and SetFocusEntity()
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 4/01/03    Time: 1:58p
// Updated in $/Neuroshare/nsClassifier
// removed dead code
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/27/03    Time: 1:51p
// Updated in $/Neuroshare/nsClassifier
// Added NS header
// Moved several functions into the DOC class 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef MAINFRM_H_INCLUDED
#define MAINFRM_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HtmlFrameWnd.h"


class CMainFrame : public CHtmlFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:
// Overrides
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	int m_nSortMethod;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFileNew();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
