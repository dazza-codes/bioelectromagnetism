///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageKMeansOpt.cpp $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/31/03 6:04p $
//
// $History: PropPageKMeansOpt.cpp $
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 10/31/03   Time: 6:04p
// Updated in $/Neuroshare/PowerNAP
// Fixed labels.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 10/31/03   Time: 5:36p
// Updated in $/Neuroshare/PowerNAP
// Changed to CPropPageKMeansOpt.
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/29/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// ComboBox select for "All" now occurs in DoDataExchange();
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/29/03    Time: 11:10a
// Updated in $/Neuroshare/nsClassifier
// Added "All" option to KMeans options for using all PC coord in
// calculation
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "PropPageKMeansOpt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageKMeansOpt property page

IMPLEMENT_DYNCREATE(CPropPageKMeansOpt, CPropertyPage)

CPropPageKMeansOpt::CPropPageKMeansOpt() : CPropertyPage(CPropPageKMeansOpt::IDD)
{
	//{{AFX_DATA_INIT(CPropPageKMeansOpt)
	//}}AFX_DATA_INIT
}

CPropPageKMeansOpt::~CPropPageKMeansOpt()
{
}

void CPropPageKMeansOpt::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageKMeansOpt)
	DDX_Control(pDX, IDC_OPTK_CBO_PCCNT, m_cboNumPCA);
	DDX_Control(pDX, IDC_OPTK_CBO_ITER, m_cboNumIter);
	//}}AFX_DATA_MAP

    if (!pDX->m_bSaveAndValidate)
    {
        if ((m_nNumPCA == 0) || (m_nNumPCA > 20))        
            m_cboNumPCA.SelectString(-1, "All");
    }


}


BEGIN_MESSAGE_MAP(CPropPageKMeansOpt, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageKMeansOpt)
	ON_CBN_SELCHANGE(IDC_OPTK_CBO_ITER, OnChange)
	ON_CBN_SELCHANGE(IDC_OPTK_CBO_PCCNT, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageKMeansOpt message handlers


BOOL CPropPageKMeansOpt::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

    char buffer[20];

    _itoa(m_nNumIter, buffer, 10);
    m_cboNumIter.SelectString(-1, buffer);
    
    if (m_nNumPCA)
    {
        _itoa(m_nNumPCA, buffer, 10);
        m_cboNumPCA.SelectString(-1, buffer);
    }
    else
        m_cboNumPCA.SelectString(-1, "All");

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CPropPageKMeansOpt::OnChange()
{
    // Number of iterations of algorithm changed
    CString str;
    int nSel = m_cboNumIter.GetCurSel();
    m_cboNumIter.GetLBText(nSel, str);
    
    m_nNumIter = atoi(str);	
   
    // Number of PC coordinates to use changed
    nSel = m_cboNumPCA.GetCurSel();
    m_cboNumPCA.GetLBText(nSel, str);
    
    m_nNumPCA = atoi(str);

    SetModified(true);
}
