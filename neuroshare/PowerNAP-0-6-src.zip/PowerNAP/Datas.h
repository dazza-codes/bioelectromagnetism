///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: Datas.h $
//
// Description   : implementation of the Centroid List classes
//
// Authors       : Kirk Korver
//
// $Date: 3/11/04 12:57p $
//
// $History: Datas.h $
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:57p
// Updated in $/Neuroshare/PowerNAP
// Added ability to delete units and reclassify units
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:29p
// Updated in $/Neuroshare/PowerNAP
// Added const functions
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 2/27/04    Time: 2:14p
// Updated in $/Neuroshare/PowerNAP
// Added back() as a const function
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:50a
// Created in $/Neuroshare/nsClassifier
// Separated the "Datas" into their own file
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////


#ifndef DATAS_H_INCLUDED
#define DATAS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>

#include "nsAPItypes.h"
#include "PowerNAP.h"       // needed for UnitMasks
#include "DataSegment.h"
#include "DataAnalog.h"
#include "CommonTypes.h"


typedef std::vector <DataSegment> SEGMENTLIST;
typedef std::vector <DataAnalog> ANALOGLIST;

typedef std::vector <ns_SEGSOURCEINFO> VECTORSEGSOURCEINFO;

class Datas
{
public:
    Datas(DWORD dwEntityID) : m_dwEntityID(dwEntityID) {}

    DWORD GetEntityID() const { return m_dwEntityID; }      // Get the Entity ID
    CString GetLabel() const;                               // Retrieve the entity label

private:
    DWORD m_dwEntityID;
};

class Segments : public Datas
{
public:
    Segments(DWORD dwEntityID) : Datas(dwEntityID) {}


    SEGMENTLIST::iterator begin() { return m_vSegments.begin(); }
    SEGMENTLIST::const_iterator begin() const { return m_vSegments.begin(); }

    SEGMENTLIST::iterator end()   { return m_vSegments.end();   }
    SEGMENTLIST::const_iterator end() const  { return m_vSegments.end();   }

    DataSegment & operator [] (DWORD nIndex) { return m_vSegments[nIndex]; }
    const DataSegment & operator [] (DWORD nIndex) const { return m_vSegments[nIndex]; }

    void push_back(DataSegment & seg) { m_vSegments.push_back(seg); }
    void clear() { m_vSegments.clear(); }
    bool empty() const { return m_vSegments.empty(); } 
    size_t size() const { return m_vSegments.size(); }

    DataSegment & back() { return m_vSegments.back(); }
    const DataSegment & back() const { return m_vSegments.back(); }

    SEGMENTLIST::iterator erase(SEGMENTLIST::iterator it) { return m_vSegments.erase(it); }

    SEGMENTLIST & GetList() { return m_vSegments; }
    const SEGMENTLIST & GetList() const { return m_vSegments; }

    void GetInfo(ns_SEGMENTINFO & rInfo) const;         // Get the "segment" info
    void GetInfo(VECTORSEGSOURCEINFO & rvInfo) const;   // Get info about the "sources" of each segment


    void DeleteTheseUnits(UnitMasks enUnit);            // Delete every segment with this unit
    bool CompactUnits();    // remove "holes" in the unit classifications; TRUE means data changed; FALSE, not
    void ReclassifyUnits(UnitMasks enFrom, UnitMasks enTo); // reclassify the "from" units as the "to" units

protected:
    SEGMENTLIST m_vSegments;
};


class Analogs : public Datas
{
public:
    Analogs(DWORD dwEntityID) : Datas(dwEntityID) {}


    ANALOGLIST::iterator begin() { return m_vAnalogs.begin(); }
    ANALOGLIST::iterator end()   { return m_vAnalogs.end();   }
    DataAnalog & operator [] (DWORD nIndex) { return m_vAnalogs[nIndex]; }
    void push_back(DataAnalog & seg) { m_vAnalogs.push_back(seg); }
    void clear() { m_vAnalogs.clear(); }
    bool empty() const { return m_vAnalogs.empty(); } 
    size_t size() const { return m_vAnalogs.size(); }
    DataAnalog & back() { return m_vAnalogs.back(); }
    const DataAnalog & back() const { return m_vAnalogs.back(); }
    ANALOGLIST::iterator erase(ANALOGLIST::iterator it) { return m_vAnalogs.erase(it); }

    ANALOGLIST & GetList() { return m_vAnalogs; }


    void GetInfo(ns_ANALOGINFO & rInfo) const;
    double GetSampleRate() const;               // Get the sampling rate in Hz



protected:
    ANALOGLIST m_vAnalogs;
};


#endif // include guards
