///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageShyOpt.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 10/31/03 6:07p $
//
// $History: PropPageShyOpt.h $
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/31/03   Time: 6:07p
// Updated in $/Neuroshare/PowerNAP
// Renamed page.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/30/03   Time: 5:39p
// Updated in $/Neuroshare/PowerNAP
// Changed the name of the class.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/27/03    Time: 11:22a
// Updated in $/Neuroshare/nsClassifier
// Added author in header.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 8/26/03    Time: 6:29p
// Created in $/Neuroshare/nsClassifier
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPPAGESHYOPT_H_INCLUDED
#define PROPPAGESHYOPT_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropPageShyOpt dialog

class CPropPageShyOpt : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageShyOpt)

// Construction
public:
	CPropPageShyOpt();
	~CPropPageShyOpt();

// Dialog Data
	//{{AFX_DATA(CPropPageShyOpt)
	enum { IDD = IDD_PROPPAGE_SHY_OPT };
	int		m_nPosPCA;
	int		m_nPosPenaltyFct;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPageShyOpt)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPageShyOpt)
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
