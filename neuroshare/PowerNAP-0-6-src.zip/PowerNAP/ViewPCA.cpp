///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewPCA.cpp $
//
// Description   : Display projections of PC decomposition - PC1 v PC2 and PC2 v PC3
//
// Authors       : Angela Wang
//
// $Date: 3/11/04 4:32p $
//
// $History: ViewPCA.cpp $
// 
// *****************  Version 40  *****************
// User: Kkorver      Date: 3/11/04    Time: 4:32p
// Updated in $/Neuroshare/PowerNAP
// 
// *****************  Version 39  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:36p
// Updated in $/Neuroshare/PowerNAP
// Use new GetActiveSegment()
// 
// *****************  Version 38  *****************
// User: Kkorver      Date: 2/19/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// PCA now uses floating point math for the conversion. The result is that
// BIG and small numbers will now be displayed properly
// 
// *****************  Version 37  *****************
// User: Abranner     Date: 1/30/04    Time: 3:57p
// Updated in $/Neuroshare/PowerNAP
// Simplified initialization of property sheets.
// 
// *****************  Version 36  *****************
// User: Abranner     Date: 10/31/03   Time: 6:07p
// Updated in $/Neuroshare/PowerNAP
// Fixed options property sheet.
// 
// *****************  Version 35  *****************
// User: Abranner     Date: 10/29/03   Time: 9:55a
// Updated in $/Neuroshare/PowerNAP
// Removed setting the title, now done in string table.
// 
// *****************  Version 34  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:43a
// Updated in $/Neuroshare/PowerNAP
// Overhaul of the PCA display
// 
// *****************  Version 33  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 32  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 31  *****************
// User: Abranner     Date: 10/16/03   Time: 1:23p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 30  *****************
// User: Abranner     Date: 10/13/03   Time: 1:59p
// Updated in $/Neuroshare/nsClassifier
// Changed IsThisSegment() to IsActiveSegment().
// 
// *****************  Version 29  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 28  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 27  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 26  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 25  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 24  *****************
// User: Awang        Date: 8/29/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Save #PC coordinates saved correctly from combobox
// 
// *****************  Version 23  *****************
// User: Awang        Date: 8/28/03    Time: 2:30p
// Updated in $/Neuroshare/nsClassifier
// OnUpdate clears centroid list if HINT says new waveform data  is loaded
// 
// *****************  Version 22  *****************
// User: Awang        Date: 8/28/03    Time: 11:18a
// Updated in $/Neuroshare/nsClassifier
// Changed "Shy sorting" to "T distribution" in status bar message
// 
// *****************  Version 21  *****************
// User: Awang        Date: 8/28/03    Time: 9:42a
// Updated in $/Neuroshare/nsClassifier
// Added Status bar messages
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 19  *****************
// User: Awang        Date: 8/27/03    Time: 12:12p
// Updated in $/Neuroshare/nsClassifier
// Fixed - after a sort, display shows the correct axis.
// Increased the scale to display %125 of max, min of data.
// 
// *****************  Version 18  *****************
// User: Abranner     Date: 8/27/03    Time: 10:57a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet and removed CViewOptKMeans.
// 
// *****************  Version 17  *****************
// User: Abranner     Date: 8/26/03    Time: 6:24p
// Updated in $/Neuroshare/nsClassifier
// Adjustments after merging.
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 8/26/03    Time: 6:01p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 15  *****************
// User: Awang        Date: 8/26/03    Time: 2:25p
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 14  *****************
// User: Awang        Date: 8/22/03    Time: 10:44a
// Updated in $/Neuroshare/nsClassifier
// Centroid class removed
// 
// *****************  Version 13  *****************
// User: Awang        Date: 8/19/03    Time: 12:25p
// Updated in $/Neuroshare/nsClassifier
// Removed code that was commented out
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 8/18/03    Time: 5:30p
// Updated in $/Neuroshare/nsClassifier
// Changed how OnUpdate redraws the PCA window.
// 
// *****************  Version 11  *****************
// User: Awang        Date: 8/18/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Changed name of centroid lists
// 
// *****************  Version 10  *****************
// User: Awang        Date: 8/15/03    Time: 1:21p
// Updated in $/Neuroshare/nsClassifier
// Added PCAMainFrame.h file
// 
// *****************  Version 9  *****************
// User: Awang        Date: 8/05/03    Time: 3:41p
// Updated in $/Neuroshare/nsClassifier
// Add centroid display
// 
// *****************  Version 8  *****************
// User: Awang        Date: 6/30/03    Time: 3:59p
// Updated in $/Neuroshare/nsClassifier
// Local control removed to toolbars in ViewPCA and ViewWaveform
// 
// *****************  Version 7  *****************
// User: Awang        Date: 6/18/03    Time: 2:30p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 6  *****************
// User: Awang        Date: 6/11/03    Time: 9:05a
// Updated in $/Neuroshare/nsClassifier
// Fixed Cluster ID for NOISEUNIT
// 
// *****************  Version 5  *****************
// User: Awang        Date: 6/10/03    Time: 4:22p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing.
// Implemented selection and highlighting of one waveform point.
// 
// *****************  Version 4  *****************
// User: Awang        Date: 5/30/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 3  *****************
// User: Awang        Date: 5/06/03    Time: 10:08a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 2  *****************
// User: Awang        Date: 5/06/03    Time: 9:56a
// Updated in $/Neuroshare/nsClassifier
// In progress work on drawing clusters
// 
// *****************  Version 1  *****************
// User: Awang        Date: 4/28/03    Time: 12:16p
// Created in $/Neuroshare/nsClassifier
// 

///////////////////////////////////////////////////////////////////////////////////////////////////
//
// ViewPCA.cpp : implementation file
//
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Disable warning C4768
#pragma warning(disable : 4786)

#include <limits.h>
#include <float.h>
#include <math.h>
#include <algorithm>
#include "stdafx.h"

#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "Visitor.h" 
#include "VisitorKMeans.h"
#include "ns_common.h"
#include "ViewPCA.h"
#include "DisplayPCProj.h"
#include "VisitorPCA.h"
#include "VisitorShyAlgorithm.h"
#include "ViewWaveforms.h"
#include "MainFramePCA.h"
#include "PropSheetSpkSort.h"


/////////////////////////////////////////////////////////////////////////////
// CViewPCA


typedef std::vector<CPoint> POINTVECTOR;
typedef std::vector<int> INTVECTOR;


//Global data
INTVECTOR   g_avInPtIndexArray[UNITCOUNT];


/////////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CViewPCA, CFormView)

CViewPCA::CViewPCA() :
    CFormView(CViewPCA::IDD),
    m_apdMyWaves(NULL),
    m_apdCtr(NULL),
    m_pMainFrame(NULL)
{
    //{{AFX_DATA_INIT(CViewPCA)
	//}}AFX_DATA_INIT

    m_apdMyWaves = NULL;
    m_lCurrCluster = -1;// not selected yet
    m_pDocument = NULL;

    // Set default axis PC1 v. PC2 for the display
    m_nXAxis = 0;
    m_nYAxis = 1;
}


CViewPCA::~CViewPCA()
{
    CleanPCDataPoints();
}


void CViewPCA::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CViewPCA)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewPCA, CFormView)
//    ON_MESSAGE(WM_USER_UPDATEUNITS, UpdatePCViews)
    //{{AFX_MSG_MAP(CViewPCA)
    ON_COMMAND(ID_SORTINGOPTIONS, OnSortingOptions)
    ON_WM_SIZE()
    ON_MESSAGE(WM_USER_UNSELECTWF, OnUserUnSelectWF)
    ON_MESSAGE(WM_USER_SELECTWF, OnUserSelectWF)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewPCA diagnostics

#ifdef _DEBUG
void CViewPCA::AssertValid() const
{
    CFormView::AssertValid();
}

void CViewPCA::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif //_DEBUG

CDocPowerNAP*  CViewPCA::GetDocument()
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}


/////////////////////////////////////////////////////////////////////////////
// CViewPCA message handlers

void CViewPCA::OnInitialUpdate() 
{
    ReplaceWindowControl(*this, m_wndPCA, IDC_PC1_FRAME);
    
    // Size frame to fit the formview
    m_pMainFrame = static_cast<CMainFramePCA *>(GetParentFrame());
    m_pMainFrame->RecalcLayout();
    ResizeParentToFit(FALSE);

    CFormView::OnInitialUpdate();
}


void CViewPCA::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
    CDocPowerNAP * pDoc = GetDocument();

    ////////////////////////////////////////////////////////////////////////////////////
    // Clean up old arrays and lists
    // Clear the CLIENT COODINATES CPoint data arrays for a fresh draw of the data points
    m_wndPCA.m_vPCData.clear();

    // Clear the CLIENT COODINATES CPoint data arrays for a fresh draw of the centroids
    m_wndPCA.m_vPCCtr.clear();
    
    // If new data has been loaded, due to re-thresholding
    // clear out old Centroid (PC space) list

    // Without this test, then the center's are always cleared, and "never" visible
    if (lHint == HINT_USER_NEWDATA)
        pDoc->m_isSortInfo.m_icCtrPCList.clear();
    
    CleanPCDataPoints();// clear out old m_apdMyWaves
    
    ////////////////////////////////////////////////////////////////////////////////////
    // Get updated data    
    // Get the latest waveform list
    if ( (pDoc->AreThereSegments()) && (pDoc->IsActiveSegment()) )
    {
        m_nWFCount = pDoc->GetActiveSegment().size();      // number of waveforms
        m_nPtCount = (int) pDoc->GetNumOfPointsPerWave();  // number of waveform pts
        
        // Allocate array (m_apdMyWaves) to be filled with PC data from VisitorPCA 
        CreatePCDataArray();
        
        if (m_apdMyWaves)
        {
            //If PCA not done already, do it now.
            //(NOTE:  After sort analysis, the PC pts should really come from the sort algorithm)
            // Visitor fills the array m_apdMyWaves and then does a Principal decomposition
            // replacing the original values.
            VisitorPCA v;
            GenericVisitable gv(pDoc, this);
            gv.Accept(v);
            
            // Load the new PC decomposition of the waveform points and
            // convert into client coordinates for plotting into g_vPCData
            LoadPCClientPoints(m_apdMyWaves, m_nWFCount);    
            
            // First display 
            // Get axis selected or use default
            m_wndPCA.SetAxis(m_nXAxis, m_nYAxis);
            
            // Load the centroids into global g_vPCCtr, if data has been sorted
            int nCurrEntIndex = pDoc->GetActiveEntityIndex();
            int nCurrEnt = pDoc->GetActiveEntity();
            
            // Set status bar message
            CString str;
            if (pDoc->m_icEntityInfoVector[nCurrEntIndex].m_bRulesDefined == true)
            {
                LoadCtr();
                
                // Set status bar message with rules defined
                if (m_nSortMethod == 0)
                {
                    str.Format("Entity %d - T distribution defined units", nCurrEnt);
                }
                else if (m_nSortMethod == 1)
                {
                    str.Format("Entity %d - K Means defined units", nCurrEnt);
                }
                else if (m_nSortMethod == 2)
                {
                    str.Format("Entity %d - manually defined units", nCurrEnt);
                }
                
                m_pMainFrame->StatusBarMessage(str.GetBuffer(0));
            }
            else
            {
                str.Format("Entity %d", nCurrEnt);
                m_pMainFrame->StatusBarMessage(str.GetBuffer(0));
            }
        }
    }
        
    // Clear the PC feature space display and redraw it
    m_wndPCA.Invalidate(); 
}// OnUpdate


// This function is called by PCProj whenever points inside a polygon
// are defined.  All projections need to be updated to reflect the new cluster
// definitions.  Radio buttions are released to ready the cursor for next action.
void CViewPCA::UpdatePCViews(WPARAM wParam, LPARAM lParam)
{
    m_wndPCA.Invalidate();
}


// Cache the client coordinate projections of the PC data points into g_vPCData
// Input : pPCData - array of doubles containing the waveforms transformed into PC space
//         dwPtCount - number of data points
//
void CViewPCA::LoadPCClientPoints(double **pPCData, const uint32 dwPtCount)
{
    // Cache the client coordinates and cluster ID of the PC data points
    // Check if waveform data exists, if not, exit
    if (pPCData == NULL)
    {
        m_nPtCount = 0;    
        return;
    }

    // Clear the CPoint data arrays for a fresh draw of the data points
    m_wndPCA.m_vPCData.clear();
 
    // Cache number of points in data
    m_nPtCount = dwPtCount;    

    // I want to find the largest value...this is the largest of the X, Y and Z
    double dMax = FindMaxValue(pPCData);
    dMax *= 1.10;       // A little padding
    m_wndPCA.SetMaxValue(dMax);
    
    //First PC1 v PC2 ////////////////////////////////////////////////////
    const int nXAxis = 0; // X axis
    const int nYAxis = 1; // Y axis
    const int nZAxis = 2; // Z axis

    CRect rectClient;

    GetDlgItem(IDC_PC1_FRAME)->GetClientRect(&rectClient);
    int nClientWidth = rectClient.Width();
    int nClientHeight = rectClient.Height();
    
    // Convert to client coordinates for this display (X Y Z)
    NsPoint3D pnt;  // 3D point
    DWORD dwUnit;
    for (int nPt = 0; nPt < dwPtCount; nPt++)
    {
        // Get unit of this point
        CDocPowerNAP * pDoc = GetDocument();
        dwUnit = pDoc->GetActiveSegment()[nPt].GetUnitID();

        pnt.x = pPCData[nPt][nXAxis];
        pnt.y = pPCData[nPt][nYAxis];
        pnt.z = pPCData[nPt][nZAxis];

        // Save the data from document 
        NsPCData data(nPt, dwUnit, pnt);
        m_wndPCA.m_vPCData.push_back(data);
        
        // Save original unitID's
        pDoc->UnitList.push_back(dwUnit);
    }
}


// Reset the unitID of  data points currently defined as unit = lCluster
// to original file unitID
void CViewPCA::SetOrigUnitDef(const INT32 lSearchCluster)
{
    int nWFIndx = 0;

    DWORD dwUnitID;
    PCDATALIST::iterator it;
    for (it = m_wndPCA.m_vPCData.begin(); it != m_wndPCA.m_vPCData.end(); ++it)
    {
        CDocPowerNAP * pDoc = GetDocument();
        if (it->GetClstrID() == pDoc->GetBITUnit(lSearchCluster))
        {
            // Get original file UnitID of this point, that is converted to 
            // cluster ID
            dwUnitID = pDoc->UnitList[nWFIndx];

            // Set to orginal file unitID in client coord list
             it->SetClstrID(dwUnitID);

             // Set waveform list in document for all views to redraw
             pDoc->GetActiveSegment()[nWFIndx].SetUnitID(dwUnitID); 
        }
        ++nWFIndx;
    }
}//SetOrigUnitDef



// Highlight selected PC waveform point in red
void CViewPCA::OnUserSelectWF(WPARAM wParam, LPARAM lParam)
{
    // lParam = currently selected Waveform Index
    // wParam = previously selected waveform index
    UINT32 nPrevWF = (UINT32) wParam;
    UINT32 nSelWF = (UINT32) lParam;

    // Call the display to high-light the waveform selected
    // Decide which display needs to high-light 
    m_wndPCA.HilightWF(nPrevWF, nSelWF);
}


// Return to original state of PC waveform point
// Inputs:
//  lParam = currently selected Waveform Index
//  wParam = previously selected waveform index
void CViewPCA::OnUserUnSelectWF(WPARAM wParam, LPARAM lParam)
{
    INT32 lPrevWF = (INT32) wParam;
    INT32 lSelWF = (INT32) lParam;
    if (lSelWF < 0)
        return;

    // Call the display to high-light the waveform selected
    // Decide which display needs to high-light 
    m_wndPCA.UnHilightWF(lPrevWF, lSelWF);
}


void CViewPCA::SetDisplayMode(const UINT32 nMode, const INT32 lClstr)
{
    CString str;

    m_lCurrCluster = lClstr;

    m_wndPCA.SetDrawMode(nMode);

    // Set message on status bar for manual drawing or selecting one point
    int nCurrEnt = GetDocument()->GetActiveEntity();
    if (nMode == CLUSTERCUTTOOLS)
    {
        if (m_lCurrCluster == NOISE)
            str.Format("Entity %d - noise unit selection", nCurrEnt);
        else if (m_lCurrCluster == NOISE_OUT)
             str.Format("Entity %d - noise units defined outside selection", nCurrEnt);
        else
             str.Format("Entity %d - unit %d selection", nCurrEnt, m_lCurrCluster);
       
        m_pMainFrame->StatusBarMessage(str.GetBuffer(0));
    }
    else if (nMode == SELECTMODE)
    {
        str.Format("Entity %d - highlight one waveform point", nCurrEnt);
        m_pMainFrame->StatusBarMessage(str.GetBuffer(0));
    }
        
    // Set current cluster    
    m_wndPCA.SetWorkingClstr(lClstr);
    
    // Clear highlighting selection
    m_wndPCA.ClearSelections( );
}


// Allocate 2-D double array to be filled with PC coordinates of
// waveform data computed by VisitorPCA.
void CViewPCA::CreatePCDataArray()
{
    // Create 2-D array to hold PC points    
    if ((m_apdMyWaves == NULL) && (m_nWFCount > 0) && (m_nPtCount > 0))
    {
        // Allocate space for a 2D array of doubles
        m_apdMyWaves = new double* [m_nWFCount];
        
        for (int indx=0; indx < m_nWFCount; indx++)
            m_apdMyWaves[indx] = new double [m_nPtCount];
    }
}//CreatePCDataArray


// De-allocate array of PC data values
void CViewPCA::CleanPCDataPoints()
{
    if (m_apdMyWaves)
    {
        // De-allocate array    
        for (int indx=0; indx<m_nWFCount; indx++)
            delete [] m_apdMyWaves[indx];
    
        delete [] m_apdMyWaves;
        m_apdMyWaves = NULL;
    }
}//CleanPCDataPoints


void CViewPCA::SetAxis(int nXAxis, int nYAxis)
{
    // Pass Axis selection on to display projections
    m_nXAxis = nXAxis;
    m_nYAxis = nYAxis;

    m_wndPCA.SetAxis(nXAxis, nYAxis);
}


void CViewPCA::SetSortMethod(int nMethod)
{
    //  Set the selected sorting method from the combobox
    m_nSortMethod = nMethod;
}


// Cache the client coordinate projections of the centroids in PC space into g_vPCData
// Input : none
void CViewPCA::LoadCtr(void)
{
    // Clear the Centroid client coordinates for a fresh draw of the data points
    m_wndPCA.m_vPCCtr.clear();
    
    const int nXAxis = 0; // X- axis
    const int nYAxis = 1; // Y-axis
    const int nZAxis = 2; // Z-axis
    int nCtrIdx = 0;

    CRect rectClient;

    GetDlgItem(IDC_PC1_FRAME)->GetClientRect(&rectClient);
    int nClientWidth = rectClient.Width();
    int nClientHeight = rectClient.Height();
    
    NsPoint3D pnt;
    
    // Convert into client coordinates
    CDocPowerNAP * pDoc = GetDocument();
    for (CTRPCLIST::iterator it = pDoc->m_isSortInfo.m_icCtrPCList.begin();
        it != pDoc->m_isSortInfo.m_icCtrPCList.end();  ++it)
    {
        // Get the centroids defined by sorting algorithm
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        pnt.x = aicWave[nXAxis];
        pnt.y = aicWave[nYAxis];
        pnt.z = aicWave[nZAxis];

        // Save Centroids in client coordinates into a global vector 
        NsPCData data(0, pDoc->GetBITUnit(nCtrIdx), pnt);

        m_wndPCA.m_vPCCtr.push_back(data);       
       
        ++nCtrIdx;
    }
}

 
void CViewPCA::ClearCtr()
{
    // Clear the centroid list in PC coordinates
    GetDocument()->m_isSortInfo.m_icCtrPCList.clear();

    // Clear the centroid list in client coordinates
    m_wndPCA.m_vPCCtr.clear();
    
    // Clear the PC feature space display
    m_wndPCA.Invalidate(); 
}
 

void CViewPCA::ShowOptSpkSort(int nView)
{
    CDocPowerNAP *pDocument = GetDocument();

    CPropSheetSpkSort icPropSheetSpkSort("Automatic Spike Sorting", NULL, nView, pDocument);

    if (icPropSheetSpkSort.DoModal() == IDOK)
        Invalidate();
}


void CViewPCA::OnSortingOptions() 
{
    ShowOptSpkSort(0);  
}

void CViewPCA::OnSize(UINT nType, int cx, int cy) 
{
    CFormView::OnSize(nType, cx, cy);

    // OnSize get's called a lot before the window is fully visible.
    // This test is just to ensure that the control has been created
    // prior to trying work with it
    if (m_wndPCA.m_hWnd)
    {
        CRect rWaves;
        m_wndPCA.GetWindowRect(rWaves);
        ScreenToClient(rWaves);

        // There are 2 borders...one on the left, and one on the right
        int nWidth = cx - rWaves.left * 2;
        int nHeight = cy - rWaves.top * 2;

        m_wndPCA.SetWindowPos(this, 0, 0, nWidth, nHeight, SWP_NOZORDER | SWP_NOMOVE);

        ShowScrollBar(SB_BOTH, false);  // i NEVER want scroll bars
    }
}

double CViewPCA::FindMaxValue(double **pPCData)
{
    double dMax = -DBL_MAX;      // minimum possible number....all others must be larger

    // Set range of X, Y, and Z axis 
    // (PC1, PC2, and PC3 projections)
    for (int nAxis = 0; nAxis < 3; ++nAxis)
    {
        for (int nIndx = 0; nIndx < m_nPtCount; nIndx++)
        {
            // Get Max of values of axis
            double dTemp = pPCData[nIndx][nAxis];
            dMax = (dMax < dTemp ? dTemp : dMax);
        }
    }
    return dMax;
}
