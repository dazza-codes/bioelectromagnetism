///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PowerNAP.h $
//
// Description   : interface of the CAppPowerNAP class
//
// Authors       : Kirk Korver
//
// $Date: 3/09/04 5:10p $
//
// $History: PowerNAP.h $
// 
// *****************  Version 33  *****************
// User: Kkorver      Date: 3/09/04    Time: 5:10p
// Updated in $/Neuroshare/PowerNAP
// Created multiple constants to make uses clearer
// 
// *****************  Version 32  *****************
// User: Abranner     Date: 3/05/04    Time: 3:01p
// Updated in $/Neuroshare/PowerNAP
// Fixed colors and added a spinner control.
// 
// *****************  Version 31  *****************
// User: Abranner     Date: 3/05/04    Time: 9:21a
// Updated in $/Neuroshare/PowerNAP
// Added string array with unit labels.
// 
// *****************  Version 30  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:50p
// Updated in $/Neuroshare/PowerNAP
// Added playback capabilities
// 
// *****************  Version 29  *****************
// User: Abranner     Date: 2/10/04    Time: 11:41a
// Updated in $/Neuroshare/PowerNAP
// Added colors and pens for additional units.
// 
// *****************  Version 28  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 27  *****************
// User: Abranner     Date: 10/31/03   Time: 6:04p
// Updated in $/Neuroshare/PowerNAP
// Removed templates for options.
// 
// *****************  Version 26  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 25  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:18a
// Updated in $/Neuroshare/nsClassifier
// Added HINT_USER_NONE
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 10/15/03   Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// Added colors and masks to application.
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// *****************  Version 22  *****************
// User: Awang        Date: 8/28/03    Time: 2:38p
// Updated in $/Neuroshare/nsClassifier
// Added user HINTS
// 
// *****************  Version 21  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 20  *****************
// User: Awang        Date: 8/18/03    Time: 11:44a
// Updated in $/Neuroshare/nsClassifier
// Added Sorted Units information display and view
// 
// *****************  Version 19  *****************
// User: Awang        Date: 8/05/03    Time: 2:06p
// Updated in $/Neuroshare/nsClassifier
// Re-orgainized DocTemplates
// Added views for KMeans and Manual clustering options
// 
// *****************  Version 18  *****************
// User: Awang        Date: 6/30/03    Time: 3:51p
// Updated in $/Neuroshare/nsClassifier
// Toolbars, EnityInfo View and menu options added
// 
// *****************  Version 17  *****************
// User: Awang        Date: 6/18/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// *****************  Version 15  *****************
// User: Awang        Date: 6/11/03    Time: 9:05a
// Updated in $/Neuroshare/nsClassifier
// Fixed Cluster ID for NOISEUNIT
// 
// *****************  Version 14  *****************
// User: Awang        Date: 6/10/03    Time: 4:41p
// Updated in $/Neuroshare/nsClassifier
// Color definitions and unit colors placed here.
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 12  *****************
// User: Awang        Date: 5/01/03    Time: 1:38p
// Updated in $/Neuroshare/nsClassifier
// Added ViewPCA stuff
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 4/29/03    Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Added a view for Entity Infos
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 4/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef POWERNAP_H_INCLUDED
#define POWERNAP_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "nsAPItypes.h"


/////////////////////////////////////////////////////////////////////////////

// User Messages
enum tagUSERMESSAGES
{
    WM_USER_UPDATEUNITS = WM_USER + 1,  // update unit colors
    WM_USER_SELECTWF,                    // waveform is selected/highlight it
    WM_USER_UNSELECTWF,                  // waveform is unselected
    WM_USER_UPDATETEMPLATE              // new template
};

// User Hints
enum tagUSERHINTS
{
    HINT_USER_NONE,         // No hint
    HINT_USER_NEWDATA,      // new data
    HINT_USER_ANIMATING,    // the "animating" data has changed
};

// Masks for unit ids
enum UnitMasks
{
    UNIT_UNCLASS_MASK   = 0x0000,   // mask for unclassified units
    UNIT_NOISE_MASK     = 0x0001,   // mask for noise units
    UNIT_1_MASK         = 0x0002,   // mask for unit 1
    UNIT_2_MASK         = 0x0004,   // mask for unit 2
    UNIT_3_MASK         = 0x0008,   // mask for unit 3
    UNIT_4_MASK         = 0x0010,   // mask for unit 4
    UNIT_5_MASK         = 0x0020,   // mask for unit 5
    UNIT_6_MASK         = 0x0040,   // mask for unit 6
    UNIT_7_MASK         = 0x0080,   // mask for unit 7
    UNIT_8_MASK         = 0x0100,   // mask for unit 8
    UNIT_9_MASK         = 0x0200,   // mask for unit 9
    UNIT_10_MASK        = 0x0400,   // mask for unit 10
    UNIT_NOISE_OUT_MASK = 0x0800,   // mask for noise out units
    CONTINUOUS_MASK     = 0x1000,   // mask for continuous channel

    UNIT_ALL_MASK = UNIT_UNCLASS_MASK |
                    UNIT_NOISE_MASK |
                    UNIT_1_MASK |
                    UNIT_2_MASK |
                    UNIT_3_MASK |
                    UNIT_4_MASK |
                    UNIT_5_MASK |
                    UNIT_6_MASK |
                    UNIT_7_MASK |
                    UNIT_8_MASK |
                    UNIT_9_MASK |
                    UNIT_10_MASK |
                    UNIT_NOISE_OUT_MASK |
                    CONTINUOUS_MASK,
};

// Indeces into arrays
enum
{
    UNCLASS = 0,
    UNIT1,
    UNIT2,
    UNIT3,
    UNIT4,
    UNIT5,
    UNIT6,
    UNIT7,
    UNIT8,
    UNIT9,
    UNIT10,
    NOISE,
    NOISE_OUT,
    UNITCOUNT,
};


//////////////////////////////////////////////////////////////////////////////


// THIS IS THE MASTER LIST FOR ALL OF THE TEXTS. 
//
// If you want a sub-set of this list, create a new one below
enum
{
    UL_ALL,
    UL_UNCLASS,
    UL_UNIT1,
    UL_UNIT2,
    UL_UNIT3,
    UL_UNIT4,
    UL_UNIT5,
    UL_UNIT6,
    UL_UNIT7,
    UL_UNIT8,
    UL_UNIT9,
    UL_UNIT10,
    UL_NOISE,
    UL_NOISE_OUT,
    UL_COUNT,
};

static const char * UNITLABEL[UL_COUNT] = { "All",
                                            "Unclassified",
                                            "Unit 1",
                                            "Unit 2",
                                            "Unit 3",
                                            "Unit 4",
                                            "Unit 5",
                                            "Unit 6",
                                            "Unit 7",
                                            "Unit 8",
                                            "Unit 9",
                                            "Unit 10",
                                            "Noise",
                                            "Noise Out" };

//////////////////////////////////////////////////////////////////////////////

// Used to show all of the available "units" in the waveform dropdown list
enum 
{
    WL_ALL,
    WL_UNCLASS,
    WL_UNIT1,
    WL_UNIT2,
    WL_UNIT3,
    WL_UNIT4,
    WL_UNIT5,
    WL_UNIT6,
    WL_UNIT7,
    WL_UNIT8,
    WL_UNIT9,
    WL_UNIT10,
    WL_NOISE,
    WL_COUNT,
};
static const char * WU_LABEL[WL_COUNT] =    // this is odd, but it ensures the same wording
{
    UNITLABEL[UL_ALL],
    UNITLABEL[UL_UNCLASS],
    UNITLABEL[UL_UNIT1],
    UNITLABEL[UL_UNIT2],
    UNITLABEL[UL_UNIT3],
    UNITLABEL[UL_UNIT4],
    UNITLABEL[UL_UNIT5],
    UNITLABEL[UL_UNIT6],
    UNITLABEL[UL_UNIT7],
    UNITLABEL[UL_UNIT8],
    UNITLABEL[UL_UNIT9],
    UNITLABEL[UL_UNIT10],
    UNITLABEL[UL_NOISE],
};

//////////////////////////////////////////////////////////////////////////////

// Used for the property page manual sorting
enum 
{
    MS_UNIT1,
    MS_UNIT2,
    MS_UNIT3,
    MS_UNIT4,
    MS_UNIT5,
    MS_UNIT6,
    MS_UNIT7,
    MS_UNIT8,
    MS_UNIT9,
    MS_UNIT10,
    MS_NOISE,
    MS_NOISE_OUT,
    MS_COUNT,
};
static const char * MU_LABEL[MS_COUNT] = 
{
    UNITLABEL[UL_UNIT1],
    UNITLABEL[UL_UNIT2],
    UNITLABEL[UL_UNIT3],
    UNITLABEL[UL_UNIT4],
    UNITLABEL[UL_UNIT5],
    UNITLABEL[UL_UNIT6],
    UNITLABEL[UL_UNIT7],
    UNITLABEL[UL_UNIT8],
    UNITLABEL[UL_UNIT9],
    UNITLABEL[UL_UNIT10],
    UNITLABEL[UL_NOISE],
    UNITLABEL[UL_NOISE_OUT],
};

//////////////////////////////////////////////////////////////////////////////

typedef struct {
	COLORREF dispback;
	COLORREF dispgridmin;
	COLORREF disptext;
	COLORREF dispwave;
	COLORREF dispunit[17];  // 0 = unclassified
    COLORREF dispchansel[3];
} COLORTABLE;


/////////////////////////////////////////////////////////////////////////////
// Define global unit colors
const COLORREF	LIGHT_GREY =    RGB(192, 192, 192);
const COLORREF	MEDIUM_GREY =   RGB(160, 160, 160);
const COLORREF	DARK_GREY = 	RGB(48, 48, 48);
const COLORREF  MAGENTA = 		RGB(255, 100, 153);
const COLORREF  CYAN = 			RGB(0, 255, 255);
const COLORREF  YELLOW = 		RGB(255, 255, 0);
const COLORREF  PURPLE = 		RGB(200, 0, 255);
const COLORREF  GREEN = 		RGB(0, 255, 0);
const COLORREF  BLUE = 			RGB(0, 0, 255);
const COLORREF  RED = 			RGB(255, 0, 0);
const COLORREF  DARK_GREEN = 	RGB(57, 181, 74);
const COLORREF  ORANGE =		RGB(247, 148, 29);
const COLORREF  LT_BROWN =      RGB(166, 124, 92);
const COLORREF  BLACK=          RGB(0, 0, 0);
const COLORREF  WHITE =         RGB(254, 254, 254);
const COLORREF  LT_GREEN =      RGB(0,128,0); // used for grid


/////////////////////////////////////////////////////////////////////////////
// CAppPowerNAP:


class CAppPowerNAP : public CWinApp
{
public:
    CAppPowerNAP();
    ~CAppPowerNAP();    // destructor

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAppPowerNAP)
    public:
    virtual BOOL InitInstance();
    virtual int ExitInstance();
    //}}AFX_VIRTUAL

// Implementation

protected:
    CSingleDocTemplate * m_pFilesInUseTemplate;
    CSingleDocTemplate * m_pWaveformsTemplate;
    CSingleDocTemplate * m_pTemplateLibDetails;
	CSingleDocTemplate * m_pEntInfoTemplate;
	CSingleDocTemplate * m_pViewPCATemplate;
	CSingleDocTemplate * m_pViewSortedTemplate;
    CSingleDocTemplate * m_pViewRasterTemplate;

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	// Get the fully qualified path to the directory where the app is running
    CString GetAppPath();

    // Get the fully qualifed name of the EXE running
    CString GetAppPathName();   


    CSingleDocTemplate * GetWaveformsTemplate();
    CSingleDocTemplate * GetLibDetailsTemplate();
    CSingleDocTemplate * GetEntInfoTemplate();
    CSingleDocTemplate * GetViewPCATemplate();
    CSingleDocTemplate * GetSortedInfoTemplate();
    CSingleDocTemplate * GetViewRasterTemplate();



    //{{AFX_MSG(CAppPowerNAP)
    afx_msg void OnAppAbout();
    afx_msg void OnFileNew();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
