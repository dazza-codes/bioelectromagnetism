///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorPCA.h $
//
// Description   : interface for the VisitorPCA class.
//
// Authors       : Kirk Korver
//
// $Date: 10/21/03 2:43p $
//
// $History: VisitorPCA.h $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/05/03    Time: 3:42p
// Updated in $/Neuroshare/nsClassifier
// Use same algorithm for principal component decomposition princomp and
// deleted other algorithm
// 
// *****************  Version 3  *****************
// User: Awang        Date: 5/30/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 4/10/03    Time: 9:51a
// Updated in $/Neuroshare/nsClassifier
// First implementation of the PCA algorithm
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 4/09/03    Time: 2:07p
// Created in $/Neuroshare/nsClassifier
// This is the Principle Component Analysis Algorithm classes
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef VISITORPCA_H_INCLUDED
#define VISITORPCA_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Visitor.h"
#include "DocPowerNAP.h"
#include "Visitor.h"
#include "cmatrix"


//
// typedef for different matrix types
//
typedef techsoft::matrix<double> Matrix;
typedef std::valarray<double>    Vector;


// This class will perform a Principle Component Analysis based on the data available
class VisitorPCA :
    public BaseVisitor,          // required
    public Visitor<GenericVisitable, bool>
{
public:
    bool Visit(GenericVisitable & data);

private:
    void FillWaves(double ** apdWaves, int nNumberOfWaves, int nNumOfPointsPerWave, CDocPowerNAP & rcDoc);

    
    void princomp(Matrix *pc, Matrix *score, Matrix data);
    void meancols(Matrix *meanc, Matrix data);
    void sumcols(Matrix *sumc, Matrix data);
   
    void trace(Matrix mtrace);
    
    
    
};





#endif // include guards
