///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PowerNAP.cpp $
//
// Description   : Defines the class behaviors for the application.
//
// Authors       : Kirk Korver
//
// $Date: 2/27/04 1:52p $
//
// $History: PowerNAP.cpp $
// 
// *****************  Version 48  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:52p
// Updated in $/Neuroshare/PowerNAP
// Renamed CAboutDlg to CDlgAbout
// 
// *****************  Version 47  *****************
// User: Kkorver      Date: 2/18/04    Time: 1:24p
// Updated in $/Neuroshare/PowerNAP
// The library manager now is passed the app path
// 
// *****************  Version 46  *****************
// User: Abranner     Date: 10/31/03   Time: 6:04p
// Updated in $/Neuroshare/PowerNAP
// Removed templates for options.
// 
// *****************  Version 45  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 44  *****************
// User: Abranner     Date: 10/15/03   Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// Added colors and masks to application.
// 
// *****************  Version 43  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// *****************  Version 42  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 41  *****************
// User: Abranner     Date: 8/27/03    Time: 2:58p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 8/27/03    Time: 10:57a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet and removed CViewOptKMeans.
// 
// *****************  Version 39  *****************
// User: Abranner     Date: 8/26/03    Time: 6:24p
// Updated in $/Neuroshare/nsClassifier
// Adjustments after merging.
// 
// *****************  Version 38  *****************
// User: Abranner     Date: 8/26/03    Time: 5:59p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 37  *****************
// User: Awang        Date: 8/25/03    Time: 1:39p
// Updated in $/Neuroshare/nsClassifier
// Renamed MainFramePCA
// 
// *****************  Version 36  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 35  *****************
// User: Awang        Date: 8/18/03    Time: 11:44a
// Updated in $/Neuroshare/nsClassifier
// Added Sorted Units information display and view
// 
// *****************  Version 34  *****************
// User: Awang        Date: 8/12/03    Time: 10:47a
// Updated in $/Neuroshare/nsClassifier
// CViewPCA has its own mainframe CPCAMainFrame
// 
// *****************  Version 33  *****************
// User: Awang        Date: 8/05/03    Time: 2:06p
// Updated in $/Neuroshare/nsClassifier
// Re-orgainized DocTemplates
// Added views for KMeans and Manual clustering options
// 
// *****************  Version 32  *****************
// User: Awang        Date: 6/30/03    Time: 3:50p
// Updated in $/Neuroshare/nsClassifier
// Toolbars, EnityInfo View and menu options added
// 
// *****************  Version 31  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// *****************  Version 30  *****************
// User: Awang        Date: 6/10/03    Time: 4:40p
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 28  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 27  *****************
// User: Awang        Date: 5/01/03    Time: 1:38p
// Updated in $/Neuroshare/nsClassifier
// Added ViewPCA stuff
// 
// *****************  Version 26  *****************
// User: Abranner     Date: 4/29/03    Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Added a view for Entity Infos
// 
// *****************  Version 25  *****************
// User: Abranner     Date: 4/28/03    Time: 5:28p
// Updated in $/Neuroshare/nsClassifier
// Added one more option to align peaks.
// 
// *****************  Version 24  *****************
// User: Awang        Date: 4/28/03    Time: 12:33p
// Updated in $/Neuroshare/nsClassifier
// Changed include header to DisplaySpike.h
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 4/25/03    Time: 9:30a
// Updated in $/Neuroshare/nsClassifier
// Check in before changing all kinds of things to help. Not all help is
// functional here.
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 4/24/03    Time: 10:14a
// Updated in $/Neuroshare/nsClassifier
// Added GetAppPath() and GetAppPathName()
// 
// *****************  Version 21  *****************
// User: Almut        Date: 4/24/03    Time: 9:39a
// Updated in $/Neuroshare/nsClassifier
// More changes to html help stuff. I also added the GetAppDir function to
// the app.
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 4/24/03    Time: 9:20a
// Updated in $/Neuroshare/nsClassifier
// Added the doc template for the Library Details window
// 
// *****************  Version 19  *****************
// User: Kkorver      Date: 4/23/03    Time: 11:32a
// Updated in $/Neuroshare/nsClassifier
// Removed references to unneeded files
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 4/23/03    Time: 10:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed the files FilesInUseView to ViewFilesInUse and
// WaveformsView to ViewWaveforms
// 
// *****************  Version 17  *****************
// User: Kkorver      Date: 4/22/03    Time: 2:02p
// Updated in $/Neuroshare/nsClassifier
// Major changes...we no longer use MDI, but rather a SDI with lots of
// windows open at the same time
// 
// *****************  Version 16  *****************
// User: Kkorver      Date: 4/22/03    Time: 11:09a
// Updated in $/Neuroshare/nsClassifier
// Use the new FileVersion class to obtain the version information
// 
// *****************  Version 15  *****************
// User: Almut        Date: 4/21/03    Time: 5:09p
// Updated in $/Neuroshare/nsClassifier
// Changed class names and the size of the views for (options pop and
// align).
// 
// *****************  Version 14  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 4/11/03    Time: 12:12p
// Updated in $/Neuroshare/nsClassifier
// Renamed constants to match the convention
// 
// *****************  Version 12  *****************
// User: Angela       Date: 4/11/03    Time: 11:31a
// Updated in $/Neuroshare/nsClassifier
// Add OnFileNew()
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 4/11/03    Time: 10:47a
// Updated in $/Neuroshare/nsClassifier
// Added test to see that the libaries exist
// 
// *****************  Version 10  *****************
// User: Angela       Date: 4/11/03    Time: 10:24a
// Updated in $/Neuroshare/nsClassifier
// added AboutDlg to waveform views menu bar
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:19p
// Updated in $/Neuroshare/nsClassifier
// Renamed CWaveformsView to CViewWaveforms
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 4/10/03    Time: 10:20a
// Updated in $/Neuroshare/nsClassifier
// Remove unnecessary deletes. They were causing a GPF
// 
// *****************  Version 7  *****************
// User: Angela       Date: 4/10/03    Time: 9:40a
// Updated in $/Neuroshare/nsClassifier
// show different file menu for waveform view
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 4/09/03    Time: 1:54p
// Updated in $/Neuroshare/nsClassifier
// Renamed CFilesInUse to CViewFilesInUse
// 
// *****************  Version 5  *****************
// User: Angela       Date: 4/09/03    Time: 1:33p
// Updated in $/Neuroshare/nsClassifier
// Added 2nd MDIDocTemplate
// make waveforms view appear
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/25/03    Time: 1:42p
// Updated in $/Neuroshare/nsClassifier
// Added popup menu choice to insert data files
// 
// *****************  Version 3  *****************
// User: Kirk         Date: 3/25/03    Time: 11:31a
// Updated in $/Neuroshare/nsClassifier
// Removed unnecessary include
// 
// *****************  Version 2  *****************
// User: Kirk         Date: 3/25/03    Time: 11:24a
// Updated in $/Neuroshare/nsClassifier
// Changed from CNsClassifierView to FilesInUse
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "FileVersion.h"
#include "PowerNAP.h"

#include "MainFrm.h"
#include "DocPowerNAP.h"

#include "NsLibraryImpMgr.h"
#include "ViewLibDetails.h"
#include "DisplaySpike.h"
#include "ViewFilesInUse.h"
#include "ViewWaveforms.h"
#include "ViewEntInfo.h"
#include "ViewPCA.h"
#include "ViewOptUnitSelection.h"
#include "ViewRaster.h"
#include "Splash.h"
#include "MainFramePCA.h"
#include "MainFrameWaveforms.h"
#include "MainFrameRaster.h"
#include "ViewRaster.h"

#include "ViewSortedInfo.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAppPowerNAP

BEGIN_MESSAGE_MAP(CAppPowerNAP, CWinApp)
    //{{AFX_MSG_MAP(CAppPowerNAP)
    ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
    ON_COMMAND(ID_FILE_NEW, OnFileNew)
    //}}AFX_MSG_MAP
    // Standard file based document commands
    ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAppPowerNAP construction

CAppPowerNAP::CAppPowerNAP()
{

}


CAppPowerNAP::~CAppPowerNAP()
{

}

/////////////////////////////////////////////////////////////////////////////
// The one and only CAppPowerNAP object

CAppPowerNAP theApp;

/////////////////////////////////////////////////////////////////////////////
// CAppPowerNAP initialization

BOOL CAppPowerNAP::InitInstance()
{
	// CG: The following block was added by the Splash Screen component.
	{
		CCommandLineInfo cmdInfo;

        ParseCommandLine(cmdInfo);

        CSplashWnd::EnableSplashScreen(cmdInfo.m_bShowSplash);
	}

    // Standard initialization
    // If you are not using these features and wish to reduce the size
    //  of your final executable, you should remove from the following
    //  the specific initialization routines you do not need.

#ifdef _AFXDLL
    Enable3dControls();         // Call this when using MFC in a shared DLL
#else
    Enable3dControlsStatic();   // Call this when linking to MFC statically
#endif

    NsLibraryImpMgr::CreateMgr(GetAppPath());

    // Warn the user if there is no way to look at any data
    if (NsLibraryImpMgr::GetMgr().GetNumOfLibrariesAvailable() == 0)
    {
        CString msg;
        msg  = "Error\n\n";
        msg += "There are no Neuroshare DLLs to be found.\n";
        msg += "Consequently, you will NOT be able to view any data.\n\n";

        msg += "Do you want to continue anyway?";

        if (IDNO == AfxMessageBox(msg, MB_ICONEXCLAMATION | MB_YESNO | MB_DEFBUTTON2, 0))
            return false;
    }

    
    // Change the registry key under which our settings are stored.
    // TODO: You should modify this string to be something appropriate
    // such as the name of your company or organization.
    SetRegistryKey(_T("Neuroshare\\Tools Suite"));

    LoadStdProfileSettings();  // Load standard INI file options (including MRU)


    // Register the application's document templates.  Document templates
    //  serve as the connection between documents, frame windows and views.
    ///////////////////////////////////////////////////////////////////////////////////    
    // Main views of the data
    
    // FileInUse 
    m_pFilesInUseTemplate = new CSingleDocTemplate(
        IDR_FILESINUSE_TMPL,                // Menu resource
        RUNTIME_CLASS(CDocPowerNAP),        // document class
        RUNTIME_CLASS(CMainFrame),          // frame class
        RUNTIME_CLASS(CViewFilesInUse));    // view class
    // By adding the template, we don't have to worry about the delete later on. It 
    // is done for us
    AddDocTemplate(m_pFilesInUseTemplate);

    // ViewWaveforms
    m_pWaveformsTemplate = new CSingleDocTemplate(
        IDR_WAVEFORMSVIEW_TMPL,             // Menu resource
        RUNTIME_CLASS(CDocPowerNAP),        // document class
        RUNTIME_CLASS(CMainFrameWaveforms), // frame class
        RUNTIME_CLASS(CViewWaveforms));     // view class
    AddDocTemplate(m_pWaveformsTemplate);

    // ViewPCA
    m_pViewPCATemplate = new CSingleDocTemplate(
        IDR_VIEWPCA_TMPL,
        RUNTIME_CLASS(CDocPowerNAP),            // document class
        RUNTIME_CLASS(CMainFramePCA),           // frame class
        RUNTIME_CLASS(CViewPCA));               // view class
    AddDocTemplate(m_pViewPCATemplate);

    // ViewSortedInfo
    m_pViewSortedTemplate = new CSingleDocTemplate(
        IDR_VIEWSORTED_TMPL,
        RUNTIME_CLASS(CDocPowerNAP),            // document class
        RUNTIME_CLASS(CMainFrame),              // frame class
        RUNTIME_CLASS(CViewSortedInfo));        // view class
    AddDocTemplate(m_pViewSortedTemplate);
    
    // ViewRaster
	m_pViewRasterTemplate = new CSingleDocTemplate(
		IDR_VIEWRASTER_TMPL,
		RUNTIME_CLASS(CDocPowerNAP),		    // document class
		RUNTIME_CLASS(CMainFrameRaster),		// frame class
		RUNTIME_CLASS(CViewRaster));		    // view class
	AddDocTemplate(m_pViewRasterTemplate);

    ///////////////////////////////////////////////////////////////////////////////////    
    // Informational views about the DLL library, entity information   
    
    // Library information
    m_pTemplateLibDetails = new CSingleDocTemplate(
        IDR_VIEWLIBDETAILS_TMPL,
        RUNTIME_CLASS(CDocPowerNAP),            // document class
        RUNTIME_CLASS(CMainFrame),              // frame class
        RUNTIME_CLASS(CViewLibDetails));        // view class
    AddDocTemplate(m_pTemplateLibDetails);

    // Selected entity information
    m_pEntInfoTemplate = new CSingleDocTemplate(
        IDR_MAINFRAME,                      // Menu resource
        RUNTIME_CLASS(CDocPowerNAP),        // document class
        RUNTIME_CLASS(CMainFrame),          // frame class
        RUNTIME_CLASS(CViewEntInfo));       // view class
    AddDocTemplate(m_pEntInfoTemplate);
    

    ///////////////////////////////////////////////////////////////////////////////////    
     
    // Parse command line for standard shell commands, DDE, file open
    CCommandLineInfo cmdInfo;
    ParseCommandLine(cmdInfo);

    // Dispatch commands specified on the command line
    if (!ProcessShellCommand(cmdInfo))
        return FALSE;

    return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CDlgAbout dialog used for App About

class CDlgAbout : public CDialog
{
public:
    CDlgAbout();

// Dialog Data
    //{{AFX_DATA(CDlgAbout)
    enum { IDD = IDD_ABOUTBOX };
    CString m_strVersion;
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CDlgAbout)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    //{{AFX_MSG(CDlgAbout)
        // No message handlers
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

CDlgAbout::CDlgAbout() : CDialog(CDlgAbout::IDD)
{
    //{{AFX_DATA_INIT(CDlgAbout)
    m_strVersion = _T("");
    //}}AFX_DATA_INIT
}

void CDlgAbout::DoDataExchange(CDataExchange* pDX)
{
    // Write in the version number
    if (!pDX->m_bSaveAndValidate)
    {
        // Get and store the current version.
        FileVersion icVer;

        CString strVersion;
        icVer.GetVersionString(strVersion);

        m_strVersion.Format("PowerNAP v%s", strVersion);
    
    }   CDialog::DoDataExchange(pDX);

    //{{AFX_DATA_MAP(CDlgAbout)
    DDX_Text(pDX, IDC_ABT_LBL_VERSION, m_strVersion);
    //}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CDlgAbout, CDialog)
    //{{AFX_MSG_MAP(CDlgAbout)
        // No message handlers
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CAppPowerNAP::OnAppAbout()
{
    CDlgAbout aboutDlg;
    aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CAppPowerNAP message handlers


int CAppPowerNAP::ExitInstance() 
{
    // Cleanup the Library Manager
    NsLibraryImpMgr::DestroyMgr();

	// Close any open HTML Help windows
	HtmlHelp(NULL, NULL, HH_CLOSE_ALL, 0) ;

    // !!!! DON'T DELETE THE TEMPLATES !!!!
    // The templates are automatically deleted for us by the CList

    return CWinApp::ExitInstance();
}



CSingleDocTemplate * CAppPowerNAP::GetWaveformsTemplate()
{
    return m_pWaveformsTemplate;
}

CSingleDocTemplate * CAppPowerNAP::GetLibDetailsTemplate()
{
    return m_pTemplateLibDetails;
}

CSingleDocTemplate * CAppPowerNAP::GetEntInfoTemplate()
{
    return m_pEntInfoTemplate;
}

CSingleDocTemplate * CAppPowerNAP::GetViewPCATemplate()
{
    return m_pViewPCATemplate;
}

CSingleDocTemplate * CAppPowerNAP::GetSortedInfoTemplate()
{
    return m_pViewSortedTemplate;
}

CSingleDocTemplate * CAppPowerNAP::GetViewRasterTemplate()
{
    return m_pViewRasterTemplate;
}


void CAppPowerNAP::OnFileNew() 
{
    CWinApp::OnFileNew();
}


// Get the fully qualified path to the directory where the app is running
CString CAppPowerNAP::GetAppPath()
{
    CString szTemp(GetAppPathName());

    szTemp = szTemp.Left(szTemp.ReverseFind('\\'));
    return szTemp;
}

// Get the fully qualifed name of the EXE running
CString CAppPowerNAP::GetAppPathName()
{
    CString szTemp = __targv[0];
    return szTemp;
}



BOOL CAppPowerNAP::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following lines were added by the Splash Screen component.
	if (CSplashWnd::PreTranslateAppMessage(pMsg))
		return TRUE;

	return CWinApp::PreTranslateMessage(pMsg);
}

