///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DisplayPCProj.cpp $
//
// Description   : Display PC projections
//
// Authors       : Angela Wang 
//
// $Date: 3/11/04 12:56p $
//
// $History: DisplayPCProj.cpp $
// 
// *****************  Version 26  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:56p
// Updated in $/Neuroshare/PowerNAP
// Fixed problem with "noise out" drawing
// 
// *****************  Version 25  *****************
// User: Kkorver      Date: 3/09/04    Time: 5:10p
// Updated in $/Neuroshare/PowerNAP
// Removed dead code
// "Noise Out" selection now works
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 3/05/04    Time: 3:01p
// Updated in $/Neuroshare/PowerNAP
// Fixed colors and added a spinner control.
// 
// *****************  Version 23  *****************
// User: Abranner     Date: 3/05/04    Time: 11:15a
// Updated in $/Neuroshare/PowerNAP
// Changed to use char array for unit labels. Also added automated cursor
// changing.
// 
// *****************  Version 22  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:30p
// Updated in $/Neuroshare/PowerNAP
// Now use GetActiveSegment()
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 2/19/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// PCA now uses floating point math for the conversion. The result is that
// BIG and small numbers will now be displayed properly
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 10/31/03   Time: 5:32p
// Updated in $/Neuroshare/PowerNAP
// Removed blank spaces.
// 
// *****************  Version 19  *****************
// User: Abranner     Date: 10/24/03   Time: 5:17p
// Updated in $/Neuroshare/PowerNAP
// Fixed 'Divide by Zero' problem in XfmWorldToScreen().
// 
// *****************  Version 18  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:43a
// Updated in $/Neuroshare/PowerNAP
// Overhaul of the PCA display
// 
// *****************  Version 17  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 10/16/03   Time: 1:18p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 15  *****************
// User: Abranner     Date: 9/09/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 14  *****************
// User: Awang        Date: 8/29/03    Time: 11:10a
// Updated in $/Neuroshare/nsClassifier
// Added "All" option to KMeans options for using all PC coord in
// calculation
// 
// *****************  Version 13  *****************
// User: Awang        Date: 8/28/03    Time: 11:40a
// Updated in $/Neuroshare/nsClassifier
// Cleared the polylist when units of points have been defined.
// 
// *****************  Version 12  *****************
// User: Awang        Date: 8/27/03    Time: 12:18p
// Updated in $/Neuroshare/nsClassifier
// Fixed DefInsidePt and DefOutsidePt to define pt in the region for all
// x, y, z dimensions
// 
// *****************  Version 11  *****************
// User: Awang        Date: 8/26/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Fixed NOISEUNIT_OUT region
// 
// *****************  Version 10  *****************
// User: Awang        Date: 8/25/03    Time: 10:53a
// Updated in $/Neuroshare/nsClassifier
// Draw larger centroid markers
// 
// *****************  Version 9  *****************
// User: Awang        Date: 8/05/03    Time: 1:55p
// Updated in $/Neuroshare/nsClassifier
// Reduce to 1 PC projection display
// Created CPCAMainFrame to deal with toolbar with custom controls
// 
// *****************  Version 7  *****************
// User: Awang        Date: 6/18/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 6  *****************
// User: Awang        Date: 6/11/03    Time: 9:05a
// Updated in $/Neuroshare/nsClassifier
// Fixed Cluster ID for NOISEUNIT
// 
// *****************  Version 5  *****************
// User: Awang        Date: 6/10/03    Time: 4:20p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing.
// Implemented selection and highlighting of one waveform point.
// 
// *****************  Version 4  *****************
// User: Awang        Date: 5/30/03    Time: 2:58p
// Updated in $/Neuroshare/nsClassifier
// Testing cursor loading......
// 
// *****************  Version 3  *****************
// User: Awang        Date: 5/30/03    Time: 11:54a
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 2  *****************
// User: Awang        Date: 5/06/03    Time: 9:56a
// Updated in $/Neuroshare/nsClassifier
// In progress work on drawing clusters
// 
// *****************  Version 1  *****************
// User: Awang        Date: 4/28/03    Time: 12:15p
// Created in $/Neuroshare/nsClassifier
// 
// DisplayPCProj.cpp : implementation file
//

#include "stdafx.h"
#include <math.h>
#include "PowerNAP.h"
#include "Centroid.h"
#include "DisplayPCProj.h"
#include "ViewPCA.h"
#include "DisplaySpike.h"
#include "ViewWaveforms.h"
#include "CloneBitmap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Disable warning C4768
#pragma warning(disable : 4786)


/////////////////////////////////////////////////////////////////////////////
// NsPCData

NsPCData::NsPCData(NsPCData const & rhs)
{
    m_uWFIndex = rhs.m_uWFIndex;
    m_lClstrID = rhs.m_lClstrID;
    m_ptPCClient = rhs.m_ptPCClient;
}

NsPCData::~NsPCData()
{
}


NsPCData & NsPCData::operator = (NsPCData const & rhs)
{
    // Cleanup old stuff
    NsPCData::~NsPCData();
    m_uWFIndex = rhs.m_uWFIndex;
    m_lClstrID = rhs.m_lClstrID;
    m_ptPCClient = rhs.m_ptPCClient;
  
    return *this;
}


NsPCData::NsPCData(UINT32 uWFIndx, INT32 lClstrID, NsPoint3D ptData)
{
    m_uWFIndex = uWFIndx;
    m_lClstrID = lClstrID;
    m_ptPCClient.x = ptData.x;
    m_ptPCClient.y = ptData.y;
    m_ptPCClient.z = ptData.z;
}


/////////////////////////////////////////////////////////////////////////////
// CDisplayPCProj

CDisplayPCProj::CDisplayPCProj() : 
    m_pDoc(NULL),
    m_pcActiveMouse(NULL)
{
    m_icMouseRegular.SetParent(this);
    m_icMouseDrawing.SetParent(this);
    m_icMouseSelecting.SetParent(this);

    // Red pen for selecting
    m_penRed.CreatePen( PS_SOLID, 1, RED );

    // The pen we use to draw grid lines
    m_penGrid.CreatePen(PS_DOT, 1, LT_GREEN);

    m_lCurrClstr = -1;// no selected cluster  
    
    m_rectSelection = m_rectPrev = CRect(0, 0, 0, 0);
    m_lSelWfIndex = -1;
    m_bHitAPt = false;
    m_flag_mouse_inside = false;

    m_bReadyToDraw = false;  
    SwitchMouse(MSE_REGULAR);
}


CDisplayPCProj::~CDisplayPCProj()
{
}


BEGIN_MESSAGE_MAP(CDisplayPCProj, CWnd)
    //{{AFX_MSG_MAP(CDisplayPCProj)
    ON_WM_CREATE()
    ON_WM_PAINT()
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONUP()
    ON_WM_SIZE()
    ON_WM_MOUSEMOVE()
    ON_WM_SETCURSOR()
    ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
    
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CDisplayPCProj::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
    if (CWnd::OnCreate(lpCreateStruct) == -1)
        return -1;
    
    GetClientRect(&m_rectClient);
    m_nClientWidth = m_rectClient.Width();
    m_nClientHeight = m_rectClient.Height();

    // Get pointer to document
    CWnd *pWnd = GetParentFrame();
    m_pDoc = (CDocPowerNAP *)((CFrameWnd *)pWnd)->GetActiveDocument();
   
    for (int i = 1; i < UNITCOUNT; ++i)
    {
        HBITMAP hBmp;
        CCloneBitmap bmpClone;
        HCURSOR hCursor;
        hBmp = LoadBitmap(AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_CURSOR));

        if(hBmp != NULL)
        {
          bmpClone.Clone(hBmp);
          DeleteObject(hBmp);
          // change GRAY pixels to appropriate color.
          bmpClone.ChangeColor(IRGB(128, 128, 128), INVERSECOLOR(m_pDoc->m_icColorTable.dispunit[i]));

          // make icon, using WHITE color as transparent.
          hCursor = bmpClone.MakeCursor(IRGB(255, 255, 255));
        }

        m_hDrawingCursor[i] = hCursor;
    }

    // Restore default arrow cursor
    m_hArrowCursor = (HICON) LoadImage(NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_DEFAULTCOLOR);

    return 0;
}// OnCreate


// Updates call this function to repaint view
void CDisplayPCProj::OnPaint() 
{
    CPaintDC dc(this); // device context for painting
    
    dc.SetBkColor(m_pDoc->m_icColorTable.dispback);
    dc.FillRect(m_rectClient, &m_pDoc->m_wndbkBrush);
    
    // Draw the grid
    DrawAxes(dc);
   
    // Draw the labels for first display
    DrawLabels(dc, m_nXAxis, m_nYAxis);// coordinate 1 vs 2

    // Draw the data points
    DrawPCPoints(dc, m_nXAxis, m_nYAxis);

    // Draw the defined centroids
    DrawCtr(dc, m_nXAxis, m_nYAxis);

    // Draw selection rectangle
    if ((!m_rectSelection.IsRectNull()) && (m_lSelWfIndex > 0))
    {
        DrawRectSel(dc);
    }
}


// Draw the X and Y axis in the middle of display
void CDisplayPCProj::DrawAxes(CDC & rcDC)
{
    // Put the dashed pen in
    CPen * pcOldPen = rcDC.SelectObject(&m_penGrid);
    
    // Draw  1 horizontal line
    int nY = m_nClientHeight / 2;
    rcDC.MoveTo(0, nY);
    rcDC.LineTo(m_nClientWidth, nY);
    
    // Draw 1 vertical line
    int nX = m_nClientWidth / 2;
    rcDC.MoveTo(nX, 0);
    rcDC.LineTo(nX, m_nClientHeight);

    // Put the old pen back in
    rcDC.SelectObject(pcOldPen);
}



// Draw the data points to screen with the unit colors
void CDisplayPCProj::DrawPCPoints(CDC & rcDC, const int nX, const int nY)
{
    // Draw the 2D projection of the PC data points
    // nX gives the X-axis coordinate
    // nY gives the Y-axis coordinate
    
    // Check if PC data exists, if not, exit
    if (m_vPCData.empty())
        return;
    
    // Draw the points
    CPoint pnt;

    // Put ANY pen into the DC to get the "current" one
    CPen * pOldPen = rcDC.SelectObject(m_pDoc->GetBITUnitPen(UNIT_NOISE_MASK));
    
    for (PCDATALIST::iterator it = m_vPCData.begin(); it != m_vPCData.end(); ++it)
    {
        CFloatPoint val;

        rcDC.SelectObject(m_pDoc->GetBITUnitPen(it->GetClstrID()));
        
        // Draw the x and y coord of point to the DC
        if (nX == 0)
            val.x = it->GetPCPt().x;
        else if (nX == 1)
            val.x = it->GetPCPt().y;
        else if (nX == 2)
            val.x = it->GetPCPt().z;

        if (nY == 0)
            val.y = it->GetPCPt().x;
        else if (nY == 1)
            val.y = it->GetPCPt().y;
        else if (nY == 2)
            val.y = it->GetPCPt().z;


        // Scale the displayed values based on what we were told
        // ...most likely this is to fit on the screen....
        CPoint ptVal = XfmWorldToScreen(val);

        rcDC.Rectangle(ptVal.x - 1, ptVal.y - 1,
                       ptVal.x + 1, ptVal.y + 1);
    }
    // Put back old pen
    rcDC.SelectObject(&pOldPen);
}


// Write the axis labels 
void CDisplayPCProj::DrawLabels(CDC & rcDC, const int nXProj, const int nYProj)
{
    // Label axis as PC coordinates 

    // Check for valid projections
    if ((nXProj > 2) || (nXProj < 0) ||
        (nYProj > 2
        ) || (nXProj < 0))
        return;
    
    // Set font for text
    CFont font;
    CFont* pOldFont;
    const int nFontSize_Default = 90;
    
    font.CreatePointFont(nFontSize_Default,_T("MS San Serif"));
    pOldFont= rcDC.SelectObject(&font);
    rcDC.SetTextColor(LT_GREEN);

    // Label X axis -  
    CSize TextSize;
    CString strLabel;

    strLabel.Format("PC%d", nXProj + 1);
    TextSize = rcDC.GetTextExtent(strLabel);
    
    rcDC.DrawText(strLabel, -1, CRect(m_nClientWidth - TextSize.cx, (m_nClientHeight/2)-TextSize.cy,
                m_nClientWidth, m_nClientHeight/2), DT_SINGLELINE|DT_LEFT|DT_NOCLIP);
    
    // Label Y axis 
    strLabel.Format("PC%d", nYProj + 1);
    TextSize = rcDC.GetTextExtent(strLabel);
    rcDC.DrawText(strLabel, -1, CRect(m_nClientWidth/2, 0, (m_nClientWidth/2) + TextSize.cx, TextSize.cy),
                        DT_SINGLELINE|DT_LEFT|DT_NOCLIP);
    
    // Get old font
    rcDC.SelectObject(pOldFont);
}//SetLabels()


void CDisplayPCProj::OnSize(UINT nType, int cx, int cy) 
{
    CWnd::OnSize(nType, cx, cy);    

    // NOTE: OnSize automatically gets called during the setup of the control
  
    GetClientRect(m_rectClient) ;

    // Set some member variables to avoid multiple function calls
    m_nClientHeight = m_rectClient.Height() ;
    m_nClientWidth  = m_rectClient.Width() ;
}// OnSize


void CDisplayPCProj::OnLButtonDown(UINT nFlags, CPoint point) 
{
    m_pcActiveMouse->OnLButtonDown(nFlags, point);
}


void CDisplayPCProj::OnLButtonUp(UINT nFlags, CPoint point) 
{
    m_pcActiveMouse->OnLButtonUp(nFlags, point);
}


void CDisplayPCProj::OnMouseMove(UINT nFlags, CPoint point) 
{
    m_pcActiveMouse->OnMouseMove(nFlags, point);
}


// Purpose: draw the current "center" onto the display
// Inputs:
//  rcDC - the device context to draw onto
//  nXProj - which coordinate to use for the X-axis
//  nYProj - which coordinate to use for the Y-axis 
void CDisplayPCProj::DrawCtr(CDC & rcDC, const int nXProj, const int nYProj)
{
    static const int CROSS_HEIGHT = 8;

    if (m_vPCCtr.empty())
        return;
    
    // Put any-old pen in there to save the "old one"
    CPen * pOldPen = rcDC.SelectObject(&m_pDoc->m_penUnitColor[0]);

    ASSERT( nXProj <= 2);
    ASSERT( nYProj <= 2);

    int nCtrCnt = m_pDoc->m_isSortInfo.K;
    int nPCCnt = m_pDoc->m_isSortInfo.nPCCnt;
 
    
    int nCtrIdx = 1;
    for (PCDATALIST::iterator it = m_vPCCtr.begin(); it != m_vPCCtr.end(); ++it)
    {
        CFloatPoint pt;

        // Get the two projections of centroid to draw
        if (nXProj == 0)
            pt.x = it->GetPCPt().x;
        else if (nXProj == 1)
            pt.x = it->GetPCPt().y;
        else if (nXProj == 2)
            pt.x = it->GetPCPt().z;

        if (nYProj == 0)
            pt.y = it->GetPCPt().x;
        else if (nYProj == 1)
            pt.y = it->GetPCPt().y;
        else if (nYProj == 2)
            pt.y = it->GetPCPt().z;
        
        // Get the cluster color to draw points
        rcDC.SelectObject(&m_pDoc->m_penUnitColor[nCtrIdx]);
        
        // Scale the point and draw an X
        CPoint ptVal = XfmWorldToScreen(pt);
        
        rcDC.MoveTo(ptVal.x, ptVal.y - CROSS_HEIGHT);
        rcDC.LineTo(ptVal.x, ptVal.y + CROSS_HEIGHT);
        rcDC.MoveTo(ptVal.x - CROSS_HEIGHT, ptVal.y);
        rcDC.LineTo(ptVal.x + CROSS_HEIGHT, ptVal.y);

        // Increment centroid index
        nCtrIdx++;
    }
    // Replace old pen
    pOldPen = rcDC.SelectObject(pOldPen);
}


// Set cluster index currently working on
void CDisplayPCProj::SetWorkingClstr(INT32 lClusterIndex)
{
    // Set cluster definition to current unit
    m_lCurrClstr = lClusterIndex;
}//SetWorkingClstr


BOOL CDisplayPCProj::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
    if ((nHitTest == HTCLIENT) && (m_bReadyToDraw == true))
    {
       
        // Get screen coordinates
        DWORD dwPos = ::GetMessagePos();
        CPoint point(LOWORD(dwPos), HIWORD (dwPos));
        ScreenToClient(&point);
        CRect rect;
        GetClientRect(&rect);
        
        // Set cursor to drawing pencil if it is in the client area.
       ::SetCursor(((point.y < rect.Height()) && (point.x < rect.Width())) ? 
           m_hDrawingCursor[m_lCurrClstr] : (SetCursor(m_hArrowCursor)));
 
        // Cursor is set
        return TRUE;
    }

    return CWnd::OnSetCursor(pWnd, nHitTest, message);
}//OnSetCursor


// Erase the cluster polygon from the display 
void CDisplayPCProj::ErasePoly()
{
    CClientDC dc(this);
    
    if (m_lCurrClstr == NOISE_OUT)
        dc.SelectObject(m_pDoc->m_penUnitColor[NOISE]);
    else
        dc.SelectObject(m_pDoc->m_penUnitColor[m_lCurrClstr]);

    int nOldMode = dc.SetROP2(R2_XORPEN);
     
    // Go through list of polygons
    LISTOFPOINTVECTORS::iterator itPolyPt;
    for (itPolyPt = m_icPolyList[m_lCurrClstr].begin();
         itPolyPt != m_icPolyList[m_lCurrClstr].end();
         ++itPolyPt)
    {
        // Move to first point
        CPoint * ptFirst = itPolyPt->begin();
        dc.MoveTo(*ptFirst);

        for (POINTVECTOR::const_iterator itPt = itPolyPt->begin(); itPt != itPolyPt->end(); ++itPt)
        {
            dc.LineTo(*itPt);
        }
    }    
    
    // Restore  previous drawing mode    
    dc.SetROP2(nOldMode);
}//ErasePoly


// Reset the unitID of data points to original file unitID
// and display points in previous cluster colors
void CDisplayPCProj::ClearClusters(INT32 lClstr)
{
    if (!m_icPolyList[lClstr].empty())
        m_icPolyList[lClstr].clear();

   // Set flag for no drawing cursor
    m_bReadyToDraw = false; 
}


// Set the PC projection for the axis on current display
void CDisplayPCProj::SetAxis(int nXAxis, int nYAxis)
{
    m_nXAxis = nXAxis;
    m_nYAxis = nYAxis;
    Invalidate();
}


// Test if cursor has hit on a data point, if so
// circle it and highlight waveforms view of hit point.
// Inputs:
//  ptCursor - the SCREEN point to test against
bool CDisplayPCProj::HitTestPCPoint(CPoint ptCursor)
{
    // Initialize iterator for PCData
    PCDATALIST::iterator it;
    it = m_vPCData.begin();

    // Index into SEGMENTLIST
    int nWFIndex = 0;

    while ((!m_bHitAPt) && (it != m_vPCData.end()))
    {
        CFloatPoint ptData;
        ptData.x = it->GetPCPt().x;
        ptData.y = it->GetPCPt().y;

        CPoint ptScreen = XfmWorldToScreen(ptData);
     
        if (m_rectSelection.PtInRect(ptScreen))
        {
            // Save WF index
            m_lSelWfIndex = nWFIndex;
            
            // Save cursor pt position
            m_ptSelected = ptCursor;
            
            // Found first point inside
            m_bHitAPt = true;
        }

        // Increment waveform index
        ++nWFIndex;

        //Increment iterator
        ++it;
    }

    return m_bHitAPt;
}//HitTestPCPoint


// Draw a rectangle centered about Cursor point
void CDisplayPCProj::DrawRectSel(CDC & rcDC)
{
    // Choose red 
    CBrush brRed;
    brRed.CreateSolidBrush(RED);

    rcDC.FrameRect(&m_rectSelection, &brRed);
    
    // Reset selection
    m_bHitAPt = false;
}


// Remove any selection rectangle that may exist
void CDisplayPCProj::RemoveRectSel(CDC & rcDC)
{
    // Draw the old selection rect in backgroun color
    rcDC.FrameRect(&m_rectPrev, &m_pDoc->m_wndbkBrush);
    
    // Reset selection
    m_bHitAPt = false;

    // Set to null - doesn't exist anymore
    m_rectPrev = CRect(0, 0, 0, 0);
}


// High-light a selected waveform point in red
// return previously selected waveform to original clstrID
void CDisplayPCProj::HilightWF(INT32 lPrevWFIndex, INT32 lWFIndex)
{
    // Highlight the waveform point to red
    UINT32 dwRedClstr = 7;
    m_lSelWfIndex = lWFIndex;
    
    m_ptSelected.x = m_vPCData[lWFIndex].GetPCPt().x;
    m_ptSelected.y = m_vPCData[lWFIndex].GetPCPt().y;
    
    
    ChangePtColor(m_vPCData[lWFIndex].GetPCPt(), dwRedClstr);    

    // Return previously selected point to original color 
    if (lPrevWFIndex> 0)
        ChangePtColor(m_vPCData[lPrevWFIndex].GetPCPt(), m_vPCData[lPrevWFIndex].GetClstrID()); 
}


// Change the color of the point to the corresponding color
// of the cluster
void CDisplayPCProj::ChangePtColor(NsPoint3D &rptData, INT32 lClstr)
{
    CClientDC dc(this);
    
    //Select new pen color for unit
    //if clusters are defined, set unit color, otherwise use original file settings
    CPen *pOldPen;
    pOldPen = dc.SelectObject(m_pDoc->GetBITUnitPen(lClstr));
    
    CPoint pt = XfmWorldToScreen(CFloatPoint(rptData.x, rptData.y));

    // Draw the new point to the DC
    dc.Rectangle(pt.x - 1, pt.y - 1,
                 pt.x + 1, pt.y + 1);

    dc.SelectObject(&pOldPen);// classified unit color
}


// Remove selection rectangle and tell document to remove
// high-lighting of waveforms in other views
void CDisplayPCProj::ClearSelections()
{
    CClientDC dc(this);

    // remove the red selection rect
    RemoveRectSel(dc);
 
    // Un select waveform in document
    if (m_lSelWfIndex > 0)
        m_pDoc->SetUnSelWF(m_lSelWfIndex);
}


void CDisplayPCProj::UnHilightWF(INT32 lPrevWFIndex, INT32 lSelWFIndex)
{
    // Return previously selected point to original color 
    ChangePtColor(m_vPCData[lSelWFIndex].GetPCPt(), m_vPCData[lSelWFIndex].GetClstrID()); 

    //Clear selection rectangle and selection index
    m_rectSelection = CRect(0, 0, 0, 0);
    m_lSelWfIndex = -1;// no selection
}


// Purpose: Eventually, manually drawing the region will come here
//  this function will decide if a point is "inside" the drawn region.
//  if it is, it will mark it as part of the correct type
void CDisplayPCProj::DefInsidePts(UINT32 lClstr)
{
   // Notes:  points on the line are classified as outside.
    // Create a new CRgn for each polygon drawn for each cluster
    //
    CRgn rgnCluster;

    CClientDC dc(this);
   
    // Check each PC point in segmentlist
    // Index into SegmentList 
    int nWFIndex = 0;

    // Iterate through all data points on screen
    // itPt is an index into SEGMENTLIST
    PCDATALIST::iterator itPt;
    for (itPt = m_vPCData.begin(); itPt != m_vPCData.end(); ++itPt)
    {
        //Iterate through each drawn polygon region for this cluster
        // m_icPolyList contains a list of drawn polygons for each cluster
        // Find the points inside each of these and define a centroid for each 
        // polygon region.
        LISTOFPOINTVECTORS::iterator itPoly;
        int nPoly = 0;
        int nRgnIndex = 0;
       
        for (itPoly = m_icPolyList[lClstr].begin();
            itPoly != m_icPolyList[lClstr].end();
            ++itPoly)
        {
            // Create CRgn region from polygon
            CPoint * pPt = (*itPoly).begin();
            BOOL bRet = rgnCluster.CreatePolygonRgn(pPt, (*itPoly).size(), WINDING);
            
            if (bRet)
            {
                //Valid region has been created from drawn polygon
                
                // Get x  and y -axis coordinates from data point
                CFloatPoint ptData;
                if ( m_nXAxis == 0)
                    ptData.x = itPt->GetPCPt().x;
                else if (m_nXAxis == 1)
                    ptData.x = itPt->GetPCPt().y;
                else if (m_nXAxis == 2)
                    ptData.x = itPt->GetPCPt().z;

                if ( m_nYAxis == 0)
                    ptData.y = itPt->GetPCPt().x;
                else if (m_nYAxis == 1)
                    ptData.y = itPt->GetPCPt().y;
                else if (m_nYAxis == 2)
                    ptData.y = itPt->GetPCPt().z;

                CPoint ptScreen = XfmWorldToScreen(ptData);

                if (rgnCluster.PtInRegion(ptScreen))
                {
                    // The data point is INSIDE the drawn region
                    // WFIndex  
                    UINT32 uWFIndex = itPt->GetWFIndex();

                    // Change cluster ID in list of PC data points for this point
                    itPt->SetClstrID(m_pDoc->GetBITUnit(lClstr));
                    m_pDoc->GetActiveSegment()[uWFIndex].SetUnitID(m_pDoc->GetBITUnit(lClstr));
                }
                
                // Remove CRgn
                rgnCluster.DeleteObject();
            }
        }// next polygon region
        
        // Increment waveform index
        ++nWFIndex;
    }// next waveform point
}


void CDisplayPCProj::SetDrawMode(int nDrawMode)
{
    // Set flag for drawing polygons cursor
    switch(nDrawMode)
    {
    case(CLUSTERCUTTOOLS):
    case(DRAWMODE):
            SwitchMouse(MSE_DRAWING);
            m_bReadyToDraw = true;
            break;

    case(SELECTMODE):
            SwitchMouse(MSE_SELECTING);
            m_bReadyToDraw = false;
            break;

    default:
            SwitchMouse(MSE_REGULAR);
            m_bReadyToDraw = false;
            break;

    }//end switch
}


void CDisplayPCProj::MouseMoveProcessing(UINT nFlags, CPoint point)
{
    // Check for entrance of cursor
    if (!m_flag_mouse_inside)
    {
        TRACKMOUSEEVENT tme;
        tme.cbSize = sizeof(TRACKMOUSEEVENT);
        tme.dwFlags = TME_LEAVE;
        tme.hwndTrack = m_hWnd;
        
        _TrackMouseEvent(&tme);// watch for a mouse leave event
        
        // "Generate a mouse leave event"
        m_flag_mouse_inside = true;
    }
}


// Mouse is leaving display
LRESULT CDisplayPCProj::OnMouseLeave ( WPARAM wParam, LPARAM lParam )
{
    // Remove selection rectangle
    ClearSelections();

    m_flag_mouse_inside = false ;

    return TRUE ;
}


void CDisplayPCProj::DefOutsidePts(UINT32 lClstr)
{ 
    // Notes:  points on the line are classified as outside.
    // Create a new CRgn for each polygon drawn for each cluster
    CRgn rgnCluster;

    CClientDC dc(this);
   
    // Check each PC point in segmentlist
    // Index into SegmentList 
    int nWFIndex = 0;

    // Iterate through all data points on screen
    // itPt is an index into SEGMENTLIST
    
    LISTOFPOINTVECTORS::iterator itPoly;
    int nPoly = 0;
    int nRgnIndex = 0;
    
    //Iterate through each drawn polygon region for this cluster
    // m_icPolyList contains a list of drawn polygons for each cluster
    for (itPoly = m_icPolyList[lClstr].begin();
            itPoly != m_icPolyList[lClstr].end();
            ++itPoly)
    {
        // Create CRgn region from polygon
        CPoint * pPt = (*itPoly).begin();
        BOOL bRet = rgnCluster.CreatePolygonRgn(pPt, (*itPoly).size(), WINDING);
        
        if (bRet)
        {   // Valid polygon region created
            
            PCDATALIST::iterator itPt;
            for (itPt = m_vPCData.begin(); itPt != m_vPCData.end(); ++itPt)
            {
                // Find the points outside each of these polygon region.

                // Get x  and y -axis coordinates from data point
                CFloatPoint ptData;
                if ( m_nXAxis == 0)
                    ptData.x = itPt->GetPCPt().x;
                else if (m_nXAxis == 1)
                    ptData.x = itPt->GetPCPt().y;
                else if (m_nXAxis == 2)
                    ptData.x = itPt->GetPCPt().z;

                if ( m_nYAxis == 0)
                    ptData.y = itPt->GetPCPt().x;
                else if (m_nYAxis == 1)
                    ptData.y = itPt->GetPCPt().y;
                else if (m_nYAxis == 2)
                    ptData.y = itPt->GetPCPt().z;

                CPoint ptScreen = XfmWorldToScreen(ptData);
                
                if (!rgnCluster.PtInRegion(ptScreen))
                {
                    // The data point is OUTSIDE the drawn region
                    // WFIndex  
                    UINT32 uWFIndex = itPt->GetWFIndex();
                    
                    // Change cluster ID in list of PC data points for this point
                    itPt->SetClstrID(NOISE);
                    
                    // Set unit of this point in waveform list
                    m_pDoc->GetActiveSegment()[uWFIndex].SetUnitID(UNIT_NOISE_MASK);
                }
            }// next waveform point
            
            // Remove CRgn
            rgnCluster.DeleteObject(); 
        }
    }// next polygon region
}

void CDisplayPCProj::SetMaxValue(double dMaxValue)
{
    if (dMaxValue == 0.0)
        m_dMaxValue = 1.0;
    else
        m_dMaxValue = dMaxValue;
    Invalidate();
}

inline CPoint CDisplayPCProj::XfmWorldToScreen(CFloatPoint point)
{
    CPoint ptScreen;

    int nMidWidth = m_nClientWidth / 2;
    int nMidHight = m_nClientHeight / 2;
    
    ptScreen.x = point.x * nMidWidth / m_dMaxValue;
    ptScreen.x += nMidWidth;
    
    ptScreen.y = point.y * nMidHight / m_dMaxValue;
    ptScreen.y = - ptScreen.y;    // y axis is reversed
    ptScreen.y += nMidHight;

    return ptScreen;
}

inline CDisplayPCProj::CFloatPoint CDisplayPCProj::XfmScreenToWorld(CPoint point)
{
    CFloatPoint ptWorld;

    int nMidWidth = m_nClientWidth / 2;
    int nMidHight = m_nClientHeight / 2;
    
    ptWorld.x = point.x - nMidWidth;
    ptWorld.x = ptWorld.x * m_dMaxValue / nMidWidth;
    
    ptWorld.y = point.y - nMidHight;
    ptWorld.y = - ptWorld.y;    // y axis is reversed
    ptWorld.y = ptWorld.y * m_dMaxValue / nMidHight;

    return ptWorld;
}


void CDisplayPCProj::SwitchMouse(MouseType enMouse)
{
    switch (enMouse)
    {
    case MSE_REGULAR:
        m_pcActiveMouse = &m_icMouseRegular;
        break;

    case MSE_DRAWING:
        m_pcActiveMouse = &m_icMouseDrawing;
        break;

    case MSE_SELECTING:
        m_pcActiveMouse = &m_icMouseSelecting;
        break;
    } 
}

void CDisplayPCProj::MouseDrawing::OnLButtonDown(UINT nFlags, CPoint point)
{
    CDPCPState::OnLButtonDown(nFlags, point);

    // Capture the mouse until button up.
    m_pParent->SetCapture();

    // Pressing the mouse button in the view window starts a new stroke
    // Save the first point of this stroke
    
    m_pParent->m_ptFirst = point;
    
    // A new stroke creates a new array of pts and initiates cluster definition
    m_pParent->m_vOnePolyPts.clear();
    m_pParent->m_vOnePolyPts.push_back(point);
    
    // Serves as the MoveTo() anchor point for the
    // LineTo() the next point, as the user drags the
    // mouse.      
    m_pParent->m_ptPrev = point;   
}

void CDisplayPCProj::MouseDrawing::OnLButtonUp(UINT nFlags, CPoint point)
{
    CDPCPState::OnLButtonUp(nFlags, point);

    // Save the last point
    m_pParent->m_ptPrev = point;

    // Add polygon to list of polygons for this cluster
    m_pParent->m_icPolyList[m_pParent->m_lCurrClstr].push_back(m_pParent->m_vOnePolyPts);

    // Now polygon is drawn. Find the points that lie within the polygon
    // region defined by the points m_icPolyArray.  g_avInPtIndexArray is now
    // filled by this function.
    if (m_pParent->m_lCurrClstr <= NOISE)
        m_pParent->DefInsidePts(m_pParent->m_lCurrClstr); 
    else if (m_pParent->m_lCurrClstr == NOISE_OUT)
        m_pParent->DefOutsidePts(m_pParent->m_lCurrClstr); 

    // Release the mouse capture established at the beginning of the mouse drag.
    ::ReleaseCapture();

    // Once points inside are defined, remove the polygon circle from view
    // and clear polygon list
    m_pParent->ErasePoly();
    m_pParent->m_icPolyList[m_pParent->m_lCurrClstr].clear();    

    // Get this view to update
    m_pParent->m_pDoc->UpdateAllViews(NULL);
}

void CDisplayPCProj::MouseDrawing::OnDragging(UINT nFlags, CPoint point)
{
    m_pParent->MouseMoveProcessing(nFlags, point);
    
    // Mouse movement is interesting 
    // only if the user is currently drawing a new stroke by dragging
    // the captured mouse.

    CClientDC dc(m_pParent);
    CPen * pOldPen;

    // Ready to draw polygons
    // Select pen color for currently selected unit
    // Get color of polygon
    
    // Set the selected pen color    
    if (m_pParent->m_lCurrClstr == NOISE + 1)
        pOldPen = dc.SelectObject(&m_pParent->m_pDoc->m_penUnitColor[NOISE]); // Outside NOISE pts
    else 
        pOldPen = dc.SelectObject(&m_pParent->m_pDoc->m_penUnitColor[m_pParent->m_lCurrClstr]);
    
    dc.MoveTo(m_pParent->m_ptPrev);
    dc.LineTo(point);
    dc.SelectObject(pOldPen);
    
    m_pParent->m_ptPrev = point;
    
    // Save point to polygon's array of points
    m_pParent->m_vOnePolyPts.push_back(point);
}


// Author & Date:       Kirk Korver     23 Oct 2003
// Purpose: I'm in the state of trying to "select" a point, and someone clicked
// Inputs: See CWnd::OnLButtonDown()
void CDisplayPCProj::MouseSelecting::OnLButtonDown(UINT nFlags, CPoint point)
{
    CDPCPState::OnLButtonDown(nFlags, point);
    static const int SELECTION_TARGET = 3;

    CClientDC dc(m_pParent);

    // Remove previous selection...it was saved last pass through (look below)
    if (!m_pParent->m_rectPrev.IsRectNull())
        m_pParent->RemoveRectSel(dc);


    // Create new rect around cursor point +/-3
    m_pParent->m_rectSelection = CRect(point.x - SELECTION_TARGET, point.y - SELECTION_TARGET,
                                       point.x + SELECTION_TARGET, point.y + SELECTION_TARGET);
    
    // Test to see if a data point was hit
    // if hit, draw a selection rectangle
    // and notify waveforms view a waveform was selected
    if (m_pParent->HitTestPCPoint(point))
    {
        // Change color of waveform in document
        m_pParent->m_pDoc->SetSelWF(m_pParent->m_lSelWfIndex);
        
        // Save so can erase later
        m_pParent->m_rectPrev = m_pParent->m_rectSelection;
        
        // Draw selection rect
        m_pParent->DrawRectSel(dc);
    }
}



