///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageWf.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 1/30/04 3:54p $
//
// $History: PropPageWf.cpp $
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 1/30/04    Time: 3:54p
// Updated in $/Neuroshare/PowerNAP
// Streamlined data transfer.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "PropPageWf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageWf property page

IMPLEMENT_DYNCREATE(CPropPageWf, CPropertyPage)

CPropPageWf::CPropPageWf() : CPropertyPage(CPropPageWf::IDD)
{
	//{{AFX_DATA_INIT(CPropPageWf)
	m_nAlignPt = 0;
	m_nNumPt = 0;
	//}}AFX_DATA_INIT
}

CPropPageWf::~CPropPageWf()
{
}

void CPropPageWf::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageWf)
	DDX_Control(pDX, IDC_EDT_NumPt, m_lblNumPt);
	DDX_Control(pDX, IDC_LBL_NumPtTxt, m_lblNumPtTxt);
	DDX_Control(pDX, IDC_RDO_NEGPEAKS, m_rdoNegPeaks);
	DDX_Control(pDX, IDC_RDO_POSPEAKS, m_rdoPosPeaks);
	DDX_Control(pDX, IDC_RDO_ALLPEAKS, m_rdoAllPeaks);
	DDX_Control(pDX, IDC_LBL_AlgnPt, m_lblAlignPt);
	DDX_Control(pDX, IDC_RDO_MEANPEAK, m_rdoMeanPeak);
	DDX_Control(pDX, IDC_RDO_ALIGNPOINT, m_rdoAlignPt);
	DDX_Control(pDX, IDC_EDT_AlignPt, m_AlignPt);
	DDX_Text(pDX, IDC_EDT_AlignPt, m_nAlignPt);
	DDX_Text(pDX, IDC_EDT_NumPt, m_nNumPt);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageWf, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageWf)
	ON_BN_CLICKED(IDC_RDO_ALIGNPOINT, OnRdoAlignpoint)
	ON_BN_CLICKED(IDC_RDO_MEANPEAK, OnRdoMeanpeak)
	ON_EN_CHANGE(IDC_EDT_AlignPt, OnChange)
	ON_BN_CLICKED(IDC_RDO_ALLPEAKS, OnRdoAllPeaks)
	ON_BN_CLICKED(IDC_RDO_NEGPEAKS, OnRdoNegPeaks)
	ON_BN_CLICKED(IDC_RDO_POSPEAKS, OnRdoPosPeaks)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageWf message handlers


BOOL CPropPageWf::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
    if (m_bAlignMeanPt)
    {
        m_rdoMeanPeak.SetCheck(1);
	    m_AlignPt.EnableWindow(false);
        m_lblAlignPt.EnableWindow(false);
        m_lblNumPtTxt.EnableWindow(false);
        m_lblNumPt.EnableWindow(false);
    }
    else
    {
        m_rdoAlignPt.SetCheck(1);
	    m_AlignPt.EnableWindow();
        m_lblAlignPt.EnableWindow();
        m_lblNumPtTxt.EnableWindow();
        m_lblNumPt.EnableWindow();
    }

    if (m_nWhatPeaks == 0) // all peaks
        m_rdoAllPeaks.SetCheck(1);
    else if (m_nWhatPeaks == 1) // pos peaks
        m_rdoPosPeaks.SetCheck(1);
    else if (m_nWhatPeaks == 2) // neg peaks
        m_rdoNegPeaks.SetCheck(1);
    else
        m_rdoAllPeaks.SetCheck(1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropPageWf::OnChange()
{
    SetModified(true);
}

void CPropPageWf::OnRdoAlignpoint() 
{
    m_bAlignMeanPt = false;

	m_AlignPt.EnableWindow();

    // Make labels invisible
    m_lblAlignPt.EnableWindow();
    m_lblNumPtTxt.EnableWindow();
    m_lblNumPt.EnableWindow();

    OnChange();
}

void CPropPageWf::OnRdoMeanpeak() 
{
    m_bAlignMeanPt = true;

	m_AlignPt.EnableWindow(false);

    // Make labels invisible
    m_lblAlignPt.EnableWindow(false);
    m_lblNumPtTxt.EnableWindow(false);
    m_lblNumPt.EnableWindow(false);

    OnChange();
}

void CPropPageWf::OnRdoAllPeaks() 
{
    m_nWhatPeaks = 0;

    OnChange();
}

void CPropPageWf::OnRdoPosPeaks() 
{
	m_nWhatPeaks = 1;

    OnChange();
}

void CPropPageWf::OnRdoNegPeaks() 
{
	m_nWhatPeaks = 2;

    OnChange();
}
