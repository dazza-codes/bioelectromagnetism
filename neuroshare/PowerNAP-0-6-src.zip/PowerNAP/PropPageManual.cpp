///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageManual.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 3/09/04 5:10p $
//
// $History: PropPageManual.cpp $
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 3/09/04    Time: 5:10p
// Updated in $/Neuroshare/PowerNAP
// Use the MU_LABEL constants
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 3/05/04    Time: 3:01p
// Updated in $/Neuroshare/PowerNAP
// Fixed colors and added a spinner control.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 3/05/04    Time: 1:32p
// Updated in $/Neuroshare/PowerNAP
// First version of new buttons.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 2/19/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// PCA now uses floating point math for the conversion. The result is that
// BIG and small numbers will now be displayed properly
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 5:53p
// Updated in $/Neuroshare/PowerNAP
// First working implementation of this class. Was also renamed to
// CPropPageManual.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "powernap.h"
#include "ns_common.h"
#include "DocPowerNAP.h"
#include "PropPageManual.h"
#include "ViewPCA.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageManual property page

IMPLEMENT_DYNCREATE(CPropPageManual, CPropertyPage)

CPropPageManual::CPropPageManual()
    : CPropertyPage(CPropPageManual::IDD)
{
    m_pDoc = NULL;
    m_pViewPCA = NULL;

    m_nSelUnit = 0;
    m_bDrawing = false;

	//{{AFX_DATA_INIT(CPropPageManual)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPageManual::~CPropPageManual()
{
}

void CPropPageManual::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageManual)
	DDX_Control(pDX, IDC_SPN_UNIT, m_icSpinUnit);
	DDX_Control(pDX, IDC_CBO_UNIT, m_icCboUnits);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageManual, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageManual)
	ON_BN_CLICKED(IDC_MAN_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_BTN_PEN, OnBtnPen)
	ON_CBN_SELCHANGE(IDC_CBO_UNIT, OnSelchangeCboUnit)
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageManual message handlers

BOOL CPropPageManual::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
    // Put picture on button
    CButton * pBtn = (CButton *) GetDlgItem(IDC_BTN_PEN);
    HICON hIco = AfxGetApp()->LoadIcon(IDI_PEN);
    pBtn->SetIcon(hIco);

    for (int i = 0; i < ARRAY_SIZE(MU_LABEL); ++i)
        m_icCboUnits.AddString(MU_LABEL[i]);

    m_icCboUnits.SelectString(-1, MU_LABEL[MS_UNIT1]);
    m_nSelUnit = m_icCboUnits.GetCurSel() + 1;

    m_icSpinUnit.SetRange(0, ARRAY_SIZE(MU_LABEL) - 1);
    m_icSpinUnit.SetPos(m_nSelUnit - 1);

    return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropPageManual::OnRemove() 
{
/*    // Remove selected unit	
    // Recolor the points of the currently selected cluster
    // to original unit definition
    if (m_nSelUnit )
    {
        if (m_nSelUnit == NOISE_OUT)
        {        
            // Reset current cluster in PCDATALIST to original file UNITID
            m_pViewPCA->SetOrigUnitDef(NOISE);   
        
            // Clear the old cluster information
            m_pViewPCA->m_icDisplayPC1.ClearClusters(NOISE_OUT);
        }
        else
        {
            // Reset current cluster in PCDATALIST to original file UNITID
            m_pViewPCA->SetOrigUnitDef(m_nSelUnit);   
        
            // Clear the old cluster information
            m_pViewPCA->m_icDisplayPC1.ClearClusters(m_nSelUnit);
        }


        // Clear currently selected cluster
        m_nSelUnit = 0;
        
        // Update views
        GetDocument()->UpdateAllViews(NULL);
    }  */
}

void CPropPageManual::OnBtnPen() 
{
    m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
    m_bDrawing = true;
}

void CPropPageManual::OnSelchangeCboUnit() 
{
    m_nSelUnit = m_icCboUnits.GetCurSel() + 1;
    m_icSpinUnit.SetPos(m_nSelUnit - 1);

    if (m_bDrawing)
        m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
}

void CPropPageManual::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
    m_nSelUnit = nPos + 1;
    m_icCboUnits.SetCurSel(m_nSelUnit - 1);

    if (m_bDrawing)
        m_pViewPCA->SetDisplayMode(CLUSTERCUTTOOLS, m_nSelUnit);
	
	CPropertyPage::OnHScroll(nSBCode, nPos, pScrollBar);
}
