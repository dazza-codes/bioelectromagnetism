///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: Visitor.h $
//
// Description   : interface for the Visitor classes.
//
// Authors       : Kirk Korver
//
// $Date: 5/30/03 12:01p $
//
// $History: Visitor.h $
// 
// *****************  Version 2  *****************
// User: Awang        Date: 5/30/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 4/01/03    Time: 1:55p
// Created in $/Neuroshare/nsClassifier
// This defines the visitor and visited base classes
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef VISITOR_H_INCLUDED
#define VISITOR_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// The part that is a Visitor
class BaseVisitor
{
public:
    virtual ~BaseVisitor() {}
};


template <class T, typename R>
class Visitor
{
public:
    typedef R ReturnType; // Available for clients
    virtual ReturnType Visit(T&) = 0;
};



// The part that the visitor visits. We call it "visitable"
template <typename R>
class BaseVisitable
{
public:
    typedef R ReturnType;
    virtual ~BaseVisitable() {}
    virtual ReturnType Accept(BaseVisitor&) = 0;
protected:
    template <class T>
    static ReturnType AcceptImpl(T & visited, BaseVisitor & guest)
    {
        // Apply the Acyclic Visitor
        Visitor<T, R>* p = dynamic_cast< Visitor<T, R>* > (&guest);
         
        if (p)
        {
            return p->Visit(visited);
        }
        return ReturnType();
    }
};



// Every derived visitable class needs one of these!
#define DEFINE_VISITABLE()                         \
    virtual ReturnType Accept(BaseVisitor & guest) \
        { return AcceptImpl(*this, guest); }





///////////////////////////////////////////////////
// This is an example of what it would look like
//
// class MyData : public BaseVisitable <bool>
// {
// public:
//    DEFINE_VISITABLE();
// };
//
//
// class VisitorAlgorithm :
//     public BaseVisitor,                  // required
//     public Visitor<MyData, bool>         // One for each type of data
// {
// public:
//     bool Visit(MyData & data)
//     {
//         ... the magic of this algorithm ...
//     }
// };
///////////////////////////////////////////////////




#endif // include guard