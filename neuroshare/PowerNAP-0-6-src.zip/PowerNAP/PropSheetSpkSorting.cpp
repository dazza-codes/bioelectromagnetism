///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropSheetSpkSorting.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 3/05/04 11:15a $
//
// $History: PropSheetSpkSorting.cpp $
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 3/05/04    Time: 11:15a
// Updated in $/Neuroshare/PowerNAP
// Changed to use char array for unit labels. Also added automated cursor
// changing.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 1/30/04    Time: 12:08p
// Updated in $/Neuroshare/PowerNAP
// Fixed initialization problem.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 1/26/04    Time: 4:28p
// Updated in $/Neuroshare/PowerNAP
// Fixed problem with shutdown sequence.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 1/26/04    Time: 4:00p
// Updated in $/Neuroshare/PowerNAP
// Made calling and updating the PropSheetSpkSorting easier.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 1/26/04    Time: 3:51p
// Updated in $/Neuroshare/PowerNAP
// Property sheet will now update by itself when ViewPCA is killed. Safer
// this way and less knowledge needed to implement.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 6:05p
// Updated in $/Neuroshare/PowerNAP
// First working version of the spike sorting property sheets.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "powernap.h"
#include "PropSheetSpkSorting.h"
#include "DocPowerNAP.h"
#include "ViewPCA.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropSheetSpkSorting

IMPLEMENT_DYNAMIC(CPropSheetSpkSorting, CPropertySheet)

CPropSheetSpkSorting::CPropSheetSpkSorting(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
    m_pDoc = NULL;
    m_pViewPCA = NULL;

    AddPage(&m_icPropPageShy);
    AddPage(&m_icPropPageKMeans);
    AddPage(&m_icPropPageManual);
}

CPropSheetSpkSorting::CPropSheetSpkSorting(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
    m_pDoc = NULL;
    m_pViewPCA = NULL;

    AddPage(&m_icPropPageShy);
    AddPage(&m_icPropPageKMeans);
    AddPage(&m_icPropPageManual);
}

CPropSheetSpkSorting::~CPropSheetSpkSorting()
{
}


BEGIN_MESSAGE_MAP(CPropSheetSpkSorting, CPropertySheet)
	//{{AFX_MSG_MAP(CPropSheetSpkSorting)
	ON_WM_CLOSE()
	ON_WM_ACTIVATE()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropSheetSpkSorting message handlers

BOOL CPropSheetSpkSorting::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
    CWnd *pWnd = GetDlgItem(IDHELP);
    pWnd->ShowWindow(false);

    // Pass the document pointer on to the pages
    m_icPropPageShy.m_pDoc = m_pDoc;
    m_icPropPageKMeans.m_pDoc = m_pDoc;
    m_icPropPageManual.m_pDoc = m_pDoc;

    UpdateSheet(true);

	return bResult;
}

void CPropSheetSpkSorting::OnClose() 
{
    // If ViewPCA is still there, set default display mode
    if (m_pViewPCA)
    {
        m_pViewPCA->SetDisplayMode(DEFAULT, -1);

        // Release the Sort btn on toolbar
        ((CMainFramePCA *) m_pViewPCA->GetParentFrame())->ReleaseSortBtn();

        // Clear the previous opened options view pointer
        ((CMainFramePCA *) m_pViewPCA->GetParentFrame())->ClearPrevSort();
    } 
	
	CPropertySheet::OnClose();
}


// Author & Date:   Almut Branner   26 Jan 2004
// Purpose: This makes sure we aren't showing options that are not available
//          for the currently open views
void CPropSheetSpkSorting::UpdateSheet(bool bInitialize)
{
    CViewPCA * pViewPCA = m_pDoc->GetViewPCAPtr();

    if (m_pViewPCA != pViewPCA)
    {
        m_pViewPCA = pViewPCA;
        m_icPropPageManual.m_pViewPCA = pViewPCA;
    }
    else if (!bInitialize)  // Done for speed reasons
        return;
	
    if ((!m_pViewPCA) && (GetPageCount() == 3) && (&m_icPropPageManual))
        RemovePage(&m_icPropPageManual);
    else if ((m_pViewPCA) && (GetPageCount() == 2) && (&m_icPropPageManual))
        AddPage(&m_icPropPageManual);
}

void CPropSheetSpkSorting::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
    UpdateSheet(false);
	
	CPropertySheet::OnActivate(nState, pWndOther, bMinimized);
}

void CPropSheetSpkSorting::OnMouseMove(UINT nFlags, CPoint point) 
{
    UpdateSheet(false);
	
	CPropertySheet::OnMouseMove(nFlags, point);
}
