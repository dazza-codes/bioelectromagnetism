///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DlgAdvancedOpen.cpp $
//
// Description   : definition of the FilesInUseView class 
//
// Authors       : Kirk Korver
//
// $Date: 10/21/03 2:43p $
//
// $History: DlgAdvancedOpen.cpp $
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 5/12/03    Time: 11:11a
// Updated in $/Neuroshare/nsClassifier
// First functional version of a data + dll query
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DlgAdvancedOpen.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAdvancedOpen dialog


CDlgAdvancedOpen::CDlgAdvancedOpen(CWnd* pParent /*=NULL*/)
    : CDialog(CDlgAdvancedOpen::IDD, pParent)
{
    //{{AFX_DATA_INIT(CDlgAdvancedOpen)
    m_strDataFilename = _T("");
    m_strDllFilename = _T("");
    //}}AFX_DATA_INIT
}


void CDlgAdvancedOpen::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CDlgAdvancedOpen)
    DDX_Text(pDX, IDC_AO_DATAFILE, m_strDataFilename);
    DDV_CustomValidate(pDX, m_strDataFilename);         // Put DDV right after DDX to set focus on error

    DDX_Text(pDX, IDC_AO_DLL, m_strDllFilename);
    DDV_CustomValidate(pDX, m_strDllFilename);          // Put DDV right after DDX to set focus on error
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAdvancedOpen, CDialog)
    //{{AFX_MSG_MAP(CDlgAdvancedOpen)
    ON_BN_CLICKED(IDC_AO_BROWSE_DATA, OnBrowseData)
    ON_BN_CLICKED(IDC_AO_BROWSE_DLL, OnBrowseDll)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAdvancedOpen message handlers

void CDlgAdvancedOpen::OnBrowseData() 
{
    // prepare to prompt
    CFileDialog icFileDlg
    (
        TRUE,                                           // TRUE = file open 
        NULL,                                           // Default Extension - we use filters
        NULL,                                           // Filename - let them choose
        OFN_FILEMUSTEXIST,                              // flags - file must exist and hide read only
        "All Files (*.*)|*.*||",// File extensions
        this                                            
    );

    if (icFileDlg.DoModal() == IDOK)    // if cancel was not pressed
        SetDlgItemText(IDC_AO_DATAFILE, icFileDlg.GetPathName());
}

void CDlgAdvancedOpen::OnBrowseDll() 
{
    // prepare to prompt
    CFileDialog icFileDlg
    (
        TRUE,                                           // TRUE = file open 
        NULL,                                           // Default Extension - we use filters
        NULL,                                           // Filename - let them choose
        OFN_FILEMUSTEXIST,                              // flags - file must exist and hide read only
        "Dll Files (*.dll)|*.dll|All Files (*.*)|*.*||",// File extensions
        this
    );

    if (icFileDlg.DoModal() == IDOK)    // if cancel was not pressed
        SetDlgItemText(IDC_AO_DLL, icFileDlg.GetPathName());
}

void CDlgAdvancedOpen::DDV_CustomValidate(CDataExchange * pDX, const CString & strFile)
{
    // In this case, we only care about the validation when the window closes
    if (pDX->m_bSaveAndValidate)
    {
        if (strFile.GetLength() == 0)
        {
            AfxMessageBox("You must enter a valid filename", MB_OK | MB_ICONERROR);
            pDX->Fail();
        }
    }
}
