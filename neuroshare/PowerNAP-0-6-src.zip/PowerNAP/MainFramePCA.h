///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFramePCA.h $
//
// Description   : interface of the CMainFramePCA class
//
// Authors       : 
//
// $Date: 10/31/03 6:03p $
//
// $History: MainFramePCA.h $
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 10/31/03   Time: 6:03p
// Updated in $/Neuroshare/PowerNAP
// Changed toolbars, removed combo box for spike sorting, and how that is
// called.
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:44a
// Updated in $/Neuroshare/PowerNAP
// Bug Fix: Switching from Manual-Mode to T-Distribution-Mode would cause
// an exception
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 7  *****************
// User: Awang        Date: 8/28/03    Time: 9:19a
// Updated in $/Neuroshare/nsClassifier
// Set status bar messages remain the same for OnIdle message
// 
// *****************  Version 6  *****************
// User: Awang        Date: 8/27/03    Time: 12:13p
// Updated in $/Neuroshare/nsClassifier
// Clears centroids from a previous sort
// 
// *****************  Version 5  *****************
// User: Awang        Date: 8/27/03    Time: 10:17a
// Updated in $/Neuroshare/nsClassifier
// Fixed - when mainframe closes, the options views also close without
// assertions
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/25/03    Time: 1:36p
// Updated in $/Neuroshare/nsClassifier
// Re-worked toolbar so buttons are all shown in toolbar resource
// 
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MAINFRAMEPCA_H_INCLUDED
#define MAINFRAMEPCA_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDocPowerNAP;

/////////////////////////////////////////////////////////////////////////////
// CMainFramePCA frame

class CMainFramePCA : public CFrameWnd
{
	DECLARE_DYNCREATE(CMainFramePCA)
protected:
	CMainFramePCA();           // protected constructor used by dynamic creation

// Attributes
public:
    CComboBox m_cboBoxX;
    CComboBox m_cboBoxY;
    CComboBox m_cboSortMeth;

    CButton * m_pBtn;

    CStatic m_textXAxis;
    CStatic m_textYAxis;

    int m_nXAxis;
    int m_nYAxis;

    CStatusBar  m_wndStatusBar;
    CString     m_szStatusBarString;

    // Operations
public:
    void StatusBarMessage(LPCTSTR fmt);
	void ClearPrevSort(void);
	CToolBar    m_wndToolBar;
    CButton     * m_pBtnSort;

	int                 m_nSortMethod;
	long                m_lCurrCluster;
    
    bool CreateXAxisCombo();
    bool CreateYAxisCombo();
    bool CreateXAxisTextBox();
    bool CreateYAxisTextBox();

    void ReleaseSortBtn();

// Overrides
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);

    // ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFramePCA)
	protected:
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
    BOOL m_bProgCreated;
    
    bool m_bHiliteBtnDown;
    bool m_bSortBtnDown;
    bool m_bManOptBtnDown;

    CProgressCtrl       m_wndProgBar;
    CDocPowerNAP        * m_pDoc;

    void InitToolbar();

	virtual ~CMainFramePCA();

	// Generated message map functions
	//{{AFX_MSG(CMainFramePCA)
    afx_msg LRESULT OnSetMessageString(WPARAM wParam, LPARAM lParam);
	afx_msg void OnUpdateViewStatusbar(CCmdUI* pCmdUI); 
	afx_msg void OnViewStatusbar(); 
	afx_msg void OnUpdateViewToolbar(CCmdUI* pCmdUI); 
	afx_msg void OnViewToolbar(); 
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnCboAxis();
    afx_msg void OnBtnHilite();
	afx_msg void OnBtnSort();
	afx_msg void OnUpdateBtnHilite(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBtnSort(CCmdUI* pCmdUI);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
