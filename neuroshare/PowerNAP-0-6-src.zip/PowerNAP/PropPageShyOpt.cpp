///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageShy.cpp $
//
// Description   :  
//
// Authors       : 
//
// $Date: 10/30/03 5:39p $
//
// $History: PropPageShy.cpp $
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/30/03   Time: 5:39p
// Updated in $/Neuroshare/PowerNAP
// Changed the name of the class.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 8/26/03    Time: 6:30p
// Created in $/Neuroshare/nsClassifier
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PowerNAP.h"
#include "PropPageShyOpt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageShyOpt property page

IMPLEMENT_DYNCREATE(CPropPageShyOpt, CPropertyPage)

CPropPageShyOpt::CPropPageShyOpt() : CPropertyPage(CPropPageShyOpt::IDD)
{
	//{{AFX_DATA_INIT(CPropPageShy)
	m_nPosPCA = -1;
	m_nPosPenaltyFct = -1;
	//}}AFX_DATA_INIT
}

CPropPageShyOpt::~CPropPageShyOpt()
{
}

void CPropPageShyOpt::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageShyOpt)
	DDX_CBIndex(pDX, IDC_CBO_NUMPCA, m_nPosPCA);
	DDX_CBIndex(pDX, IDC_CBO_PENALTY, m_nPosPenaltyFct);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageShyOpt, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageShyOpt)
	ON_CBN_SELCHANGE(IDC_CBO_NUMPCA, OnChange)
	ON_CBN_SELCHANGE(IDC_CBO_PENALTY, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageShyOpt message handlers


void CPropPageShyOpt::OnChange()
{
    SetModified(true);
}

