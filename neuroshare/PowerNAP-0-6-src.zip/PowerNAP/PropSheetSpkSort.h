///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropSheetSpkSort.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 2/02/04 6:17p $
//
// $History: PropSheetSpkSort.h $
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 1/30/04    Time: 3:54p
// Updated in $/Neuroshare/PowerNAP
// Streamlined data transfer.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/31/03   Time: 6:05p
// Updated in $/Neuroshare/PowerNAP
// Changed names of property pages.
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/27/03    Time: 11:21a
// Updated in $/Neuroshare/nsClassifier
// Added author in header.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 8/26/03    Time: 6:29p
// Created in $/Neuroshare/nsClassifier
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPSHEETSPKSORT_H_INCLUDED
#define PROPSHEETSPKSORT_H_INCLUDED

#include "PropPageShyOpt.h"
#include "PropPageKMeansOpt.h"

class CDocPowerNAP;     // forware declare to avoid #include "DocPowerNAP.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPropSheetSpkSort : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropSheetSpkSort)

// Construction
public:
	CPropSheetSpkSort(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0, 
                      CDocPowerNAP* pDoc = NULL);
	CPropSheetSpkSort(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0, 
                      CDocPowerNAP* pDoc = NULL);

// Attributes
public:
    CPropPageShyOpt m_icPropPageShyOpt;
    CPropPageKMeansOpt m_icPropPageKMeansOpt;
    CDocPowerNAP* m_pDoc;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropSheetSpkSort)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropSheetSpkSort();

	// Generated message map functions
protected:
	void UpdateDoc();
	void InitializePropPages();

	//{{AFX_MSG(CPropSheetSpkSort)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
    afx_msg void OnApply ();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
