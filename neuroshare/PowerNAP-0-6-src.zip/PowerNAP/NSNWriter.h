///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NSNWriter.h $
//
// Authors       : Kirk Korver
//
// $Date: 10/21/03 2:43p $
//
// $History: NSNWriter.h $
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 9/11/03    Time: 7:05a
// Created in $/Neuroshare/nsClassifier
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef NSNWRITER_H_INCLUDED
#define NSNWRITER_H_INCLUDED


#include "nsNSNLibrary.h"


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class NSNWriter
{
public:
    NSNWriter();
    ~NSNWriter();

    bool IsOK() { return m_pNSN != 0; }

    IWriteNSN * GetIWriteNSN() { return m_pNSN; }

protected:
    IWriteNSN * m_pNSN;


    typedef  IUnKnown * (WINAPI * QUERYINTERFACE)(InterfaceTypes enType);
    QUERYINTERFACE m_pfQueryInterface;

    void LoadDLL(LPCSTR szDllName);
    void UnloadDLL();

    static HINSTANCE m_hDLL;
    static int m_nDllRefCount;
};

#endif // include guards
