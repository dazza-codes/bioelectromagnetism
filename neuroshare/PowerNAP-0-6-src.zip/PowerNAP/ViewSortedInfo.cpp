///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewSortedInfo.cpp $
//
// Authors       : Angela Wang
//
// $Date: 3/04/04 5:25p $
//
// $History: ViewSortedInfo.cpp $
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:25p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 10/21/03   Time: 4:31p
// Updated in $/Neuroshare/PowerNAP
// Moved ReplaceWindowControl() to the common area
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 10/15/03   Time: 6:06p
// Updated in $/Neuroshare/nsClassifier
// Changed unit drawing.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 2  *****************
// User: Awang        Date: 8/22/03    Time: 10:45a
// Updated in $/Neuroshare/nsClassifier
// Removed unit 6 display
// 
// *****************  Version 1  *****************
// User: Awang        Date: 8/18/03    Time: 11:38a
// Created in $/Neuroshare/nsClassifier
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// ViewSortedInfo.cpp : implementation file
//

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "DisplaySortedWf.h"
#include "ViewSortedInfo.h"
#include "ns_common.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewSortedInfo

IMPLEMENT_DYNCREATE(CViewSortedInfo, CFormView)

CViewSortedInfo::CViewSortedInfo()
	: CFormView(CViewSortedInfo::IDD)
{
	//{{AFX_DATA_INIT(CViewSortedInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CViewSortedInfo::~CViewSortedInfo()
{
}

void CViewSortedInfo::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewSortedInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewSortedInfo, CFormView)
	//{{AFX_MSG_MAP(CViewSortedInfo)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewSortedInfo diagnostics

#ifdef _DEBUG
void CViewSortedInfo::AssertValid() const
{
	CFormView::AssertValid();
}

void CViewSortedInfo::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CDocPowerNAP* CViewSortedInfo::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}



#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CViewSortedInfo message handlers

void CViewSortedInfo::OnInitialUpdate() 
{

    // Create the graphical window for SPIKE EVENT WAVEFORM DISPLAY
    // Spike Events Display
    ReplaceWindowControl(*this, m_graphwnd_Clstr1, IDC_SORTEDINFO_FRM1);
    ReplaceWindowControl(*this, m_graphwnd_Clstr2, IDC_SORTEDINFO_FRM2);
    ReplaceWindowControl(*this, m_graphwnd_Clstr3, IDC_SORTEDINFO_FRM3);
    ReplaceWindowControl(*this, m_graphwnd_Clstr4, IDC_SORTEDINFO_FRM4);
    ReplaceWindowControl(*this, m_graphwnd_Clstr5, IDC_SORTEDINFO_FRM5);
    
     
    CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
    // Size frame to fit the formview
    m_pMainFrame = static_cast<CMainFrame *>(GetParentFrame());
    m_pMainFrame->RecalcLayout();
    ResizeParentToFit(FALSE);

    // Set the title
    m_pMainFrame->SetTitle("Sorted Units Information");
	
}

int CViewSortedInfo::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    // Set the title
    CMainFrame * pFrame = static_cast<CMainFrame *>(GetParentFrame());
    pFrame->SetTitle("Waveforms");
   
	pFrame->EnableDocking(CBRS_ALIGN_ANY);
	
	return 0;
}

void CViewSortedInfo::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
    
    if ((!m_graphwnd_Clstr1) && (!m_graphwnd_Clstr2) && (!m_graphwnd_Clstr3) &&
        (!m_graphwnd_Clstr4) && (!m_graphwnd_Clstr5) )
        return;
    

    //Clear display
    
    CDocPowerNAP *pDocument = GetDocument();
	
    // Calculate min and max of waveform values
    pDocument->SetMinMaxWfValues();

    // Getting info from first selected data file
    FileInfo & isInfo = *pDocument->m_icFileVector[0];

    m_dwCurrEntity = pDocument->GetActiveEntity();

    pDocument->GetSegmentInfo(isInfo.icFile, m_dwCurrEntity, m_isSegInfo);
    pDocument->GetSegmentSourceInfo(isInfo.icFile, m_dwCurrEntity, 0, m_isSegSourceInfo);


    // Set the min and max waveform values in all the template displays
    m_graphwnd_Clstr1.SetCurrEntity(m_dwCurrEntity);
    m_graphwnd_Clstr1.SetAxisScaling(pDocument->m_dMaxWfVal, m_isSegInfo.dwMaxSampleCount);
    m_graphwnd_Clstr1.SetDrawUnit(UNIT_1_MASK);// set cluster to 1
    m_graphwnd_Clstr1.Invalidate();

    m_graphwnd_Clstr2.SetCurrEntity(m_dwCurrEntity);
    m_graphwnd_Clstr2.SetAxisScaling(pDocument->m_dMaxWfVal, m_isSegInfo.dwMaxSampleCount);
    m_graphwnd_Clstr2.SetDrawUnit(UNIT_2_MASK);// set cluster to 2
    m_graphwnd_Clstr2.Invalidate();

    
    m_graphwnd_Clstr3.SetCurrEntity(m_dwCurrEntity);
    m_graphwnd_Clstr3.SetAxisScaling(pDocument->m_dMaxWfVal, m_isSegInfo.dwMaxSampleCount);
    m_graphwnd_Clstr3.SetDrawUnit(UNIT_3_MASK);// set cluster to 3
    m_graphwnd_Clstr3.Invalidate();

    m_graphwnd_Clstr4.SetCurrEntity(m_dwCurrEntity);
    m_graphwnd_Clstr4.SetAxisScaling(pDocument->m_dMaxWfVal, m_isSegInfo.dwMaxSampleCount);
    m_graphwnd_Clstr4.SetDrawUnit(UNIT_4_MASK);// set cluster to 4
    m_graphwnd_Clstr4.Invalidate();

    m_graphwnd_Clstr5.SetCurrEntity(m_dwCurrEntity);
    m_graphwnd_Clstr5.SetAxisScaling(pDocument->m_dMaxWfVal, m_isSegInfo.dwMaxSampleCount);
    m_graphwnd_Clstr5.SetDrawUnit(UNIT_5_MASK);// set cluster to 5
    m_graphwnd_Clstr5.Invalidate();


}

