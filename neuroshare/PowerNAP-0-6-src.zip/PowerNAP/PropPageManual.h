///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageManual.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 3/05/04 3:01p $
//
// $History: PropPageManual.h $
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 3/05/04    Time: 3:01p
// Updated in $/Neuroshare/PowerNAP
// Fixed colors and added a spinner control.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 3/05/04    Time: 1:32p
// Updated in $/Neuroshare/PowerNAP
// First version of new buttons.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 5:53p
// Updated in $/Neuroshare/PowerNAP
// First working implementation of this class. Was also renamed to
// CPropPageManual.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPPAGEMANUAL_H_INCLUDED
#define PROPPAGEMANUAL_H_INCLUDED

class CDocPowerNAP;     // forward declare to avoid #include "DocPowerNAP.h"
class CViewPCA;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropPageManual dialog

class CPropPageManual : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageManual)

// Construction
public:
	CPropPageManual();
	~CPropPageManual();

    CDocPowerNAP* m_pDoc;
	CViewPCA* m_pViewPCA;

// Dialog Data
	//{{AFX_DATA(CPropPageManual)
	enum { IDD = IDD_PROPPAGE_MANUAL };
	CSpinButtonCtrl	m_icSpinUnit;
	CComboBox	m_icCboUnits;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPageManual)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
    int m_nSelUnit;
    bool m_bDrawing;

    // Generated message map functions
	//{{AFX_MSG(CPropPageManual)
	virtual BOOL OnInitDialog();
	afx_msg void OnRemove();
	afx_msg void OnBtnPen();
	afx_msg void OnSelchangeCboUnit();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
