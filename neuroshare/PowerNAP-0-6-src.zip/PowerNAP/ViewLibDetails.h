///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewLibDetails.h $
//
// Description   : implementation of the CViewLibDetails class 
//
// Authors       : Kirk Korver
//
// $Date: 2/19/04 4:07p $
//
// $History: ViewLibDetails.h $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 2/19/04    Time: 4:07p
// Updated in $/Neuroshare/PowerNAP
// There is an 'ADD' button on the library details. This button will set
// the correct settings in the registry so the DLL will be remembered
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 4/28/03    Time: 12:34p
// Updated in $/Neuroshare/nsClassifier
// Added capability to turn tooltips off.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 4/25/03    Time: 5:39p
// Updated in $/Neuroshare/nsClassifier
// Implemented tooltip support for all windows (hovering shows message).
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 4/24/03    Time: 1:16p
// Updated in $/Neuroshare/nsClassifier
// Added member variables for the list's
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 4/24/03    Time: 9:19a
// Created in $/Neuroshare/nsClassifier
// Initial checkin of CViewLibDetails window
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#if !defined(VIEWLIBDETAILS_H_INCLUDED)
#define VIEWLIBDETAILS_H_INCLUDED


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ViewLibDetails.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CViewLibDetails form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CViewLibDetails : public CFormView
{
protected:
	CViewLibDetails();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewLibDetails)

// Form Data
public:
	//{{AFX_DATA(CViewLibDetails)
	enum { IDD = IDD_DLG_DLL_INFO };
	CListBox	m_lstFileDescriptions;
	CListBox	m_lstLibraries;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewLibDetails)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CViewLibDetails();

    // Purpose: populate the library list
    // Inputs:
    //  The global list in the NSLibImpManager
    void PopulateLibrary();

    // Purpose: display all of the details about this library on the screen
    // Inputs:
    //  szDLLPathName - fully qualifed name of the DLL to read fom
    void ShowDetails(LPCSTR szDLLPathName);

    // Given a number, get a month string
    // Inputs:
    //  nMonth - 0 = January and 11 = December
    // Outputs:
    //  String corresponding to that month
    LPCSTR GetMonth(DWORD nMonth);



#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CViewLibDetails)
	afx_msg void OnClose();
	afx_msg void OnLstLibrariesSelchange();
	afx_msg void OnBtnAdd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CToolTipCtrl m_tool;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIEWLIBDETAILS_H__F5CF899B_3D87_4CB5_BB84_81A649E54049__INCLUDED_)
