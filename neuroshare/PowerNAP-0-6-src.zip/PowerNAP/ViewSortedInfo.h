///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewSortedInfo.h $
//
// Description   :  
//
// Authors       : Angela Wang
//
// $Date: 10/21/03 4:31p $
//
// $History: ViewSortedInfo.h $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/21/03   Time: 4:31p
// Updated in $/Neuroshare/PowerNAP
// Moved ReplaceWindowControl() to the common area
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 9/02/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Added Neuroshare headers.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////


#ifndef VIEWSORTEDINFO_H_INCLUDED
#define VIEWSORTEDINFO_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ViewSortedInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CViewSortedInfo form view


#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "DisplaySortedWf.h"
#include "nsAPItypes.h"	// Added by ClassView

class CViewSortedInfo : public CFormView
{
protected:
	CViewSortedInfo();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewSortedInfo)

// Form Data
public:
	//{{AFX_DATA(CViewSortedInfo)
	enum { IDD = IDD_VIEWSORTEDINFO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
    CMainFrame * m_pMainFrame;
    ns_SEGMENTINFO  m_isSegInfo;
    ns_SEGSOURCEINFO m_isSegSourceInfo;

// Operations
public:
	uint32 m_dwCurrEntity;
	CDocPowerNAP * GetDocument(void);
	CDisplaySortedWf m_graphwnd_Clstr1;
	CDisplaySortedWf m_graphwnd_Clstr2;
	CDisplaySortedWf m_graphwnd_Clstr3;
	CDisplaySortedWf m_graphwnd_Clstr4;
	CDisplaySortedWf m_graphwnd_Clstr5;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewSortedInfo)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CViewSortedInfo();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CViewSortedInfo)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#ifndef _DEBUG  // debug version in .cpp
inline CDocPowerNAP* CViewSortedInfo::GetDocument()
   { return (CDocPowerNAP*)m_pDocument; }
#endif


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
