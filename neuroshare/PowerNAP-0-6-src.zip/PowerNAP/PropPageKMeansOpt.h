///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageKMeansOpt.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 10/31/03 6:04p $
//
// $History: PropPageKMeansOpt.h $
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 10/31/03   Time: 6:04p
// Updated in $/Neuroshare/PowerNAP
// Fixed labels.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 10/31/03   Time: 5:36p
// Updated in $/Neuroshare/PowerNAP
// Changed to CPropPageKMeansOpt.
// 
// *****************  Version 5  *****************
// User: Awang        Date: 8/29/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// ComboBox select for "All" now occurs in DoDataExchange();
// 
// *****************  Version 4  *****************
// User: Awang        Date: 8/29/03    Time: 11:10a
// Updated in $/Neuroshare/nsClassifier
// Added "All" option to KMeans options for using all PC coord in
// calculation
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/27/03    Time: 11:22a
// Updated in $/Neuroshare/nsClassifier
// Added author in header.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPPAGEKMEANSOPT_H_INCLUDED
#define PROPPAGEKMEANSOPT_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropPageKMeansOpt dialog

class CPropPageKMeansOpt : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageKMeansOpt)

// Construction
public:
	CPropPageKMeansOpt();
	~CPropPageKMeansOpt();

	int	m_nNumIter;
	int	m_nNumPCA;

// Dialog Data
	//{{AFX_DATA(CPropPageKMeansOpt)
	enum { IDD = IDD_PROPPAGE_KMEANS_OPT };
	CComboBox	m_cboNumPCA;
	CComboBox	m_cboNumIter;
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPageKMeansOpt)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPageKMeansOpt)
	afx_msg void OnChange();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // Include guard
