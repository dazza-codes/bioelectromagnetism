///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPageShy.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 10/31/03 6:05p $
//
// $History: PropPageShy.h $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 6:05p
// Updated in $/Neuroshare/PowerNAP
// First working version of the spike sorting property sheets.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPPAGESHY_H_INCLUDED
#define PROPPAGESHY_H_INCLUDED

class CDocPowerNAP;     // forward declare to avoid #include "DocPowerNAP.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropPageShy dialog

class CPropPageShy : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageShy)

// Construction
public:
	CPropPageShy();
	~CPropPageShy();

    CDocPowerNAP* m_pDoc;

// Dialog Data
	//{{AFX_DATA(CPropPageShy)
	enum { IDD = IDD_PROPPAGE_SHY };
		// NOTE: the ClassWizard will add data members here
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropPageShy)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPropPageShy)
	afx_msg void OnBtnSort();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
