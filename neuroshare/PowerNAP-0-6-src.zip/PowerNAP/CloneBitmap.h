///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2004  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Kirk Korver
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  kkorver@cyberkineticsinc.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: CloneBitmap.h $
//
// Description   : This class allows you to convert a bitmap into a icon or cursor and recolor
//                 one of the colors. Got this class from CodeGuru and modified it.
//
// Authors       : Almut Branner
//
// $Date: 3/05/04 11:14a $
//
// $History: CloneBitmap.h $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 3/05/04    Time: 11:14a
// Updated in $/Neuroshare/PowerNAP
// Cursors now have the right hotspot.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 3/05/04    Time: 9:15a
// Created in $/Neuroshare/PowerNAP
// Class to convert a bitmap into a cursor or icon.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#ifndef AFX_CLONEBITMAP_H_INCLUDED
#define AFX_CLONEBITMAP_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define IRGB(r,g,b)			((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
#define INVERSECOLOR(x)		((COLORREF)(x&0xFF00)|((x&0xFF)<<16)|((x&0xFF0000)>>16))

class CCloneBitmap : public CBitmap  
{
public:
	COLORREF *m_lpData;
	HICON MakeIcon(COLORREF clrTransparent);
    HCURSOR MakeCursor(COLORREF clrTransparent);
    ICONINFO GetIconInfo(COLORREF clrTransparent);
	int ChangeColor(COLORREF clrOld, COLORREF clrNew);
	int Clone(HBITMAP hSrc);
	CCloneBitmap();
	virtual ~CCloneBitmap();
};

#endif // include guard
