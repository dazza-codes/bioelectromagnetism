///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFrameWaveforms.cpp $
//
// Description   : interface of the CMainFrameWaveforms class
//
// Authors       : Almut Branner
//
// $Date: 3/09/04 5:11p $
//
// $History: MainFrameWaveforms.cpp $
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 3/09/04    Time: 5:11p
// Updated in $/Neuroshare/PowerNAP
// Make use of WU_LABEL constants
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 3/05/04    Time: 11:15a
// Updated in $/Neuroshare/PowerNAP
// Changed to use char array for unit labels. Also added automated cursor
// changing.
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 2/10/04    Time: 10:16a
// Updated in $/Neuroshare/PowerNAP
// Added additional units to combo box.
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 10/31/03   Time: 6:03p
// Updated in $/Neuroshare/PowerNAP
// Changed toolbars, removed combo box for spike sorting, and how that is
// called.
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 10/29/03   Time: 9:55a
// Updated in $/Neuroshare/PowerNAP
// Removed setting the title, now done in string table.
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 9/12/03    Time: 1:41p
// Updated in $/Neuroshare/nsClassifier
// Added author in title.
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 8/29/03    Time: 2:16p
// Updated in $/Neuroshare/nsClassifier
// Sort button is now working but not sticky.
// 
// *****************  Version 5  *****************
// User: Awang        Date: 8/28/03    Time: 11:16a
// Updated in $/Neuroshare/nsClassifier
// Changed "Shy" to "T distribution" in Sorting combo box
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 8/26/03    Time: 5:59p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/25/03    Time: 12:13p
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/25/03    Time: 11:02a
// Updated in $/Neuroshare/nsClassifier
// Changed some variable names to conform with coding standard. Changed
// the toolbar and some tooltips.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ns_common.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "MainFrameWaveforms.h"
#include <afxpriv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//Status Bar
static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrameWaveforms

IMPLEMENT_DYNCREATE(CMainFrameWaveforms, CFrameWnd)

CMainFrameWaveforms::CMainFrameWaveforms()
{
}

CMainFrameWaveforms::~CMainFrameWaveforms()
{
}


BEGIN_MESSAGE_MAP(CMainFrameWaveforms, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrameWaveforms)
	ON_MESSAGE(WM_SETMESSAGESTRING, OnSetMessageString)
	ON_WM_CREATE()
	ON_COMMAND(ID_WFTB_BTNSORT, OnBtnSort)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrameWaveforms message handlers


BOOL CMainFrameWaveforms::PreCreateWindow(CREATESTRUCT& cs) 
{
//    cs.style &= ~(WS_MINIMIZEBOX | WS_MAXIMIZEBOX);
    cs.dwExStyle |= WS_EX_CONTEXTHELP;

    if( !CFrameWnd::PreCreateWindow(cs) )
        return FALSE;

    return TRUE;
}


int CMainFrameWaveforms::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    // Initialize toolbar
    InitToolbar();

    if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

    return 0;
}


// Author & Date:   Almut Branner     25 August 2003
// Purpose: Initialize the toolbar
void CMainFrameWaveforms::InitToolbar()
{
	if (!m_icToolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_icToolbar.LoadToolBar(IDR_WAVEFORMS_TOOLBAR))
	{
		TRACE("Failed to create toolbar\n");
		return;       // fail to create
	}

    // Let tool bar be dockable
    m_icToolbar.EnableDocking(CBRS_ALIGN_ANY);
    EnableDocking(CBRS_ALIGN_ANY);
    DockControlBar(&m_icToolbar);

    CRect rect;

    // Create combo box for unit selection
    m_icToolbar.SetButtonInfo(m_icToolbar.CommandToIndex(ID_WFTB_COMBOUNIT), 
                              ID_WFTB_COMBOUNIT, TBBS_SEPARATOR, 150);
    m_icToolbar.GetItemRect(m_icToolbar.CommandToIndex(ID_WFTB_COMBOUNIT), &rect);
	const int nDropHeight = 300;
    rect.bottom = rect.top + nDropHeight;

    m_icCboUnits.Create(WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP | CBS_DROPDOWNLIST,
        rect, &m_icToolbar, ID_WFTB_COMBOUNIT);

    // Add all units up to and including noise
    for (int i = 0; i < ARRAY_SIZE(WU_LABEL); ++i)
        m_icCboUnits.AddString(WU_LABEL[i]);

    // Change threshold button property
    m_icToolbar.SetButtonStyle(m_icToolbar.CommandToIndex(ID_WFTB_THRESHOLDBTN), 
        TBBS_CHECKBOX);

    // Create edit box for threshold voltage
	m_icToolbar.SetButtonInfo(m_icToolbar.CommandToIndex(ID_WFTB_THRESHOLDEDIT), 
                              ID_WFTB_THRESHOLDEDIT, TBBS_SEPARATOR, 50);
    m_icToolbar.GetItemRect(m_icToolbar.CommandToIndex(ID_WFTB_THRESHOLDEDIT), &rect);

    if (!m_icLblThresh.Create(WS_BORDER | WS_CHILD | WS_VISIBLE | SS_CENTER, rect, 
            &m_icToolbar, ID_WFTB_THRESHOLDEDIT))
    {
		TRACE("Failed to create edit control\n");
		return;
	}

    // Create edit box for units
	m_icToolbar.SetButtonInfo(m_icToolbar.CommandToIndex(ID_WFTB_THRESHUNITSTEXT), 
                              ID_WFTB_THRESHUNITSTEXT, TBBS_SEPARATOR, 25);
    m_icToolbar.GetItemRect(m_icToolbar.CommandToIndex(ID_WFTB_THRESHUNITSTEXT), &rect);
    rect.top += 2;
    rect.bottom -= 2;

    if (!m_icLblThreshUnits.Create(" uV ", WS_CHILD | WS_VISIBLE, rect, &m_icToolbar, ID_WFTB_THRESHUNITSTEXT))
    {
		TRACE("Failed to create edit control\n");
		return;
	}

    // Set default selections
    m_icCboUnits.SelectString(-1, WU_LABEL[WL_ALL]);

    m_icToolbar.SetHeight(32);
}


// Author & Date:   Almut Branner     25 August 2003
// Purpose: Used to only show requested title and not parent
void CMainFrameWaveforms::OnUpdateFrameTitle(BOOL bAddToTitle)
{
    // We do the "false" because we only want the "title" and
    // Not the app name as well
	CFrameWnd::OnUpdateFrameTitle(false);	
}


void CMainFrameWaveforms::OnBtnSort() 
{
    CDocPowerNAP * pDoc = (CDocPowerNAP *) GetActiveDocument();

    if (pDoc->m_icFileVector.empty())
    {
        // No data
        return;
    }
    else
    {
        // We need to have a waveform list before doing anything
        if (pDoc->m_icSegmentList.empty())
            return;
    
        pDoc->ShowPropSheetSpkSorting(TDISTRMETHOD);
    }
}

/////////////////////////////////////////////////////////////////////////////////
// Set idle status bar message
// This prevents the default on-idle message from posting whenever the menu bar
// is clicked. 
LRESULT CMainFrameWaveforms::OnSetMessageString(WPARAM wParam, LPARAM lParam)
{
	UINT nIDLast = m_nIDLastMessage;
	m_nFlags &= ~WF_NOPOPMSG;

	CWnd* pMessageBar = GetMessageBar();
	if (pMessageBar != NULL)
	{
		CString sMsg;
		CString strMessage;

		// set the message bar text
		if (lParam != 0)
		{
			ASSERT(wParam == 0);    // can't have both an ID and a string
            m_szStatusBarString = (LPCTSTR)lParam;
            sMsg = m_szStatusBarString;
		}
		else if (wParam != 0)
		{
			// map SC_CLOSE to PREVIEW_CLOSE when in print preview mode
			if (wParam == AFX_IDS_SCCLOSE && m_lpfnCloseProc != NULL)
				wParam = AFX_IDS_PREVIEW_CLOSE;

            // get message associated with the ID indicated by wParam
            if (wParam == AFX_IDS_IDLEMESSAGE)
                sMsg = m_szStatusBarString;
            else
            {
                GetMessageString(wParam, strMessage);
                sMsg = strMessage;
            }
        }
        
		pMessageBar->SetWindowText(sMsg);

		// update owner of the bar in terms of last message selected
		CFrameWnd* pFrameWnd = pMessageBar->GetParentFrame();
		if (pFrameWnd != NULL)
		{
			m_nIDLastMessage = (UINT)wParam;
			m_nIDTracking = (UINT)wParam;
		}
	}

	m_nIDLastMessage = (UINT)wParam;    	// new ID (or 0)
	m_nIDTracking = (UINT)wParam;       	// so F1 on toolbar buttons work

	return nIDLast;
}


//////////////////////////////////////////////////////////////////////////////////
// Sets the status bar message
void CMainFrameWaveforms::StatusBarMessage(TCHAR * fmt,...)
{
	TCHAR buffer[256]= _T("");

	CStatusBar* pStatus = (CStatusBar*) 
		GetDescendantWindow(AFX_IDW_STATUS_BAR);

    if (pStatus)
    {
        va_list argptr;
	    va_start(argptr, fmt);

	    _vsnprintf(buffer, 256, fmt, argptr);
	    va_end(argptr);

   	    m_szStatusBarString = buffer;
            SetMessageText((LPCTSTR) m_szStatusBarString);
    }
    return;
}
