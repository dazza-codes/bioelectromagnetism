///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropSheetSpkSorting.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 3/05/04 11:15a $
//
// $History: PropSheetSpkSorting.h $
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 3/05/04    Time: 11:15a
// Updated in $/Neuroshare/PowerNAP
// Changed to use char array for unit labels. Also added automated cursor
// changing.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 1/26/04    Time: 4:00p
// Updated in $/Neuroshare/PowerNAP
// Made calling and updating the PropSheetSpkSorting easier.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 1/26/04    Time: 3:51p
// Updated in $/Neuroshare/PowerNAP
// Property sheet will now update by itself when ViewPCA is killed. Safer
// this way and less knowledge needed to implement.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/31/03   Time: 6:05p
// Updated in $/Neuroshare/PowerNAP
// First working version of the spike sorting property sheets.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPSHEETSPKSORTING_H_INCLUDED
#define PROPSHEETSPKSORTING_H_INCLUDED

#include "PropPageShy.h"
#include "PropPageKMeans.h"
#include "PropPageManual.h"

class CDocPowerNAP;     // forward declare to avoid #include "DocPowerNAP.h"
class CViewPCA;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropSheetSpkSorting

class CPropSheetSpkSorting : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropSheetSpkSorting)

// Construction
public:
	CPropSheetSpkSorting(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CPropSheetSpkSorting(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
    CPropPageShy m_icPropPageShy;
    CPropPageKMeans m_icPropPageKMeans;
    CPropPageManual m_icPropPageManual;
    CDocPowerNAP* m_pDoc;
	CViewPCA* m_pViewPCA;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropSheetSpkSorting)
	public:
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropSheetSpkSorting();

	// Generated message map functions
protected:
	void UpdateSheet(bool bInitialize);

	//{{AFX_MSG(CPropSheetSpkSorting)
	afx_msg void OnClose();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
