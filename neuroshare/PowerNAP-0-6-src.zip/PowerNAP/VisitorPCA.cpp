///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorPCA.cpp $
//
// Description   : implementation of the VisitorPCA class.
//
// Authors       : Kirk Korver
//
// $Date: 3/03/04 4:33p $
//
// $History: VisitorPCA.cpp $
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:33p
// Updated in $/Neuroshare/PowerNAP
// Use the new GetActiveSegment()
// 
// *****************  Version 11  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:46p
// Updated in $/Neuroshare/PowerNAP
// GetWave() no longer needs the EntityID passed to it
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 7  *****************
// User: Awang        Date: 8/05/03    Time: 3:42p
// Updated in $/Neuroshare/nsClassifier
// Use same algorithm for principal component decomposition princomp and
// deleted other algorithm
// 
// *****************  Version 6  *****************
// User: Awang        Date: 6/18/03    Time: 2:30p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 5  *****************
// User: Awang        Date: 6/10/03    Time: 4:23p
// Updated in $/Neuroshare/nsClassifier
// Copy waveform data into a temp array, because DOPCA rewrites it.
// 
// *****************  Version 4  *****************
// User: Awang        Date: 5/30/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 4/10/03    Time: 9:53a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 4/10/03    Time: 9:51a
// Updated in $/Neuroshare/nsClassifier
// First implementation of the PCA algorithm
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 4/09/03    Time: 2:06p
// Created in $/Neuroshare/nsClassifier
// This is the Principle Component Analysis Algorithm classes
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>

#include "Visitor.h" 
#include "PowerNAP.h"
#include "VisitorPCA.h"
#include "DocPowerNAP.h"
#include "ViewPCA.h"


//using namespace AlgorithmPCA;

bool VisitorPCA::Visit(GenericVisitable & data)
{
    CDocPowerNAP * pDocData = data.m_pcDoc;

    const Segments & rSeg = data.m_pcDoc->GetActiveSegment();
    int n = rSeg.size();  
    
    // number of points in a waveform
    int m = data.m_pcDoc->GetNumOfPointsPerWave();  
    

    // Copy the waveforms with all data points into a matrix
    Matrix Waveforms(n, m, 0.0);
    int nIdx = 0;

    for (SEGMENTLIST::const_iterator it = rSeg.begin(); it != rSeg.end(); ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        for (UINT nPt = 0; nPt < m; ++nPt)
        {
            Waveforms(nIdx, nPt) = aicWave[nPt];
        }
        ++nIdx;
    }
    


    ///////////////////////////////////////////////////////////////////////
    // Principal component analysis
    Matrix pc(m, m, 0.0);       // The eigen-vectors used
    Matrix score(n, m, 0.0);    // The waveform data converted into PC space

    
    princomp(&pc, &score, Waveforms);
    
    
    // Store PC decomposition into array
    CViewPCA *pView = (CViewPCA *)data.m_pcView;
    
    for (nIdx = 0; nIdx < n; ++ nIdx)
    {
        for (int nPt = 0; nPt < m; ++nPt)
            pView->m_apdMyWaves[nIdx][nPt] = score(nIdx, nPt);
    }

    return true;

}

void VisitorPCA::princomp(Matrix *pc, Matrix *score, Matrix data)
{
    int m = data.rowno();
    int n = data.colno();

    Matrix avg(1, n, 0.0);

    meancols(&avg, data);

    Matrix centerx(m, n, 0.0);

    for (int i = 0; i < m; ++i)
    {
        centerx[i] = (Vector) data[i] - (Vector) avg[0];
    }

    Matrix U = centerx;
    Vector latent;  // Equivalent to W
    Matrix tempPC;

    U /= sqrt((double) m - 1);

    U.svd(tempPC, latent);  // tempPC is 48x48; latent is 48 long

    U.free();  // Since this is big and I don't need it, I am freeing the memory

    (*pc) = tempPC;
    (*score) = centerx * tempPC;
}




void VisitorPCA::meancols(Matrix *meanc, Matrix data)
{
    Matrix tempMean;

    sumcols(&tempMean, data);

    tempMean /= data.rowno();

    (*meanc) = tempMean;
}

void VisitorPCA::sumcols(Matrix *sumc, Matrix data)
{
    int rows = data.rowno();
    int cols = data.colno();
    Matrix tempSum(1, cols, 0.0);

    for (int j = 0; j < cols; ++j)
    {
        for (int i = 0; i < rows; ++i)
        {
            tempSum(0, j) = tempSum(0, j) + data(i, j);
        }
    }

    (*sumc) = tempSum;
}




/*


// This class will perform a Principle Component Analysis based on the data available
bool VisitorPCA::Visit(CDocPowerNAP & data)
{
    _CrtMemState checkPt1;
    _CrtMemCheckpoint( &checkPt1 );

    int m;      // points per wave form
    int n;      // Number of samples

    m = data.GetNumOfPointsPerWave();
    n = data.m_icSegmentList.size();

    double ** apdMyWaves = matrix(n, m);
    double ** apdMyEigenVectors = matrix(m, m);
    double * adMean = vector(m);

    FillWaves(apdMyWaves, n, m, data);
  
    DoPCA(apdMyWaves, n, m, apdMyEigenVectors, adMean);

    free_matrix(apdMyWaves, n, m);
    apdMyWaves = 0;

    free_matrix(apdMyEigenVectors, m, m);
    apdMyEigenVectors = 0;
    
    free_vector(adMean, m);
    adMean = 0;


    _CrtMemDumpAllObjectsSince( &checkPt1 );

    return true;
}

*/
// Author & Date:   Kirk Korver     10 Apr 2003
// Purpose: Fill in all of the waves from the document class
// Inputs:
//  nNumberOfWaves - number of waves in our sample set
//  nNumOfPointsPerWave - number of data points that exist in each wave form
//  rcDoc - 

/*
void VisitorPCA::FillWaves(double ** apdWaves, int nNumberOfWaves, int nNumOfPointsPerWave, CDocPowerNAP & rcDoc)
{

    // Copy the waveform into apdWaves
    int nRow = 0;
    for (SEGMENTENTITYLIST::iterator it = rcDoc.m_icSegmentList.begin(); 
                        it != rcDoc.m_icSegmentList.end(); ++it)
    {
        // Get the values for the waveform, temporarily
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        // Copy waveform points into another array, because it is overwritten 
        memcpy(apdWaves[nRow], & aicWave[0], nNumOfPointsPerWave * sizeof(double));

        DWORD dwUnitID = it->GetUnitID();
        nRow++;

    } // Next waveform

}

*/ 

#define MIN(a, b)  (((a) < (b)) ? (a) : (b)) 

void VisitorPCA::trace(Matrix mtrace)
{
    double temp;
    int maxx = MIN(mtrace.rowno(), 10);
    int maxy = MIN(mtrace.colno(), 10);


    for (int x = 0; x < maxx; ++x)
    {
        for (int y = 0; y < maxy; ++y)
        {
            temp = mtrace[x][y];
            TRACE("%4.4f  \t", temp);
        }
        TRACE("\n");
    }
}