///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2004  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Kirk Korver
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  kkorver@cyberkineticsinc.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// $Workfile: CloneBitmap.cpp $
//
// Description   : This class allows you to convert a bitmap into a icon or cursor and recolor
//                 one of the colors. Got this class from CodeGuru and modified it.
//
// Authors       : Almut Branner
//
// $Date: 3/05/04 11:14a $
//
// $History: CloneBitmap.cpp $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 3/05/04    Time: 11:14a
// Updated in $/Neuroshare/PowerNAP
// Cursors now have the right hotspot.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 3/05/04    Time: 9:15a
// Created in $/Neuroshare/PowerNAP
// Class to convert a bitmap into a cursor or icon.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CloneBitmap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCloneBitmap::CCloneBitmap()
{
	m_hObject = NULL;
	m_lpData = NULL;
}


CCloneBitmap::~CCloneBitmap()
{
}


int CCloneBitmap::Clone(HBITMAP hSrc)
{
	CBitmap bmpSrc;
	BITMAP bmp;
	if (!bmpSrc.Attach(hSrc))
		return 0;
	if (!bmpSrc.GetBitmap(&bmp))
		return 0;
	HGDIOBJ hOldSrc, hOldDest;
	if (m_hObject)
		DeleteObject();
	BITMAPINFOHEADER bmi;
	CDC dcSrc, dcDest, dcScr;
	HDC hdc;
	hdc = ::GetDC(NULL);
	dcScr.Attach(hdc);
	dcDest.CreateCompatibleDC(&dcScr);
	dcSrc.CreateCompatibleDC(&dcScr);
	bmi.biBitCount = 32;
	bmi.biClrImportant = 0;
	bmi.biClrUsed = 0;
	bmi.biCompression = BI_RGB;
	bmi.biHeight = bmp.bmHeight;
	bmi.biPlanes = 1;
	bmi.biSize = sizeof(bmi);
	bmi.biSizeImage = 0;
	bmi.biWidth = bmp.bmWidth;
	bmi.biXPelsPerMeter = 0;
	bmi.biYPelsPerMeter = 0;
	m_hObject = CreateDIBSection(dcScr, (LPBITMAPINFO)&bmi, 0, (void**)&m_lpData, NULL, DIB_RGB_COLORS);
	hOldDest = dcDest.SelectObject(*this);
	hOldSrc = dcSrc.SelectObject(bmpSrc);
	if (!dcDest.BitBlt(0, 0, bmp.bmWidth, bmp.bmHeight, &dcSrc, 0, 0, SRCCOPY))
		return 0;
	dcSrc.SelectObject(hOldSrc);
	dcDest.SelectObject(hOldDest);
	dcSrc.DeleteDC();
	dcDest.DeleteDC();
	dcScr.Detach();
	ReleaseDC(NULL, hdc);
	bmpSrc.Detach();
	return 1;
}


int CCloneBitmap::ChangeColor(COLORREF clrOld, COLORREF clrNew)
{
	if (m_lpData == NULL)
		return 0;
	BITMAP bmp;
	if (!GetBitmap(&bmp))
		return 0;
	if ( (bmp.bmHeight == 0) || (bmp.bmWidth == 0) )
		return 0;
	DWORD dwSize;
	dwSize = bmp.bmHeight*bmp.bmWidth;

	COLORREF *pData;
	pData = m_lpData;

	for (DWORD d=0; d<dwSize; d++)
	{
		if (*pData == clrOld)
			*pData = clrNew;
		pData++;
	}
	
	return 1;
}


HICON CCloneBitmap::MakeIcon(COLORREF clrTransparent)
{
    ICONINFO ii = GetIconInfo(clrTransparent);

    if ( (ii.hbmColor == NULL) || (ii.hbmMask == NULL) )
        return NULL;

	HICON hIcon = CreateIconIndirect(&ii);

    ::DeleteObject(ii.hbmMask);
	::DeleteObject(ii.hbmColor);

	return hIcon;
}


HCURSOR CCloneBitmap::MakeCursor(COLORREF clrTransparent)
{
    ICONINFO ii = GetIconInfo(clrTransparent);

    if ( (ii.hbmColor == NULL) || (ii.hbmMask == NULL) )
        return NULL;

    ii.fIcon = false;  // This is a cursor, not an icon
    ii.yHotspot = 32;  // Move the hotspot to the bottom left

	HCURSOR hCursor = CreateIconIndirect(&ii);

	::DeleteObject(ii.hbmMask);
	::DeleteObject(ii.hbmColor);

	return hCursor;
}


ICONINFO CCloneBitmap::GetIconInfo(COLORREF clrTransparent)
{
	BITMAP bmp;
	DWORD dwSize;
	COLORREF *lpData;

	ICONINFO ii;
	ii.fIcon = true;
	ii.hbmColor = NULL;
	ii.hbmMask = NULL;
	ii.xHotspot = 0;
	ii.yHotspot = 0;

	if (m_lpData == NULL)
		return ii;
	if (!GetBitmap(&bmp))
		return ii;
	if ( (bmp.bmHeight == 0) || (bmp.bmWidth == 0) )
		return ii;

	HBITMAP hMask, hColor;
	LPCOLORREF lpColorData, lpMaskData;

	BITMAPINFOHEADER bmi;
	bmi.biBitCount = 32;
	bmi.biClrImportant = 0;
	bmi.biClrUsed = 0;
	bmi.biCompression = BI_RGB;
	bmi.biHeight = 32;
	bmi.biPlanes = 1;
	bmi.biSize = sizeof(bmi);
	bmi.biSizeImage = 0;
	bmi.biWidth = 32;
	bmi.biXPelsPerMeter = 0;
	bmi.biYPelsPerMeter = 0;

	hColor = CreateDIBSection(NULL, (LPBITMAPINFO)&bmi, 0, (void**)&lpColorData, NULL, DIB_RGB_COLORS);
	if (hColor == NULL)
		return ii;

	hMask = CreateDIBSection(NULL, (LPBITMAPINFO)&bmi, 0, (void**)&lpMaskData, NULL, DIB_RGB_COLORS);
	if (hMask == NULL)
	{
		::DeleteObject(hColor);
		return ii;
	}

	dwSize = 32 * 32;

	lpData = m_lpData;

	for (DWORD d=0; d<dwSize; ++d)
	{
		if (*lpData == clrTransparent)
		{
			lpMaskData[d] = 0xFFFFFF;
			lpColorData[d] = 0;
		}
		else
		{
			lpMaskData[d] = 0;
			lpColorData[d] = *lpData;
		}
		lpData++;
	}

	ii.hbmColor = hColor;
	ii.hbmMask = hMask;

    return ii;
}