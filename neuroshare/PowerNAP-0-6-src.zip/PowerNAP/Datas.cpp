///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: Datas.cpp $
//
// Description   : implementation of the Centroid List classes
//
// Authors       : Kirk Korver
//
// $Date: 3/11/04 12:57p $
//
// $History: Datas.cpp $
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:57p
// Updated in $/Neuroshare/PowerNAP
// Added ability to delete units and reclassify units
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:28p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 3/04/04    Time: 9:38a
// Updated in $/Neuroshare/PowerNAP
// Use new GetEntity()
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:50a
// Created in $/Neuroshare/nsClassifier
// Separated the "Datas" into their own file
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ns_common.h"
#include <vector>
#include <algorithm>
#include <boost/bind.hpp>

#include "Datas.h"
#include "DocPowerNAP.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif




CString Datas::GetLabel() const
{
    return CString(Data::m_pDoc->GetEntity(m_dwEntityID).isEntityInfo.szEntityLabel);
}



// Author & Date:   Kirk Korver     Oct 17, 2003
// Purpose: Function to retrieve the ns_SEGMENTINFO structure
// Inputs:  Reference to the structure receiving the ns_SEGMENTINFO
void Segments::GetInfo(ns_SEGMENTINFO & rInfo) const
{
    ASSERT(Data::m_pDoc->m_icFileVector.empty() == false);

    NsFile & rFile = Data::m_pDoc->m_icFileVector[0]->icFile;

    rFile.GetSegmentInfo(GetEntityID(), rInfo);
}

// Author & Date:   Kirk Korver     Oct 17, 2003
// Purpose: Function to retrieve a vector of ns_SEGSOURCEINFO structures
// Inputs:  Reference to the vector receiving the ns_SEGSOURCEINFO structures
void Segments::GetInfo(VECTORSEGSOURCEINFO & rvInfo) const
{
    ASSERT(Data::m_pDoc->m_icFileVector.empty() == false);

    ns_SEGMENTINFO isSegInfo;
    NsFile & rFile = Data::m_pDoc->m_icFileVector[0]->icFile;

    rFile.GetSegmentInfo(GetEntityID(), isSegInfo);
    
    for (int nSource = 0; nSource < isSegInfo.dwSourceCount; ++nSource)
    {
        ns_SEGSOURCEINFO isSegSourceInfo;

        rFile.GetSegmentSourceInfo(GetEntityID(), nSource, isSegSourceInfo);

        rvInfo.push_back(isSegSourceInfo);
    } 
}

struct SameUnit : std::binary_function <UnitMasks, DataSegment, bool>
{
    bool operator()(UnitMasks enUnit, const DataSegment & rSeg) const
    {
        return rSeg.GetUnitID() == enUnit;
    }
};

// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: delete every segment of this unit
void Segments::DeleteTheseUnits(UnitMasks enUnit)
{
    // Remove if   Unit == enUnit
    //
    // the bind<bool> is needed to call the operator that returns bool
    m_vSegments.erase(std::remove_if(m_vSegments.begin(), m_vSegments.end(),
        boost::bind<bool>(SameUnit(), enUnit, _1)), m_vSegments.end());
}

// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: remove "holes" in the unit classifications
// Outputs:
//  TRUE means data changed; FALSE, no changes
bool Segments::CompactUnits()
{
    struct Mapping
    {
        UnitMasks enOrigMask;
        UnitMasks enNewMask;
        DWORD nCount;
    } asMap[] = 
    { // original      new (ignore)  count          // It is important
        {UNIT_1_MASK,  UNIT_1_MASK,  0},            // that these are "in order"
        {UNIT_2_MASK,  UNIT_2_MASK,  0},
        {UNIT_3_MASK,  UNIT_3_MASK,  0},
        {UNIT_4_MASK,  UNIT_4_MASK,  0},
        {UNIT_5_MASK,  UNIT_5_MASK,  0},
        {UNIT_6_MASK,  UNIT_6_MASK,  0},
        {UNIT_7_MASK,  UNIT_7_MASK,  0},
        {UNIT_8_MASK,  UNIT_8_MASK,  0},
        {UNIT_9_MASK,  UNIT_9_MASK,  0},
        {UNIT_10_MASK, UNIT_10_MASK, 0},
    };

    SEGMENTLIST::iterator it;
    int i;
    // First get the counts for each of the units
    for (it = m_vSegments.begin(); it != m_vSegments.end(); ++it)
    {
        for (i = 0; i < ARRAY_SIZE(asMap); ++i)
        {
            if (asMap[i].enOrigMask == (*it).GetUnitID())
            {
                ++asMap[i].nCount;
                break;
            }
        }
    }


    // Test to see if we have a hole, does the "compacting" as well

                // numbers   zero, if a number follows, then we have a "hole"
    enum CuState { CU_NUMBER, CU_ZERO, CU_HOLE};
    CuState enCuState = CU_NUMBER;
    for (i = 0; i < ARRAY_SIZE(asMap); ++i)
    {
        if (enCuState == CU_NUMBER)
        {
            if (asMap[i].nCount == 0)
                enCuState = CU_ZERO;
        }
        else
        {
            if (asMap[i].nCount != 0)
            {
                enCuState = CU_HOLE;
                break;
            }
        }
    }

    if (enCuState != CU_HOLE)       // no holes, no changes
        return false;


    // Now, "compact" these counts
    int nIdxLastUnit = 0;
    for (i = 0; i < ARRAY_SIZE(asMap); ++i)
    {
        if (asMap[i].nCount != 0)
        {
            asMap[i].enNewMask = asMap[nIdxLastUnit++].enOrigMask;
        }
    }

    // Now go through and make these changes happen
    for (it = m_vSegments.begin(); it != m_vSegments.end(); ++it)
    {
        for (i = 0; i < ARRAY_SIZE(asMap); ++i)
        {
            if (asMap[i].enOrigMask == (*it).GetUnitID())
            {
                (*it).SetUnitID(asMap[i].enNewMask);
                break;
            }
        }
    }
    return true;
}

// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: reclassify every "from" unit as the "to" unit
//  enFrom - the unit we are to change
//  enTo - what this unit should be classified as
void Segments::ReclassifyUnits(UnitMasks enFrom, UnitMasks enTo)
{
    for (SEGMENTLIST::iterator it = m_vSegments.begin(); it != m_vSegments.end(); ++it)
    {
        if ((*it).GetUnitID() == enFrom)
        {
            (*it).SetUnitID(enTo);
        }
    }
}

//////////////////////////////////////////////////////////////////////////////




// Author & Date:   Kirk Korver     Oct 17, 2003
// Purpose: get all of the "info" about this entity
void Analogs::GetInfo(ns_ANALOGINFO & rInfo) const
{
    ASSERT(Data::m_pDoc->m_icFileVector.empty() == false);

    NsFile & rFile = Data::m_pDoc->m_icFileVector[0]->icFile;

    rFile.GetAnalogInfo(GetEntityID(), rInfo);
}


// Author & Date:   Kirk Korver     Oct 17, 2003
// Purpose: Function to retrieve the sampling rate of this waveform
// Output:  The sampling rate in Hz.
double Analogs::GetSampleRate() const
{
    ns_ANALOGINFO isInfo;
    GetInfo(isInfo);
    return isInfo.dSampleRate;
}


//////////////////////////////////////////////////////////////////////////////

