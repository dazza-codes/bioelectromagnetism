// ViewOptUnitSelection.cpp : implementation file
//

#include "stdafx.h"
#include "PowerNAP.h"
#include "ViewOptUnitSelection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewOptUnitSelection

IMPLEMENT_DYNCREATE(CViewOptUnitSelection, CFormView)

CViewOptUnitSelection::CViewOptUnitSelection()
	: CFormView(CViewOptUnitSelection::IDD)
{
	//{{AFX_DATA_INIT(CViewOptUnitSelection)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CViewOptUnitSelection::~CViewOptUnitSelection()
{
}

void CViewOptUnitSelection::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewOptUnitSelection)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewOptUnitSelection, CFormView)
	//{{AFX_MSG_MAP(CViewOptUnitSelection)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewOptUnitSelection diagnostics

#ifdef _DEBUG
void CViewOptUnitSelection::AssertValid() const
{
	CFormView::AssertValid();
}

void CViewOptUnitSelection::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CViewOptUnitSelection message handlers
