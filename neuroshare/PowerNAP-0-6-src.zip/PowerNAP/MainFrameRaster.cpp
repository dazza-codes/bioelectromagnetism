///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFrameRaster.cpp $
//
// Description   : interface of the CMainFrameRaster class
//
// Authors       : Almut Branner
//
// $Date: 10/29/03 9:56a $
//
// $History: MainFrameRaster.cpp $
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 10/29/03   Time: 9:56a
// Updated in $/Neuroshare/PowerNAP
// Removed setting the title, now done in string table.
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 10/17/03   Time: 1:03p
// Updated in $/Neuroshare/nsClassifier
// Turned raster combo box to change rate into buttons. Partially fixed
// single-to-multiline mode. Updating sorting algorithms.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/16/03   Time: 2:09p
// Updated in $/Neuroshare/nsClassifier
// Added accelerator keys. Removed Play, Pause and Scroll buttons.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/08/03   Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with scrolling (don't override PreCreateWindow()). Also
// fixed unit selection (Have to call OnPrepareDC() before using DPtoLP
// and so on). Removed code not needed.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "MainFrameRaster.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

UINT enumlinesizeval[ENUMLINESIZE_COUNT] = { 0, 7, 13, 19, 25, 37, 49, 61, 85, 200 };
UINT enumwidthval[ENUMWIDTH_COUNT] = { 250, 200, 150, 100, 80, 50, 30, 20, 10, 5, 2, 1 };

/////////////////////////////////////////////////////////////////////////////
// CMainFrameRaster

IMPLEMENT_DYNCREATE(CMainFrameRaster, CFrameWnd)

CMainFrameRaster::CMainFrameRaster()
{
    m_pwndView = NULL;
}

CMainFrameRaster::~CMainFrameRaster()
{
}


BEGIN_MESSAGE_MAP(CMainFrameRaster, CFrameWnd)
    ON_MESSAGE(WM_USER_CHANGELINEMODE, OnChangeLineMode)
	//{{AFX_MSG_MAP(CMainFrameRaster)
	ON_WM_CREATE()
	ON_NOTIFY(TBN_DROPDOWN, AFX_IDW_TOOLBAR, OnToolbarDropDown)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_WM_GETMINMAXINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrameRaster message handlers

int CMainFrameRaster::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

    // Initialize toolbar
    InitToolbar();

	return 0;
}

// Author & Date:   Almut Branner     25 August 2003
// Purpose: Used to only show requested title and not parent
void CMainFrameRaster::OnUpdateFrameTitle(BOOL bAddToTitle)
{
    // We do the "false" because we only want the "title" and
    // Not the app name as well
	CFrameWnd::OnUpdateFrameTitle(false);	
}


void CMainFrameRaster::InitToolbar()
{
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_VIEWRASTER_TOOLBAR))
	{
		TRACE("Failed to create toolbar\n");
		return;       // fail to create
	}

    CRect rect;

    //////////////////////////////
    // Now the Main Toolbar
    m_fntToolbar.CreatePointFont(85, "Toolbar Font", NULL);
    m_wndToolBar.SetFont(&m_fntToolbar, true);

    // This is needed for drop arrows
    m_wndToolBar.GetToolBarCtrl().SetExtendedStyle(TBSTYLE_EX_DRAWDDARROWS);

    // Create label for the channel id
    m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_LABEL_CHANNEL), ID_LABEL_CHANNEL, 
        TBBS_SEPARATOR, 85);
    m_wndToolBar.GetItemRect(m_wndToolBar.CommandToIndex(ID_LABEL_CHANNEL), &rect);
    rect.top += 3;

    m_icLblChannel.Create(WS_CHILD | WS_VISIBLE | ES_RIGHT | ES_READONLY,
        rect, &m_wndToolBar, ID_LABEL_CHANNEL);
    m_icLblChannel.SetFont(&m_fntToolbar, true);
    m_icLblChannel.SetMargins(1, 1);
    m_icLblChannel.SetWindowText("None");

    // Turn some buttons into checkboxes
    m_wndToolBar.SetButtonStyle(m_wndToolBar.CommandToIndex(ID_SINGLELINEMODE), TBBS_CHECKBOX);
    m_wndToolBar.SetButtonStyle(m_wndToolBar.CommandToIndex(ID_MULTILINEMODE), TBBS_CHECKBOX);
    m_wndToolBar.SetButtonStyle(m_wndToolBar.CommandToIndex(ID_EVENTS), TBBS_CHECKBOX);
    m_wndToolBar.SetButtonStyle(m_wndToolBar.CommandToIndex(ID_CONT), TBBS_CHECKBOX);

    // Sort button
    DWORD dwStyle = m_wndToolBar.GetButtonStyle(m_wndToolBar.CommandToIndex(ID_SORT));
    dwStyle |= TBSTYLE_DROPDOWN;
    m_wndToolBar.SetButtonStyle(m_wndToolBar.CommandToIndex(ID_SORT), dwStyle);

    // Hide buttons without functionality
    m_wndToolBar.GetToolBarCtrl().HideButton(ID_APP_ABOUT, true);
    m_wndToolBar.GetToolBarCtrl().HideButton(ID_CONTSCALE, true);
    m_wndToolBar.GetToolBarCtrl().HideButton(ID_EDIT_CUT, true);
    m_wndToolBar.GetToolBarCtrl().HideButton(ID_EDIT_COPY, true);
    m_wndToolBar.GetToolBarCtrl().HideButton(ID_EDIT_PASTE, true);
    m_wndToolBar.GetToolBarCtrl().HideButton(ID_FILE_PRINT, true);
    
    // Change sizes and move the toolbars into the right starting position
    m_wndToolBar.SetHeight(30);

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);

	DockControlBar(&m_wndToolBar);

    // Set some default behavior
    if (m_pwndView->m_bSingleLineFormat)
    {
        OnChangeLineMode(0, 0);
        m_wndToolBar.GetToolBarCtrl().CheckButton(ID_EVENTS, true);
        m_wndToolBar.GetToolBarCtrl().CheckButton(ID_CONT, false);
    }
    else
    {
        OnChangeLineMode(1, 0);
    }
}


// Author & Date:   Almut Branner     29 July 2003
// Purpose: Defines the minimum size of the window
void CMainFrameRaster::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
    lpMMI->ptMinTrackSize.x = 200;
    lpMMI->ptMinTrackSize.y = 150;
    
	CFrameWnd::OnGetMinMaxInfo(lpMMI);
}


// Author & Date:   Almut Branner     28 July 2003
// Purpose: Called when line mode changes
void CMainFrameRaster::OnChangeLineMode(UINT wParam, LONG lParam)
{
    // SingleLineMode
    if (wParam == 0)
    {
        m_wndToolBar.GetToolBarCtrl().CheckButton(ID_SINGLELINEMODE, true);
        m_wndToolBar.GetToolBarCtrl().CheckButton(ID_MULTILINEMODE, false);
        m_wndToolBar.GetToolBarCtrl().HideButton(ID_EVENTS, false);
        m_wndToolBar.GetToolBarCtrl().HideButton(ID_CONT, false);
        m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_CONT) + 1, ID_SEPARATOR, TBBS_SEPARATOR, 6);
    }
    // MultiLineMode
    else
    {
        m_wndToolBar.GetToolBarCtrl().CheckButton(ID_SINGLELINEMODE, false);
        m_wndToolBar.GetToolBarCtrl().CheckButton(ID_MULTILINEMODE, true);
        m_wndToolBar.GetToolBarCtrl().HideButton(ID_EVENTS, true);
        m_wndToolBar.GetToolBarCtrl().HideButton(ID_CONT, true);
        m_wndToolBar.SetButtonInfo(m_wndToolBar.CommandToIndex(ID_CONT) + 1, ID_SEPARATOR, TBBS_SEPARATOR, 1);
    }
}


// Author & Date:   Almut Branner     31 July 2003
// Purpose: Copies the contents of the selected edit box
void CMainFrameRaster::OnEditCopy() 
{
    CEdit* pEdit = (CEdit*) GetFocus();
    pEdit->Copy();
}


// Author & Date:   Almut Branner     31 July 2003
// Purpose: Handles drop down menus on toolbar
void CMainFrameRaster::OnToolbarDropDown(NMTOOLBAR* pnmtb, LRESULT *plr)
{
	CWnd *pWnd;
	UINT nID;

	// Switch on button command id's.
	switch (pnmtb->iItem)
	{
	case ID_SORT:
		pWnd = &m_wndToolBar;
		nID  = IDR_MENU_SORT;
		break;
	default:
		return;
	}
	
	// load and display popup menu
	CMenu menu;
	menu.LoadMenu(nID);
	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup);
    pPopup->SetDefaultItem(ID_SORT_CHANNEL, false);
	
	CRect rc;
	pWnd->SendMessage(TB_GETRECT, pnmtb->iItem, (LPARAM)&rc);
	pWnd->ClientToScreen(&rc);
	
	pPopup->TrackPopupMenu( TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_VERTICAL,
		rc.left, rc.bottom, this, &rc);
}


BOOL CMainFrameRaster::PreCreateWindow(CREATESTRUCT& cs) 
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}
