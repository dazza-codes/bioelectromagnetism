///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFrameWaveforms.h $
//
// Description   : interface of the CMainFrameWaveforms class
//
// Authors       : Almut Branner
//
// $Date: 10/31/03 6:03p $
//
// $History: MainFrameWaveforms.h $
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/31/03   Time: 6:03p
// Updated in $/Neuroshare/PowerNAP
// Changed toolbars, removed combo box for spike sorting, and how that is
// called.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 9/12/03    Time: 1:41p
// Updated in $/Neuroshare/nsClassifier
// Added author in title.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/26/03    Time: 5:59p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/25/03    Time: 11:02a
// Updated in $/Neuroshare/nsClassifier
// Changed some variable names to conform with coding standard. Changed
// the toolbar and some tooltips.
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MAINFRAMEWAVEFORMS_H_INCLUDED
#define MAINFRAMEWAVEFORMS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMainFrameWaveforms frame

class CMainFrameWaveforms : public CFrameWnd
{
	DECLARE_DYNCREATE(CMainFrameWaveforms)
protected:
	CMainFrameWaveforms();           // protected constructor used by dynamic creation

// Attributes
public:
	CComboBox       m_icCboUnits;
	CEdit           m_icLblThresh;
    CStatic         m_icLblThreshUnits;
	CStatusBar      m_wndStatusBar;
    CToolBar        m_icToolbar;

    CString         m_szStatusBarString;

// Operations
public:

// Overrides
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);
    void StatusBarMessage(TCHAR * fmt,...);

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrameWaveforms)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	void InitToolbar();
	virtual ~CMainFrameWaveforms();

	// Generated message map functions
	//{{AFX_MSG(CMainFrameWaveforms)
    afx_msg LRESULT OnSetMessageString(WPARAM wParam, LPARAM lParam);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnBtnSort();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
