///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropSheetSpkSort.cpp $
//
// Description   :  
//
// Authors       : 
//
// $Date: 2/02/04 6:17p $
//
// $History: PropSheetSpkSort.cpp $
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 1/30/04    Time: 3:54p
// Updated in $/Neuroshare/PowerNAP
// Streamlined data transfer.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/31/03   Time: 6:05p
// Updated in $/Neuroshare/PowerNAP
// Changed names of property pages.
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Awang        Date: 8/29/03    Time: 12:00p
// Updated in $/Neuroshare/nsClassifier
// Save #PC in document correctly from combobox
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 10:56a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 8/26/03    Time: 6:30p
// Created in $/Neuroshare/nsClassifier
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PowerNAP.h"
#include "PropSheetSpkSort.h"
#include "DocPowerNAP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropSheetSpkSort

IMPLEMENT_DYNAMIC(CPropSheetSpkSort, CPropertySheet)

CPropSheetSpkSort::CPropSheetSpkSort(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage,
                                     CDocPowerNAP* pDoc)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
    m_pDoc = pDoc;

    InitializePropPages();
}

CPropSheetSpkSort::CPropSheetSpkSort(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage,
                                     CDocPowerNAP* pDoc)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
    m_pDoc = pDoc;

    InitializePropPages();
}

CPropSheetSpkSort::~CPropSheetSpkSort()
{

}


BEGIN_MESSAGE_MAP(CPropSheetSpkSort, CPropertySheet)
	//{{AFX_MSG_MAP(CPropSheetSpkSort)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
    ON_BN_CLICKED (ID_APPLY_NOW, OnApply)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropSheetSpkSort message handlers

BOOL CPropSheetSpkSort::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
    CWnd *pWnd = GetDlgItem(IDHELP);
    pWnd->ShowWindow(false);

	return bResult;
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Update the data in the document after apply was hit.
void CPropSheetSpkSort::OnApply()
{
    GetActivePage()->UpdateData(true);

    UpdateDoc();

    m_icPropPageShyOpt.SetModified(false);
    m_icPropPageKMeansOpt.SetModified(false);
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Initialize all the property pages. Grab the appropriate data from the documents.
void CPropSheetSpkSort::InitializePropPages()
{
    AddPage(&m_icPropPageShyOpt);
    AddPage(&m_icPropPageKMeansOpt);

    m_icPropPageShyOpt.m_nPosPenaltyFct = m_pDoc->m_nPenaltyFactor;
    m_icPropPageShyOpt.m_nPosPCA = m_pDoc->m_nNumPCA;

    m_icPropPageKMeansOpt.m_nNumIter = m_pDoc->m_isSortInfo.nIterCnt;
    m_icPropPageKMeansOpt.m_nNumPCA = m_pDoc->m_isSortInfo.nPCCnt;
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Update the data in the document.
void CPropSheetSpkSort::UpdateDoc()
{
    if (m_pDoc != NULL)
    {
        m_pDoc->m_nNumPCA = m_icPropPageShyOpt.m_nPosPCA;
        m_pDoc->m_nPenaltyFactor = m_icPropPageShyOpt.m_nPosPenaltyFct;

        if (m_icPropPageKMeansOpt.m_nNumPCA)
            m_pDoc->m_isSortInfo.nPCCnt = m_icPropPageKMeansOpt.m_nNumPCA;
        else if (m_icPropPageKMeansOpt.m_nNumPCA == 0)
            m_pDoc->m_isSortInfo.nPCCnt = m_pDoc->GetNumOfPointsPerWave();

        m_pDoc->m_isSortInfo.nIterCnt = m_icPropPageKMeansOpt.m_nNumIter;
    }
}


// Author & Date:   Almut Branner   1 Feb 2004
// Purpose: We only want to change the do something if we actually changed something.
//          Since the Apply button tracks this, we only have to check its 'enabled' status.
BOOL CPropSheetSpkSort::DestroyWindow() 
{
    // This will figure out whether any data has changed
    if (GetDlgItem(ID_APPLY_NOW)->IsWindowEnabled())
        UpdateDoc();
	
	return CPropertySheet::DestroyWindow();
}
