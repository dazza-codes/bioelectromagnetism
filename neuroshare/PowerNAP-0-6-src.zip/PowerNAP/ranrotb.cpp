///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ranrotb.cpp $
//
// Description   : interface for the VisitorShyAlgorithm class.
//
// Authors       : Almut Branner
//
// $Date: 6/10/03 10:04a $
//
// $History: ranrotb.cpp $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 6/10/03    Time: 10:04a
// Updated in $/Neuroshare/nsClassifier
// Put in #pragma warning to disable warning message.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

/************************* RANROTB.CPP ****************** AgF 1999-03-03 *
*  Random Number generator 'RANROT' type B                               *
*                                                                        *
*  This is a lagged-Fibonacci type of random number generator with       *
*  rotation of bits.  The algorithm is:                                  *
*  X[n] = ((X[n-j] rotl r1) + (X[n-k] rotl r2)) modulo 2^b               *
*                                                                        *
*  The last k values of X are stored in a circular buffer named          *
*  randbuffer.                                                           *
*  The code includes a self-test facility which will detect any          *
*  repetition of previous states.                                        *
*                                                                        *
*  The theory of the RANROT type of generators and the reason for the    *
*  self-test are described at www.agner.org/random                       *
*                                                                        *
* � 2002 A. Fog. GNU General Public License www.gnu.org/copyleft/gpl.html*
*************************************************************************/

#include "stdafx.h"
#include "randomc.h"
#include <string.h>  // some compilers require <mem.h> instead
#include <stdio.h>
#include <stdlib.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// If your system doesn't have a rotate function for 32 bits integers,
// then use the definition below. If your system has the _lrotl function 
// then remove this.
// unsigned long _lrotl (unsigned long x, int r) {
//   return (x << r) | (x >> (sizeof(x)*8-r));}


// constructor:
TRanrotBGenerator::TRanrotBGenerator(long int seed)
{
  RandomInit(seed);
  // detect computer architecture
  union {double f; unsigned long i[2];} convert;
  convert.f = 1.0;
  if (convert.i[1] == 0x3FF00000) Architecture = LITTLE_ENDIAN;
  else if (convert.i[0] == 0x3FF00000) Architecture = BIG_ENDIAN;
  else Architecture = NON_IEEE;
}


// returns a random number between 0 and 1:
double TRanrotBGenerator::Random()
{
  unsigned long x;
  // generate next random number
  x = randbuffer[p1] = _lrotl(randbuffer[p2], R1) + _lrotl(randbuffer[p1], R2);
  // rotate list pointers
  if (--p1 < 0) p1 = KK - 1;
  if (--p2 < 0) p2 = KK - 1;
  // perform self-test
  if (randbuffer[p1] == randbufcopy[0] &&
    memcmp(randbuffer, randbufcopy+KK-p1, KK*sizeof(long)) == 0) {
      // self-test failed
      if ((p2 + KK - p1) % KK != JJ) {
        // note: the way of printing error messages depends on system
        // In Windows you may use FatalAppExit
        printf("Random number generator not initialized");}
      else {
        printf("Random number generator returned to initial state");}
      exit(1);}
  // conversion to float:
  union {double f; unsigned long i[2];} convert;
  switch (Architecture) {
  case LITTLE_ENDIAN:
    convert.i[0] =  x << 20;
    convert.i[1] = (x >> 12) | 0x3FF00000;
    return convert.f - 1.0;
  case BIG_ENDIAN:
    convert.i[1] =  x << 20;
    convert.i[0] = (x >> 12) | 0x3FF00000;
    return convert.f - 1.0;
  case NON_IEEE: default:
  ;} 
  // This somewhat slower method works for all architectures, including 
  // non-IEEE floating point representation:
  return (double)x * (1./((double)(unsigned long)(-1L)+1.));
}


// returns integer random number in desired interval:
int TRanrotBGenerator::IRandom(int min, int max) 
{
  int iinterval = max - min + 1;
  if (iinterval <= 0) return -0x80000000; // error
  int i = (int) (iinterval * Random()); // truncate
  if (i >= iinterval) i = iinterval-1;
  return min + i;
}
  

void TRanrotBGenerator::RandomInit (long int seed) 
{
  // this function initializes the random number generator.
  int i;
  unsigned long s = seed;

  // make random numbers and put them into the buffer
  for (i=0; i<KK; i++) 
  {
    s = s * 2891336453 + 1;
    randbuffer[i] = s;
  }

  // check that the right data formats are used by compiler:
  union {
    double randp1;
    unsigned long randbits[2];};
  randp1 = 1.5;
  assert(randbits[1]==0x3FF80000); // check that IEEE double precision float format used

  // initialize pointers to circular buffer
  p1 = 0;  p2 = JJ;
  // store state for self-test
  memcpy (randbufcopy, randbuffer, KK*sizeof(long));
  memcpy (randbufcopy+KK, randbuffer, KK*sizeof(long));
  // randomize some more
  for (i=0; i<9; i++) Random();
}

