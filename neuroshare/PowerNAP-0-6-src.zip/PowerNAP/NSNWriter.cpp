///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NSNWriter.cpp $
//
// Authors       : Kirk Korver
//
// $Date: 10/21/03 2:43p $
//
// $History: NSNWriter.cpp $
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 9/11/03    Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// LoadDLL() now uses the passed parameter
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 9/11/03    Time: 7:05a
// Created in $/Neuroshare/nsClassifier
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NSNWriter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


HINSTANCE NSNWriter::m_hDLL = 0;
int NSNWriter::m_nDllRefCount = 0;
static const char NSN_DLL_NAME[] = "nsNSNLibrary.dll";


NSNWriter::NSNWriter() :
    m_pNSN(0),
    m_pfQueryInterface(0)
{
    // Get the current working directory
    LoadDLL(NSN_DLL_NAME);
    if (!m_hDLL)
        return;

    IUnKnown * I = m_pfQueryInterface(IWRITE_NSN);
    if (I)
        m_pNSN = static_cast<IWriteNSN *>(I);

}

NSNWriter::~NSNWriter()
{
    if (m_pNSN)
        m_pNSN->Release();

    UnloadDLL();
}




void NSNWriter::LoadDLL(LPCSTR szDllName)
{
    if (m_hDLL)
    {
        ++m_nDllRefCount;
        return;
    }

    do
    {
        m_hDLL = ::LoadLibrary(szDllName);
        if (!m_hDLL)
            break;;


        // Now lets set all of our pointers
        // A macro to help with gettng the addresses
        #define SetPointers(MyName, Type, DllName)                  \
            MyName = (Type) GetProcAddress(m_hDLL, DllName);        \
            if (0 == MyName)                                        \
                break;                                              \

        SetPointers(m_pfQueryInterface, QUERYINTERFACE, "QueryInterface")

        #undef SetPointers
        // We don't need the macro any more


        ++m_nDllRefCount;

        return;

    } while (FALSE);

    // If we got here, then bad things happened
}


void NSNWriter::UnloadDLL()
{
    if (--m_nDllRefCount == 0)
    {
        ::FreeLibrary(m_hDLL);
        m_hDLL = 0;
    }

    m_pfQueryInterface = 0;
}
