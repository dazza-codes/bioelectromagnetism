///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropPagePop.h $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 1/30/04 3:54p $
//
// $History: PropPagePop.h $
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 1/30/04    Time: 3:54p
// Updated in $/Neuroshare/PowerNAP
// Streamlined data transfer.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef PROPPAGEPOP_H_INCLUDED
#define PROPPAGEPOP_H_INCLUDED

#include "NumEdit.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropPagePop dialog

class CPropPagePop : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPagePop)

// Construction
public:
	CPropPagePop();
	~CPropPagePop();

// Dialog Data
	//{{AFX_DATA(CPropPagePop)
	enum { IDD = IDD_PROPPAGE_POP };
	CEdit	m_edtSamples;
	CEdit	m_edtGroups;
	UINT	m_nNumOfGroups;
	UINT	m_nNumOfSamples;
	UINT	m_nNumFiles;
	UINT	m_nTtlNumSamples;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPagePop)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void UpdateTotalNumSamples();
	// Generated message map functions
	//{{AFX_MSG(CPropPagePop)
	afx_msg void OnChange();
	afx_msg void OnKillfocus();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
