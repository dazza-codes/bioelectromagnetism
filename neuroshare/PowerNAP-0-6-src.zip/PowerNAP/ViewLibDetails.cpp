///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewLibDetails.cpp $
//
// Description   : implementation of the CViewLibDetails class 
//
// Authors       : Kirk Korver
//
// $Date: 2/19/04 4:07p $
//
// $History: ViewLibDetails.cpp $
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 2/19/04    Time: 4:07p
// Updated in $/Neuroshare/PowerNAP
// There is an 'ADD' button on the library details. This button will set
// the correct settings in the registry so the DLL will be remembered
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 9/11/03    Time: 9:35a
// Updated in $/Neuroshare/nsClassifier
// Updated the formatting of the library extensions
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 4/28/03    Time: 12:34p
// Updated in $/Neuroshare/nsClassifier
// Added capability to turn tooltips off.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 4/25/03    Time: 5:39p
// Updated in $/Neuroshare/nsClassifier
// Implemented tooltip support for all windows (hovering shows message).
// 
// *****************  Version 2  *****************
// User: Kkorver      Date: 4/24/03    Time: 1:16p
// Updated in $/Neuroshare/nsClassifier
// Added code for ShowDetails() and PopulateLibrary()
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 4/24/03    Time: 9:19a
// Created in $/Neuroshare/nsClassifier
// Initial checkin of CViewLibDetails window
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "ViewLibDetails.h"
#include "NsLibraryImpMgr.h"
#include "Registry.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewLibDetails

IMPLEMENT_DYNCREATE(CViewLibDetails, CFormView)

CViewLibDetails::CViewLibDetails()
	: CFormView(CViewLibDetails::IDD)
{
	//{{AFX_DATA_INIT(CViewLibDetails)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CViewLibDetails::~CViewLibDetails()
{
}

void CViewLibDetails::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewLibDetails)
	DDX_Control(pDX, IDC_LDT_LST_FILEDESCRIPTIONS, m_lstFileDescriptions);
	DDX_Control(pDX, IDC_LDT_LST_LIBRARIES, m_lstLibraries);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewLibDetails, CFormView)
	//{{AFX_MSG_MAP(CViewLibDetails)
	ON_BN_CLICKED(IDC_LDT_BTN_CLOSE, OnClose)
	ON_LBN_SELCHANGE(IDC_LDT_LST_LIBRARIES, OnLstLibrariesSelchange)
	ON_BN_CLICKED(IDC_LDT_BTN_ADD, OnBtnAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewLibDetails diagnostics

#ifdef _DEBUG
void CViewLibDetails::AssertValid() const
{
	CFormView::AssertValid();
}

void CViewLibDetails::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CViewLibDetails message handlers

void CViewLibDetails::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
    GetParentFrame()->SetTitle("Library Details");

    PopulateLibrary();
	
    // Size the window to match that of the form in the resource editor
    GetParentFrame()->RecalcLayout();
    ResizeParentToFit(false);
}


// Author & Date:   Kirk Korver     23 Apr 2003
// Purpose: populate the library list
// Inputs:
//  The global list in the NSLibImpManager
void CViewLibDetails::PopulateLibrary()
{
    m_lstLibraries.ResetContent();      // remove any entries

    const NsLibraryList & rcList = NsLibraryImpMgr::GetMgr().GetLibraryList();
    const ElementList & rcElements = rcList.GetElementList();
    
    ElementList::const_iterator it;
    for (it = rcElements.begin(); it != rcElements.end(); ++it)
    {
        m_lstLibraries.AddString(it->m_strDllPathName);
    }
    
    m_lstLibraries.SetCurSel(0);        // show the 1st entry..to be nice
    OnLstLibrariesSelchange();
}

// Author & Date:   Kirk Korver     24 Apr 2003
// Purpose: display all of the details about this library on the screen
// Inputs:
//  szDLLPathName - fully qualifed name of the DLL to read fom
void CViewLibDetails::ShowDetails(LPCSTR szDLLPathName)
{
    NsLibraryImp const * pcLib = NsLibraryImpMgr::GetMgr().GetLibrary(szDLLPathName);

    ns_LIBRARYINFO icInfo;
    if (ns_OK != pcLib->GetLibraryInfo(&icInfo, sizeof(icInfo)))
    {
        CString msg;
        msg.Format("Unable to read from\n%s", szDLLPathName);
        AfxMessageBox(msg, MB_ICONEXCLAMATION, 0);
        return;
    }

    // File Descriptions
    m_lstFileDescriptions.ResetContent();
    CString msg;
    const char fmt[] = "%-20s\t\t%s";
    msg.Format(fmt, "Extension", "Description");
    m_lstFileDescriptions.AddString(msg);
    for (int i = 0; i < icInfo.dwFileDescCount; ++i)
    {
        msg.Format(fmt, 
                   icInfo.FileDesc[i].szExtension, 
                   icInfo.FileDesc[i].szDescription);

        m_lstFileDescriptions.AddString(msg);
    }

    // The versions
    SetDlgItemInt(IDC_LDT_TXT_VERLIBMAJOR, icInfo.dwLibVersionMaj, false);
    SetDlgItemInt(IDC_LDT_TXT_VERLIBMINOR, icInfo.dwLibVersionMin, false);
    SetDlgItemInt(IDC_LDT_TXT_VERAPIMAJOR, icInfo.dwAPIVersionMaj, false);
    SetDlgItemInt(IDC_LDT_TXT_VERAPIMINOR, icInfo.dwAPIVersionMin, false);

    // Library Description
    SetDlgItemText(IDC_LDT_TXT_LIBRARYDESCRIPTION, icInfo.szDescription);

    // Library Creator
    SetDlgItemText(IDC_LDT_TXT_LIBRARYCREATOR, icInfo.szCreator);

    // Modification time
    {
        CString strTime;
        strTime.Format("%s %i, %i",
                        GetMonth(icInfo.dwTime_Month),
                        icInfo.dwTime_Day,
                        icInfo.dwTime_Year);

        SetDlgItemText(IDC_LDT_TXT_MODIFICATIONTIME, strTime);
    }
}

// Author & Date:   Kirk Korver     24 Apr 2003
// Given a number, get a month string
// Inputs:
//  nMonth - 1 = January and 12 = December
// Outputs:
//  String corresponding to that month
LPCSTR CViewLibDetails::GetMonth(DWORD nMonth)
{
    if (nMonth > 12)
        nMonth = 0;

    LPCSTR aszMonths[13] =
    {
        "Unknown",
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    };

    return aszMonths[nMonth];
}


void CViewLibDetails::OnClose() 
{
    GetParentFrame()->DestroyWindow();
}

void CViewLibDetails::OnLstLibrariesSelchange() 
{
    CString strDLL;
    int nSelection = m_lstLibraries.GetCurSel();
    m_lstLibraries.GetText(nSelection, strDLL);
	ShowDetails(strDLL);
}

void CViewLibDetails::OnBtnAdd() 
{
    // prepare to prompt
    CFileDialog icFileDlg
    (
        TRUE,                                           // TRUE = file open 
        NULL,                                           // Default Extension - we use filters
        NULL,                                           // Filename - let them choose
        OFN_FILEMUSTEXIST,                              // flags - file must exist and hide read only
        "Dll Files (*.dll)|*.dll|All Files (*.*)|*.*||",// File extensions
        this
    );

    if (icFileDlg.DoModal() == IDOK)    // if cancel was not pressed
    {
        // Add this DLL to the registry
        CString strKey = szLIBRARY_REGISTRY_BASE;
        strKey += "\\";
        strKey += icFileDlg.GetFileTitle();
        strKey += "\\Path";
        CRegString icReg(strKey, "", FALSE, HKEY_LOCAL_MACHINE);
        icReg = icFileDlg.GetPathName();

        // Now add it to our internal list of active DLLs
        NsLibraryImpMgr::GetMgr().AddLibraryToSystem(icFileDlg.GetPathName());

        // Now update the screen
        PopulateLibrary();
    }
}
