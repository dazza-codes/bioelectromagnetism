// (c) Copyright 2002, 2003 Cyberkinetics, Inc.
//
// $Workfile: DlgChooser.h $
// $Archive: /Neuroshare/nsClassifier/DlgChooser.h $
// $Revision: 2 $
// $Date: 10/07/03 9:37a $
// $Author: Abranner $
//
// $History: DlgChooser.h $
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 9/15/03    Time: 5:48p
// Created in $/Neuroshare/nsClassifier
// 
// *****************  Version 1  *****************
// User: Kkorver      Date: 5/28/03    Time: 12:01p
// Created in $/Cerebus/WindowsApps/Raster
// Initial checkin of the "Chooser" window 
// 
// $NoKeywords: $
///////////////////////////////////////////////////////////////////////////////

#ifndef DLGCHOOSER_H_INCLUDED
#define DLGCHOOSER_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <list>

struct ChosenElement
{
    ChosenElement(CString strLabel, DWORD dwID, bool bChosen) :
        strLabel(strLabel),
        dwID(dwID),
        bChosen(bChosen)
    {
    }

    CString strLabel;
    DWORD dwID;
    bool bChosen;
};

typedef std::list <ChosenElement> CHOSENLIST;


/////////////////////////////////////////////////////////////////////////////
// CDlgChooser dialog

class CDlgChooser : public CDialog
{
// Construction
public:
	CDlgChooser(CWnd* pParent = NULL);   // standard constructor
    
    void AddEntry(LPCSTR szLabel, DWORD dwID, bool bChosen);  // Add an element into the "chosen" list

    const CHOSENLIST & GetList() { return m_icList; }

// Dialog Data
	//{{AFX_DATA(CDlgChooser)
	enum { IDD = IDD_CHOOSER };
	CButton	m_btnRemoveAllFromSelected;
	CButton	m_btnAddAllToSelected;
	CButton	m_btnRemoveFromSelected;
	CButton	m_btnAddToSelected;
	CListBox	m_lstSelected;
	CListBox	m_lstNotSelected;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChooser)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

    CHOSENLIST m_icList;

    void FillCommonList(const CListBox & lstList, bool bChosen);
    void MoveSelections(CListBox & lstTo, CListBox & lstFrom);
    void MoveAll(CListBox & lstTo, CListBox & lstFrom);

	// Generated message map functions
	//{{AFX_MSG(CDlgChooser)
	afx_msg void OnLstNotSelectedSetFocus();
	afx_msg void OnLstSelectedSetfocus();
	afx_msg void OnBtnAddToSelected();
	afx_msg void OnBtnRemoveFromSelected();
	afx_msg void OnBtnRemoveAllFromSelected();
	afx_msg void OnBtnAddAllToSelected();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
    CToolTipCtrl m_icToolTip;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guards
