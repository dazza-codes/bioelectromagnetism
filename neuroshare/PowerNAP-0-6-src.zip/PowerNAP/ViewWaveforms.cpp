///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewWaveforms.cpp $
//
// Authors       : Angela Wang
//
// $Date: 3/11/04 12:52p $
//
// $History: ViewWaveforms.cpp $
// 
// *****************  Version 64  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:52p
// Updated in $/Neuroshare/PowerNAP
// Added ability to delete units and reclassify units
// 
// *****************  Version 63  *****************
// User: Kkorver      Date: 3/09/04    Time: 5:09p
// Updated in $/Neuroshare/PowerNAP
// Added constants instead of magic numbers
// 
// *****************  Version 62  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Added basic "clipping" functions
// 
// *****************  Version 61  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:25p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 60  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:34p
// Updated in $/Neuroshare/PowerNAP
// Update to the animation to remove flickering
// 
// *****************  Version 59  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:47p
// Updated in $/Neuroshare/PowerNAP
// Added Playback capabilities
// 
// *****************  Version 58  *****************
// User: Abranner     Date: 2/10/04    Time: 10:16a
// Updated in $/Neuroshare/PowerNAP
// Added additional units to combo box.
// 
// *****************  Version 57  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 56  *****************
// User: Abranner     Date: 1/30/04    Time: 3:57p
// Updated in $/Neuroshare/PowerNAP
// Simplified initialization of property sheets.
// 
// *****************  Version 55  *****************
// User: Abranner     Date: 10/31/03   Time: 6:06p
// Updated in $/Neuroshare/PowerNAP
// Added status bar messages.
// 
// *****************  Version 54  *****************
// User: Abranner     Date: 10/27/03   Time: 10:35a
// Updated in $/Neuroshare/PowerNAP
// Changed size of FIU dialog and removed non-functioning buttons.
// 
// *****************  Version 53  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:41a
// Updated in $/Neuroshare/PowerNAP
// Better way to test if the window is visible
// 
// *****************  Version 52  *****************
// User: Kkorver      Date: 10/21/03   Time: 5:39p
// Updated in $/Neuroshare/PowerNAP
// Added OnUpdateWftbThresholdbtn(), The threshold button now tracks the
// "state" of thresholding in the system
// The spikes display now reiszes
// 
// *****************  Version 51  *****************
// User: Kkorver      Date: 10/21/03   Time: 4:31p
// Updated in $/Neuroshare/PowerNAP
// Moved ReplaceWindowControl() to the common area
// 
// *****************  Version 50  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 49  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:15a
// Updated in $/Neuroshare/nsClassifier
// Removed dead code
// 
// *****************  Version 48  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 47  *****************
// User: Abranner     Date: 10/15/03   Time: 6:06p
// Updated in $/Neuroshare/nsClassifier
// Changed SetDrawUnit calls.
// 
// *****************  Version 46  *****************
// User: Abranner     Date: 10/13/03   Time: 1:59p
// Updated in $/Neuroshare/nsClassifier
// Changed IsThisSegment() to IsActiveSegment().
// 
// *****************  Version 45  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 44  *****************
// User: Abranner     Date: 9/11/03    Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// Fixed indeces to m_dThreshold.
// 
// *****************  Version 43  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 42  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 41  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 39  *****************
// User: Awang        Date: 8/29/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Save #PC coordinates saved correctly from combobox
// 
// *****************  Version 38  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 37  *****************
// User: Abranner     Date: 8/27/03    Time: 10:57a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet and removed CViewOptKMeans.
// 
// *****************  Version 36  *****************
// User: Abranner     Date: 8/26/03    Time: 6:24p
// Updated in $/Neuroshare/nsClassifier
// Adjustments after merging.
// 
// *****************  Version 35  *****************
// User: Abranner     Date: 8/26/03    Time: 6:01p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 34  *****************
// User: Abranner     Date: 8/25/03    Time: 11:02a
// Updated in $/Neuroshare/nsClassifier
// Changed some variable names to conform with coding standard. Changed
// the toolbar and some tooltips.
// 
// *****************  Version 33  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 32  *****************
// User: Awang        Date: 8/05/03    Time: 3:16p
// Updated in $/Neuroshare/nsClassifier
// New toolbar buttons
// 
// *****************  Version 31  *****************
// User: Awang        Date: 6/30/03    Time: 3:59p
// Updated in $/Neuroshare/nsClassifier
// Local control removed to toolbars in ViewPCA and ViewWaveform
// 
// *****************  Version 30  *****************
// User: Awang        Date: 6/18/03    Time: 2:30p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 29  *****************
// User: Awang        Date: 6/10/03    Time: 4:42p
// Updated in $/Neuroshare/nsClassifier
// Highlighting of selected waveforms
// 
// *****************  Version 28  *****************
// User: Abranner     Date: 5/06/03    Time: 11:08a
// Updated in $/Neuroshare/nsClassifier
// Added help for one button to be able to test it.
// 
// *****************  Version 27  *****************
// User: Awang        Date: 5/06/03    Time: 11:04a
// Updated in $/Neuroshare/nsClassifier
// checked that m_tool.m_hWnd exists
// 
// *****************  Version 26  *****************
// User: Abranner     Date: 5/05/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with the graph update. The scaling (or max voltage value)
// of all waveforms is now calculated in the document and not the graph
// window.
// 
// *****************  Version 25  *****************
// User: Abranner     Date: 4/30/03    Time: 3:06p
// Updated in $/Neuroshare/nsClassifier
// Fixed bug cause by merging.
// 
// *****************  Version 24  *****************
// User: Abranner     Date: 4/30/03    Time: 2:55p
// Updated in $/Neuroshare/nsClassifier
// Changed window positions.
// Changed the entity list to a list control.
// Fized a bug in the waveform view.
// 
// *****************  Version 23  *****************
// User: Kkorver      Date: 4/30/03    Time: 2:35p
// Updated in $/Neuroshare/nsClassifier
// Added ReplaceWindowControl()
// Untabified the document
// 
// *****************  Version 22  *****************
// User: Abranner     Date: 4/29/03    Time: 5:08p
// Updated in $/Neuroshare/nsClassifier
// Threshold line now tracks and arrows work.
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 4/29/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Added OnCreate() that set's the title of the frame
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 4/28/03    Time: 12:59p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with tooltips.
// 
// *****************  Version 19  *****************
// User: Awang        Date: 4/28/03    Time: 12:33p
// Updated in $/Neuroshare/nsClassifier
// Changed include header to DisplaySpike.h
// 
// *****************  Version 18  *****************
// User: Awang        Date: 4/28/03    Time: 11:53a
// Updated in $/Neuroshare/nsClassifier
// Changed name of class CDisplaySpike
// 
// *****************  Version 17  *****************
// User: Abranner     Date: 4/25/03    Time: 5:39p
// Updated in $/Neuroshare/nsClassifier
// Implemented tooltip support for all windows (hovering shows message).
// 
// *****************  Version 16  *****************
// User: Abranner     Date: 4/25/03    Time: 1:54p
// Updated in $/Neuroshare/nsClassifier
// HTML help now works.
// 
// *****************  Version 15  *****************
// User: Abranner     Date: 4/25/03    Time: 9:30a
// Updated in $/Neuroshare/nsClassifier
// Check in before changing all kinds of things to help. Not all help is
// functional here.
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 4/24/03    Time: 10:15a
// Updated in $/Neuroshare/nsClassifier
// GetAppDirectory() became GetAppPath()
// 
// *****************  Version 13  *****************
// User: Almut        Date: 4/24/03    Time: 9:39a
// Updated in $/Neuroshare/nsClassifier
// More changes to html help stuff. I also added the GetAppDir function to
// the app.
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 4/23/03    Time: 10:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed the files FilesInUseView to ViewFilesInUse and
// WaveformsView to ViewWaveforms
// 
// *****************  Version 11  *****************
// User: Almut        Date: 4/22/03    Time: 3:22p
// Updated in $/Neuroshare/nsClassifier
// Basic help support works now.
// 
// *****************  Version 10  *****************
// User: Almut        Date: 4/22/03    Time: 10:27a
// Updated in $/Neuroshare/nsClassifier
// Added help support to the project but no messages are setup yet.
// 
// *****************  Version 9  *****************
// User: Almut        Date: 4/18/03    Time: 1:08p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anomaly #13.
// Thresholding now has a plus and minus button and a text box for editing
// the threshold.
// Also figured out how to recognize the return key in edit boxes and use
// it to make something happen.
// 
// *****************  Version 8  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 7  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 4/10/03    Time: 3:20p
// Updated in $/Neuroshare/nsClassifier
// Removed Spurious Code
// 
// *****************  Version 5  *****************
// User: Angela       Date: 4/10/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Updates and no extra frames created
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:16p
// Updated in $/Neuroshare/nsClassifier
// Added NS Header
// Renamed class to CViewWaveforms
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "ViewFilesInUse.h"
#include "DisplaySpike.h"
#include "MainFrameWaveforms.h"
#include "ViewWaveforms.h"
#include "PropSheetSpkSort.h"
#include "ns_common.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const double dScaleWaveform = 1.05; // This could be a global variable
                                    // because it is also used by the CDisplaySpike 


/////////////////////////////////////////////////////////////////////////////
// CViewWaveforms

IMPLEMENT_DYNCREATE(CViewWaveforms, CFormView)

CViewWaveforms::CViewWaveforms()
    : CFormView(CViewWaveforms::IDD)
{
    //{{AFX_DATA_INIT(CViewWaveforms)
    //}}AFX_DATA_INIT
}

CViewWaveforms::~CViewWaveforms()
{
}

void CViewWaveforms::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CViewWaveforms)
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewWaveforms, CFormView)
    //{{AFX_MSG_MAP(CViewWaveforms)
    ON_BN_CLICKED(ID_WFTB_THRESHOLDBTN, OnBtnToolBarThresh)
	ON_CBN_SELCHANGE(ID_WFTB_COMBOUNIT, OnSelchangeWfCombo)
	ON_COMMAND(ID_VIEW_WFTOOLBAR_TMPL, OnViewWfToolbar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WFTOOLBAR_TMPL, OnUpdateViewWfToolbar)
	ON_COMMAND(ID_SORTINGOPTIONS, OnSortingOptions)
	ON_WM_SIZE()
	ON_UPDATE_COMMAND_UI(ID_WFTB_THRESHOLDBTN, OnUpdateWftbThresholdbtn)
	ON_COMMAND(ID_WFTB_CLIP, OnWftbClip)
	ON_UPDATE_COMMAND_UI(ID_WFTB_CLIP, OnWftbClipUpdate)
	ON_COMMAND(ID_WV_EDIT_DELETECURRENTUNIT, OnEditDeletecurrentunit)
	ON_UPDATE_COMMAND_UI(ID_WV_EDIT_DELETECURRENTUNIT, OnUpdateEditDeletecurrentunit)
    ON_WM_VSCROLL()
	ON_COMMAND(ID_WV_EDIT_COMPACTUNITS, OnEditCompactunits)
	//}}AFX_MSG_MAP
    ON_COMMAND_RANGE(ID_WV_EDIT_DELETEUNIT_UNCLASSIFIED, ID_WV_EDIT_DELETEUNIT_UNIT10, OnEditDeleteunitUnitX)
    ON_COMMAND_RANGE(ID_WV_EDIT_RECLASSIFY_UNCLASSIFIED, ID_WV_EDIT_RECLASSIFY_UNIT10, OnEditReclassifyUnitX)
    ON_UPDATE_COMMAND_UI_RANGE(ID_WV_EDIT_RECLASSIFY_UNCLASSIFIED, ID_WV_EDIT_RECLASSIFY_UNIT10, OnUpdateReclassifyUnitX)
    ON_MESSAGE(WM_USER_UNSELECTWF, UnHilightWF)
    ON_MESSAGE(WM_USER_SELECTWF, HilightWF)

    ON_NOTIFY(NF_SPK_NEW_REJECT, IDC_SPIKEDISPLAY_FRAME, OnNotifyNewReject)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewWaveforms diagnostics

#ifdef _DEBUG
void CViewWaveforms::AssertValid() const
{
    CFormView::AssertValid();
}

void CViewWaveforms::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}

CDocPowerNAP* CViewWaveforms::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDocPowerNAP)));
    return (CDocPowerNAP*)m_pDocument;
}


#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CViewWaveforms message handlers

void CViewWaveforms::OnInitialUpdate() 
{
    if (m_tool.m_hWnd == NULL)
        m_tool.Create(this);

    // Create the graphical window for SPIKE EVENT WAVEFORM DISPLAY
    // Spike Events Display
    ReplaceWindowControl(*this, m_wndSpikes, IDC_SPIKEDISPLAY_FRAME);
    
    // Size frame to fit the formview
    GetParentFrame()->RecalcLayout();
    ResizeParentToFit(FALSE);

    // Everything else is done in OnUpdate() which is automatically called from here
    CFormView::OnInitialUpdate();
}

BOOL CViewWaveforms::PreTranslateMessage(MSG* pMsg) 
{
    m_tool.RelayEvent(pMsg);

    return CFormView::PreTranslateMessage(pMsg);
}


// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: We are trying to animate, but we are currently "paused"
// Inputs:
//  see OnUpdate()
void CViewWaveforms::OnUpdateAnimatePaused(CView* pSender, LPARAM lHint, CObject* pHint)
{
    CDocPowerNAP *pDoc = GetDocument();         // done for convenience

    UINT nNumOfWaves = pDoc->m_icPlayBack.m_nWaveformCount;
    
    CMainFrameWaveforms * pFrame = static_cast<CMainFrameWaveforms *>(GetParentFrame());
    pFrame->StatusBarMessage("Animating");
    
    uint32 dwStopIndex = 0;              // 1 past the Last index that is valid
    
    uint32 dwEntityID = pDoc->GetActiveEntity();
    double dTime = pDoc->m_icPlayBack.m_dTime;
    
#pragma message ("OnUpdateAnimate only works with 1 file...")
    
    NsFile & rcFile = pDoc->m_icFileVector[0]->icFile;
    
    ns_RESULT ret = pDoc->GetIndexByTime(rcFile, dwEntityID, dTime, ns_BEFORE, &dwStopIndex);
    if (ret == ns_OK)
        ++dwStopIndex;  // because "end" is really 1 past the end, we need to be 1 past this
    
    
    UINT32 dwStartIndex;
    if (dwStopIndex > nNumOfWaves)
        dwStartIndex = dwStopIndex - nNumOfWaves;
    else
        dwStartIndex = 0;
    
    
    m_wndSpikes.DrawTheseSpikes(dwStartIndex, dwStopIndex);
    m_bAnimateIsRunning = false;
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: animate as "running"
// Inputs:
//  see OnUpdate()
void CViewWaveforms::OnUpdateAnimateRunning(CView* pSender, LPARAM lHint, CObject* pHint)
{
    CDocPowerNAP *pDoc = GetDocument();         // done for convenience

    if (m_bAnimateIsRunning)
        m_wndSpikes.AnimateToHere(pDoc->m_icPlayBack.m_dTime);
    else
    {
        m_wndSpikes.AnimateBegin(pDoc->m_icPlayBack.m_nWaveformCount, pDoc->m_icPlayBack.m_dTime);
        m_bAnimateIsRunning = true;
    }
}


// Author & Date:   Kirk Korver     26 Feb 2004
// Purpose: time to update the screen, and it is because we
//  are now "animating"
// Inputs:
//  see OnUpdate()
void CViewWaveforms::OnUpdateAnimate(CView* pSender, LPARAM lHint, CObject* pHint)
{
    CDocPowerNAP *pDoc = GetDocument();

    if ( (pDoc->AreThereSegments()) && (pDoc->IsActiveSegment()) )
    {
        if (pDoc->m_icPlayBack.m_enMode == CDocPowerNAP::PlayBack::PB_RUNNING)
            OnUpdateAnimateRunning(pSender, lHint, pHint);
        else
            OnUpdateAnimatePaused(pSender, lHint, pHint);
    }
}

// Author & Date:   Kirk Korver     26 Feb 2004
// Purpose: time to update the screen, and it is because it
//  is time to do a "normal" screen redraw...as opposed to animation
// Inputs:
//  see OnUpdate()
void CViewWaveforms::OnUpdateNormal(CView* pSender, LPARAM lHint, CObject* pHint)
{
    CDocPowerNAP *pDocument = GetDocument();
    CString szStatusBar = "Ready";
    CMainFrameWaveforms * pFrame = static_cast<CMainFrameWaveforms *>(GetParentFrame());
    pFrame->StatusBarMessage(szStatusBar.GetBuffer(0));

    // TRUE to show tooltips,FALSE to disable tooltips
    if (m_tool.m_hWnd)
    {
        if (pDocument->m_bTooltips)
            m_tool.Activate(true);
        else
            m_tool.Activate(false);
    }

    int32 nEntityID = 0;

    if ( (pDocument->AreThereSegments()) && (pDocument->IsActiveSegment()) )
    {
        // Calculate min and max of waveform values
        pDocument->SetMinMaxWfValues();

        // Set the min and max waveform values in the spike display
        nEntityID = pDocument->GetActiveEntity();
        m_wndSpikes.SetCurrEntity(nEntityID);
        m_wndSpikes.SetMinMaxWfVal(pDocument->m_dMaxWfVal);

        ChangeDisplayedUnits();
    }

    this->ShowWindow(SW_SHOW);
    m_wndSpikes.Invalidate();
    
    if ( (pDocument->AreThereSegments()) && (pDocument->IsActiveSegment()) )
    {
        // Make sure we still have waveforms
        if (pDocument->m_dMaxWfVal != 0)
        {
            CString szTemp;
            double dThreshold = pDocument->GetThreshold(nEntityID);
        }
        else if (pDocument->GetThreshold(nEntityID) != 0)
        {
            AfxMessageBox("Threshold out of range (no matching waveforms).\nThreshold will be reset to zero!", 
                MB_ICONEXCLAMATION, 0);
            pDocument->SetThreshold(nEntityID, 0);
            pDocument->RebuildSegListEntryAndUpdateViews(nEntityID, HINT_USER_NEWDATA);
        }
    }
}

void CViewWaveforms::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
    if (GetDocument()->m_icPlayBack.m_bPlayBackActive)
        OnUpdateAnimate(pSender, lHint, pHint);
    else
        OnUpdateNormal(pSender, lHint, pHint);
}


/*
void CViewWaveforms::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
    CDocPowerNAP *m_pDocument = GetDocument();
    DWORD dwCurrEntity = m_pDocument->GetActiveEntity();
    
    // This draw will "erase" the previous line
    m_wndSpikes.DrawThreshold();

    // Update the threshold in the document
    // Value has to be inverted because the slider goes top to bottom
    m_pDocument->m_dThreshold[dwCurrEntity] = (-1) * m_ThresholdSlider.GetPos();

    if (nSBCode == SB_ENDSCROLL)
    {
        // This action invalidates all wave forms
        m_pDocument->EraseWaveForms();

        // Get this view to update
        m_pDocument->UpdateAllViews(NULL);
    }
    else
    {
        m_wndSpikes.DrawThreshold();
    }

    CFormView::OnVScroll(nSBCode, nPos, pScrollBar);
}
*/

// Author & Date:   Angela Wang     10 June 2003
// Purpose: High-light the selected waveform, and restore previously selected
// Inputs: Index in SEGMENTLIST of selection
// Returns: Previously selected segment index
UINT32 CViewWaveforms::HilightWF( WPARAM wParam, LPARAM lParam)
{
   
    UINT32 dwWFIndex = DWORD( lParam );
    UINT32 dwPrevWFIndex = DWORD (wParam);
    
    m_wndSpikes.HilightSpike(dwWFIndex);
    m_wndSpikes.UnHilightSpike(dwPrevWFIndex);

    return dwPrevWFIndex;

}

// Remove the highlighting of selected waveform
void CViewWaveforms::UnHilightWF( WPARAM wParam, LPARAM lParam)
{

    INT32 nWFIndex = INT32( lParam );
    
    if (nWFIndex > 0)
        m_wndSpikes.UnHilightSpike(nWFIndex);

}
 
void CViewWaveforms::OnSelchangeWfCombo()
{
    ChangeDisplayedUnits();
}


void CViewWaveforms::OnBtnToolBarThresh()
{
    // Current threshold status
    BOOL bThreshold = GetDocument()->GetThresholding();
    
    // Save the opposite of previous value in doc
    GetDocument()->SetThresholding(!bThreshold);
}

void CViewWaveforms::OnWftbClip() 
{
    m_wndSpikes.SetRejecting(true);
}



// Hide or display waveforms toolbar
void CViewWaveforms::OnViewWfToolbar() 
{
    CMainFrameWaveforms * pFrame = static_cast<CMainFrameWaveforms *>(GetParentFrame());
    pFrame->ShowControlBar(&pFrame->m_icToolbar, (pFrame->m_icToolbar.GetStyle() &
                            WS_VISIBLE) == 0, FALSE);
}


// Check whether waveforms toolbar is visible
void CViewWaveforms::OnUpdateViewWfToolbar(CCmdUI* pCmdUI) 
{
    CMainFrameWaveforms * pFrame = static_cast<CMainFrameWaveforms *>(GetParentFrame());
    pCmdUI->SetCheck ((pFrame->m_icToolbar.GetStyle () & WS_VISIBLE) ? 1 : 0);
}


CViewFilesInUse * CViewWaveforms::GetFIUPtr()
{
    // Get CFilesInUse view
    POSITION pos = GetDocument()->GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetDocument()->GetNextView(pos);
        if (pView->IsKindOf(RUNTIME_CLASS(CViewFilesInUse)))
        {
            m_pFIUView = (CViewFilesInUse *) pView;
            return m_pFIUView;
        }
    }

    return NULL;
}


void CViewWaveforms::ShowOptSpkSort(int nView)
{
    CDocPowerNAP *pDocument = GetDocument();

    CPropSheetSpkSort icPropSheetSpkSort("Automatic Spike Sorting", NULL, nView, pDocument);

    if (icPropSheetSpkSort.DoModal() == IDOK)
        Invalidate();
}

void CViewWaveforms::OnSortingOptions() 
{
    ShowOptSpkSort(0);
}

void CViewWaveforms::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);

    // Is this window created?  On size is called several times earlier
    if (m_wndSpikes.m_hWnd)
    {
        CRect rWaves;
        m_wndSpikes.GetWindowRect(rWaves);
        ScreenToClient(rWaves);

        // There are 2 borders...one on the left, and one on the right
        int nWidth = cx - rWaves.left * 2;
        int nHeight = cy - rWaves.top * 2;

        m_wndSpikes.SetWindowPos(this, 0, 0, nWidth, nHeight, SWP_NOZORDER | SWP_NOMOVE);

        ShowScrollBar(SB_BOTH, false);  // i NEVER want scroll bars
    }
}

void CViewWaveforms::OnUpdateWftbThresholdbtn(CCmdUI* pCmdUI) 
{
    int nCheck = (GetDocument()->GetThresholding() ? 1 : 0);

    pCmdUI->SetCheck(nCheck);
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Figure out which units to display and change dsplay
void CViewWaveforms::ChangeDisplayedUnits()
{
    CString szStatusBar = "Ready";
    int32 nEntityID = GetDocument()->GetActiveEntity();
    CMainFrameWaveforms * pFrame = static_cast<CMainFrameWaveforms *>(GetParentFrame());
    int nSel =  pFrame->m_icCboUnits.GetCurSel();
    switch (nSel)
    {
    case WL_ALL:
        m_wndSpikes.SetDrawUnit(UNIT_ALL_MASK);
        szStatusBar.Format("Entity %d", nEntityID);
        break;
    case WL_UNCLASS:
        m_wndSpikes.SetDrawUnit(UNIT_UNCLASS_MASK);
        szStatusBar.Format("Entity %d - Unclassified Units", nEntityID);
        break;
    case WL_UNIT1:
        m_wndSpikes.SetDrawUnit(UNIT_1_MASK);
        szStatusBar.Format("Entity %d - Unit 1", nEntityID);
        break;
    case WL_UNIT2:
        m_wndSpikes.SetDrawUnit(UNIT_2_MASK);
        szStatusBar.Format("Entity %d - Unit 2", nEntityID);
        break;
    case WL_UNIT3:
        m_wndSpikes.SetDrawUnit(UNIT_3_MASK);
        szStatusBar.Format("Entity %d - Unit 3", nEntityID);
        break;
    case WL_UNIT4:
        m_wndSpikes.SetDrawUnit(UNIT_4_MASK);
        szStatusBar.Format("Entity %d - Unit 4", nEntityID);
        break;
    case WL_UNIT5:
        m_wndSpikes.SetDrawUnit(UNIT_5_MASK);
        szStatusBar.Format("Entity %d - Unit 5", nEntityID);
        break;
    case WL_UNIT6:
        m_wndSpikes.SetDrawUnit(UNIT_6_MASK);
        szStatusBar.Format("Entity %d - Unit 6", nEntityID);
        break;
    case WL_UNIT7:
        m_wndSpikes.SetDrawUnit(UNIT_7_MASK);
        szStatusBar.Format("Entity %d - Unit 7", nEntityID);
        break;
    case WL_UNIT8:
        m_wndSpikes.SetDrawUnit(UNIT_8_MASK);
        szStatusBar.Format("Entity %d - Unit 8", nEntityID);
        break;
    case WL_UNIT9:
        m_wndSpikes.SetDrawUnit(UNIT_9_MASK);
        szStatusBar.Format("Entity %d - Unit 9", nEntityID);
        break;
    case WL_UNIT10:
        m_wndSpikes.SetDrawUnit(UNIT_10_MASK);
        szStatusBar.Format("Entity %d - Unit 10", nEntityID);
        break;
    case WL_NOISE:
        m_wndSpikes.SetDrawUnit(UNIT_NOISE_MASK);
        szStatusBar.Format("Entity %d - Noise", nEntityID);
        break;

    default:
        ASSERT(0);
    }
//    m_wndSpikes.Invalidate();

    pFrame->StatusBarMessage(szStatusBar.GetBuffer(0));
}


// A new reject has been sent
void CViewWaveforms::OnNotifyNewReject(NMHDR *pNMHDR, LRESULT *pResult)
{
    SPK_NEW_REJECT * pReject = reinterpret_cast<SPK_NEW_REJECT *>(pNMHDR);
    GetDocument()->RejectActiveEntity(pReject->dRejectValue);
    m_wndSpikes.SetRejecting(false);    // we immediatly turn this off
}

void CViewWaveforms::OnWftbClipUpdate(CCmdUI* pCmdUI) 
{
    int nCheck = m_wndSpikes.GetRejecting() ? 1 : 0;
    pCmdUI->SetCheck(nCheck);
}

void CViewWaveforms::OnEditDeletecurrentunit() 
{
    UnitMasks enUnit = m_wndSpikes.GetDrawUnit();
    GetDocument()->DeleteUnitFromActiveSegment(enUnit);
}

void CViewWaveforms::OnEditDeleteunitUnitX(UINT nID) 
{
    // This is a mapping from menu ID's to Neuroshare Unit IDs
    static const struct Mapping
    {
        UINT nRsID; 
        UnitMasks enNsIdToDelete;
    } asMap[] = 
        {
            {ID_WV_EDIT_DELETEUNIT_UNCLASSIFIED,    UNIT_UNCLASS_MASK},
            {ID_WV_EDIT_DELETEUNIT_NOISE,           UNIT_NOISE_MASK},  
            {ID_WV_EDIT_DELETEUNIT_UNIT1,           UNIT_1_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT2,           UNIT_2_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT3,           UNIT_3_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT4,           UNIT_4_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT5,           UNIT_5_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT6,           UNIT_6_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT7,           UNIT_7_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT8,           UNIT_8_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT9,           UNIT_9_MASK},      
            {ID_WV_EDIT_DELETEUNIT_UNIT10,          UNIT_10_MASK},     
        };

    // Find the match, and then make it leave
    for (const Mapping * pMap = asMap; pMap != ARRAY_END(asMap); ++pMap)
    {
        if (pMap->nRsID == nID)
        {
            GetDocument()->DeleteUnitFromActiveSegment(pMap->enNsIdToDelete);
            return; // There is only 1 match
        }
    }

    ASSERT(0);  // should never get here
}

void CViewWaveforms::OnUpdateEditDeletecurrentunit(CCmdUI* pCmdUI) 
{
    // Only enable this menu if we are NOT on "all"
    UnitMasks enUnit = m_wndSpikes.GetDrawUnit();
    pCmdUI->Enable(enUnit == UNIT_ALL_MASK ? 0 : 1);
}

void CViewWaveforms::OnEditCompactunits() 
{
    GetDocument()->CompactUnitsFromActiveSegment();   // remove "holes" in the unit classifications
}

void CViewWaveforms::OnEditReclassifyUnitX(UINT nID)
{
    UnitMasks enFromUnit = m_wndSpikes.GetDrawUnit();

    // This is a mapping from menu ID's to Neuroshare Unit IDs
    static const struct Mapping
    {
        UINT nRsID; 
        UnitMasks enNewUnit;
    } asMap[] = 
    {
        {ID_WV_EDIT_RECLASSIFY_UNCLASSIFIED,    UNIT_UNCLASS_MASK},
        {ID_WV_EDIT_RECLASSIFY_NOISE,           UNIT_NOISE_MASK},  
        {ID_WV_EDIT_RECLASSIFY_UNIT1,           UNIT_1_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT2,           UNIT_2_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT3,           UNIT_3_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT4,           UNIT_4_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT5,           UNIT_5_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT6,           UNIT_6_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT7,           UNIT_7_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT8,           UNIT_8_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT9,           UNIT_9_MASK},      
        {ID_WV_EDIT_RECLASSIFY_UNIT10,          UNIT_10_MASK},     
    };

    for (const Mapping * pMap = asMap; pMap != ARRAY_END(asMap); ++pMap)
    {
        if (pMap->nRsID == nID)
        {
            GetDocument()->ReclassifyActiveSegment(enFromUnit, pMap->enNewUnit);
            return; // only 1 match
        }
    }

    ASSERT(0);  // never should happen
}

void CViewWaveforms::OnUpdateReclassifyUnitX(CCmdUI* pCmdUI)
{
    // Only enable this menu if we are NOT on "all"
    UnitMasks enUnit = m_wndSpikes.GetDrawUnit();
    pCmdUI->Enable(enUnit == UNIT_ALL_MASK ? 0 : 1);
}
