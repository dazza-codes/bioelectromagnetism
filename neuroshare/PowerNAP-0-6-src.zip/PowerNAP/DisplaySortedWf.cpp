// DisplaySortedWf.cpp : implementation file
//

#include "stdafx.h"
#include "PowerNAP.h"
#include "DisplaySortedWf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDisplaySortedWf

CDisplaySortedWf::CDisplaySortedWf()
{
    // Red psna
    m_penRedThick.CreatePen(PS_SOLID, 2, RED);
    m_penRedThin.CreatePen(PS_DOT, 1, RED);
 
    m_crBackColor  = BLACK;
    
    m_brushBack.CreateSolidBrush(m_crBackColor);
    

}

CDisplaySortedWf::~CDisplaySortedWf()
{
}


BEGIN_MESSAGE_MAP(CDisplaySortedWf, CWnd)
	//{{AFX_MSG_MAP(CDisplaySortedWf)
	ON_WM_CREATE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDisplaySortedWf message handlers

BOOL CDisplaySortedWf::PreCreateWindow(CREATESTRUCT& cs) 
{
    WNDCLASS wc;
    wc.style        = CS_OWNDC|CS_DBLCLKS; 
    wc.lpfnWndProc  = AfxWndProc;
    wc.cbClsExtra   = NULL;
    wc.cbWndExtra   = NULL;
    wc.hInstance    = AfxGetInstanceHandle(); 
    wc.hIcon        = NULL; 
    wc.hCursor      = (HICON) LoadImage(NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_DEFAULTCOLOR);
    wc.hbrBackground= m_brushBack; 
    wc.lpszMenuName = NULL; 
    wc.lpszClassName= "DisplaySortedWf";   

    if (!AfxRegisterClass( &wc )) 
        return FALSE;
    
    cs.lpszClass = "DisplaySortedWf";	
	return CWnd::PreCreateWindow(cs);
}

int CDisplaySortedWf::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    GetClientRect(&m_rectClient);
    m_nClientWidth = m_rectClient.Width();
    m_nClientHeight = m_rectClient.Height();

    // Get pointer to document
    CWnd *pWnd = GetParentFrame();
    m_pDoc = (CDocPowerNAP *)((CFrameWnd *)pWnd)->GetActiveDocument();
    	
	return 0;
}

void CDisplaySortedWf::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
    dc.SetBkColor (m_crBackColor);
    dc.FillRect(m_rectClient, &m_brushBack);

    // Draw Centroid Waveform
    DrawWaveform(dc);
	
	// Do not call CWnd::OnPaint() for painting messages
}//OnPaint() 



void CDisplaySortedWf::DrawWaveform(CDC &rCDC)
{
    // Check if centroid waveform exists
    if (m_pDoc->m_isSortInfo.m_icCtrWfList.empty())
        return;

    // Draw the waveform
    CTRWAVEFORMLIST::iterator it;

    it = m_pDoc->m_isSortInfo.m_icCtrWfList.begin();
    int nPtCount = it->GetNumOfPoints();
    CPoint *apPt =  new CPoint [nPtCount];// array to hold waveform points
    
    //Select pen color
    rCDC.SelectObject(*m_pDoc->GetBITUnitPen(m_dwCurrUnit));
    
    for (it = m_pDoc->m_isSortInfo.m_icCtrWfList.begin(); 
         it != m_pDoc->m_isSortInfo.m_icCtrWfList.end(); ++it)
    {
        // Plot waveform if it is the right unit for display
        if ( m_dwCurrUnit == it->GetUnitID())
        {
            // Display either just one unit or ALL units
            WAVEFORM aicWave;
            it->GetWave(aicWave);

            DWORD nPt = 0;
            for (WAVEFORM::iterator wit = aicWave.begin(); wit != aicWave.end(); ++wit)
            {
                apPt[nPt].x = (int) ((double) nPt * m_dXScaleFactor + 0.5); // horizontal pixels
                apPt[nPt].y = (int) (((double) m_nClientHeight / 2) - ((*wit) * m_dYScaleFactor)); 
                ++nPt;
            }
            rCDC.Polyline(apPt, nPt);//plot points
        }
    } // Next waveform

    // Clean up
    delete [] apPt;
}



void CDisplaySortedWf::SetAxisScaling(double dYMax, double dXMax)
{
    // Set vertical scale factor
    m_dYScaleFactor = m_nClientHeight / (2 * dYMax);

    // Set horizontal scale factor
    m_dXScaleFactor = m_nClientWidth / dXMax;
}

void CDisplaySortedWf::SetCurrEntity(uint32 dwEntity)
{
//    m_dwCurrEntity = dwEntity;
}

void CDisplaySortedWf::SetDrawUnit(uint32 dwUnit)
{
    // Set current unit to draw to the cluster number
    m_dwCurrUnit = dwUnit;
}
