///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: ViewRaster.h $
//
// Description   : interface of the CViewRaster class
//
// Authors       : Almut Branner
//
// $Date: 3/03/04 4:35p $
//
// $History: ViewRaster.h $
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:35p
// Updated in $/Neuroshare/PowerNAP
// Added Animation for playback
// Added XfmWorldToScreenX()
// 
// *****************  Version 14  *****************
// User: Abranner     Date: 2/10/04    Time: 10:17a
// Updated in $/Neuroshare/PowerNAP
// Changed unit selection to UINT instead of BYTE to include more units.
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 10/21/03   Time: 3:20p
// Updated in $/Neuroshare/PowerNAP
// Removed unneeded m_pDoc variables
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 10/17/03   Time: 4:01p
// Updated in $/Neuroshare/nsClassifier
// Chopped out unnecessary code.
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 10/17/03   Time: 2:06p
// Updated in $/Neuroshare/nsClassifier
// Fix analog channel view. Fixed problems with multiline mode.
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 10/17/03   Time: 1:03p
// Updated in $/Neuroshare/nsClassifier
// Turned raster combo box to change rate into buttons. Partially fixed
// single-to-multiline mode. Updating sorting algorithms.
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 10/16/03   Time: 2:09p
// Updated in $/Neuroshare/nsClassifier
// Removed unnecessary code.
// 
// *****************  Version 7  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 10/15/03   Time: 6:07p
// Updated in $/Neuroshare/nsClassifier
// Changed how units are drawn and the initialization of the view to deal
// with updating the view when necessary.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 10/08/03   Time: 1:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with scrolling (don't override PreCreateWindow()). Also
// fixed unit selection (Have to call OnPrepareDC() before using DPtoLP
// and so on). Removed code not needed.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 10/07/03   Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Implementation of raster without showing the data.
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 9/15/03    Time: 11:13a
// Updated in $/Neuroshare/nsClassifier
// Adjusted the Debug/Release versions of GetDocument()
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef VIEWRASTER_H_INCLUDED
#define VIEWRASTER_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "DocPowerNAP.h"
#include "QZoomView.h"

#include <algorithm>
#include <vector>
#include <list>
#include <deque>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CViewRaster window

static const WM_USER_CHANGELINEMODE = WM_USER+50;

class CViewRaster : public QZoomView
{
protected:
	CViewRaster();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewRaster)

// Attributes
public:
	CDocPowerNAP * GetDocument();

    enum { cbMAXCHANS = 160 };
    enum { cbMAXUNITS = 5 };

    enum Units { ALL = 0, UNCLASSIFIED, UNIT1, UNIT2, UNIT3, UNIT4, UNIT5, NOISE, CONT, 
                 MAXLINESPERCHANS };
    enum { FRAME_LABELWIDTH = 100 };
    enum { MAXLINECOUNT = cbMAXCHANS * MAXLINESPERCHANS };
    enum { TOPOFFSET = 7 };
    enum { MARGINRIGHT = 20 };

    bool m_bSingleLineFormat;   // TRUE means that all units/data is plotted in a single line
                                            // FALSE means to use a separate line for each
    bool m_bInitialized;

    UINT m_uFrameWidth;        // period of frame updating in 1ms intervals

    // This tells me details about a particular scan line
    struct LineInfo
    {
        UINT uIDSizeID;             // what is the enumerated size of this line?
        
        UINT nID;                   // What is the local ID 
        UINT nChannel;              // What is the channel for this line? (1 based)
        Units enUnit;               // What unit is visible on this line
        bool bIsDigital;            // TRUE means this is a digital channel

        UINT nType;                 // General purpose TYPE variable
    };

    typedef vector<LineInfo> VECT_LINEINFO;

// Operations
public:
    void OnChangeLineMode();                    // Update display when line mode changes

    void BuildVisibleLineInfo(VECT_LINEINFO & rLines);  // build line info's from current data
    void BuildArrays(const VECT_LINEINFO & rLines);     // build current data from line info

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewRaster)
	protected:
	virtual void OnDraw(CDC* pDC);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CViewRaster();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

    int XfmWorldToScreenX(double dTime);

    CToolBar *m_pToolBar;

    UINT m_uTotalWidth;
    UINT m_uTotalHeight;

    CFont m_fntLabel;           // font used for frame and buffer text

    UINT m_uChanAvailCount;                 // number of channels available for raster lines
    UINT m_uChanAvailList[cbMAXCHANS + 1];  // list array of channel id's of available channels
    INT  m_nChanScale[cbMAXCHANS + 1];      // continuous scaling for each raster line
    BOOL m_bChanUnits[cbMAXCHANS + 1];      // colored units enabled flag for each channelid
    BOOL m_bChanCont[cbMAXCHANS + 1];       // continuous enabled flag for each channelid
    BOOL m_bChanDigSer[cbMAXCHANS + 1];     // digital or serial events

    INT  m_nID2Line[cbMAXCHANS * MAXLINESPERCHANS + 1];  // mapping between channel/unit ids and line indices (-1 = no mapping)
    UINT m_uIDSizeID[cbMAXCHANS * MAXLINESPERCHANS + 1]; // enumerated size index of each raster line
    BOOL m_bIDEvents[cbMAXCHANS * MAXLINESPERCHANS + 1]; // spikes enabled flag for each channelid

    UINT m_uLineCount;                      // number of raster lines
    UINT m_uLine2ID[MAXLINECOUNT];          // channel id of each raster line
    UINT m_uLineOffsetY[MAXLINECOUNT];      // offset from top of frame and frame buffer to center of raster line
    UINT m_uLineSize[MAXLINECOUNT];         // size (in pixels) of each raster line

	int GetLine(UINT nPos);                 // Find the line for a certain y position
	UINT GetMaxWidth();

    void UpdateFrameBuffer(CDC & rcDC, UINT32 time);
    void UpdateChannelsAvailable();
    void InitRasterDisplay(); // Initialize Raster, meaning reset data and calculate offsets for lines.
    void PaintFrameDisplay(CDC & rcDC, UINT nStartLine, UINT nStopLine); // Repaint certain lines
                                                                         // on the screen

    class ChannelIterator
    {
    public:
        ChannelIterator(UINT * pChannelList, UINT nChannelCount);
        ~ChannelIterator();

        operator const bool () const;       // Are we done
        void operator++();                  // Advance

        UINT GetChannelNum();   // Get the ID/Number of the current channel (1 based)

    private:
        UINT m_nIndex;

        UINT const * const m_pChannels;
        UINT m_nChannelCount;
    };

    HICON m_hIcon;

protected:

    // Variables of interest during animation
    struct Animate
    {
        bool m_bDrawAnimate;        // TRUE means we want an animation draw; FALSE, regular
        bool m_bIsLineVisible;      // TRUE means the line is visible; FLASE, not
        int m_nLastX;               // This is the position (screen coordinates) of the last line draw

        Animate() : m_bDrawAnimate(false), m_bIsLineVisible(false) {}

    } m_isAnimate;

    void OnUpdateAnimate(CView* pSender, LPARAM lHint, CObject* pHint); // trying to animate
    void OnUpdateNormal(CView* pSender, LPARAM lHint, CObject* pHint);  // normal drawing

    void DrawAnimateLine(CDC & rcDC, double dTime, int nRasterOps);


	void InitLines();
	void ResetData();
    void RestartRasterPlot();       // Top level, clear and restart the painting with the current settings
	void ResetSingleLineRaster();   // Reset raster to single line display
	void OnChangePos(bool bUp);
    void OnChangeLineSize(int nSize);
	void OnChangeWidth(int nSize);

    BOOL OnToolTipNotify(UINT id, NMHDR* pTTTStruct, LRESULT* pResult);

    //////////////////////////////////////////////////////////////////////////
    // Drawing routines
    //////////////////////////////////////////////////////////////////////////

    void DrawLine(CDC & rcDC, UINT nLine);

    // Purpose: Draw the continuous waveforms right here
    void DrawLineContinuous(CDC & rcDC, UINT nTimepoint, UINT nLine, INT16 nContMin, INT16 nContMax);

    // Purpose: draw the events onto the line
    void DrawLineEvents(CDC & rcDC, UINT nTimepoint, UINT nLine, int nColor);

  	void DrawLabel(CDC & rcDC, UINT nLine);
    CString GetLabel(UINT nChannel, Units enUnit);

    //////////////////////////////////////////////////////////////////////////
    // Channel selection 
    //////////////////////////////////////////////////////////////////////////

    UINT m_anUnitSelections[cbMAXCHANS + 1];   // Array to hold information about which channels
                                            // are selected
	UINT m_nLastSelElec;                    // Indicating the last electrode that was selected
    UINT m_nPrevSelElec;                    // Indicates the previously selected electrode that
                                            // is different from the last
    UINT m_nLastSelUnit;                    // Indicating the last unit that was selected

    void UpdateUnitSelections();            // Update unit selection on all channels
	void UnselectAllChannels();
    void SelectAllChannels();
    void SelectUnit(int nChannel, Units enUnit);   // Select a unit on a channel
    void UnselectUnit(int nChannel, Units enUnit); // Unselect a unit on a channel
    void SelectLine(int nLine);                 // Select a line
    void UnselectLine(int nLine);               // Unselect a line
    void OnChangeChannels();                    // Update controls when the channels change
   
    //////////////////////////////////////////////////////////////////////////

    bool IsChannelVisible(UINT nChannel);       // TRUE means visible; FALSE, hidden
    bool IsUnitVisible(UINT nChannel, Units enUnit);  // TRUE means visible; FALSE, hidden

	UINT GetChannel4Line(UINT nLine);           // Get the channel corresponding to a line
    UINT GetChannel4ID(UINT nID);               // Get the channel corresponding to an ID
    Units GetUnit4Line(UINT nLine);             // Get the unit corresponding to a line
    Units GetUnit4ID(UINT nID);                 // Get the unit corresponding to an ID
	UINT GetID(UINT nChannel);                  // Get the starting (ID - 1) corresponding to a channel
	int  GetBITUnit(Units enUnit);              // Get the converted Unit ID
	bool UnitInData(int nChannel, Units enUnit);

    void HideChannel(UINT nChannel);            // Hide a channel if it is visible
    void UnHideChannel(UINT nChannel);          // Unhide a channel and add it to the bottom
    void UnHideChannelAndSetSize(UINT nChannel, UINT nSize); // Unhide a channel, add it to the bottom + set size
	void HideUnit(UINT nChannel, Units enUnit);   // Hide a unit of a particular channel
	void UnHideUnit(UINT nChannel, Units enUnit); // Unhide a unit of a particular channel
	void UnHideUnitAndSetSize(UINT nChannel, Units enUnit, UINT nSize); // Unhide a unit of a particular channel + set size



	// Generated message map functions
	//{{AFX_MSG(CViewRaster)
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnRefreshScreen();
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnUp();
	afx_msg void OnBtnDown();
	afx_msg void OnBtnMultiLineMode();
	afx_msg void OnBtnSingleLineMode();
	afx_msg void OnBtnChooser();
	afx_msg void OnBtnClearAll();
	afx_msg void OnBtnAddAll();
	afx_msg void OnBtnMin();
	afx_msg void OnBtnMax();
	afx_msg void OnBtnEvents();
	afx_msg void OnBtnCont();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnBtnBigger();
	afx_msg void OnBtnSmaller();
	afx_msg void OnBtnSort();
	afx_msg void OnBtnSortChannel();
	afx_msg void OnBtnSortMode();
	afx_msg void OnBtnSortUnits();
	afx_msg void OnBtnSelectAll();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewZoomfull();
	afx_msg void OnZoomIn();
	afx_msg void OnUpdateZoomIn(CCmdUI* pCmdUI);
	afx_msg void OnZoomInOne();
	afx_msg void OnZoomOut();
	afx_msg void OnUpdateZoomOut(CCmdUI* pCmdUI);
	afx_msg void OnZoomOutOne();
	afx_msg void OnZoomToWindow();
	afx_msg void OnHand();
	afx_msg void OnUpdateHand(CCmdUI* pCmdUI);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnBtnNarrower();
	afx_msg void OnBtnWider();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in .cpp
inline CDocPowerNAP* CViewRaster::GetDocument()
   { return (CDocPowerNAP*) m_pDocument; }
#endif


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // include guard
