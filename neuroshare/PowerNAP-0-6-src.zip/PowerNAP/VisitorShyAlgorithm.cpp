///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VisitorShyAlgorithm.cpp $
//
// Description   : interface for the VisitorShyAlgorithm class.
//
// Authors       : Almut Branner
//
// $Date: 3/04/04 9:38a $
//
// $History: VisitorShyAlgorithm.cpp $
// 
// *****************  Version 16  *****************
// User: Kkorver      Date: 3/04/04    Time: 9:38a
// Updated in $/Neuroshare/PowerNAP
// Use new GetEntity()
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:32p
// Updated in $/Neuroshare/PowerNAP
// Use the new GetSegment()
// 
// *****************  Version 14  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:46p
// Updated in $/Neuroshare/PowerNAP
// GetWave() no longer needs the EntityID passed to it
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 2/10/04    Time: 5:14p
// Updated in $/Neuroshare/PowerNAP
// Algorithm now only runs on subset and doesn't crash when no units are
// found.
// 
// *****************  Version 12  *****************
// User: Abranner     Date: 2/10/04    Time: 11:40a
// Updated in $/Neuroshare/PowerNAP
// Changed algorithm to allow processing of some units first and then all.
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 2/09/04    Time: 11:44a
// Updated in $/Neuroshare/PowerNAP
// Algorithm now initialized with an EntityID and variable names changed
// to be more meaningful.
// 
// *****************  Version 10  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 10/16/03   Time: 1:23p
// Updated in $/Neuroshare/nsClassifier
// Changed UnitIDs to BIT UnitIDs and made pens and colors global.
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 5  *****************
// User: Abranner     Date: 8/25/03    Time: 11:03a
// Updated in $/Neuroshare/nsClassifier
// Centroid class was replaced with Waveform class.
// 
// *****************  Version 4  *****************
// User: Abranner     Date: 8/21/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Calculating the representative waveform for each cluster now works.
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 8/21/03    Time: 2:26p
// Updated in $/Neuroshare/nsClassifier
// Spike sorting now works and has been optimized for speed.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "math.h"
#include "DocPowerNAP.h"
#include "PowerNAP.h"
#include "VisitorShyAlgorithm.h"
#include <time.h>                      // define time()
#include "randomc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define MIN(a, b)  (((a) < (b)) ? (a) : (b)) 


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bool VisitorShyAlgorithm::Visit(CDocPowerNAP & rcDoc)
{
    // Make sure that the current entity is really a segment
    if (rcDoc.GetIdxSegment(m_dwEntityID) < 0)
        return false;

    Segments & rSeg = rcDoc.GetSegment(m_dwEntityID);

    // Change mouse cursor to indicate that something is happening
    AfxGetApp()->DoWaitCursor(1);

    double dPenaltyFactors;
    int nNumOfPoints;
    double dN;
    int nPCA;

    int nMaxNumWaveforms = 1000;

    // Get data on the waveforms and other things
    int nNumOfTotalWaveforms = rSeg.size();
    int nNumOfWaveforms = MIN(rSeg.size(), nMaxNumWaveforms);
    int nNumOfPointsPerWave = rcDoc.GetNumOfPointsPerWave();

    // Initializing things
    switch(rcDoc.m_nNumPCA)
    {
        case 0:
            {
                nNumOfPoints = 2;
                dN = 30.0;
                nPCA = 1;
            }
            break;
        case 1:
            {
                nNumOfPoints = 3;
                dN = 45.0;
                nPCA = 1;
            }
            break;
        case 2:
            {
                nNumOfPoints = 5;
                dN = 60.0;
                nPCA = 1;
            }
            break;
        case 3:
            {
                nNumOfPoints = 10;
                dN = 80.0;
                nPCA = 1;
            }
            break;
        case 4:
            {
                nNumOfPoints = 20;
                dN = 150.0;
                nPCA = 1;
            }
            break;
        case 5:
            {
                nNumOfPoints = nNumOfPointsPerWave;
                dN = 300.0;
                nPCA = 0;
            }
            break;
        default:
            {
                nNumOfPoints = 5;
                dN = 60.0;
                nPCA = 1;
            }
    }

    switch(rcDoc.m_nPenaltyFactor)
    {
        case 0:
            dPenaltyFactors = 0.5;
            break;
        case 1:
            dPenaltyFactors = 0.7;
            break;
        case 2:
            dPenaltyFactors = 0.9;
            break;
        case 3:
            dPenaltyFactors = 1.0;
            break;
        case 4:
            dPenaltyFactors = 1.2;
            break;
        case 5:
            dPenaltyFactors = 1.5;
            break;
        case 6:
            dPenaltyFactors = 2.0;
            break;
        default:
            dPenaltyFactors = 1.0;
    }

    dN = dN / dPenaltyFactors;

    int nNumOfUnits = ceil((double) nNumOfWaveforms / dN);
    if (nNumOfUnits > 10)
        nNumOfUnits = 10;

    // Copy the waveforms with all data points into a matrix
    Matrix SampledWaveforms(nNumOfWaveforms, nNumOfPointsPerWave, 0.0);
    int nCount = 0;

    int nSkip = nNumOfTotalWaveforms / nNumOfWaveforms;

    for (SEGMENTLIST::iterator it = rSeg.begin(); nCount < nNumOfWaveforms; it = it + nSkip)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);
        ASSERT(aicWave.size() > 0);

        for (UINT nPt = 0; nPt < nNumOfPointsPerWave; ++nPt)
        {
            SampledWaveforms(nCount, nPt) = aicWave[nPt];  
        }
        ++nCount;
    }

    // Principal component analysis
    Matrix PC(nNumOfPointsPerWave, nNumOfPointsPerWave, 0.0);
    Matrix Score(nNumOfWaveforms, nNumOfPointsPerWave, 0.0);

    princomp(&PC, &Score, SampledWaveforms);

    // Copy the first few data points of the pc score into a matrix
    Score.resize(nNumOfWaveforms, nNumOfPoints);  // This just clips it. It does not erase data.

    SampledWaveforms.resize(nNumOfWaveforms, nNumOfPoints);
    SampledWaveforms.null();

    SampledWaveforms = Score;

    Score.free();

    // Fuzzy c-means sorting
    Matrix mu(nNumOfUnits, nNumOfPoints, 0.0);
    Matrix U(nNumOfUnits, nNumOfWaveforms, 0.0);
    Vector options(4);

    options[0] = 2;
    options[1] = 20;
    options[2] = 1;
    options[3] = 0;

    Vector obj_fcn(options[1]);  // Everything is initialized to zero

    FuzzyCMeans(&mu, &U, &obj_fcn, SampledWaveforms, nNumOfUnits, options);

    options.free();

    // Estimate error covariance matrix
    Matrix diffs(nNumOfUnits * nNumOfWaveforms, nNumOfPoints, 0.0);  // Distance to cluster centers

    DistClusterCenters(&diffs, SampledWaveforms, mu);

    U = ~U;

    double *Sigma;
    Sigma = new double[nNumOfPoints * nNumOfPoints * nNumOfUnits];
    Matrix sumUcol(1, nNumOfUnits, 0.0);  // U(n, g)

    SumCols(&sumUcol, U);

    int i;
    int j;
    int k;

    UpdateSigma(Sigma, U, diffs, sumUcol);

    Matrix Pj(nNumOfUnits, nNumOfUnits, 0.0);

    Pj.diag() = (Vector) sumUcol[0];
    Pj /= sumUcol.sum();

    sumUcol.free();

    // EM sorting
    double nu = 20.0;  // Initial nu value
    Matrix Z(nNumOfWaveforms, nNumOfUnits, 0.0);
    Matrix M(nNumOfWaveforms, nNumOfUnits, 0.0);

    TRACE("First algorithm\n");
    // 10 iterations of regular EM
   if (!sac_t_algorithm(&Pj, &mu, Sigma, &nu, &Z, &U, &M, dN, 10, "regular", SampledWaveforms))
       return false;

    TRACE("Second algorithm\n");
    // modified Mario algorithm
    if (!sac_t_algorithm(&Pj, &mu, Sigma, &nu, &Z, &U, &M, dN, 500, "agglomerate", SampledWaveforms))
        return false;

    TRACE("Third algorithm\n");
    // 10 iterations of regular EM
    if (!sac_t_algorithm(&Pj, &mu, Sigma, &nu, &Z, &U, &M, dN, 10, "regular", SampledWaveforms))
        return false;

    nNumOfUnits = Pj.rowno();

    // Now classify ALL the data

    // Calculate means and covariances in full waveforms space
    // Copy the waveforms with all data points into a matrix
    Matrix Waveforms(nNumOfTotalWaveforms, nNumOfPointsPerWave, 0.0);

    nCount = 0;
    for (it = rSeg.begin(); nCount < nNumOfTotalWaveforms; ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        for (UINT nPt = 0; nPt < nNumOfPointsPerWave; ++nPt)
        {
            Waveforms(nCount, nPt) = aicWave[nPt];
        }
        ++nCount;
    }

    Matrix meanWaveformsCol(1, nNumOfPointsPerWave, 0.0);

    MeanCols(&meanWaveformsCol, Waveforms);

    Matrix ones(nNumOfUnits, 1, 1.0);
    Matrix tempMu = mu * ~((Matrix) PC[mslice(0, 0, nNumOfPointsPerWave, nNumOfPoints)]) + 
        ones * meanWaveformsCol;

    ones.free();
    meanWaveformsCol.free();

    mu.resize(tempMu.rowno(), tempMu.colno());
    mu.null();
    mu = tempMu;

    tempMu.free();

    diffs.resize(nNumOfWaveforms, nNumOfPointsPerWave);
    diffs.null();
    
    delete [] Sigma;
    Sigma = new double[nNumOfPointsPerWave * nNumOfPointsPerWave * nNumOfUnits];  // nNumOfUnits has changed

    Matrix ZU(nNumOfWaveforms, nNumOfUnits, 0.0);
    Matrix ZUcol(nNumOfWaveforms, 1, 0.0);
    Matrix tempDiffs(nNumOfWaveforms, nNumOfPointsPerWave, 0.0);
    Matrix tempProd(nNumOfPointsPerWave, nNumOfPointsPerWave, 0.0);

    for (i = 0; i < nNumOfWaveforms; ++i)
        for (j = 0; j < nNumOfUnits; ++j)
            ZU(i, j) = Z(i, j) * U(i, j);

    SampledWaveforms.resize(nNumOfWaveforms, nNumOfPointsPerWave);
    SampledWaveforms.null();
    nCount = 0;

    for (it = rSeg.begin(); nCount < nNumOfWaveforms; it = it + nSkip)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);
        ASSERT(aicWave.size() > 0);

        for (UINT nPt = 0; nPt < nNumOfPointsPerWave; ++nPt)
        {
            SampledWaveforms(nCount, nPt) = aicWave[nPt];  
        }
        ++nCount;
    }

    for (k = 0; k < nNumOfUnits; ++k)
    {
        ones.resize(nNumOfWaveforms, 1);
        ones = 1.0;

        diffs = (Matrix) SampledWaveforms[mslice(0, 0, nNumOfWaveforms, nNumOfPointsPerWave)] 
                - ones * (Matrix) mu[mslice(k, 0, 1, nNumOfPointsPerWave)];

        ones.resize(1, nNumOfPointsPerWave);
        ones = 1.0;

        ZUcol = ZU[mslice(0, k, nNumOfWaveforms, 1)];
        tempDiffs = ZUcol * ones;

        for (i = 0; i < nNumOfWaveforms; ++i)
            for (j = 0; j < nNumOfPointsPerWave; ++j)
                tempDiffs(i, j) = tempDiffs(i, j) * diffs(i, j);

        tempProd = ~tempDiffs * diffs;

        for (i = 0; i < nNumOfPointsPerWave; ++i)
            for (j = 0; j < nNumOfPointsPerWave; ++j)
                *(Sigma + (i * nNumOfPointsPerWave + j) * nNumOfUnits + k) = tempProd(i, j) / ZUcol.sum();
    }  // end k
    
    SampledWaveforms.free();
    ZUcol.free();
    tempDiffs.free();
    tempProd.free();

    if (nNumOfTotalWaveforms != nNumOfWaveforms)
    {
        Z.resize(nNumOfTotalWaveforms, nNumOfUnits);
        Z.null();
        U.resize(nNumOfTotalWaveforms, nNumOfUnits);
        U.null();
    }
    
    TRACE("All waveforms algorithm\n");
    // 1 iterations of regular EM - full Waveform
    sac_t_algorithm(&Pj, &mu, Sigma, &nu, &Z, &U, &M, dN, 1, "regular", Waveforms);

    Matrix ClusterCenters = mu;
    double *ClusterSigma;
    ClusterSigma = new double[nNumOfPointsPerWave * nNumOfPointsPerWave * nNumOfUnits];

    memcpy(ClusterSigma, Sigma, (nNumOfPointsPerWave * nNumOfPointsPerWave * nNumOfUnits) * sizeof(double));
    
    Matrix ClusterProportions = Pj;

    // Take max of cols but here rows because of transpose.
    Vector Y(nNumOfTotalWaveforms);
    Vector Classification(nNumOfTotalWaveforms);

    for (i = 0; i < nNumOfTotalWaveforms; ++i)
    {
        Y[i] = ((Vector) Z[i]).max();
        for (j = 0; j < nNumOfUnits; ++j)
        {
            if (Z(i, j) == Y[i])
            {
                Classification[i] = j + 1;
                break;
            }
        }
    }

    // Calculate cluster center for comparison
    PC.resize(nNumOfPointsPerWave, nNumOfPointsPerWave);
    Score.resize(nNumOfTotalWaveforms, nNumOfPointsPerWave);
    PC.null();
    Score.null();

    princomp(&PC, &Score, Waveforms);

    rcDoc.m_isSortInfo.m_icCtrPCList.clear();
    rcDoc.m_isSortInfo.m_icCtrWfList.clear();
    rcDoc.GetEntity(m_dwEntityID).m_bRulesDefined = true;

    int nPCCnt = nNumOfPointsPerWave;
    Matrix meanColsWF(1, Waveforms.colno(), 0.0);
    MeanCols(&meanColsWF, Waveforms);
    Matrix center(1, nPCCnt, 0.0);

    for (int nCtr = 0; nCtr < nNumOfUnits; ++nCtr)
    {
        center = ((Matrix) ClusterCenters[mslice(nCtr, 0, 1, Waveforms.colno())] - meanColsWF)
                  * (Matrix) PC[mslice(0, 0, PC.rowno(), nPCCnt)];

        WAVEFORM icCtrWaveform;
        WAVEFORM icCtrCoord;

        // Transform centroid into waveform space
		for (int nPt = 0; nPt < nPCCnt; ++nPt)
		{
            icCtrCoord.push_back(center(0, nPt));

            double dTemp = 0;

			for (int nn = 0; nn < nPCCnt; ++nn)
			{
                dTemp += center(0, nn) * PC(nPt, nn);
			}

            icCtrWaveform.push_back(dTemp + meanColsWF(0, nPt));	//in uVolts	
		}

        // Save centroid waveforms in document
        int nNsUnit = pow(2, nCtr + 1);

        // Save centroids in PC space in document
        Centroid Ctr(nCtr + 1, icCtrCoord);
        rcDoc.m_isSortInfo.m_icCtrPCList.push_back(Ctr);

        Centroid CtrWf(nNsUnit, icCtrWaveform);
        rcDoc.m_isSortInfo.m_icCtrWfList.push_back(CtrWf);
    }//  next centroid

    // decide which clusters contain garbage
    if (nNumOfUnits > 1)
    {
        Vector f(nNumOfUnits);
        for (i = 0; i < nNumOfUnits; ++i)
        {
            Matrix CurrentSigma(nNumOfPointsPerWave, nNumOfPointsPerWave, 0.0);
            GetCurrentSigma(&CurrentSigma, Sigma, i, nNumOfPointsPerWave, nNumOfUnits);
            Matrix tempPC = PC[mslice(0, 1, PC.rowno(), 2)];
            Matrix sig1 = ~tempPC * (CurrentSigma * tempPC);
            f[i] = sig1(0, 0);
            for (j = 1; j < sig1.rowno(); ++j)
                f[i] = f[i] * sig1(j, j);
        }

        // Calculate median of f
        double nMedian;
        {
            Vector temp1 = f;
            Vector Sorted = f;
            for (i = 0; i < nNumOfUnits; ++i)
            {
                Sorted[i] = temp1.min();
                for (j = 0; j < nNumOfUnits; ++j)
                {
                    if (temp1[j] == Sorted[i])
                    {
                        temp1[j] = temp1.max() + 1;
                        break;
                    }
                }
            }

            int nMid = Sorted.size() / 2;
            if (Sorted.size() % 2 == 0)
                nMedian = (Sorted[nMid] + Sorted[nMid - 1]) / 2.0;
            else
                nMedian = Sorted[nMid];
        }

        Vector Garbage(nNumOfUnits);
        int nCount = 0;
        for (i = 0; i < nNumOfUnits; ++i)
        {
            if (f[i] > 10.0 * nMedian)
            {
                Garbage[nCount] = i;
                Classification[nCount] = NOISE;
                ++nCount;
            }
        }
        Garbage.resize(nCount);

        TRACE("Number of Garbage units: %d\n", nCount);

    }  // end if g

    delete [] Sigma;

    // Get rid of outliers
    ZU.resize(nNumOfTotalWaveforms, nNumOfUnits);
    ZU.null();

    for (i = 0; i < nNumOfTotalWaveforms; ++i)
        for (j = 0; j < nNumOfUnits; ++j)
            ZU(i, j) = Z(i, j) * U(i, j);

    nCount = 0;
    for (i = 0; i < nNumOfTotalWaveforms; ++i)
    {
        Vector rowZU = ZU[i];
        if (rowZU.max() < 0.5)
        {
            Classification[i] = NOISE;
            ++nCount;
        }
    }
    TRACE("Number of outlier units: %d\n", nCount);

    TRACE("nu = %f\n", nu);
    TRACE("NumUnits = %d\n", nNumOfUnits);

    // Set the unit ID for each channel
    nCount = 0;
    DWORD temp;

    for (it = rSeg.begin(); nCount < nNumOfTotalWaveforms; ++it)
    {
        temp = Classification[nCount];
        it->SetUnitID(rcDoc.GetBITUnit(temp));
        ++nCount;
    }

    rcDoc.UpdateAllViews(NULL);

    delete [] ClusterSigma;

    // Change mouse cursor back to normal
    AfxGetApp()->DoWaitCursor(0);

    return true;
}


void VisitorShyAlgorithm::FuzzyCMeans(Matrix *center, Matrix *U, Vector *obj_fcn,
                                      Matrix data, int cluster_n, Vector options)
{
    int data_n = data.rowno();
    int in_n = data.colno();

    int expo = options[0];
    int max_iter = options[1];
    int min_impro = options[2];
    int display = options[3];

    Vector objfcn(max_iter);  // Everything is initialized to zero

    initfcm(U, cluster_n, data_n);

    // Main loop
    for (int iter = 0; iter < max_iter; ++iter)
    {
        double dObj_fcn;

        stepfcm(U, center, &dObj_fcn, data, (*U), cluster_n, expo);

        objfcn[iter] = dObj_fcn;
        // check termination condition
        if (iter > 0)
        {
            if (abs(objfcn[iter] - objfcn[iter - 1]) < min_impro)
                break;
        }
    }  // next iter

    objfcn.resize(iter + 1, 1);

    // Set returm values
    *obj_fcn = objfcn;
}

void VisitorShyAlgorithm::initfcm(Matrix *U, int cluster_n, int data_n)
{
    Matrix col_sum(1, data_n, 0.0);

    int i;
    int j;

    long int seed = time(0);  // random seed
  
    // choose one of the random number generators:
    TRanrotBGenerator rg(seed);  // make instance of random number generator
    double dRandom;

    for (i = 0; i < cluster_n; ++i)
    {
        for (j = 0; j < data_n; ++j)
        {
            dRandom = rg.Random();
            (*U)(i, j) = dRandom;
        }
    }

    SumCols(&col_sum, (*U));

    for (i = 0; i < cluster_n; ++i)
        for (j = 0; j < data_n; ++j)
            (*U)(i, j) = (*U)(i, j) / col_sum(0, j);
}

void VisitorShyAlgorithm::distfcm(Matrix *out, Matrix center, Matrix data)
{
    int i;
    int j;
    int k;
    double dTemp = 0.0;

    if (data.colno() > 1)
    {
        for (k = 0; k < center.rowno(); ++k)
        {
            for (i = 0; i < data.rowno(); ++i)
            {
                dTemp = 0.0;
                for (j = 0; j < data.colno(); ++j)
                {
                    dTemp = dTemp + pow((data(i, j) - center(k, j)), 2.0);
                }
                (*out)(k, i) = sqrt(dTemp);
            }
        }
    }
    else
    {
        // TODO: Have to implement eventually
    }
}

void VisitorShyAlgorithm::stepfcm(Matrix *U_new, Matrix *center, double *obj_fcn, 
                                  Matrix data, Matrix U, int cluster_n, int expo)
{
    Matrix mf(cluster_n, data.rowno(), 0.0);

    int i;
    int j;
    
    for (i = 0; i < cluster_n; ++i)
        for (j = 0; j < data.rowno(); ++j)
            mf(i, j) = pow(U(i, j), expo);

    Matrix mfsumrow(cluster_n, 1, 0.0);

    SumRows(&mfsumrow, mf);

    *center = mf * data;

    for (i = 0; i < cluster_n; ++i)
        for (j = 0; j < data.colno(); ++j)
            (*center)(i, j) = (*center)(i, j) / mfsumrow(i, 0);

    Matrix dist(cluster_n, data.rowno(), 0.0);

    distfcm(&dist, (*center), data);

    double dTemp = 0.0;
    for (i = 0; i < cluster_n; ++i)
        for (j = 0; j < data.rowno(); ++j)
            dTemp = dTemp + pow(dist(i, j), 2.0) * mf(i, j);

    *obj_fcn = dTemp;

    for (j = 0; j < data.rowno(); ++j)
        for (i = 0; i < cluster_n; ++i)
            (*U_new)(i, j) = pow(dist(i, j), (-2.0 / (expo - 1)));

    Matrix tmpcolsum(1, data.rowno(), 0.0);
    SumCols(&tmpcolsum, (*U_new));

    for (i = 0; i < cluster_n; ++i)
        for (j = 0; j < data.rowno(); ++j)
            (*U_new)(i, j) = (*U_new)(i, j) / tmpcolsum(0, j);
}


bool VisitorShyAlgorithm::sac_t_algorithm(Matrix *Pj, Matrix *mu, double *Sigma, 
         double *nu, Matrix *Z, Matrix *U, Matrix *M, int N, int max_iteration, 
         CString method, Matrix waveforms)
{
    // Initializing
    int nNumOfWaveforms = waveforms.rowno();
    int nNumOfPoints = waveforms.colno();
    int nNumOfUnits = (*Pj).rowno();

    Matrix Pjopt;
    Matrix muopt;
    double *Sigma_optimal = NULL;
    double nuopt;
    Matrix Zopt;
    Matrix Uopt;
    Matrix Mopt;

    // Estimate error covariance matrix
    Matrix diffs(nNumOfUnits * nNumOfWaveforms, nNumOfPoints, 0.0);  // Distance to cluster centers

    DistClusterCenters(&diffs, waveforms, *mu);

    int i;
    int j;

    double delta = 1.0;
    double Lmax = -2147483648.0;
    double L = Lmax;
    double nu_old = *nu;

    Matrix detSigma(nNumOfUnits, nNumOfUnits, 0.0);

    (*M).resize(nNumOfWaveforms, nNumOfUnits);
    (*M).null();

    MahalanobisDistances(M, &detSigma, diffs, Sigma);

    diffs.free();
   
    Matrix Prob(nNumOfWaveforms, nNumOfUnits, 0.0);

    UpdateProbabilities(&Prob, *M, detSigma, *nu, nNumOfPoints);

    detSigma.free();

    int iter = 0;  // iteration counter

    Matrix Lhist;
    Matrix ghist;
    Matrix ZU(nNumOfWaveforms, nNumOfUnits, 0.0);

    // Start algorithm
    while ((nNumOfUnits >= 1) && (iter < max_iteration))
    {
        while (((delta > 0.1) || (abs(*nu - nu_old) > exp(-1))) && (iter < max_iteration))
        {
            ++iter;

            // E step
            for (i = 0; i < nNumOfWaveforms; ++i)
                for (j = 0; j < nNumOfUnits; ++j)
                    (*U)(i, j) = (*nu + nNumOfPoints) / (*nu + (*M)(i, j));

            Matrix SumZ(nNumOfWaveforms, 1, 0.0);

            *Z = Prob * (*Pj);

            SumRows(&SumZ, *Z);

            for (i = 0; i < nNumOfWaveforms; ++i)
            {
                for (j = 0; j < nNumOfUnits; ++j)
                {
                    (*Z)(i, j) = (*Z)(i, j) / SumZ(i, 0);
                    ZU(i, j) = (*Z)(i, j) * (*U)(i, j);
                }
            }

            SumZ.free();

            // M step
            if (method == "agglomerate")
            {
                double deltaP = 1.0;
                int gtemp = nNumOfUnits;
                Matrix Pjold(nNumOfUnits, nNumOfUnits, 0.0);
                Matrix temp1(nNumOfWaveforms, nNumOfUnits, 0.0);
                Matrix temp2(nNumOfWaveforms, 1, 0.0);

                while (deltaP > pow(10, -4))
                {
                    Pjold = *Pj;
                    temp1 = Prob * (*Pj);
                    temp2.null();

                    SumRows(&temp2, temp1);
                    
                    for (j = 0; j < nNumOfUnits; ++j)
                    {
                        if ((*Pj)(j, j) > 0)
                        {
                            double dTemp = 0.0;

                            for (i = 0; i < nNumOfWaveforms; ++i)
                            {
                                dTemp = dTemp + temp1(i, j) / temp2(i, 0);
                            }
                            dTemp = dTemp - (double) N / 2;

                            if (dTemp < 0)
                                dTemp = 0;

                            (*Pj)(j, j) = dTemp / ((double) nNumOfWaveforms - 
                                              (double) N / 2 * gtemp);

                            if ((*Pj)(j, j) == 0)
                            {
                                temp2.null();

                                SumRows(&temp2, (Matrix) Prob * (*Pj));
                                gtemp = gtemp - 1;
                            }
                        }
                    }
                    deltaP = ((*Pj) - Pjold).norm1();
                }
            }
            else if (method == "regular")
            {
                Matrix temp1 = Prob * (*Pj);
                Matrix temp2(nNumOfWaveforms, 1, 0.0);  // Sum of rows

                SumRows(&temp2, temp1);

                (*Pj).resize(nNumOfUnits, nNumOfUnits);
                (*Pj).null();

                for (j = 0; j < nNumOfUnits; ++j)
                    for (i = 0; i < nNumOfWaveforms; ++i)
                        (*Pj)(j, j) = (*Pj)(j, j) + temp1(i, j) / temp2(i, 0);  // Sum of cols

                (*Pj) /= nNumOfWaveforms;
            }

            *mu = ~ZU * waveforms;

            // Sum of cols
            Matrix sumZU(1, nNumOfUnits, 0.0);

            SumCols(&sumZU, ZU);

            for (i = 0; i < nNumOfUnits; ++i)
                for (j = 0; j < nNumOfPoints; ++j)
                    (*mu)(i, j) = (*mu)(i, j) / sumZU(0, i);

            // Update DOF parameter

            // digamma, here for single value
            Matrix x(1, 1, ((*nu) + (double) nNumOfPoints) / 2);
            Matrix di(1, 1, 0.0);
            
            digamma(&di, x);

            x.free();
      
            Matrix X(nNumOfWaveforms, nNumOfUnits, 0.0);

            for (i = 0; i < nNumOfWaveforms; ++i)
                for (j = 0; j < nNumOfUnits; ++j)
                    X(i, j) = (*Z)(i, j) * (di(0, 0) + log(2.0 / ((*nu) + (*M)(i, j))) - 
                              (*U)(i, j));

            di.free();
            
            double sumZ = (*Z).sum();
            double sumX = X.sum();
            double y = -1.0 * X.sum() / (*Z).sum();
    
            X.free();
            
            double temp = 1.0 / (y + log(y) - 1);
            nu_old = (*nu);

            *nu = MIN(100, 2.0 * temp + 0.0416 * (1 + erf(0.6594 * log(2.1971 * temp))));

            // Calculate covariance
            diffs.resize(nNumOfUnits * nNumOfWaveforms, nNumOfPoints);
            diffs.null();

            DistClusterCenters(&diffs, waveforms, *mu);

            UpdateSigma(Sigma, ZU, diffs, sumZU);

            sumZU.free();

            (*M).resize(nNumOfWaveforms, nNumOfUnits);
            (*M).null();

            detSigma.resize(nNumOfUnits, nNumOfUnits);
            detSigma.null();

            MahalanobisDistances(M, &detSigma, diffs, Sigma);

            // Update probabilities
            UpdateProbabilities(&Prob, *M, detSigma, *nu, nNumOfPoints);

            // switch method
            if (method == "agglomerate")
            {
                // cycle is done, purge empty components
                Vector tokeep(nNumOfUnits);

                int no = (*Pj).rowno();
                int count = 0;

                for (i = 0; i < no; ++i)
                {
                    if ((*Pj)(i, i) != 0)
                    {
                        tokeep[count] = i;
                        ++count;
                    }
                }

                // I did not find any units
                if (count == 0)
                {
                    TRACE("No units found\n");
                    return false;
                }

                tokeep.resize(count);

                if (count < nNumOfUnits)
                {
                    nNumOfUnits = count;
                    ResizeData(Pj, mu, &Prob, Z, U, &ZU, M, Sigma, tokeep, count);
                }

                tokeep.free();

                // Update and compare likelihood
                double oldL = L;

                // Mario expression
                Matrix tempProb = Prob * (*Pj);
                Matrix tempProbRow(nNumOfWaveforms, 1, 0.0);

                SumRows(&tempProbRow, tempProb);

                for (i = 0; i < nNumOfWaveforms; ++i)
                    tempProbRow(i, 0) = log(tempProbRow(i, 0));

                tempProb.free();

                Matrix logPj = *Pj;

                for (i = 0; i < nNumOfUnits; ++i)
                    logPj(i, i) = log((double) nNumOfWaveforms * (*Pj)(i, i) / 12);

                L = tempProbRow.sum() - ((double) N/2 * logPj.sum() + 
                    (double) nNumOfUnits/2 * log((double) nNumOfWaveforms/12) + 
                    (double) nNumOfUnits * (N+1)/2);  // result ok

                tempProbRow.free();

                Lhist.resize(Lhist.rowno() + 1, 1);
                Lhist(Lhist.rowno() - 1, 0) = L;

                ghist.resize(ghist.rowno() + 1, 1);
                ghist(ghist.rowno() - 1, 0) = nNumOfUnits;

                delta = L - oldL;
                if (delta < 0)
                    delta = -delta;
            }  // case; here if method "agglomerate"
        }  // while delta
            
//        TRACE("iter %d\n", iter);

        if (method == "agglomerate")
        {
            if (L > Lmax)
            {
                if (Sigma_optimal)
                {
                    delete [] Sigma_optimal;
                    Sigma_optimal = NULL;
                }
                Sigma_optimal = new double[nNumOfPoints * nNumOfPoints * nNumOfUnits];

                memcpy(Sigma_optimal, Sigma, (nNumOfPoints * nNumOfPoints * nNumOfUnits) * sizeof(double));

                Lmax = L;
                Pjopt = *Pj;
                muopt = *mu;
                nuopt = *nu;
                Zopt = *Z;
                Uopt = *U;
                Mopt = *M;
            }
            else
                break;

            // purge smallest component
            Vector PjDiag = (*Pj).diag();
            double Y = PjDiag.min();
            int ind;
            for (i = 0; i < nNumOfUnits; ++i)
            {
                if ((*Pj)(i, i) == Y)
                {
                    ind = i;
                    break;
                }
            }

            Vector tokeep(nNumOfUnits - 1);
            int count = 0;
            for (i = 0; i < nNumOfUnits; ++i)
            {
                if (i != ind)
                {
                    tokeep[count] = i;
                    ++count;
                }
            }
        
            nNumOfUnits = count;
            ResizeData(Pj, mu, &Prob, Z, U, &ZU, M, Sigma, tokeep, count);

            tokeep.free();
            delta = 1.0;
        }  // if method or case
    }  // while g

//    TRACE("Iterations: %d\n", iter);

    if (method == "agglomerate")
    {
        if (Sigma_optimal != NULL)
            memcpy(Sigma, Sigma_optimal, (nNumOfPoints * nNumOfPoints * nNumOfUnits) * sizeof(double));
        else
            return false;

        *mu = muopt;
        *Pj = Pjopt;
        *nu = nuopt;
        *Z = Zopt;
        *U = Uopt;
        *M = Mopt;
    }

    delete [] Sigma_optimal;
    Sigma_optimal = NULL;

    return true;
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Implementation of the digamma function
void VisitorShyAlgorithm::digamma(Matrix *d, Matrix x)
{
    *d = x;

    for (int i = 0; i < x.rowno(); ++i)
    {
        for (int j = 0; j < x.colno(); ++j)
        {
            (*d)(i, j) = digammas(x(i, j));
        }
    }
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Implementation of the digamma function
double VisitorShyAlgorithm::digammas(double x)
{
    double a = pow(10, -8);
    double b = 10.0;
    double s3 = 1.0 / 12.0;
    double s4 = 1.0 / 120.0;
    double s5 = 1.0 / 252.0;
    double g = -0.57721566490153;
    double d;

    if (x <= 0)
        d = 0.0;
    else if (x < a)
        d = (double) g - 1.0 / x;
    else if (x > b)
    {
        double y = 1.0 / (x * x);
        d = log(x) - 0.5 / x - y * (s3 - y * (s4 - y * s5));
    }
    else
        d = digammas(x + 1.0) - 1.0 / x;

    return d;
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Implementation of the error function
double VisitorShyAlgorithm::erf(double x)
{
    double integral = 0.0;
    double step_number = 50.0;
    double step_size = x / step_number;  // x / step_number

    // Error function
    for (int i = 0; i < step_number; i = i + 2)
    {
       // TODO: Might want to change this to a simple add two points and so on
       // This is supposed to be more precise
       integral = integral + (exp(-pow(i * step_size, 2)) 
                  + 4.0 * exp(-pow((i + 1) * step_size, 2))
                  +  exp(-pow((i + 2) * step_size, 2))) * step_size / 3; 
    }

    return integral * 2.0 / sqrt(3.14159);
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Calculate the principal components of a matrix
void VisitorShyAlgorithm::princomp(Matrix *pc, Matrix *score, Matrix data)
{
    int nNumOfWaveforms = data.rowno();
    int nNumOfPoints = data.colno();

    ASSERT((*pc).rowno() == nNumOfPoints);

    Matrix avg(1, nNumOfPoints, 0.0);

    MeanCols(&avg, data);

    Matrix centerx(nNumOfWaveforms, nNumOfPoints, 0.0);

    for (int i = 0; i < nNumOfWaveforms; ++i)
        for (int j = 0; j < nNumOfPoints; ++j)
            centerx(i, j) = data(i, j) - avg(0, j);

    Matrix U = centerx;
    Vector latent;  // Equivalent to W

    U /= sqrt((double) nNumOfWaveforms - 1.0);

    U.svd(*pc, latent);  // PC is 48x48; latent is 48 long

    U.free();  // Since this is big and I don't need it, I am freeing the memory

    *score = centerx * (*pc);
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Returns the sum of all columns of a matrix
void VisitorShyAlgorithm::SumCols(Matrix *sumc, Matrix data)
{
    int rows = data.rowno();
    int cols = data.colno();
    (*sumc).null();

    ASSERT((*sumc).colno() == cols);

    for (int j = 0; j < cols; ++j)
    {
        for (int i = 0; i < rows; ++i)
        {
            (*sumc)(0, j) = (*sumc)(0, j) + data(i, j);
        }
    }
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Returns the sum of all rows of a matrix
void VisitorShyAlgorithm::SumRows(Matrix *sumr, Matrix data)
{
    int rows = data.rowno();
    int cols = data.colno();
    (*sumr).null();

    ASSERT((*sumr).rowno() == rows);

    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            (*sumr)(i, 0) = (*sumr)(i, 0) + data(i, j);
        }
    }
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Returns the mean of all columns of a matrix
void VisitorShyAlgorithm::MeanCols(Matrix *meanc, Matrix data)
{
    SumCols(meanc, data);

    *meanc /= data.rowno();
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Returns the mean of all rows of a matrix
void VisitorShyAlgorithm::MeanRows(Matrix *meanr, Matrix data)
{
    SumRows(meanr, data);

    *meanr /= data.colno();
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Square root of a matrix
void VisitorShyAlgorithm::sqrtm(Matrix *X, Matrix Y)
{
    if (Y.isSymmetric())
        Y.chold();
    else
        return;

    Matrix V;
    Vector S;

    Y.svd(V, S);

    Matrix Sdiag(Y.rowno(), Y.colno(), 0.0);
    Sdiag.diag() = S;

    *X = Y * Sdiag * ~Y;
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Implementation of TRACE() command for matrices
void VisitorShyAlgorithm::trace(Matrix mtrace)
{
    double temp;
    int maxx = MIN(mtrace.rowno(), 10);
    int maxy = MIN(mtrace.colno(), 10);

    for (int x = 0; x < maxx; ++x)
    {
        for (int y = 0; y < maxy; ++y)
        {
            temp = mtrace[x][y];
            TRACE("%f  \t", temp);
        }
        TRACE("\n");
    }
}


// Author & Date:   Almut Branner   10 Feb 2004
// Purpose: Turn the currently selected sigma into a matrix
void VisitorShyAlgorithm::GetCurrentSigma(Matrix *CurrentSigma, double *Sigma, int WhichSigma, 
                                          int nNumOfWaveforms, int nNumOfUnits)
{
    ASSERT(((*CurrentSigma).rowno() == nNumOfWaveforms) && ((*CurrentSigma).colno() == nNumOfWaveforms));

    for (int i = 0; i < nNumOfWaveforms; ++i)
    {
        for (int j = 0; j < nNumOfWaveforms; ++j)
        {
            (*CurrentSigma)(i, j) = *(Sigma + (i * nNumOfWaveforms + j) * nNumOfUnits + WhichSigma);
        }
    }
}


// Author & Date:   Almut Branner, 6/13/2003
// Purpose: Calculation gamma function
//          This code came from "A numerical Library in C for Scientists and Engineers".
// Inputs:  x - value to calculate gamma function for
// Outputs: calculated value
double VisitorShyAlgorithm::gamma(double x)
{
	int inv;
	double y;
    double s;
    double f;
    double g;
    double odd;
    double even;

	if (x < 0.5) 
    {
		y = x - floor(x / 2.0) * 2;
		s = 3.14159265358979;
		if (y >= 1.0) 
        {
			s = -s;
			y = 2.0 - y;
		}
		if (y >= 0.5)
            y = 1.0 - y;
		inv = 1;
		x = 1.0 - x;
		f = s / sin(3.14159265358979 * y);
	}
    else
		inv = 0;

	if (x > 22.0)
		g = exp(loggamma(x));
	else
    {
		s = 1.0;
		while (x > 1.5)
        {
			x = x - 1.0;
			s *= x;
		}
		g = s / recipgamma(1.0 - x, &odd, &even);
	}
	return (inv ? f/g : g);
}


// Author & Date:   Almut Branner, 6/13/2003
// Purpose: Calculation recipgamma function
//          This code came from "A numerical Library in C for Scientists and Engineers".
// Inputs:  x - value to calculate recipgamma function for
// Outputs: calculated value
double VisitorShyAlgorithm::recipgamma(double x, double *odd, double *even)
{
	int i;
	double alfa,beta;
    double x2;
    double b[13];

	b[1] = -0.283876542276024;   b[2]  = -0.076852840844786;
	b[3] =  0.001706305071096;   b[4]  =  0.001271927136655;
	b[5] =  0.000076309597586;   b[6]  = -0.000004971736704;
	b[7] = -0.000000865920800;   b[8]  = -0.000000033126120;
	b[9] =  0.000000001745136;   b[10] =  0.000000000242310;
	b[11]=  0.000000000009161;   b[12] = -0.000000000000170;

	x2 = x * x * 8.0;
	alfa = -0.000000000000001;
	beta = 0.0;

	for (i=12; i>=2; i -= 2)
    {
		beta = -(alfa * 2.0 + beta);
		alfa = -beta * x2 - alfa + b[i];
	}
	*even = (beta / 2.0 + alfa) * x2 - alfa + 0.921870293650453;
	alfa = -0.000000000000034;
	beta = 0.0;
	for (i=11; i>=1; i -= 2)
    {
		beta = -(alfa * 2.0 + beta);
		alfa = -beta * x2 - alfa + b[i];
	}
	*odd = (alfa + beta) * 2.0;
	return (*odd) *x + (*even);
}


// Author & Date:   Almut Branner, 6/13/2003
// Purpose: Calculation loggamma function
//          This code came from "A numerical Library in C for Scientists and Engineers".
// Inputs:  x - value to calculate loggamma function for
// Outputs: calculated value
double VisitorShyAlgorithm::loggamma(double x)
{
	int i;
	double r;
    double x2;
    double y;
    double f;
    double u0;
    double u1;
    double u;
    double z;
    double b[19];

	if (x > 13.0) 
    {
		r=1.0;
		while (x <= 22.0) 
        {
			r /= x;
			x += 1.0;
		}
		x2 = -1.0 / (x * x);
		r = log(r);
		return log(x) * (x - 0.5) - x + r + 0.918938533204672 +
				(((0.595238095238095e-3 * x2 + 0.793650793650794e-3) * x2 +
				0.277777777777778e-2) * x2 + 0.833333333333333e-1) / x;
	} 
    else 
    {
		f = 1.0;
		u0 = u1 = 0.0;
		b[1]  = -0.0761141616704358;  b[2]  = 0.0084323249659328;
		b[3]  = -0.0010794937263286;  b[4]  = 0.0001490074800369;
		b[5]  = -0.0000215123998886;  b[6]  = 0.0000031979329861;
		b[7]  = -0.0000004851693012;  b[8]  = 0.0000000747148782;
		b[9]  = -0.0000000116382967;  b[10] = 0.0000000018294004;
		b[11] = -0.0000000002896918;  b[12] = 0.0000000000461570;
		b[13] = -0.0000000000073928;  b[14] = 0.0000000000011894;
		b[15] = -0.0000000000001921;  b[16] = 0.0000000000000311;
		b[17] = -0.0000000000000051;  b[18] = 0.0000000000000008;

		if (x < 1.0) 
        {
			f = 1.0 / x;
			x += 1.0;
		} 
        else
			while (x > 2.0) 
            {
				x -= 1.0;
				f *= x;
			}
		f = log(f);
		y = x + x - 3.0;
		z = y + y;
		for (i=18; i>=1; i--) 
        {
			u = u0;
			u0 = z * u0 + b[i] - u1;
			u1 = u;
		}
		return (u0 * y + 0.491415393029387 - u1) * (x - 1.0) * (x - 2.0) + f;
	}
}

void VisitorShyAlgorithm::DistClusterCenters(Matrix *diffs, Matrix Waveforms, Matrix mu)
{
    int nNumOfWaveforms = Waveforms.rowno();
    int gn = (*diffs).rowno();
    int nNumOfPoints = (*diffs).colno();

    ASSERT(gn != 0);

    for (int i = 0; i < gn; ++i)
    {
        int nNumOfUnits = i / nNumOfWaveforms;
        for (int j = 0; j < nNumOfPoints; ++j)
            (*diffs)(i, j) = Waveforms(i - nNumOfUnits * nNumOfWaveforms, j) - mu(nNumOfUnits, j);
    }
}


void VisitorShyAlgorithm::MahalanobisDistances(Matrix *M, Matrix *detSigma, Matrix diffs, double *Sigma)
{
    int nNumOfPoints = diffs.colno();
    int nNumOfWaveforms = (*M).rowno();
    int nNumOfUnits = (*M).colno();
    
    ASSERT((nNumOfWaveforms != 0) && (nNumOfUnits != 0));

    Matrix CurrentSigma(nNumOfPoints, nNumOfPoints, 0.0);
    Matrix tempM(nNumOfPoints, nNumOfWaveforms, 0.0);
    Matrix tempSumM(1, nNumOfWaveforms, 0.0);

    for (int k = 0; k < nNumOfUnits; ++k)
    {
        // Mahalanobis distances
        GetCurrentSigma(&CurrentSigma, Sigma, k, nNumOfPoints, nNumOfUnits);

        (*detSigma)(k, k) = 1.0 / sqrt(CurrentSigma.det());

        CurrentSigma.inv();  // or !CurrentSigma

        // Calculation of square root of matrix
        sqrtm(&CurrentSigma, CurrentSigma);

        for (int i = 0; i < nNumOfWaveforms; ++i)
            for (int j = 0; j < nNumOfPoints; ++j)
                tempM(j, i) = diffs(k * nNumOfWaveforms + i, j);

        tempM = CurrentSigma * tempM;

        for (i = 0; i < nNumOfPoints; ++i)
            for (int j = 0; j < nNumOfWaveforms; ++j)
                tempM(i, j) = tempM(i, j) * tempM(i, j);

        SumCols(&tempSumM, tempM);

        (*M)(k) = (Vector) tempSumM[0];
    }  // for k
}


void VisitorShyAlgorithm::UpdateProbabilities(Matrix *Prob, Matrix M, Matrix detSigma,
                                              double nu, int nNumOfPoints)
{
    int nNumOfWaveforms = M.rowno();
    int nNumOfUnits = M.colno();

    ASSERT(((*Prob).rowno() == nNumOfWaveforms) && ((*Prob).colno() == nNumOfUnits));

    double c = gamma((nu + nNumOfPoints)/2.0) / (gamma(nu/2.0) * pow(3.14159 * nu, (double) nNumOfPoints/2.0));

    Matrix tempM(nNumOfWaveforms, nNumOfUnits, 0.0);

    for (int i = 0; i < nNumOfWaveforms; ++i)
    {
        for (int j = 0; j < nNumOfUnits; ++j)
        {
            tempM(i, j) = c * exp(-(nu + nNumOfPoints) * log(1.0 + M(i, j) / nu) / 2.0);
        }
    }

    *Prob = tempM * detSigma;
}


void VisitorShyAlgorithm::ResizeData(Matrix *Pj, Matrix *mu, Matrix *Prob, Matrix *Z, 
                                     Matrix *U, Matrix *ZU, Matrix *M, double *Sigma, 
                                     Vector ToKeep, int new_NumOfUnits)
{
    int old_NumOfUnits = (*Pj).rowno();
    int nNumOfPoints = (*mu).colno();
    int nNumOfWaveforms = (*Prob).rowno();

    Matrix OldPj = *Pj;
    (*Pj).resize(new_NumOfUnits, new_NumOfUnits);
    (*Pj).null();
    Matrix OldMu = *mu;
    (*mu).resize(new_NumOfUnits, nNumOfPoints);
    (*mu).null();
    Matrix OldProb = (*Prob);
    (*Prob).resize(nNumOfWaveforms, new_NumOfUnits);
    (*Prob).null();
    Matrix OldZ = *Z;
    (*Z).resize(nNumOfWaveforms, new_NumOfUnits);
    (*Z).null();
    Matrix OldU = *U;
    (*U).resize(nNumOfWaveforms, new_NumOfUnits);
    (*U).null();
    Matrix OldZU = *ZU;
    (*ZU).resize(nNumOfWaveforms, new_NumOfUnits);
    (*ZU).null();
    Matrix OldM = *M;
    (*M).resize(nNumOfWaveforms, new_NumOfUnits);
    (*M).null();
    double *OldSigma;
    OldSigma = new double[nNumOfPoints * nNumOfPoints * old_NumOfUnits];

    memcpy(OldSigma, Sigma, (nNumOfPoints * nNumOfPoints * old_NumOfUnits) * sizeof(double));

    for (int i = 0; i < new_NumOfUnits; ++i)
    {
        (*Pj)(i, i) = OldPj(ToKeep[i], ToKeep[i]);

        for (int j = 0; j < nNumOfPoints; ++j)
        {
            (*mu)(i, j) = OldMu(ToKeep[i], j);

            for (int k = 0; k < nNumOfPoints; ++k)
            {
                *(Sigma + (j * nNumOfPoints + k) * new_NumOfUnits + i) = 
                    *(OldSigma + (j * nNumOfPoints + k) * old_NumOfUnits + (int) ToKeep[i]);
            }
        }
        for (j = 0; j < nNumOfWaveforms; ++j)
        {
            (*Prob)(j, i) = OldProb(j, ToKeep[i]);
            (*Z)(j, i) = OldZ(j, ToKeep[i]);
            (*U)(j, i) = OldU(j, ToKeep[i]);
            (*ZU)(j, i) = OldZU(j, ToKeep[i]);
            (*M)(j, i) = OldM(j, ToKeep[i]);
        }
    }

    delete [] OldSigma;
}

void VisitorShyAlgorithm::UpdateSigma(double *Sigma, Matrix U, Matrix Diffs, Matrix Sum)
{
    int nNumOfUnits = Sum.colno();
    int nNumOfPoints = Diffs.colno();
    int nNumOfWaveforms = Diffs.rowno() / nNumOfUnits;

    Matrix tempProd(nNumOfPoints, nNumOfWaveforms, 0.0);
    Matrix CurrentSigma(nNumOfPoints, nNumOfPoints, 0.0);

    for (int k = 0; k < nNumOfUnits; ++k)
    {
        for (int i = 0; i < nNumOfWaveforms; ++i)
            for (int j = 0; j < nNumOfPoints; ++j)
                tempProd(j, i) = U(i, k) * Diffs(k * nNumOfWaveforms + i, j);

        CurrentSigma = tempProd * (Matrix) Diffs[mslice(k * nNumOfWaveforms, 0, nNumOfWaveforms, nNumOfPoints)];
        CurrentSigma /= Sum(0, k);  // (int)

        for (i = 0; i < nNumOfPoints; ++i)
            for (int j = 0; j < nNumOfPoints; ++j)
                *(Sigma + (i * nNumOfPoints + j) * nNumOfUnits + k) = CurrentSigma(i, j);
    }  // end k
}
