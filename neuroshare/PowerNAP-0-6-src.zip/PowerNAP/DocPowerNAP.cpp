///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: DocPowerNAP.cpp $
//
// Description   : implementation of the CDocPowerNAP class
//
// Authors       : Kirk Korver
//
// $Date: 3/11/04 12:53p $
//
// $History: DocPowerNAP.cpp $
// 
// *****************  Version 99  *****************
// User: Kkorver      Date: 3/11/04    Time: 12:53p
// Updated in $/Neuroshare/PowerNAP
// Added ability to delete units and reclassify units
// 
// *****************  Version 98  *****************
// User: Kkorver      Date: 3/09/04    Time: 2:49p
// Updated in $/Neuroshare/PowerNAP
// Added basic "clipping" functions
// 
// *****************  Version 97  *****************
// User: Kkorver      Date: 3/05/04    Time: 4:00p
// Updated in $/Neuroshare/PowerNAP
// Added the ability to delete channels
// 
// *****************  Version 96  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:27p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 95  *****************
// User: Kkorver      Date: 3/04/04    Time: 9:39a
// Updated in $/Neuroshare/PowerNAP
// Create and use new GetEntity()
// Rename GetEntityIndex() to GetIdxEntity()
// 
// *****************  Version 94  *****************
// User: Kkorver      Date: 3/03/04    Time: 5:32p
// Updated in $/Neuroshare/PowerNAP
// Added a wait cursor for file opening
// 
// *****************  Version 93  *****************
// User: Kkorver      Date: 3/03/04    Time: 4:41p
// Updated in $/Neuroshare/PowerNAP
// Renamed GetTimeSpan() to GetMaxTime()
// Renamed GetSegment() to GetIdxSegment()
// Renamed GetActiveSegment() to GetIdxActiveSegment() , etc.
// Added new GetSegment() and GetActiveSegment(), etc.
// 
// *****************  Version 92  *****************
// User: Kkorver      Date: 2/27/04    Time: 1:53p
// Updated in $/Neuroshare/PowerNAP
// Added playback capabilities
// Added GetTimeSpan()
// GetWave() no longer needs the EntityID passed
// 
// *****************  Version 91  *****************
// User: Kkorver      Date: 2/24/04    Time: 10:22a
// Updated in $/Neuroshare/PowerNAP
// Now All Knows types are displayed by default when searching for a file
// 
// *****************  Version 90  *****************
// User: Abranner     Date: 2/10/04    Time: 11:41a
// Updated in $/Neuroshare/PowerNAP
// Added colors and pens for additional units.
// 
// *****************  Version 89  *****************
// User: Abranner     Date: 2/09/04    Time: 11:43a
// Updated in $/Neuroshare/PowerNAP
// VisitorShyAlgorithm is now initialized with an EntityID.
// 
// *****************  Version 88  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 87  *****************
// User: Abranner     Date: 2/03/04    Time: 12:44p
// Updated in $/Neuroshare/PowerNAP
// Made changes to doc to simplify data renewal operations.
// 
// *****************  Version 86  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 85  *****************
// User: Abranner     Date: 1/26/04    Time: 4:00p
// Updated in $/Neuroshare/PowerNAP
// Made calling and updating the PropSheetSpkSorting easier.
// 
// *****************  Version 84  *****************
// User: Abranner     Date: 10/31/03   Time: 6:02p
// Updated in $/Neuroshare/PowerNAP
// Changed window positions and the way spike sorting is initiated.
// 
// *****************  Version 83  *****************
// User: Kkorver      Date: 10/24/03   Time: 10:46a
// Updated in $/Neuroshare/PowerNAP
// Made it so newly opened windows would all be arranged
// 
// *****************  Version 82  *****************
// User: Kkorver      Date: 10/22/03   Time: 11:17a
// Updated in $/Neuroshare/PowerNAP
// RebuildAllLists() renamed to RebuildAllListsAndUpdateViews() and now
// calls UpdateAllViews() at the end
// 
// *****************  Version 81  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 80  *****************
// User: Kkorver      Date: 10/20/03   Time: 10:17a
// Updated in $/Neuroshare/nsClassifier
// Added RebuildSegListAndUpdate()
// 
// *****************  Version 79  *****************
// User: Abranner     Date: 10/17/03   Time: 2:04p
// Updated in $/Neuroshare/nsClassifier
// Fixed color of noise units.
// 
// *****************  Version 78  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:54a
// Updated in $/Neuroshare/nsClassifier
// Moved all of the Data classes to their own file
// Made the Analogs class work
// 
// *****************  Version 77  *****************
// User: Kkorver      Date: 10/17/03   Time: 9:48a
// Updated in $/Neuroshare/nsClassifier
// Updated the "data" class to no longer store the Entity ID
// 
// *****************  Version 76  *****************
// User: Kkorver      Date: 10/16/03   Time: 2:08p
// Updated in $/Neuroshare/nsClassifier
// Now access the thresholds by function call
// 
// *****************  Version 75  *****************
// User: Abranner     Date: 10/15/03   Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// Moved pens and colors to the document and added functions
// GetBITUnitColor(), GetBITUnit() and GetBITUnitPen().
// 
// *****************  Version 74  *****************
// User: Kkorver      Date: 10/15/03   Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Saving data now prompts
// 
// *****************  Version 73  *****************
// User: Abranner     Date: 10/14/03   Time: 11:12a
// Updated in $/Neuroshare/nsClassifier
// Changed initialization of DataSegment list to not use dwEntityID.
// 
// *****************  Version 72  *****************
// User: Kkorver      Date: 10/14/03   Time: 10:44a
// Updated in $/Neuroshare/nsClassifier
// Added SaveAnalogs()
// 
// *****************  Version 71  *****************
// User: Abranner     Date: 10/13/03   Time: 2:00p
// Updated in $/Neuroshare/nsClassifier
// Added functions IsSegment(), AreThereAnalogs(), IsActiveAnalog() and
// IsAnalog().
// 
// *****************  Version 70  *****************
// User: Abranner     Date: 9/12/03    Time: 5:57p
// Updated in $/Neuroshare/nsClassifier
// Fixed icons and frame. FIU now has button to launch Raster.
// 
// *****************  Version 69  *****************
// User: Abranner     Date: 9/12/03    Time: 1:25p
// Updated in $/Neuroshare/nsClassifier
// Added search functions for analog entities and fixed some bugs.
// 
// *****************  Version 68  *****************
// User: Abranner     Date: 9/11/03    Time: 5:12p
// Updated in $/Neuroshare/nsClassifier
// Added test IsThisSegment. Analog data is loaded in.
// 
// *****************  Version 67  *****************
// User: Abranner     Date: 9/11/03    Time: 3:17p
// Updated in $/Neuroshare/nsClassifier
// Changed FileInfoType and EntityInfoType to FileInfo and EntityInfo.
// Changed FILEINFOTYPE and ENTITYINFOTYPE to FILEINFOLIST and
// ENTITYINFOLIST. 
// 
// *****************  Version 66  *****************
// User: Kkorver      Date: 9/11/03    Time: 2:02p
// Updated in $/Neuroshare/nsClassifier
// Updated message box
// 
// *****************  Version 65  *****************
// User: Abranner     Date: 9/11/03    Time: 12:09p
// Updated in $/Neuroshare/nsClassifier
// Document now stores EntityID instead of EntityInList. This accomodates
// sorting of the list in FIU.
// 
// *****************  Version 64  *****************
// User: Abranner     Date: 9/11/03    Time: 9:29a
// Updated in $/Neuroshare/nsClassifier
// Changed GetCurrentEntity() to GetActiveEntity().
// 
// *****************  Version 63  *****************
// User: Abranner     Date: 9/11/03    Time: 9:23a
// Updated in $/Neuroshare/nsClassifier
// Fixed function call to GetEntityID()
// 
// *****************  Version 62  *****************
// User: Abranner     Date: 9/11/03    Time: 9:05a
// Updated in $/Neuroshare/nsClassifier
// Made EntityID protected and added function to access it.
// 
// *****************  Version 61  *****************
// User: Kkorver      Date: 9/11/03    Time: 7:05a
// Updated in $/Neuroshare/nsClassifier
// Added SaveData() and SaveSegments()
// 
// *****************  Version 60  *****************
// User: Abranner     Date: 9/10/03    Time: 1:32p
// Updated in $/Neuroshare/nsClassifier
// Changed BuildWaveformList to BuildSegmentList and changed logic that
// waveform list is assumed in GetActive... functions.
// 
// *****************  Version 59  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 58  *****************
// User: Abranner     Date: 9/09/03    Time: 3:04p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 57  *****************
// User: Awang        Date: 8/28/03    Time: 1:55p
// Updated in $/Neuroshare/nsClassifier
// GetCurrentEntity() checks for valid entity number and returns -1 for
// invalid or unselected entities
// 
// *****************  Version 56  *****************
// User: Awang        Date: 8/28/03    Time: 11:42a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 55  *****************
// User: Abranner     Date: 8/27/03    Time: 6:44p
// Updated in $/Neuroshare/nsClassifier
// Changed all Options menus. Changed look of some windows etc. Changed
// resource file to remove duplicate id entries.
// 
// *****************  Version 54  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// *****************  Version 53  *****************
// User: Abranner     Date: 8/27/03    Time: 10:57a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet and removed CViewOptKMeans.
// 
// *****************  Version 52  *****************
// User: Awang        Date: 8/26/03    Time: 2:26p
// Updated in $/Neuroshare/nsClassifier
// Removed unused function UpdateTemplate()
// 
// *****************  Version 51  *****************
// User: Awang        Date: 8/22/03    Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Removed Centroid class
// 
// *****************  Version 50  *****************
// User: Awang        Date: 8/15/03    Time: 1:20p
// Updated in $/Neuroshare/nsClassifier
// Added ViewSortedInfo and Eigenvector list 
// 
// *****************  Version 49  *****************
// User: Awang        Date: 8/05/03    Time: 2:09p
// Updated in $/Neuroshare/nsClassifier
// Added Centroid class
// KMeans sorting parameters 
// Change CreateOrActivateView to return pointer to view
// 
// *****************  Version 48  *****************
// User: Awang        Date: 6/30/03    Time: 3:53p
// Updated in $/Neuroshare/nsClassifier
// EntityInfoView added 
// 
// *****************  Version 47  *****************
// User: Awang        Date: 6/18/03    Time: 2:28p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 46  *****************
// User: Abranner     Date: 6/16/03    Time: 6:18p
// Updated in $/Neuroshare/nsClassifier
// Shy's spike sorter works. I still have to come up with a better name
// and implement the noise checking.
// 
// *****************  Version 45  *****************
// User: Awang        Date: 6/10/03    Time: 4:31p
// Updated in $/Neuroshare/nsClassifier
// Post messages for highlighting a selected waveform, changing unit
// colors on data points.
// 
// *****************  Version 44  *****************
// User: Kkorver      Date: 5/12/03    Time: 11:12a
// Updated in $/Neuroshare/nsClassifier
// Added DlgAdvancedOpen class
// 
// *****************  Version 43  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 42  *****************
// User: Awang        Date: 5/06/03    Time: 10:38a
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 41  *****************
// User: Abranner     Date: 5/05/03    Time: 3:12p
// Updated in $/Neuroshare/nsClassifier
// Fixed problem with the graph update. The scaling (or max voltage value)
// of all waveforms is now calculated in the document and not the graph
// window.
// 
// *****************  Version 40  *****************
// User: Abranner     Date: 5/02/03    Time: 4:52p
// Updated in $/Neuroshare/nsClassifier
// Fixed bug I introduced in last check in (SetTrainingPopulation).
// 
// *****************  Version 39  *****************
// User: Abranner     Date: 5/02/03    Time: 4:36p
// Updated in $/Neuroshare/nsClassifier
// Fixed bug with number of samples per group and changed global variable
// m_nNumOfSamples to mean number of samples per group and file.
// 
// *****************  Version 38  *****************
// User: Abranner     Date: 5/02/03    Time: 2:45p
// Updated in $/Neuroshare/nsClassifier
// Included number of files in CViewOptPop and added increase in number of
// samples when a file is added (to avoid non integer numbers).
// 
// *****************  Version 37  *****************
// User: Awang        Date: 5/01/03    Time: 1:38p
// Updated in $/Neuroshare/nsClassifier
// 
// *****************  Version 36  *****************
// User: Abranner     Date: 4/30/03    Time: 2:47p
// Updated in $/Neuroshare/nsClassifier
// Changed window positions.
// Changed the entity list to a list control.
// Fized a bug in the waveform view.
// 
// *****************  Version 35  *****************
// User: Abranner     Date: 4/29/03    Time: 10:42a
// Updated in $/Neuroshare/nsClassifier
// Added a view for Entity Infos
// 
// *****************  Version 34  *****************
// User: Abranner     Date: 4/28/03    Time: 5:28p
// Updated in $/Neuroshare/nsClassifier
// Added one more option to align peaks.
// 
// *****************  Version 33  *****************
// User: Abranner     Date: 4/28/03    Time: 12:34p
// Updated in $/Neuroshare/nsClassifier
// Added capability to turn tooltips off.
// 
// *****************  Version 32  *****************
// User: Kkorver      Date: 4/24/03    Time: 9:21a
// Updated in $/Neuroshare/nsClassifier
// Added the doc template for the Library Details window
// 
// *****************  Version 31  *****************
// User: Kkorver      Date: 4/23/03    Time: 10:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed the files FilesInUseView to ViewFilesInUse and
// WaveformsView to ViewWaveforms
// 
// *****************  Version 30  *****************
// User: Kkorver      Date: 4/22/03    Time: 5:52p
// Updated in $/Neuroshare/nsClassifier
// Added GetTotalEntityItemCount()
// The entity info list now stores the total number of items in all files,
// not just the most recently opened
// 
// *****************  Version 29  *****************
// User: Kkorver      Date: 4/22/03    Time: 5:11p
// Updated in $/Neuroshare/nsClassifier
// Added RemoveFile()
// 
// *****************  Version 28  *****************
// User: Awang        Date: 4/22/03    Time: 2:10p
// Updated in $/Neuroshare/nsClassifier
// Do not close file on m_icFileVector.push_back().
// 
// *****************  Version 27  *****************
// User: Kkorver      Date: 4/22/03    Time: 2:02p
// Updated in $/Neuroshare/nsClassifier
// Major changes...we no longer use MDI, but rather a SDI with lots of
// windows open at the same time
// 
// *****************  Version 26  *****************
// User: Almut        Date: 4/21/03    Time: 5:09p
// Updated in $/Neuroshare/nsClassifier
// Changed class names and the size of the views for (options pop and
// align).
// 
// *****************  Version 25  *****************
// User: Almut        Date: 4/18/03    Time: 5:43p
// Updated in $/Neuroshare/nsClassifier
// Added options for the training samples and removed options from the FIU
// view. Also changed Document to actually test the difference between two
// files.
// 
// *****************  Version 24  *****************
// User: Almut        Date: 4/17/03    Time: 6:04p
// Updated in $/Neuroshare/nsClassifier
// - Implemented first version of thresholding (Anomaly #13)
// 
// *****************  Version 23  *****************
// User: Almut        Date: 4/16/03    Time: 4:07p
// Updated in $/Neuroshare/nsClassifier
// Fixed Anonaly # 12, part of #15
// 
// Added:
// - scaling of waveforms
// - options for peak alignment
// - the way the channels and files are shown
// 
// *****************  Version 22  *****************
// User: Angela       Date: 4/11/03    Time: 1:52p
// Updated in $/Neuroshare/nsClassifier
// reposition waveform views display to show up adjacent to filesinused
// display
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 4/11/03    Time: 11:00a
// Updated in $/Neuroshare/nsClassifier
// AddDataFile() now returns true/false
// 
// *****************  Version 20  *****************
// User: Kkorver      Date: 4/11/03    Time: 9:37a
// Updated in $/Neuroshare/nsClassifier
// Added EraseWaveForms()
// 
// *****************  Version 19  *****************
// User: Angela       Date: 4/10/03    Time: 3:18p
// Updated in $/Neuroshare/nsClassifier
// Updates and no extra frames created
// 
// *****************  Version 18  *****************
// User: Angela       Date: 4/10/03    Time: 2:43p
// Updated in $/Neuroshare/nsClassifier
// Changes to updatewaveforms
// 
// *****************  Version 17  *****************
// User: Kkorver      Date: 4/10/03    Time: 2:18p
// Updated in $/Neuroshare/nsClassifier
// Added the variables for the processing options displayed in the FIU
// class
// Added SetCurrentEntity()
// 
// *****************  Version 16  *****************
// User: Almut        Date: 4/09/03    Time: 5:19p
// Updated in $/Neuroshare/nsClassifier
// Changed name from ClipCheckVisitor to VisitorClipCheck.
// 
// *****************  Version 15  *****************
// User: Kkorver      Date: 4/09/03    Time: 4:32p
// Updated in $/Neuroshare/nsClassifier
// Added GetNumOfPointsPerWave()
// 
// *****************  Version 14  *****************
// User: Angela       Date: 4/09/03    Time: 1:33p
// Updated in $/Neuroshare/nsClassifier
// Added 2nd MDIDocTemplate
// make waveforms view appear
// 
// *****************  Version 13  *****************
// User: Kkorver      Date: 4/03/03    Time: 11:29a
// Updated in $/Neuroshare/nsClassifier
// We now verify that the entities match before adding a data file
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 4/03/03    Time: 10:48a
// Updated in $/Neuroshare/nsClassifier
// We are now able to read/write the document class to a file
// 
// *****************  Version 11  *****************
// User: Kirk         Date: 4/01/03    Time: 1:56p
// Updated in $/Neuroshare/nsClassifier
// The document is now visitable
// Upgraded to use the STL for the new wavelist
// 
// *****************  Version 10  *****************
// User: Kirk         Date: 3/27/03    Time: 1:53p
// Updated in $/Neuroshare/nsClassifier
// Untabified
// Updated to allow multiple data files
// 
// *****************  Version 9  *****************
// User: Kirk         Date: 3/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Rename the NsFile iterators
// 
// *****************  Version 8  *****************
// User: Kirk         Date: 3/25/03    Time: 1:42p
// Updated in $/Neuroshare/nsClassifier
// Added popup menu choice to insert data files
// 
// *****************  Version 7  *****************
// User: Kirk         Date: 3/25/03    Time: 11:20a
// Updated in $/Neuroshare/nsClassifier
// Added NsFile to the document
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <Afxtempl.h>

#pragma warning ( disable : 4786 )


#include "PowerNAP.h"
#include "MainFrm.h"

#include "DocPowerNAP.h"
#include "NsFileIterators.h"
#include "NsLibraryImpMgr.h"
#include "VisitorAlgorithms.h"
#include "VisitorPCA.h"
#include "VisitorShyAlgorithm.h"
#include "VisitorKMeans.h"
#include "DlgAdvancedOpen.h"
#include "nsNSNLibrary.h"
#include "NSNWriter.h"
#include "ns_common.h"
#include "ViewFilesInUse.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// EntityInfoType Class

// Comparison operators
bool EntityInfo::operator == (EntityInfo const & rhs)
{
    // It is on purpose that the dwItemCount is not compared.
    // Two entities do not have to have the same number of entries to be considered equal
    return (dwEntityIndex == rhs.dwEntityIndex &&
            isEntityInfo.dwEntityType == rhs.isEntityInfo.dwEntityType &&
            strcmp(isEntityInfo.szEntityLabel, rhs.isEntityInfo.szEntityLabel) == 0 );
}


bool EntityInfo::operator != (EntityInfo const & rhs)
{
    return ! operator == (rhs);
}


/////////////////////////////////////////////////////////////////////////////
// CDocPowerNAP

IMPLEMENT_DYNCREATE(CDocPowerNAP, CDocument)

BEGIN_MESSAGE_MAP(CDocPowerNAP, CDocument)
    //{{AFX_MSG_MAP(CDocPowerNAP)
        // NOTE - the ClassWizard will add and remove mapping macros here.
        //    DO NOT EDIT what you see in these blocks of generated code!
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDocPowerNAP construction/destruction

CDocPowerNAP::CDocPowerNAP() :
    m_icPropSheetSpkSorting("Spike Sorting Methods")
{
    // initialize the color table
    m_icColorTable.dispback     = BLACK;
    m_icColorTable.dispgridmin  = DARK_GREY;
    m_icColorTable.disptext     = LIGHT_GREY;
    m_icColorTable.dispwave     = MEDIUM_GREY;
    m_icColorTable.dispunit[UNCLASS]  = LIGHT_GREY;
    m_icColorTable.dispunit[UNIT1]  = MAGENTA;
    m_icColorTable.dispunit[UNIT2]  = CYAN;
    m_icColorTable.dispunit[UNIT3]  = YELLOW;
    m_icColorTable.dispunit[UNIT4]  = PURPLE;
    m_icColorTable.dispunit[UNIT5]  = GREEN;
    m_icColorTable.dispunit[UNIT6]  = RED;
    m_icColorTable.dispunit[UNIT7]  = DARK_GREEN;
    m_icColorTable.dispunit[UNIT8]  = ORANGE;
    m_icColorTable.dispunit[UNIT9]  = LT_BROWN;
    m_icColorTable.dispunit[UNIT10] = WHITE;
    m_icColorTable.dispunit[NOISE] = BLUE;
    m_icColorTable.dispunit[12] = LIGHT_GREY;
    m_icColorTable.dispchansel[0]  = BLACK;
    m_icColorTable.dispchansel[1]  = LIGHT_GREY;
    m_icColorTable.dispchansel[2]  = YELLOW;

    m_wndbkBrush.CreateSolidBrush(m_icColorTable.dispback);

    // Set Unit Colors: {GREY,HOT_PINK,CYAN,YELLOW,PURPLE,GREEN,BLUE,RED};
    m_penUnitColor[0].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNCLASS] );
    m_penUnitColor[1].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT1] );
    m_penUnitColor[2].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT2] );
    m_penUnitColor[3].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT3] );
    m_penUnitColor[4].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT4] );
    m_penUnitColor[5].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT5] );
    m_penUnitColor[6].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT6] );
    m_penUnitColor[7].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT7] );
    m_penUnitColor[8].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT8] );
    m_penUnitColor[9].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT9] );
    m_penUnitColor[10].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[UNIT10] );
    m_penUnitColor[11].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[NOISE] );
    m_penUnitColor[12].CreatePen( PS_SOLID, 1, m_icColorTable.dispunit[12] );

    // Get pointer to CMainFrame
    m_pMainFrm = ((CMainFrame *)(AfxGetApp()->m_pMainWnd));

    m_nActiveEntity = -1;
    
    m_bSampleData = false;
    m_nNumOfSamples = 50;
    m_nNumOfGroups = 10;

    m_bThreshold = false;
    for (int i = 0; i < 256; ++i)
        m_dThreshold[i] = 0;
    m_bRemoveSaturatedSpikes = true;
    m_bAlignPeaks = false;
    m_bAlignMeanPt = true;
    m_nAlignPt = 15;
    m_bTooltips = true;
    m_nWhatPeaks = 0;  // all peaks

    m_bDiscardEmptyEntities = true;

    m_dwPrevSelIndex = 0; // previously selected waveform

    m_nNumPCA = 2;
    m_nPenaltyFactor = 3;

    //////////////////////////////////////
    // Initialze KMeans Sorting parameters
    m_isSortInfo.K = 3;
    m_isSortInfo.nPCCnt = 5;
    m_isSortInfo.nIterCnt = 20;

    (CDocPowerNAP *) Data::m_pDoc = this;
}

CDocPowerNAP::~CDocPowerNAP()
{

}


// This is the file header
void CDocPowerNAP::FileHeader::Serialize(CArchive & ar)
{
    if (ar.IsStoring())
    {
        ar << m_byVersion;
        ar << m_byFlavor;
    }
    else
    {
        ar >> m_byVersion;
        ar >> m_byFlavor;
    }
};


// This is data, that doesn't change on a per-file basis
void CDocPowerNAP::GlobalData::Serialize(CArchive & ar)
{
    if (ar.IsStoring())
    {
        ar << m_bySaturationCheck;
    }
    else
    {
        ar >> m_bySaturationCheck;
    }
};


// Copy constructor
CDocPowerNAP::PerFileData::PerFileData(PerFileData const & rhs) :
    m_strFilePathName(rhs.m_strFilePathName)
{

}


// Assignment operator
CDocPowerNAP::PerFileData & CDocPowerNAP::PerFileData::operator = (PerFileData const & rhs)
{
    m_strFilePathName = rhs.m_strFilePathName;
    return *this;
}


// This is the data that varies on each file
void CDocPowerNAP::PerFileData::Serialize(CArchive & ar)
{
    if (ar.IsStoring())
    {
        ar << m_strFilePathName;
    }
    else
    {
        ar >> m_strFilePathName;
    }
};


// Author & Date:   Kirk Korver     Apr 3, 2003
// Purpose: This function is called when each object of the list is trying
//  to be serialized.
template <>
void AFXAPI SerializeElements <CDocPowerNAP::PerFileData> 
    (CArchive & ar, 
     CDocPowerNAP::PerFileData * pData, 
     int nCount)
{
    for (int i = 0; i < nCount; ++i, ++pData)
    {
        // Serialize each CPerson object
        pData->Serialize(ar);
    }
}


/////////////////////////////////////////////////////////////////////////////
// CDocPowerNAP serialization

void CDocPowerNAP::Serialize(CArchive& ar)
{
    // This is the file header
    FileHeader icHdr;
    GlobalData icGlobal;
    CList<PerFileData, PerFileData> icFileList;

    // Are we storing data?
    if (ar.IsStoring())
    {
        icHdr.m_byVersion = FILE_MAJOR_VERSION;
        icHdr.m_byFlavor = 1;
    
        icGlobal.m_bySaturationCheck = 1;

        for (FILEINFOLIST::iterator it = m_icFileVector.begin();
             it != m_icFileVector.end();
             ++it)
        {
            PerFileData icFile;
            icFile.m_strFilePathName = (*it)->strFilePathName;

            icFileList.AddTail(icFile);
        }
    }

    icHdr.Serialize(ar);
    icGlobal.Serialize(ar);
    icFileList.Serialize(ar);

    // Are we reading in data?
    if (!ar.IsStoring())
    {
        if (icHdr.m_byVersion != 1 ||
            icHdr.m_byFlavor != 1)
        {
            AfxMessageBox("It appears this data file is not in the correct format", MB_ICONEXCLAMATION, 0);
            return;
        }

        POSITION pos = icFileList.GetHeadPosition();
        while( pos != NULL )
        {
            PerFileData icFile(icFileList.GetNext(pos));
            AddDataFile(icFile.m_strFilePathName);
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// CDocPowerNAP diagnostics

#ifdef _DEBUG
void CDocPowerNAP::AssertValid() const
{
    CDocument::AssertValid();
}

void CDocPowerNAP::Dump(CDumpContext& dc) const
{
    CDocument::Dump(dc);
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CDocPowerNAP commands
/////////////////////////////////////////////////////////////////////////////


BOOL CDocPowerNAP::OnOpenDocument(LPCTSTR lpszPathName) 
{
    if (!CDocument::OnOpenDocument(lpszPathName))
        return FALSE;

    return TRUE;
}


// Author & Date:   Almut Branner   Sept 9, 2003
// Purpose: Set the currently selected entity in the list
// Inputs:  The index to the element to be selected
// Outputs: none
void CDocPowerNAP::SetActiveEntity(int32 nEntityID)
{
    // Set focus index to the list
    m_nActiveEntity = nEntityID;
}


// Author & Date:   Angela Wang     Aug 28, 2003
// Purpose: Get the currently selected entity
// Returns: The selected entity ID.
int32 CDocPowerNAP::GetActiveEntity()
{
    ASSERT(m_nActiveEntity >= 0);
    ASSERT(!m_icEntityInfoVector.empty());
    
    return m_nActiveEntity;
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Function to compare an element with the requested EntityID
// Inputs:  Data element and EntityID to compare to
// Outputs: true if found, false if not
struct FindEntity : std::binary_function <DWORD, EntityInfo, bool>
{
    bool operator()(const DWORD & dwEntityID, const EntityInfo & EntityList) const
    {
        return EntityList.dwEntityIndex == dwEntityID;
    }
};


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Find and return the index of the requested entity
// Inputs:  The index to the element
// Outputs: none
int32 CDocPowerNAP::GetIdxEntity(int32 dwEntityID)
{
    ENTITYINFOLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icEntityInfoVector.begin(), m_icEntityInfoVector.end(), 
        std::bind1st(FindEntity(), dwEntityID));

    if (ListEntry == m_icEntityInfoVector.end())
        return -1;

    return ListEntry - m_icEntityInfoVector.begin();
}

// Author & Date:   Kirk Korver     04 Mar 2004
// Purpose:  Get the Entity associated with this entity ID
// Inputs:
//  dwEntityID - the entity we are interested in
EntityInfo & CDocPowerNAP::GetEntity(int32 dwEntityID)
{
    ASSERT(!m_icEntityInfoVector.empty());

    ENTITYINFOLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icEntityInfoVector.begin(), m_icEntityInfoVector.end(), 
        std::bind1st(FindEntity(), dwEntityID));

    ASSERT(ListEntry != m_icEntityInfoVector.end());
    return *ListEntry;
}


// Author & Date:   Almut Branner   3 Feb 2004
// Purpose: Function to compare an element with the requested NsFile
// Inputs:  Data element and NsFile reference to compare to
// Outputs: true if found, false if not
struct FindFile : std::binary_function <NsFile, SPFileInfo, bool>
{
    bool operator()(const NsFile & rcFile, const SPFileInfo FileList) const
    {
        return FileList->icFile == rcFile;
    }
};


// Author & Date:   Almut Branner   3 Feb 2004
// Purpose: Find and return the index of the requested NsFile
// Inputs:  The index to the element
// Outputs: none
int32 CDocPowerNAP::GetFileIndex(NsFile &rcFile)
{
    ASSERT(!m_icFileVector.empty());

    FILEINFOLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icFileVector.begin(), m_icFileVector.end(), 
        std::bind1st(FindFile(), rcFile));

    if (ListEntry == m_icFileVector.end())
        return -1;

    return ListEntry - m_icFileVector.begin();
}


// Author & Date:   Almut Branner   Sept 9, 2003
// Purpose: Get the currently selected element in the list
// Inputs:  none
// Outputs: The index to the selected element
int32 CDocPowerNAP::GetActiveEntityIndex()
{
    // Return the focus index to the list
    return GetIdxEntity(m_nActiveEntity);
}


// Author & Date:   Almut Branner   Sept 9, 2003
// Purpose: Function to compare an element with the requested EntityID
// Inputs:  Data element and EntityID to compare to
// Outputs: true if found, false if not
struct FindSegment : std::binary_function <DWORD, SPSegments, bool>
{
    bool operator()(const DWORD & dwEntityID, const SPSegments SegList) const
    {
        return SegList->GetEntityID() == dwEntityID;
    }
};


// Author & Date:   Almut Branner   Sept 9, 2003
// Purpose: Find and return the index of the currently selected segment entity
// Inputs:  The entity ID
// Outputs: Returns the index to the selected segment entity and -1 if no segment is selected
int32 CDocPowerNAP::GetIdxSegment(int32 dwEntityID)
{
    int32 retVal = -1;      // Assume it is not found

    ASSERT(GetEntity(dwEntityID).isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT);

    SEGMENTENTITYLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icSegmentList.begin(), m_icSegmentList.end(), 
        std::bind1st(FindSegment(), dwEntityID));

    if (ListEntry != m_icSegmentList.end())
        retVal = ListEntry - m_icSegmentList.begin();

    return retVal;
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: find and return the segment associated with this entityID
// Inputs:
//  dwEntityID - the entity ID
Segments & CDocPowerNAP::GetSegment(int32 dwEntityID)
{
    ASSERT(GetEntity(dwEntityID).isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT);

    SEGMENTENTITYLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icSegmentList.begin(), m_icSegmentList.end(), std::bind1st(FindSegment(), dwEntityID));

    ASSERT(ListEntry != m_icSegmentList.end());

    return **ListEntry;
}



// Author & Date:   Almut Branner   Sept 9, 2003
// Purpose: Find and return the index of the currently selected segment entity
// Outputs: Returns the index to the selected segment entity and -1 if no segment is selected
int32 CDocPowerNAP::GetIdxActiveSegment()
{
    ASSERT(m_icEntityInfoVector[GetActiveEntityIndex()].isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT);

    return GetIdxSegment(GetActiveEntity());
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: Get the "segment" that is currently selected
Segments & CDocPowerNAP::GetActiveSegment()
{
    ASSERT(m_icEntityInfoVector[GetActiveEntityIndex()].isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT);

    UINT nIndex = GetIdxActiveSegment();
    return *m_icSegmentList[nIndex];
}



// Author & Date:   Almut Branner   Sept 12, 2003
// Purpose: Function to compare an element with the requested EntityID
// Inputs:  Data element and EntityID to compare to
// Outputs: true if found, false if not
struct FindAnalog : std::binary_function <DWORD, SPAnalogs, bool>
{
    bool operator()(const DWORD & dwEntityID, const SPAnalogs AnalogList) const
    {
        return AnalogList->GetEntityID() == dwEntityID;
    }
};


// Author & Date:   Almut Branner   Sept 12, 2003
// Purpose: Find and return the index of the currently selected analog entity
// Inputs:  The entity ID
// Outputs: Returns the index to the selected analog entity and -1 if no analog entity is selected
int32 CDocPowerNAP::GetIdxAnalog(int32 dwEntityID)
{
    int32 retVal = -1;

    ASSERT(GetEntity(dwEntityID).isEntityInfo.dwEntityType == ns_ENTITY_ANALOG);

    ANALOGENTITYLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icAnalogList.begin(), m_icAnalogList.end(), 
        std::bind1st(FindAnalog(), dwEntityID));

    if (ListEntry != m_icAnalogList.end())
        retVal =  ListEntry - m_icAnalogList.begin();

    return retVal;
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: Get this "analog" entity
// Inputs:
//  dwEntityID - the entity we are interested in
Analogs & CDocPowerNAP::GetAnalog(int32 dwEntityID)
{
    ASSERT(GetEntity(dwEntityID).isEntityInfo.dwEntityType == ns_ENTITY_ANALOG);

    ANALOGENTITYLIST::iterator ListEntry;
    ListEntry = std::find_if(m_icAnalogList.begin(), m_icAnalogList.end(), std::bind1st(FindAnalog(), dwEntityID));

    ASSERT(ListEntry != m_icAnalogList.end());
    return **ListEntry;
}


// Author & Date:   Almut Branner   Sept 12, 2003
// Purpose: Find and return the index of the currently selected analog entity
// Inputs:  none
// Outputs: Returns the index to the selected segment entity and -1 if no analog entity is selected
int32 CDocPowerNAP::GetIdxActiveAnalog()
{
    ASSERT(m_icEntityInfoVector[GetActiveEntityIndex()].isEntityInfo.dwEntityType == ns_ENTITY_ANALOG);

    return GetIdxAnalog(GetActiveEntity());
}

// Author & Date:   Kirk Korver     03 Mar 2004
// Purpose: Get the active segment when it is an ANALOG
Analogs & CDocPowerNAP::GetActiveAnalog()
{
    return *m_icAnalogList[GetIdxActiveAnalog()];
}


void CDocPowerNAP::OnCloseDocument() 
{
    CDocument::OnCloseDocument();
}



//////////////////////////// These are all of the Neuroshare acessing functions /////////////////

ns_RESULT CDocPowerNAP::GetLibraryInfo(NsFile & rcFile, ns_LIBRARYINFO & LibraryInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetLibraryInfo(LibraryInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::OpenFile(NsFile & rcFile, LPCSTR szDataName)
{
    ns_RESULT retVal;
    retVal = rcFile.OpenFile(szDataName);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::CloseFile(NsFile & rcFile)
{
    ns_RESULT retVal;
    retVal = rcFile.CloseFile();
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}


ns_RESULT CDocPowerNAP::GetFileInfo(NsFile & rcFile, ns_FILEINFO & FileInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetFileInfo(FileInfo); 
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}
    
ns_RESULT CDocPowerNAP::GetEntityInfo(NsFile & rcFile, uint32 dwEntityID, ns_ENTITYINFO & EntityInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetEntityInfo(dwEntityID, EntityInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}
    
ns_RESULT CDocPowerNAP::GetEventInfo(NsFile & rcFile, uint32 dwEntityID, ns_EVENTINFO & EventInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetEventInfo(dwEntityID, EventInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}
    
ns_RESULT CDocPowerNAP::GetEventData(NsFile & rcFile, uint32 dwEntityID, uint32 nIndex, double *pdTimeStamp, void *pData, uint32 dwDataSize, uint32 *pdwDataRetSize) const 
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetEventData(dwEntityID, nIndex, pdTimeStamp, pData, dwDataSize, pdwDataRetSize);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetAnalogInfo(NsFile & rcFile, uint32 dwEntityID, ns_ANALOGINFO & AnalogInfo) const 
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetAnalogInfo(dwEntityID, AnalogInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetAnalogData(NsFile & rcFile, uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, uint32 *pdwContCount, double *pData) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetAnalogData(dwEntityID, dwStartIndex, dwIndexCount, pdwContCount, pData);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetSegmentInfo(NsFile & rcFile, uint32 dwEntityID, ns_SEGMENTINFO & SegmentInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetSegmentInfo(dwEntityID, SegmentInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetSegmentSourceInfo(NsFile & rcFile, uint32 dwEntityID, uint32 dwSourceID, ns_SEGSOURCEINFO & SourceInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetSegmentSourceInfo(dwEntityID, dwSourceID, SourceInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetSegmentData(NsFile & rcFile, uint32 dwEntityID, int32 nIndex, double *pdTimeStamp, double *pdData, uint32 dwDataBufferSize, uint32 *pdwSampleCount, uint32 *pdwUnitID) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetSegmentData(dwEntityID, nIndex, pdTimeStamp, pdData, dwDataBufferSize, pdwSampleCount, pdwUnitID);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetNeuralInfo(NsFile & rcFile, uint32 dwEntityID, ns_NEURALINFO & NeuralInfo) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetNeuralInfo(dwEntityID, NeuralInfo);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetNeuralData(NsFile & rcFile, uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, double *pdData) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetNeuralData(dwEntityID, dwStartIndex, dwIndexCount, pdData);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetIndexByTime(NsFile & rcFile, uint32 dwEntityID, double dTime, int32 nFlag, uint32 *pdwIndex) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetIndexByTime(dwEntityID, dTime, nFlag, pdwIndex);
#pragma message("CDocPowerNAP::GetIndexByTime - put this back in")

//fix    if (retVal != ns_OK)
//fix        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

ns_RESULT CDocPowerNAP::GetTimeByIndex(NsFile & rcFile, uint32 dwEntityID, uint32 dwIndex, double *pdTime) const
{ 
    ns_RESULT retVal;
    retVal = rcFile.GetTimeByIndex(dwEntityID, dwIndex, pdTime);
    if (retVal != ns_OK)
        ShowLastNsErrorMsg(rcFile);
    return retVal;
}

inline ns_RESULT CDocPowerNAP::GetLastErrorMsg(NsFile & rcFile, char *pszMsgBuffer, uint32 dwMsgBufferSize) const
{ 
    return rcFile.GetLastErrorMsg(pszMsgBuffer, dwMsgBufferSize);
}

#pragma message("CDocPowerNAP::ShowLastNsErrorMsg - Make post to status bar")
void CDocPowerNAP::ShowLastNsErrorMsg(NsFile & rcFile) const
{
#if 1
    // post last error message to status bar
    char szErrorMsg[256] = "\0"; // clear it
    if (ns_OK == GetLastErrorMsg(rcFile, szErrorMsg, sizeof(szErrorMsg)))
        AfxMessageBox(szErrorMsg, MB_ICONEXCLAMATION, 0);
#else
    // Clear out the previous error message
    m_pMainFrm->m_strStatusComments = "";

    // Couldn't get segment source info - post last error message to status bar
    char szErrorMsg[256] = "\0"; // clear it
    if (ns_OK == GetLastErrorMsg(rcFile, szErrorMsg, sizeof(szErrorMsg)))
        m_pMainFrm->m_strStatusComments.Format("Error: %s", szErrorMsg);
#endif
}



//////////////////////////// These are all of the Neuroshare acessing functions /////////////////

void CDocPowerNAP::AddDataFilePrompt()
{
    CString szFilter;
    BuildDataFilter(szFilter);

    // prepare to prompt
    CFileDialog icFileDlg
    (
        TRUE,                                           // TRUE = file open 
        NULL,                                           // Default Extension - we use filters
#ifdef _DEBUG
        "..\\Common Test Files \\sim100.nev",           // Filename - let them choose, but we give a good choice
#else
        NULL,                                           // Filename - let them choose
#endif
        OFN_FILEMUSTEXIST,                              // flags - file must exist and hide read only
        //"Nev Files|*.nev|All Files (*.*)|*.*||",// File extensions
        szFilter,
        NULL                                            
    );

    if (icFileDlg.DoModal() == IDOK)    // if cancel was not pressed
    {
        if (AddDataFile(icFileDlg.GetPathName()) == false)
        {
            CString msg;
            msg.Format("Error\n\nUnable to open %s\n\nDo you have the proper versions\nof the NeuroShare DLL's installed?",
                       icFileDlg.GetFileName() );

            AfxMessageBox(msg, MB_ICONEXCLAMATION, 0);
        }
    }
}

// Author & Date:   Kirk Korver     06 May 2003
// Purpose: Add this data file to the list that we will process    
// Inputs:  rsInfo - the file description
// Outputs: TRUE if the file was sucessfully added; FALSE, otherwise
bool CDocPowerNAP::AppendToFileList(SPFileInfo psInfo)
{
    FileInfo & rsInfo = *psInfo;
    bool bRetVal = true;

    // Here is what just happened. the file is about to be stored in the vector. When it comes out
    // of the vector, we want the file to close, and not now. So we need to tell this
    // instance of the class not to auto-close the file.
    rsInfo.icFile.SetDontCloseOnDestruction();

    m_icFileVector.push_back(psInfo);

    // If there was a problem in the update, then we need to 
    // remove this file
    if (!UpdateAllLists(rsInfo))
    {
        m_icFileVector.pop_back();
        bRetVal = false;
    }
    else
    {
        // Ok, now we've added it to the list. Now we want to ensure it will close on destruction
        // If confused, look above....end() is just past the end....end()-1 is the last in the list.
        m_icFileVector.back()->icFile.SetCloseOnDestruction();

        // Only need to update, if it was added
        GetTotalEntityItemCount();
    }

    // Adding stuff invalidates waveforms, so let the views know
    if (bRetVal)
        UpdateAllViews(NULL);
    
    return bRetVal;
}


// Author & Date:   Kirk Korver
// Purpose: Add a data file to the list of what we will process. Both the name
//          of the DLL and the name of the data fill will be prompted for.
//          stating which DLL to use.
// Outputs: TRUE if the file was sucessfully added; FALSE, otherwise
bool CDocPowerNAP::AddDataFileUsingThisDLLPrompt()
{
    CDlgAdvancedOpen dlg;
    if (dlg.DoModal() == IDOK)
    {
        // Ok, we have the name of 2 files, let's give it a go
        if (true == AddDataFileUsingThisDLL(dlg.m_strDataFilename, dlg.m_strDllFilename))
            return true;
        else
        {
            CString msg;
            msg.Format("Error\n\nUnable to open %s using %s\n\nDo you have the proper versions\nof the NeuroShare DLL's installed?",
                dlg.m_strDataFilename, dlg.m_strDllFilename);

            AfxMessageBox(msg, MB_ICONEXCLAMATION, 0);
            return false;
        }
    }
    return false;
}


// Author & Date:   Kirk Korver     06 May 2003
// Purpose: Add a data file to the list of what we will process explicitately
//          stating which DLL to use.
// Inputs:  szDataPathName - the fully qualifed path name of the data file to open
//          szDllPathName - the fully qualified path name of the DLL to use to read this file
// Outputs: TRUE if the file was sucessfully added; FALSE, otherwise
bool CDocPowerNAP::AddDataFileUsingThisDLL(LPCSTR szDataPathName, LPCSTR szDllPathName)
{
    CWaitCursor wc;
    SPFileInfo psFile(new FileInfo);
    psFile->strFilePathName = szDataPathName;

    if (ns_OK != psFile->icFile.OpenFileUsingThisDLL(szDataPathName, szDllPathName))
        return false;
 
    return AppendToFileList(psFile);
}


// Author & Date:   Kirk Korver     Mar 25, 2003
// Purpose: Add a data file to what we've got
// Inputs:  szPathName - the fully qualified path name of the data file to open
// Outputs: TRUE if the file was sucessfully added; FALSE, otherwise
bool CDocPowerNAP::AddDataFile(LPCSTR szPathName)
{
    CWaitCursor wc;
    SPFileInfo psFile(new FileInfo);
    psFile->strFilePathName = szPathName;

    if (ns_OK != psFile->icFile.OpenFile(szPathName))
        return false;
 
    return AppendToFileList(psFile);
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Add a data file to all lists
// Inputs:  rsFileInfo - data file we are now adding
// Outputs: True if it worked, false if not
bool CDocPowerNAP::UpdateAllLists(FileInfo & rsFileInfo)
{
    NsFile & rcFile = rsFileInfo.icFile;
    if (m_icEntityInfoVector.empty())  // If the list is empty, just fill it in
    {
        BuildEntityAndDataLists(rsFileInfo);
    }
    else
    {   // Ok, a list exists, so we have to make sure the same entities exist
        // First check the same entities are present in the file
        if ( (!CompareEntityHeaders(m_icFileVector.front()->icFile, rcFile, ns_ENTITY_SEGMENT)) ||
             (!CompareEntityHeaders(m_icFileVector.front()->icFile, rcFile, ns_ENTITY_ANALOG)) )
            return false;

        // Now we have to make sure that the actual entities in the list are the same
        ENTITYINFOLIST::iterator eit = m_icEntityInfoVector.begin();
        
        // Note: The iterator is incremented inside the functions
        if ( (!AppendEntityList(rcFile, eit, ns_ENTITY_SEGMENT)) ||
             (!AppendEntityList(rcFile, eit, ns_ENTITY_ANALOG)) )
            return false;

        AppendDataLists(rsFileInfo);
    }

    return true;
}


// Author & Date:   Almut Branner   12 Sept, 2003
// Purpose: Build the EntityInfoList and all specific entity lists for the first file
// Input:   Reference to the file to be processed
void CDocPowerNAP::BuildEntityAndDataLists(FileInfo & rsFileInfo)
{
    NsFile & rcFile = rsFileInfo.icFile;

    // Make sure that all lists are empty
    DeleteDataLists();

    // First all the segment entities
    for (NsFileEntityInfoByTypeIterator sit(rcFile, ns_ENTITY_SEGMENT); sit; ++sit)
    {
        EntityInfo Info;
        Info.dwEntityIndex = sit.GetCurrentIndex();
        Info.isEntityInfo = sit();

        // Don't throw the entry in the list if there is no data
        if ( (m_bDiscardEmptyEntities) && (Info.isEntityInfo.dwItemCount == 0) )
            continue;

        m_icEntityInfoVector.push_back(Info);

        // Fill in segment list
        SPSegments SegList(new Segments(Info.dwEntityIndex));
        m_icSegmentList.push_back(SegList);

        AppendSegmentListEntry(rsFileInfo, *m_icSegmentList.back());
    }

    // Then all the analog entities
    for (NsFileEntityInfoByTypeIterator ait(rcFile, ns_ENTITY_ANALOG); ait; ++ait)
    {
        EntityInfo Info;
        Info.dwEntityIndex = ait.GetCurrentIndex();
        Info.isEntityInfo = ait();

        // Don't throw the entry in the list if there is no data
        if ( (m_bDiscardEmptyEntities) && (Info.isEntityInfo.dwItemCount == 0) )
            continue;

        m_icEntityInfoVector.push_back(Info);

        // Fill in analog list
        SPAnalogs AnalogList(new Analogs(Info.dwEntityIndex));
        m_icAnalogList.push_back(AnalogList);

        AppendAnalogListEntry(rsFileInfo, *m_icAnalogList.back());
    }
    // TODO: Have to add other types

    SetActiveEntity(m_icEntityInfoVector.begin()->dwEntityIndex);
}


// Author & Date:   Kirk Korver
// Purpose: Append a specific file to the wave form list
// Inputs:  rsFileInfo - the file from which to append data
//          rcList - Where to put the list (basically into which entity)
void CDocPowerNAP::AppendSegmentListEntry(FileInfo & rsFileInfo, Segments & rcList)
{
    // If we are supposed to use them all, then configure it to work that way
    if (m_bSampleData)
        SetTrainingPopulation(rsFileInfo, rcList, m_nNumOfGroups, m_nNumOfSamples);
    else
        SetTrainingPopulation(rsFileInfo, rcList, m_nNumOfGroups, 0xFFFFFFFF);

    // If we ended up with no waves, then we should stop
    if (rcList.empty())
        return;

    if (m_bThreshold)
    {
        ThresholdThisEntity(rcList.GetEntityID());
    }
/*
    if (this->m_bAlignPeaks)
    {
        VisitorAlignCheck v;
        Accept(v);
    }

    // Time to clip if required.
    if (this->m_bRemoveSaturatedSpikes)
    {
        VisitorClipCheck v;
        Accept(v);
    }*/
}


// Author & Date:   Angela Wang     Mar 10, 2003
// Purpose: Create training population array of waveforms.  Total number of training waveforms
//          are selected at dwGroupCount intervals from entire timespan.     
// Inputs:  rcFile - the reference to the file we are working with
//          rcList - the list of waveforms to build..it is assumed that it is empty
//          dwGroupCount - number of groups waveform come from
//          dwTrainCount - number of waveforms to use per group and per file
// Outputs: None
void CDocPowerNAP::SetTrainingPopulation(FileInfo & rsFileInfo, Segments & rcList, 
                                         uint32 dwGroupCount, uint32 dwTrainCount)
{
    NsFile & rcFile = rsFileInfo.icFile;

    uint32 dwEntityID = rcList.GetEntityID();
    ns_ENTITYINFO EtyInfo;

    if (ns_OK != GetEntityInfo(rcFile, dwEntityID, EtyInfo))
        return;
    
    // How many samples in each continuous run of data
    uint32 dwTrainWfPerGroup = dwTrainCount;

    // Where to start each of the runs
    uint32 dwIntervalCnt = EtyInfo.dwItemCount / dwGroupCount;

    if (EtyInfo.dwItemCount <= dwTrainCount * dwGroupCount)
    {
        // Can't sample more than we have :-)
        if (EtyInfo.dwItemCount < dwTrainCount)
        {
            // Set total sample count to number available
            // Only one group
            dwTrainWfPerGroup = EtyInfo.dwItemCount;
            dwIntervalCnt = EtyInfo.dwItemCount;
        }
        else     
            dwTrainWfPerGroup = EtyInfo.dwItemCount / dwGroupCount;
    }
            
    ns_SEGMENTINFO isSegInfo;
    if (ns_OK != GetSegmentInfo(rcFile, dwEntityID, isSegInfo))
        return;
    
    if (isSegInfo.dwMaxSampleCount != isSegInfo.dwMinSampleCount)
    {
        AfxMessageBox(IDS_ERROR_DATA_POINTS_NOT_EQUAL, MB_ICONEXCLAMATION, 0);
        return;
    }
    
    //TODO: This needs to be augmented to handle tetrodes and such
    if (isSegInfo.dwSourceCount != 1)
    {
        AfxMessageBox("We can not handle multi-trodes at this point.", MB_ICONEXCLAMATION, 0);
        return;
    }
    
    DWORD nStop;

    if (EtyInfo.dwItemCount == dwTrainWfPerGroup)
        nStop = EtyInfo.dwItemCount;
    else
        nStop = EtyInfo.dwItemCount - dwTrainWfPerGroup;

    UnitList.clear();

    // All the prep work is done....let's fill in the list
    for (DWORD nStart = 0; nStart < nStop; nStart += dwIntervalCnt)
    {
        for (DWORD nRun = nStart; nRun < nStart + dwTrainWfPerGroup; ++nRun)
        {
            DataSegment ds(&rsFileInfo, &rcList, nRun);
            rcList.push_back(ds);
        }
    }
}


// Author & Date:   Almut Branner   3 Feb 2004
// Purpose: Append data to all lists from current file
void CDocPowerNAP::AppendDataLists(FileInfo & rsFileInfo)
{
    AppendSegList(rsFileInfo);
    AppendAnaList(rsFileInfo);
}


// Author & Date:   Almut Branner   4 Feb 2004
// Purpose: Append data to the segment list from current file
void CDocPowerNAP::AppendSegList(FileInfo & rsFileInfo)
{
    ENTITYINFOLIST::iterator eit = m_icEntityInfoVector.begin();

    for (EntityInfoByTypeIterator setit(this, eit, ns_ENTITY_SEGMENT); setit; ++setit)
    {
        // Fill in segment list
        SPSegments SegList(new Segments(setit.GetCurrentIndex()));
        m_icSegmentList.push_back(SegList);

        AppendSegmentListEntry(rsFileInfo, *m_icSegmentList.back());
    }
}


// Author & Date:   Almut Branner   4 Feb 2004
// Purpose: Append data to the analog list from current file
void CDocPowerNAP::AppendAnaList(FileInfo & rsFileInfo)
{
    ENTITYINFOLIST::iterator eit = m_icEntityInfoVector.begin();

    for (EntityInfoByTypeIterator aetit(this, eit, ns_ENTITY_ANALOG); aetit; ++aetit)
    {
        // Fill in analog list
        SPAnalogs AnalogList(new Analogs(aetit.GetCurrentIndex()));
        m_icAnalogList.push_back(AnalogList);

        AppendAnalogListEntry(rsFileInfo, *m_icAnalogList.back());
    }
}


// Author & Date:   Almut Branner   2 Feb 2004
// Purpose: Update and build the data lists using the current settings,
//          then update all of the views
void CDocPowerNAP::RebuildDataListsAndUpdateViews()
{
    RebuildDataLists();

    // Make ALL views update, 'cuz all lists were just erased and rebuilt
    // The only view not to update is the "sender"..NULL means ALL views
    UpdateAllViews(NULL);
}


// Author & Date:   Almut Branner   2 Feb 2004
// Purpose: Update and build the data lists using the current settings
void CDocPowerNAP::RebuildDataLists()
{
    // Make sure that all lists are empty
    DeleteDataLists();

    // Go through all entities and files
    FILEINFOLIST::iterator fit;

    for (fit = m_icFileVector.begin(); fit != m_icFileVector.end(); ++fit)
    {
        AppendDataLists(**fit);
    }

    if (m_bDiscardEmptyEntities)
        DiscardEmptyEntities();
}


// Author & Date:   Almut Branner   4 Feb 2004
// Purpose: Update and build the segment list using the current settings,
//          then update all of the views
void CDocPowerNAP::RebuildSegListAndUpdateViews()
{
    RebuildSegList();

    // Make ALL views update, 'cuz all lists were just erased and rebuilt
    // The only view not to update is the "sender"..NULL means ALL views
    UpdateAllViews(NULL);
}


// Author & Date:   Almut Branner   4 Feb 2004
// Purpose: Update and build the segment list using the current settings,
void CDocPowerNAP::RebuildSegList()
{
    // Make sure that all lists are empty
    m_icSegmentList.clear();

    // Go through all entities and files
    FILEINFOLIST::iterator fit;

    for (fit = m_icFileVector.begin(); fit != m_icFileVector.end(); ++fit)
    {
        AppendSegList(**fit);
    }

    if (m_bDiscardEmptyEntities)
        DiscardEmptyEntities();
}


// Author & Date:   Almut Branner   4 Feb 2004
// Purpose: Update and build the analog list using the current settings,
//          then update all of the views
void CDocPowerNAP::RebuildAnaListAndUpdateViews()
{
    RebuildAnaList();

    // Make ALL views update, 'cuz all lists were just erased and rebuilt
    // The only view not to update is the "sender"..NULL means ALL views
    UpdateAllViews(NULL);
}

// Author & Date:   Almut Branner   4 Feb 2004
// Purpose: Update and build the analog list using the current settings,
void CDocPowerNAP::RebuildAnaList()
{
    // Make sure that all lists are empty
    m_icAnalogList.clear();  

    // Go through all entities and files
    FILEINFOLIST::iterator fit;

    for (fit = m_icFileVector.begin(); fit != m_icFileVector.end(); ++fit)
    {
        AppendAnaList(**fit);
    }

    if (m_bDiscardEmptyEntities)
        DiscardEmptyEntities();
}


// Author & Date:   Almut Branner   2 Feb 2004
// Purpose: Update and build the all lists using the current settings,
//          then update all of the views
void CDocPowerNAP::RebuildAllListsAndUpdateViews()
{
    // Throw out the old lists
    m_icEntityInfoVector.clear();
    m_icSegmentList.clear();
    m_icAnalogList.clear();

    for (FILEINFOLIST::iterator fit = m_icFileVector.begin(); fit != m_icFileVector.end(); ++fit)
        UpdateAllLists(**fit);

    // Make ALL views update, 'cuz all lists were just erased and rebuilt
    // The only view not to update is the "sender"..NULL means ALL views
    UpdateAllViews(NULL);
}


// Author & Date:   Almut Branner   Sept 12, 2003
// Purpose: Append the current entity list with the entities in the file by type
// Inputs:  rcFile - reference to the new file
//          it - iterator through the entity list
//          nType - what entity type are we currently comparing
bool CDocPowerNAP::AppendEntityList(NsFile & rcFile, ENTITYINFOLIST::iterator & it, int32 nType)
{
    for (NsFileEntityInfoByTypeIterator sit(rcFile, nType); sit; ++sit)
    {
        // in the normal exit, both iterators will end at the same time
        if (it == m_icEntityInfoVector.end())
        {
            if (!sit)  // Both iterators ended so we're ok
                return true;
            else  // Here, only 1 iterator is at the end
            {
                EntityInfo Info;
                Info.dwEntityIndex = sit.GetCurrentIndex();
                Info.isEntityInfo = sit();

                m_icEntityInfoVector.push_back(Info);

                // Reset the iterator because its position in memory might have changed
                it = m_icEntityInfoVector.end() - 1;
            }
        }
        else
        {
            if (sit)
            {
                EntityInfo Info;
                Info.dwEntityIndex = sit.GetCurrentIndex();
                Info.isEntityInfo = sit();

                if (Info != *it)
                {  // Ok, we have a discrepancy...have to add an additional entry
                    EntityInfo Info;
                    Info.dwEntityIndex = sit.GetCurrentIndex();
                    Info.isEntityInfo = sit();

                    // We have to save the index to be able to get back to it
                    int nIndex = it - m_icEntityInfoVector.begin();

                    m_icEntityInfoVector.insert(it, Info);

                    it = m_icEntityInfoVector.begin() + nIndex;
                }
            }
        }
        ++it;
    }

    if (m_bDiscardEmptyEntities)
        DiscardEmptyEntities();

    return true;
}


// Author & Date:   Almut Branner   Feb 4, 2004
// Purpose: Compare the first file's entities with the entities in the file
// Inputs:  rcFileOld - reference to the old file
//          rcFileNew - reference to the new file
bool CDocPowerNAP::CompareEntityHeaders(NsFile & rcFileOld, NsFile & rcFileNew, int32 nType)
{
    NsFileEntityInfoByTypeIterator fitold(rcFileOld, nType);

    for (NsFileEntityInfoByTypeIterator fitnew(rcFileNew, nType); fitnew; ++fitnew)
    {
        // in the normal exit, both iterators will end at the same time
        if (!fitold)
        {
            if (!fitnew)  // Both iterators ended so we're ok
                return true;
            else
                return false;  // Here, only 1 iterator is at the end
        }
        else
        {
            if (fitnew)
            {
                EntityInfo InfoNew;
                InfoNew.dwEntityIndex = fitnew.GetCurrentIndex();
                InfoNew.isEntityInfo = fitnew();

                EntityInfo InfoOld;
                InfoOld.dwEntityIndex = fitold.GetCurrentIndex();
                InfoOld.isEntityInfo = fitold();

                if (InfoOld != InfoNew)
                    return false;  // Ok, we have a discrepancy...time to exit
            }
        }

        ++fitold;
    }

    return true;
}


// Author & Date:   Kirk Korver     22 Apr 2003
// Purpose: read from the files to fill in the total item entity count
void CDocPowerNAP::GetTotalEntityItemCount()
{
    // First 0 out the entities
    ENTITYINFOLIST::iterator eit;

    for (eit = m_icEntityInfoVector.begin(); eit != m_icEntityInfoVector.end(); ++eit)
    {
        eit->isEntityInfo.dwItemCount = 0;
    }

    FILEINFOLIST::iterator fit;

    ns_ENTITYINFO isEInfo;   // put out here for performance reasons

    // For each entity, and for each file
    for (eit = m_icEntityInfoVector.begin(); eit != m_icEntityInfoVector.end(); ++eit)
    {
        for (fit = m_icFileVector.begin(); fit != m_icFileVector.end(); ++fit)
        {
            if (ns_OK == GetEntityInfo((*fit)->icFile, (*eit).dwEntityIndex, isEInfo))
            {
                eit->isEntityInfo.dwItemCount += isEInfo.dwItemCount;
            }
        }
    }
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Throw out all entities that don't have any entries
// Output:  true - some entities were deleted, false - nothing changed
bool CDocPowerNAP::DiscardEmptyEntities()
{
    ENTITYINFOLIST::iterator eit;
    bool bChanged = false;

    for (eit = m_icEntityInfoVector.begin(); eit != m_icEntityInfoVector.end(); )
    {
        if (eit->isEntityInfo.dwItemCount == 0)
        {
            int nIndex = eit - m_icEntityInfoVector.begin();
            DWORD dwEntityID = (*eit).dwEntityIndex;

            m_icEntityInfoVector.erase(eit);

            eit = m_icEntityInfoVector.begin() + nIndex;

            // Also erase segment or analog entry
            DeleteEntityData(dwEntityID);

            if (!bChanged)
                bChanged = true;
        }
        else
            ++eit;
    }

    if (bChanged)
        SetActiveEntity(m_icEntityInfoVector.begin()->dwEntityIndex);

    return bChanged;
}


// Author & Date:   Almut Branner   5 Feb 2004
// Purpose: Delete an entry out a data list
// Input:   dwEntityID - the entity that is to be erased
// Output:  true - an entry was deleted, false - nothing changed
bool CDocPowerNAP::DeleteEntityData(uint32 dwEntityID)
{
    bool bDeleted = false;

    if (IsSegment(dwEntityID))
    {
        int32 nIndex = GetIdxSegment(dwEntityID);
        if (nIndex >= 0)  // just to make sure
        {
            m_icSegmentList.erase(m_icSegmentList.begin() + nIndex);
            bDeleted = true;
        }
    }
    else if (IsAnalog(dwEntityID))
    {
        int32 nIndex = GetIdxAnalog(dwEntityID);
        if (nIndex >= 0)  // just to make sure
        {
            m_icAnalogList.erase(m_icAnalogList.begin() + nIndex);
            bDeleted = true;
        }
    }

    return bDeleted;
}


// Author & Date:   Almut Branner   6 Feb 2004
// Purpose: Delete an entity and its data
// Input:   dwEntityID - the entity that is to be erased
// Output:  true - an entry was deleted, false - nothing changed
bool CDocPowerNAP::DeleteEntity(uint32 dwEntityID)
{
    bool bDeleted = false;

    int nIndex = GetIdxEntity(dwEntityID);
    if (nIndex >= 0)  // Have to make sure that we found an entry to delete
    {
        DeleteEntityData(dwEntityID);
        m_icEntityInfoVector.erase(m_icEntityInfoVector.begin() + nIndex);
        bDeleted = true;
        UpdateAllViews(NULL);
    }
    return bDeleted;
}


// Author & Date:   Almut Branner   12 Sept, 2003
// Purpose: Build the analog entity list
// Inputs:
//  rsFileInfo - the file we use to read this data
//  rcList - reference to the ANALOGLIST
void CDocPowerNAP::AppendAnalogListEntry(FileInfo & rsFileInfo, Analogs & rcList)
{
    NsFile & rcFile = rsFileInfo.icFile;

    DWORD dwEntityID = rcList.GetEntityID();

    DWORD dwFile = GetFileIndex(rcFile);
    DWORD dwEntity = m_icAnalogList.size() - 1;
    DWORD dwCount = GetEntity(dwEntityID).isEntityInfo.dwItemCount;
    
    DataAnalog AnalogEntry(&rsFileInfo, &rcList, 0, dwCount);
    rcList.push_back(AnalogEntry);
}


void CDocPowerNAP::DeleteContents() 
{
    m_icFileVector.clear();
    m_icEntityInfoVector.clear();
    m_icSegmentList.clear();
    m_icAnalogList.clear();  

    CDocument::DeleteContents();
}


void CDocPowerNAP::DeleteDataLists()
{
    m_icSegmentList.clear();
    m_icAnalogList.clear();  
}


// Purpose: Create or activate a view of the document data
CView * CDocPowerNAP::CreateOrActivateView(const CRuntimeClass *pClass)
{
    WINDOWPLACEMENT isPrevWndPl;    // placement of last-most found window frame
    WINDOWPLACEMENT isCurrWndPl;    // current placement of "this" window frame
    WINDOWPLACEMENT isFIUWndPl;     // current placement if the FilesInUse frame
    
    BOOL bViewFound = FALSE;
    CView *pFoundView;
    pFoundView = NULL;

    POSITION pos = GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetNextView(pos);
      
        if (pView->IsKindOf( RUNTIME_CLASS(CViewFilesInUse) ))
        {
            pView->GetParentFrame()->GetWindowPlacement(&isFIUWndPl); 
        }

        if (pView->IsKindOf( pClass ))
        {
            pFoundView = pView;
            CFrameWnd * pFrame = pView->GetParentFrame();
            ASSERT(pFrame != NULL);

            pFrame->ActivateFrame();

            bViewFound  = TRUE;
        }
        else
        {
            // Save position on child views not of the right kind
            pView->GetParentFrame()->GetWindowPlacement(&isPrevWndPl); 
        }
    }
    
    if (!bViewFound)
    {
        // If this View doesn't exist for this document, create it
        CDocTemplate * pTemplate = GetTemplateFromClass(pClass);
        ASSERT(pTemplate != NULL);
        CFrameWnd * pNewFrame = pTemplate->CreateNewFrame(this, NULL);
        ASSERT(pNewFrame != NULL);

        if (pNewFrame == NULL)
            return NULL; 

        ASSERT_KINDOF(CFrameWnd, pNewFrame);
        pTemplate->InitialUpdateFrame(pNewFrame, this);
        pFoundView = pNewFrame->GetActiveView();

        // Position the new frame
        pNewFrame->GetWindowPlacement(&isCurrWndPl);  // Get current dimensions 

        // This is were I would like to place the window..it may be off the screen though
        //    next to and to the right of the previous view
        CPoint ptWnd;
        if ((CRect) isPrevWndPl.rcNormalPosition == (CRect) isFIUWndPl.rcNormalPosition)
        {
            CRect rctPrev = isFIUWndPl.rcNormalPosition;
            CPoint ptTL(rctPrev.left, rctPrev.bottom);  // TOP/left of new window (Bottom/left of old)
            ptWnd = MakePointOnScreen(ptTL);            // Adjust if off the screen
        }
        else
        {
            CRect rctPrev = isPrevWndPl.rcNormalPosition;
            CPoint ptTL(rctPrev.right, rctPrev.top);  // TOP/left of new window (Top/left of old but shifted)
            ptWnd = MakePointOnScreen(ptTL);                   // Adjust if off the screen
        }

        CRect rctNew = isCurrWndPl.rcNormalPosition;

        pNewFrame->MoveWindow(ptWnd.x, ptWnd.y, rctNew.Width(), rctNew.Height(), TRUE);
    }
    return pFoundView;
}  //CreateOrActivateView


// Author & Date:   Kirk Korver     22 Apr 2003
// Purpose: Remove this file from the list
// Inputs:  nIndex - the offset of this file into the array of files (0 based)
void CDocPowerNAP::RemoveFile(int nIndex)
{
    ASSERT(nIndex >= 0);
    ASSERT(nIndex < m_icFileVector.size());

    m_icFileVector.erase(m_icFileVector.begin() + nIndex);

    // If there are no more files, then we need to remove the entity info's as well
    if (m_icFileVector.empty())
    {
        m_icEntityInfoVector.clear();
        m_icSegmentList.clear();
        m_icAnalogList.clear();
    }

    // In any case, the views are no longer valid, and neither are the waves
    GetTotalEntityItemCount();
    RebuildDataListsAndUpdateViews();
}

// Author & Date:   Kirk Korver     09 Apr 2003
// Purpose: Tell me how many data points each wave form contains
//          We assume that all wave forms contain the same number of data points
// Outputs: The number of points that EACH wave form has
DWORD CDocPowerNAP::GetNumOfPointsPerWave()
{
    const Segments & rSeg = GetActiveSegment();

    if (rSeg.empty())
        return 0;

    return rSeg.begin()->GetNumOfPoints();
}


// Author & Date:   Almut Branner     5 May 2003
// Purpose: Call this to calculate the minimum and maximum data values of all waveforms
void CDocPowerNAP::SetMinMaxWfValues()
{
    // Check if data file exists
    if (m_icFileVector.empty())
        return;

    const Segments & rSeg = GetActiveSegment();
    if (rSeg.empty())
        return;

    uint32 dwCurrEntity = GetActiveEntity();

    ns_SEGMENTINFO isSegInfo;
    ns_SEGSOURCEINFO isSegSourceInfo;

    FileInfo & isInfo = *m_icFileVector[0];
    
    // Getting info from first selected data file
    GetSegmentInfo(isInfo.icFile, dwCurrEntity, isSegInfo);
    GetSegmentSourceInfo(isInfo.icFile, dwCurrEntity, 0, isSegSourceInfo);

    // Scale y-axis.
    // Figure out largest positive and negative points
    double dMaxPossVal = isSegSourceInfo.dMaxVal;
    double dMinPossVal = isSegSourceInfo.dMinVal;
    double dMaxVal = 0;
    double dMinVal = 0;

    for (SEGMENTLIST::const_iterator it = rSeg.begin();
         it != rSeg.end(); ++it)
    {
        // Get the actual wave form
        WAVEFORM aicWave;
        it->GetWave(aicWave);

        for (WAVEFORM::iterator wit = aicWave.begin(); wit != aicWave.end(); ++wit)
        {
            if (*wit >= dMaxVal)
                dMaxVal = *wit;
            if (*wit <= dMinVal)
                dMinVal = *wit;
        }
    }

    // Set the vertical scaling
    // Right now the scaling has to be symmetrical because of the way we are drawing the waveform.
    // Make the scale 1.05 times larger than the maximum peaks for better viewing.
    double dScale = 1.05;

    if ((dMaxVal >= -dMinVal) && (dMaxVal * dScale < dMaxPossVal))
        m_dMaxWfVal = dMaxVal * dScale;
    else if ((-dMinVal > dMaxVal) && (dMinVal * dScale > dMinPossVal))
        m_dMaxWfVal = -dMinVal * dScale;
    else
        m_dMaxWfVal = dMaxPossVal;
}


// Author & Date:   Angela Wang     9 June 2003
// Purpose:  The waveform  with index, nSelIndex, has been selected.
//           Views should hi-light this waveform.
void CDocPowerNAP::SetSelWF(UINT32 nSelIndex)
{
    // Post message that a waveform has been selected for
    // high-lighting to each of the views
    POSITION pos = GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetNextView(pos);
        if (pView)
             pView->PostMessage( WM_USER_SELECTWF, m_dwPrevSelIndex, nSelIndex);    
    }   

    // Save previous selection
    m_dwPrevSelIndex = nSelIndex;
}


// Author & Date:   Angela Wang     10 June 2003
// Purpose:  The waveform  with index, nSelIndex, has been de-selected.
//           Views should remove hi-light of this waveform.
void CDocPowerNAP::SetUnSelWF(UINT32 nSelIndex)
{
    // Post message that a waveform has been selected for
    // high-lighting to each of the views
    POSITION pos = GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetNextView(pos);
        if (pView)
             pView->PostMessage( WM_USER_UNSELECTWF, 0, nSelIndex);    
    }   

    
    // Save previous selection
    m_dwPrevSelIndex = 0;
}


// Purpose: Set flag that current entity has sorting rules defined
void CDocPowerNAP::SetSorted(bool bRulesDefined)
{
    m_icEntityInfoVector[GetActiveEntityIndex()].m_bRulesDefined = bRulesDefined;
}


BOOL CDocPowerNAP::DestroyView(CView *pView)
{
    BOOL bRet = pView->DestroyWindow();

    return bRet;
}


// Author & Date:   Almut Branner   Sept 10, 2003
// Purpose: Check whether we have any segments
// Outputs: Returns true if segments exist
bool CDocPowerNAP::AreThereSegments()
{
    return (!m_icSegmentList.empty());
}


// Author & Date:   Almut Branner   Sept 11, 2003
// Purpose: Check whether the currently selected entity is a segment
// Outputs: Returns true if this is a segment
bool CDocPowerNAP::IsActiveSegment()
{
    return (m_icEntityInfoVector[GetActiveEntityIndex()].isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT);
}


// Author & Date:   Almut Branner   Oct 13, 2003
// Purpose: Check whether a specific entity is a segment
// Outputs: Returns true if this is a segment
bool CDocPowerNAP::IsSegment(int32 dwEntityID)
{
    return (GetEntity(dwEntityID).isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT);
}


// Author & Date:   Almut Branner   Oct 13, 2003
// Purpose: Check whether we have any analog channels
// Outputs: Returns true if analog channels exist
bool CDocPowerNAP::AreThereAnalogs()
{
    return (!m_icAnalogList.empty());
}


// Author & Date:   Almut Branner   Oct 13, 2003
// Purpose: Check whether the currently selected entity is an analog channel
// Outputs: Returns true if this is an analog channel
bool CDocPowerNAP::IsActiveAnalog()
{
    return (m_icEntityInfoVector[GetActiveEntityIndex()].isEntityInfo.dwEntityType == ns_ENTITY_ANALOG);
}


// Author & Date:   Almut Branner   Oct 13, 2003
// Purpose: Check whether a specific entity is an analog channel
// Outputs: Returns true if this is an analog channel
bool CDocPowerNAP::IsAnalog(int32 dwEntityID)
{
    return (GetEntity(dwEntityID).isEntityInfo.dwEntityType == ns_ENTITY_ANALOG);
}



// Author & Date:   Kirk Korver     12 Sept 2003
// Purpose: Save all of the data to this file.
//  This is the top-most function of the chain. Call this one when
//  you want to have all of the data saved to a file
// Inputs:
//  szName - the name of the file to create
bool CDocPowerNAP::SaveDataNoPrompt(LPCSTR szName)
{
    bool retVal = false;        // Assume it is bad

    // Get the interface from the class
    NSNWriter w;
    if (!w.IsOK())
    {
        AfxMessageBox("Problems using NSN library\n\n"
                      "Ensure that nsNSNLibrary.dll\n"
                      "is in the current directory",
                      MB_ICONEXCLAMATION, 0);
    }
    else
    {
        IWriteNSN * I = w.GetIWriteNSN();
        I->OpenFile(szName, true);

        SaveSegments(*I);

        I->CloseFile();
        retVal = true;
    }

    return retVal;
}


// Author & Date:   Kirk Korver     12 Sep 2003
// Purpose: Save the current segments into this file
//          It is assumed that the file is already open
// Inputs:  I - the interface to the currently open data file
void CDocPowerNAP::SaveSegments(IWriteNSN & I)
{
    //// for every channel
    for (SEGMENTENTITYLIST::iterator sit = m_icSegmentList.begin();
         sit != m_icSegmentList.end();
         ++sit)
    {
        // We won't store empty channels
        if ((*sit)->empty())
            continue;

        //// Get and store the common stuff
        CString szLabel = (*sit)->GetLabel();
        ns_SEGMENTINFO isInfo;
        (*sit)->GetInfo(isInfo);
        std::vector<ns_SEGSOURCEINFO> vInfo;
        (*sit)->GetInfo(vInfo);

        ASSERT(vInfo.size() == isInfo.dwSourceCount);

        ns_SEGSOURCEINFO * asInfo = vInfo.begin();

        I.BeginEntitySegment(szLabel, isInfo.dwSourceCount, isInfo.dSampleRate, isInfo.szUnits, vInfo.begin() );


        //// for each segment
        for (SEGMENTLIST::iterator it = (*sit)->begin(); it != (*sit)->end(); ++it)
        {
            double dTimeStamp = (*it).GetTime();
            uint32 dwUnitID = (*it).GetUnitID();
            WAVEFORM vWave;
            (*it).GetWave(vWave);

            I.AddDataSegment(dTimeStamp, dwUnitID, vWave.size(), vWave.begin() );
        }

        I.EndEntitySegment();
    }
}


// Author & Date:   Kirk Korver
// Purpose: Save the current analog waveforms into this file
//          It is assumed that the file is already open
// Inputs:  I - the interface to the currently open data file
void CDocPowerNAP::SaveAnalogs(IWriteNSN & I)
{
    // for every entity
    for (ANALOGENTITYLIST::iterator itChan = m_icAnalogList.begin();
         itChan != m_icAnalogList.end();
         ++itChan)
    {
        //// We won't store empty channels
        if ((*itChan)->empty())
            continue;

        DWORD dwEntityID = (*itChan)->GetEntityID();

        //// Save and store the common stuff
        CString szLabel = (*itChan)->GetLabel();
        ns_ANALOGINFO icInfo;
        (*itChan)->GetInfo(icInfo);


        I.BeginEntityAnalog(szLabel, &icInfo);

        //// Now save every individual waveform
        for (ANALOGLIST::iterator it = (*itChan)->begin(); it != (*itChan)->end(); ++it)
        {
            WAVEFORM ivWave;
            (*it).GetWave(ivWave);
            I.AddDataAnalog((*it).GetTimeFirst(), ivWave.size(), ivWave.begin());
        }

        // Close it up
        I.EndEntityAnalog();
    }
}

// Author & Date:   Kirk Korver     16 Sep 2003
// Purpose: Create the filter for all of the data files we use
//  Use this as a parameter for a file-open dialog
// Outputs:
//  rcFilter - the string with the appropriate data filters
void CDocPowerNAP::BuildDataFilter(CString & rcFilter)
{
    // Clear out any previous string
    rcFilter.Empty();

    CString strAllTypes = "All Known Types|";
    CString strSpecificTypes;


    // For every library
    const ElementList & rcLibs = NsLibraryImpMgr::GetMgr().GetLibraryList().GetElementList();
    for (ElementList::const_iterator it = rcLibs.begin(); it != rcLibs.end(); ++it)
    {
        // get the short name
        CString strShortName( it->m_strDllPathName );
        int nCharPos = strShortName.ReverseFind('\\');
        strShortName = strShortName.Right(strShortName.GetLength() - nCharPos - 1);
        nCharPos = strShortName.ReverseFind('.');
        strShortName = strShortName.Left(nCharPos);
        

        // Add every extension to the specific type list list
        const std::vector<CString> & rvExts = it->GetExtensions();
        std::vector<CString>::const_iterator it;
        for (it = rvExts.begin(); it != rvExts.end(); ++it)
        {
            CString szFlt;
            szFlt.Format("%s Files (*.%s)|*.%s|", strShortName, *it, *it);
            strSpecificTypes += szFlt;

            // Now let's build the "all types"
            strAllTypes += "*.";
            strAllTypes += *it;
            strAllTypes += ";";
        }
    }

    // I need to change the last character of All Types to a bar
    int nLen = strAllTypes.GetLength();
    strAllTypes = strAllTypes.Left(nLen - 1);
    strAllTypes += "|";

    // Add the "all files choice and the terminiation"
    strSpecificTypes += "All Files (*.*)|*.*||";

    rcFilter = strAllTypes + strSpecificTypes;
}


// Author & Date:   Kirk Korver     15 Oct 2003
// Purpose: Save the current data to a NSN format. We need
//  to prompt for the name though
bool CDocPowerNAP::SaveDataPrompt()
{
    CFileDialog dlg
    (
        FALSE,                                          // TRUE = file open 
        "nsn",                                          // Default Extension - *.nsn
        NULL,                                           // Filename - let them choose
        OFN_OVERWRITEPROMPT,                            // flags - prompt to overwrite
        "NSN-Files (*.nsn)|*.nsn|All Files (*.*)|*.*||",// File extensions
        NULL                                            // Parent Window
    );

    if (dlg.DoModal() == IDOK)    // if cancel was not pressed
    {
        if (SaveDataNoPrompt(dlg.GetPathName()))
            return true;
        else
        {
            CString msg;
            msg.Format("Error\n\nUnable to save %s\n", dlg.GetFileName() );

            AfxMessageBox(msg, MB_ICONEXCLAMATION, 0);
            return false;
        }
    }
    return false;
}

void CDocPowerNAP::SetThreshold(DWORD dwEntity, double dThreshold)
{
    ASSERT(dwEntity < ARRAY_SIZE(m_dThreshold));

    m_dThreshold[dwEntity] = dThreshold;

    // It only makes sense to set the threshold value if we want to turn it on
    if (!m_bThreshold)
        SetThresholding(true);
}


double CDocPowerNAP::GetThreshold(DWORD dwEntity)
{
    ASSERT(dwEntity < ARRAY_SIZE(m_dThreshold));

    return m_dThreshold[dwEntity];
}

// Author & Date:       Kirk Korver     15 Oct 2003
// Purpose: Force the thresholding on/off
// Inputs:
//  bOn - TRUE means we want to turn thresholding on
void CDocPowerNAP::SetThresholding(bool bOn)
{
    m_bThreshold = bOn;

    // Thresholding will actually be done here
    // This action invalidates all wave forms
    RebuildSegListAndUpdateViews();
}

bool CDocPowerNAP::GetThresholding()
{
    return m_bThreshold;
}

void CDocPowerNAP::ThresholdThisEntity(DWORD dwEntity, bool bRebuildIfNecessary /*= false*/)
{
    VisitorThresholdCheck v(dwEntity);
    Accept(v);
}

// Author & Date:   Kirk Korver     05 Mar 2004
// Purpose: remove indices with spikes that touch this value
// Inputs:
//  dRejectVal - the value to compare against.
void CDocPowerNAP::RejectActiveEntity(double dRejectVal)
{
    VisitorRejectCheck v(GetActiveEntity(), dRejectVal);
    Accept(v);
    UpdateAllViews(NULL);
}




// Author & Date:       Almut Branner     14 Oct 2003
// Purpose: Determine the color that an event has to be drawn in.
int CDocPowerNAP::GetBITUnitColor(uint32 dwUnitID)
{
    int nColor = -1;

    if (dwUnitID == 0)                         nColor = m_icColorTable.dispunit[UNCLASS];
    else if ((dwUnitID & UNIT_NOISE_MASK)!=0)  nColor = m_icColorTable.dispunit[NOISE];
    else if ((dwUnitID & UNIT_1_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT1];
    else if ((dwUnitID & UNIT_2_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT2];
    else if ((dwUnitID & UNIT_3_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT3];
    else if ((dwUnitID & UNIT_4_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT4];
    else if ((dwUnitID & UNIT_5_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT5];
    else if ((dwUnitID & UNIT_6_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT6];
    else if ((dwUnitID & UNIT_7_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT7];
    else if ((dwUnitID & UNIT_8_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT8];
    else if ((dwUnitID & UNIT_9_MASK) != 0)    nColor = m_icColorTable.dispunit[UNIT9];
    else if ((dwUnitID & UNIT_10_MASK) != 0)   nColor = m_icColorTable.dispunit[UNIT10];

    return nColor;
}


// Author & Date:       Almut Branner     14 Oct 2003
// Purpose: Determine the color that an event has to be drawn in.
CPen * CDocPowerNAP::GetBITUnitPen(uint32 dwUnitID)
{
    if (dwUnitID == 0)                           return &m_penUnitColor[UNCLASS];
    else if ((dwUnitID & UNIT_NOISE_MASK) !=0 )  return &m_penUnitColor[NOISE];
    else if ((dwUnitID & UNIT_1_MASK) != 0)      return &m_penUnitColor[UNIT1];
    else if ((dwUnitID & UNIT_2_MASK) != 0)      return &m_penUnitColor[UNIT2];
    else if ((dwUnitID & UNIT_3_MASK) != 0)      return &m_penUnitColor[UNIT3];
    else if ((dwUnitID & UNIT_4_MASK) != 0)      return &m_penUnitColor[UNIT4];
    else if ((dwUnitID & UNIT_5_MASK) != 0)      return &m_penUnitColor[UNIT5];
    else if ((dwUnitID & UNIT_6_MASK) != 0)      return &m_penUnitColor[UNIT6];
    else if ((dwUnitID & UNIT_7_MASK) != 0)      return &m_penUnitColor[UNIT7];
    else if ((dwUnitID & UNIT_8_MASK) != 0)      return &m_penUnitColor[UNIT8];
    else if ((dwUnitID & UNIT_9_MASK) != 0)      return &m_penUnitColor[UNIT9];
    else if ((dwUnitID & UNIT_10_MASK) != 0)     return &m_penUnitColor[UNIT10];

    return &m_penUnitColor[0];
}


// Author & Date:   Almut Branner   15 Oct 2003
// Purpose: Convert a unit id into a BIT unit id
uint32 CDocPowerNAP::GetBITUnit(int nUnitID)
{
    switch (nUnitID)
    {
    case UNCLASS:
        return(UNIT_UNCLASS_MASK);
    case UNIT1:
        return(UNIT_1_MASK);
    case UNIT2:
        return(UNIT_2_MASK);
    case UNIT3:
        return(UNIT_3_MASK);
    case UNIT4:
        return(UNIT_4_MASK);
    case UNIT5:
        return(UNIT_5_MASK);
    case UNIT6:
        return(UNIT_6_MASK);
    case UNIT7:
        return(UNIT_7_MASK);
    case UNIT8:
        return(UNIT_8_MASK);
    case UNIT9:
        return(UNIT_9_MASK);
    case UNIT10:
        return(UNIT_10_MASK);
    case NOISE:
        return(UNIT_NOISE_MASK);
    case NOISE_OUT:
        return(UNIT_NOISE_OUT_MASK);
    }

    return(UNIT_NOISE_MASK);
}


// Author & Date:   Kirk Korver     17 Oct 2003
// Purpose: Erase and rebuild the segment list corresponding to this entry, 
//          then update all views
// Inputs:  dwEntityID - the entity ID of the segment I want to update
//          nHint - the reason why I want to update
void CDocPowerNAP::RebuildSegListEntryAndUpdateViews(DWORD dwEntityID, DWORD nHint /*= HINT_USER_NONE*/)
{
    Segments & rcList = GetSegment(dwEntityID);

    for (FILEINFOLIST::iterator fit = m_icFileVector.begin(); fit != m_icFileVector.end(); ++fit)
    {
        // Fill in segment list
        SPSegments SegList(new Segments(dwEntityID));
        m_icSegmentList.push_back(SegList);

        AppendSegmentListEntry(**fit, rcList);
    }

    UpdateAllViews(NULL, nHint);
}


CPoint CDocPowerNAP::MakePointOnScreen(CPoint ptTest)
{
    HMONITOR hMonitor = ::MonitorFromPoint(ptTest, MONITOR_DEFAULTTONEAREST);
    
    // Get the monitor info
    MONITORINFO monInfo;
    monInfo.cbSize = sizeof(MONITORINFO);
    if (::GetMonitorInfo(hMonitor, &monInfo)==0)
    {
        TRACE("GetMonitorInfo failed");
        return ptTest;
    }
    
    CRect rctWork(monInfo.rcWork);

    // Ensure top left point is on screen
    if( rctWork.PtInRect(ptTest) == FALSE )
    {
        ptTest = rctWork.TopLeft();
    }
    return ptTest;
}


// Author & Date:   Kirk Korver     23 Oct 2003
// Purpose: Givent a view class, find the correct template to use
// Inputs:  pClass - pointer to the view class
// Outputs: The corresponding template
CDocTemplate * CDocPowerNAP::GetTemplateFromClass(const CRuntimeClass * pClass)
{
    CAppPowerNAP * pApp = static_cast<CAppPowerNAP *>(::AfxGetApp());
    CSingleDocTemplate * pTemplate = NULL;

    if (strcmp(pClass->m_lpszClassName, "CViewWaveforms") == 0)
        pTemplate = pApp->GetWaveformsTemplate();
    
    else if (strcmp(pClass->m_lpszClassName, "CViewLibDetails") == 0)
        pTemplate = pApp->GetLibDetailsTemplate();
    
    else if (strcmp(pClass->m_lpszClassName, "CViewEntInfo") == 0)
        pTemplate = pApp->GetEntInfoTemplate();
    
    else if (strcmp(pClass->m_lpszClassName, "CViewPCA") == 0)
        pTemplate = pApp->GetViewPCATemplate();
    
    else if (strcmp(pClass->m_lpszClassName, "CViewSortedInfo") == 0)
        pTemplate = pApp->GetSortedInfoTemplate();
    
    else if (strcmp(pClass->m_lpszClassName, "CViewRaster") == 0)
        pTemplate = pApp->GetViewRasterTemplate();

    return pTemplate;
}


// Author & Date:   Almut Branner   31 Oct 2003
// Purpose: Show the property sheet for spike sorting
// Input:   nMethod - Which method of spike sorting comes up initially
void CDocPowerNAP::ShowPropSheetSpkSorting(tagSortMethod nMethod)
{
    m_icPropSheetSpkSorting.m_pDoc = this;

    m_icPropSheetSpkSorting.SetActivePage(nMethod);

    if (!m_icPropSheetSpkSorting)
        m_icPropSheetSpkSorting.Create(NULL);
}


// Author & Date:   Almut Branner   31 Oct 2003
// Purpose: Get a pointer to the PCA view
// Output:  The pointer to the view or NULL if not found.
CViewPCA * CDocPowerNAP::GetViewPCAPtr()
{
    CViewPCA* pPCAView = NULL;

    POSITION pos = GetFirstViewPosition();
    while (pos != NULL)
    {
        CView* pView = GetNextView(pos);
        if (pView->IsKindOf(RUNTIME_CLASS(CViewPCA)))
        {
            pPCAView = (CViewPCA *) pView;
        }
    }

    return pPCAView;
}

// Author & Date:   Almut Branner   31 Oct 2003
// Purpose: Sort the currently active channel using the t-distributions
void CDocPowerNAP::SortActiveChannel(tagSortMethod nMethod, bool bRefresh)
{
    if (nMethod == TDISTRMETHOD)
    {
        // Do Shy's unsupervised algorithm
        VisitorShyAlgorithm v(GetActiveEntity());
        Accept(v);
    }
    else if (nMethod == KMEANSMETHOD)
    {
        // Do the K Means sorting algorithm
        VisitorKMeans v;
        GenericVisitable gv(this, NULL);
        gv.Accept(v);
    }

    // Set rules defined for this entity 
    SetSorted(true);

    if (bRefresh)
        UpdateAllViews(NULL);
}

// this will give us the times of the last entry in the list. In other words,
// We have several segments in these two [segment] entities Let's compare 
// the time of the LAST entry (aka index) 
struct LastTimeLess
{
    // Using segments
    bool operator()(const SPSegments lhs, const SPSegments rhs)
    {
        return GetTime(*lhs) < GetTime(*rhs);
    }

    double GetTime(const Segments & seg)
    {
        const DataSegment & rSeg = seg.back();
        double dTime = rSeg.GetTime();
        return dTime;
    }

    // Using Analogs
    bool operator()(const SPAnalogs lhs, const SPAnalogs rhs)
    {
        return GetTime(*lhs) < GetTime(*rhs);
    }

    double GetTime(const Analogs & ana)
    {
        const DataAnalog & rAna = ana.back();
        double dTime = rAna.GetTimeLast();
        return dTime;
    }
};

// Author & Date:   Kirk Korver     24 Feb 2004
// Purpose: each file will have a different time span. Get the total
//  time span of ALL of our entities
//
//  this assumes that the data is already sorted in time
double CDocPowerNAP::GetMaxTime()
{
    // Get the maximum segment time
    double dMaxTimeSeg = 0.0;
    if (m_icSegmentList.empty() == false)
    {
        SPSegments pcMaxSeg = *std::max_element(m_icSegmentList.begin(), m_icSegmentList.end(), LastTimeLess());
        dMaxTimeSeg = LastTimeLess().GetTime(*pcMaxSeg);   // Get the time of this segment...kinda wierd, but it works
    }

    // Get the maximum analog time
    double dMaxTimeAna = 0.0;
    if (m_icAnalogList.empty() == false)
    {
        SPAnalogs pcMaxAna = *std::max_element(m_icAnalogList.begin(), m_icAnalogList.end(), LastTimeLess());
        dMaxTimeAna = LastTimeLess().GetTime(*pcMaxAna);
    }

    double dMaxTime = dMaxTimeSeg > dMaxTimeAna ? dMaxTimeSeg : dMaxTimeAna;
    return dMaxTime;
}

// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: remove this unit from the active segments
// Inputs:
//  enUnit - the neuroshare (bit mask) unit ID to remove
void CDocPowerNAP::DeleteUnitFromActiveSegment(UnitMasks enUnit)
{
    ASSERT(IsActiveSegment() == true);

    Segments & rSeg = GetActiveSegment();
    rSeg.DeleteTheseUnits(enUnit);
    UpdateAllViews(NULL);
}


// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: remove "holes" in the unit classifications, but
//   only in the "active" segment
void CDocPowerNAP::CompactUnitsFromActiveSegment()
{
    ASSERT(IsActiveSegment() == true);

    Segments & rSeg = GetActiveSegment();
    if (rSeg.CompactUnits())        // true means that data was changed
        UpdateAllViews(NULL);
}

// Author & Date:   Kirk Korver     10 Mar 2004
// Purpose: convert every "from" unit to the "to" unit
// Inputs:
//  enFrom - the unit we are to change
//  enTo - what this unit should be classified as
void CDocPowerNAP::ReclassifyActiveSegment(UnitMasks enFrom, UnitMasks enTo)
{
    ASSERT(IsActiveSegment() == true);

    Segments & rSeg = GetActiveSegment();
    rSeg.ReclassifyUnits(enFrom, enTo);
    UpdateAllViews(NULL);
}
