///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: Centroid.cpp $
//
// Description   : implementation of the Centroid List classes
//
// Authors       : Kirk Korver
//
// $Date: 10/21/03 2:43p $
//
// $History: Centroid.cpp $
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 10/16/03   Time: 1:16p
// Updated in $/Neuroshare/nsClassifier
// Changed unit constants.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/09/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 9/08/03    Time: 4:07p
// Created in $/Neuroshare/nsClassifier
// 
// *****************  Version 11  *****************
// User: Awang        Date: 8/26/03    Time: 2:36p
// Updated in $/Neuroshare/nsClassifier
// NOISEUNIT_OUT unit added
// 
// *****************  Version 10  *****************
// User: Awang        Date: 8/05/03    Time: 3:43p
// Updated in $/Neuroshare/nsClassifier
// Added SetNsUnit()
// 
// *****************  Version 9  *****************
// User: Awang        Date: 7/17/03    Time: 10:26a
// Updated in $/Neuroshare/nsClassifier
// Changed Noise unit definition
// 
// *****************  Version 8  *****************
// User: Awang        Date: 6/18/03    Time: 2:30p
// Updated in $/Neuroshare/nsClassifier
// Sticky buttons in DisplayPCProj for units, hilighting,  and undo.
// Removed centroid creation and drawing.
// 
// *****************  Version 7  *****************
// User: Awang        Date: 6/10/03    Time: 4:43p
// Updated in $/Neuroshare/nsClassifier
// waveform class converts between Neuroshare unitID and a sequential
// clusterID used here.
// 
// *****************  Version 6  *****************
// User: Awang        Date: 5/30/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 4/01/03    Time: 1:59p
// Updated in $/Neuroshare/nsClassifier
// The document is now visitable
// Upgraded to use the STL for the new wavelist
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/27/03    Time: 1:57p
// Updated in $/Neuroshare/nsClassifier
// Added the visitor class to the wave form list
// 
// *****************  Version 3  *****************
// User: Kirk         Date: 3/25/03    Time: 11:19a
// Updated in $/Neuroshare/nsClassifier
// Converted for STL::list  to  LinkedList because of wierd memory problem
// 
// *****************  Version 2  *****************
// User: Kirk         Date: 3/24/03    Time: 11:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed AdvanceToMatch() to FindFirstMatch()
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 3/21/03    Time: 2:48p
// Created in $/Neuroshare/nsClassifier
// The list that stores the waveforms for further processing
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include <math.h>

#include "Centroid.h"


Centroid::Centroid(Centroid const & rhs)
{
    m_dwUnitID = rhs.m_dwUnitID;
    m_dwNsUnitID = rhs.m_dwNsUnitID;
    m_icWaveform = rhs.m_icWaveform;
}

Centroid::Centroid(DWORD dwNSUnitID, WAVEFORM & icWaveform)
{
    m_dwNsUnitID = dwNSUnitID;
    m_dwUnitID = NSUnitToClstr(dwNSUnitID);
    m_icWaveform = icWaveform;
}

Centroid::~Centroid()
{
}

Centroid & Centroid::operator = (Centroid const & rhs)
{
    // Cleanup old stuff
    Centroid::~Centroid();

    m_dwUnitID = rhs.m_dwUnitID;
    m_dwNsUnitID = rhs.m_dwNsUnitID;
    m_icWaveform = rhs.m_icWaveform;
    
    return *this;
}


// Get UnitID from Neuroshare datafile and convert to a usable
// cluster index
DWORD Centroid::GetUnitID()
{
    // Convert from Neuroshare UnitID obtained from data file 
    // to a sequential index used for ClusterID
    return NSUnitToClstr( GetNsUnitID() );
}


// Convert from bit flagged Neuroshare Unit IDs to
// cluster indexes
UINT32 Centroid::NSUnitToClstr(const UINT32 dwNSUnitID)
{
    if (dwNSUnitID == 0)
        return UNCLASS;//unclassified
    else if (dwNSUnitID == 1)
        return NOISE;//noise
    else if (dwNSUnitID == 2)
        return UNIT1;
    else if (dwNSUnitID == 4)
        return UNIT2;
    else if (dwNSUnitID == 8)
        return UNIT3;
    else if (dwNSUnitID == 16)
        return UNIT4;
    else if (dwNSUnitID == 32)
        return UNIT5;
    else if (dwNSUnitID == 64)
        return NOISE_OUT;
    else
    {
        // set all multiple or unknown unitID
         // to unclassified
        return 0;
    }
}//NSUnitToCluster


// Convert cluster indexes to bit flags for
// Neuroshare UnitIDs
UINT32 Centroid::ClstrToNSUnit(const UINT32 dwCluster)
{
    if (dwCluster == 0)
        return 0;// unclassified
    else if ((dwCluster == NOISE) || (dwCluster == NOISE_OUT))
        return 1;// noise
    else 
        return ((UINT32)pow(2, dwCluster));// convert double to UINT32
}//ClusterToNSUnit
