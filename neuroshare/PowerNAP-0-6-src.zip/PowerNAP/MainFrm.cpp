///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: MainFrm.cpp $
//
// Description   : implementation of the CMainFrame class
//
// Authors       : Kirk Korver
//
// $Date: 3/05/04 11:15a $
//
// $History: MainFrm.cpp $
// 
// *****************  Version 22  *****************
// User: Abranner     Date: 3/05/04    Time: 11:15a
// Updated in $/Neuroshare/PowerNAP
// Changed to use char array for unit labels. Also added automated cursor
// changing.
// 
// *****************  Version 21  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 20  *****************
// User: Abranner     Date: 8/27/03    Time: 10:57a
// Updated in $/Neuroshare/nsClassifier
// Added KMeans options to spike sorting sheet and removed CViewOptKMeans.
// 
// *****************  Version 19  *****************
// User: Abranner     Date: 8/26/03    Time: 5:59p
// Updated in $/Neuroshare/nsClassifier
// Changed options window to a PropertySheet.
// 
// *****************  Version 18  *****************
// User: Abranner     Date: 8/22/03    Time: 7:08p
// Updated in $/Neuroshare/nsClassifier
// Changed FIU interface and Waveform view toolbar (now done through
// separate MainFrame).
// 
// *****************  Version 17  *****************
// User: Awang        Date: 8/12/03    Time: 10:47a
// Updated in $/Neuroshare/nsClassifier
// CViewPCA has its own mainframe CPCAMainFrame
// 
// *****************  Version 16  *****************
// User: Awang        Date: 8/05/03    Time: 2:04p
// Updated in $/Neuroshare/nsClassifier
// Removed PCA Toolbar from this mainframe to its own mainframe
// 
// *****************  Version 15  *****************
// User: Awang        Date: 6/30/03    Time: 3:49p
// Updated in $/Neuroshare/nsClassifier
// Create toolbars for ViewWaveform and ViewPCA
// 
// *****************  Version 14  *****************
// User: Awang        Date: 5/07/03    Time: 1:43p
// Updated in $/Neuroshare/nsClassifier
// Removed TRACE comment
// 
// *****************  Version 13  *****************
// User: Abranner     Date: 5/06/03    Time: 3:01p
// Updated in $/Neuroshare/nsClassifier
// Added a splash screen.
// The add file dialog shows up later.
// The addfile function was moved to the document.
// 
// *****************  Version 12  *****************
// User: Kkorver      Date: 4/29/03    Time: 3:19p
// Updated in $/Neuroshare/nsClassifier
// Made the MainFrame not display the application name by default,
// Also the Frame will not automatically load any toolbar
// 
// *****************  Version 11  *****************
// User: Abranner     Date: 4/28/03    Time: 5:28p
// Updated in $/Neuroshare/nsClassifier
// Added one more option to align peaks.
// 
// *****************  Version 10  *****************
// User: Abranner     Date: 4/25/03    Time: 1:54p
// Updated in $/Neuroshare/nsClassifier
// HTML help now works.
// 
// *****************  Version 9  *****************
// User: Abranner     Date: 4/25/03    Time: 9:30a
// Updated in $/Neuroshare/nsClassifier
// Check in before changing all kinds of things to help. Not all help is
// functional here.
// 
// *****************  Version 8  *****************
// User: Kkorver      Date: 4/22/03    Time: 2:02p
// Updated in $/Neuroshare/nsClassifier
// Major changes...we no longer use MDI, but rather a SDI with lots of
// windows open at the same time
// 
// *****************  Version 7  *****************
// User: Almut        Date: 4/22/03    Time: 10:27a
// Updated in $/Neuroshare/nsClassifier
// Added help support to the project but no messages are setup yet.
// 
// *****************  Version 6  *****************
// User: Kkorver      Date: 4/10/03    Time: 1:36p
// Updated in $/Neuroshare/nsClassifier
// Removed  SortEntity() and SetFocusEntity()
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 3/27/03    Time: 1:52p
// Updated in $/Neuroshare/nsClassifier
// Untabified
// Moved some functionality into the DOC class
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/25/03    Time: 2:11p
// Updated in $/Neuroshare/nsClassifier
// Rename the NsFile iterators
// 
// *****************  Version 3  *****************
// User: Kirk         Date: 3/25/03    Time: 11:22a
// Updated in $/Neuroshare/nsClassifier
// Removed ProcessForm
// 
// $NoKeywords: $
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "MainFrm.h"
#include "PowerNAP.h"
#include "DocPowerNAP.h"
#include "HtmlFrameWnd.h"
#include "Splash.h"

#include "ViewPCA.h"
#include "VisitorShyAlgorithm.h"
#include "ViewKSel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CHtmlFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CHtmlFrameWnd)
    //{{AFX_MSG_MAP(CMainFrame)
    ON_WM_CREATE()
    ON_COMMAND(ID_FILE_NEW, OnFileNew)
    ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
    // Global help commands
    ON_COMMAND(ID_HELP_FINDER, CHtmlFrameWnd::OnHelpFinder)
    ON_COMMAND(ID_HELP, CHtmlFrameWnd::OnHelp)
    ON_COMMAND(ID_CONTEXT_HELP, CHtmlFrameWnd::OnContextHelp)
    ON_COMMAND(ID_DEFAULT_HELP, CHtmlFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
    ID_SEPARATOR,           // status line indicator
    ID_INDICATOR_CAPS,
    ID_INDICATOR_NUM,
    ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
 
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

    if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
        return -1;

/*
    //  This is the wizard generated code

    if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
        | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
        !m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
    {
        TRACE0("Failed to create toolbar\n");
        return -1;      // fail to create
    }
*/
    if (!m_wndStatusBar.Create(this) ||
        !m_wndStatusBar.SetIndicators(indicators,
          sizeof(indicators)/sizeof(UINT)))
    {
        TRACE0("Failed to create status bar\n");
        return -1;      // fail to create
    }

   

    // TODO: Delete these three lines if you don't want the toolbar to
    //  be dockable
/*    m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
    EnableDocking(CBRS_ALIGN_ANY);
    DockControlBar(&m_wndToolBar);
 */   
    
    return 0;
}

void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
    // We do the "false" because we only want the "title" and
    // Not the app name as well
	CFrameWnd::OnUpdateFrameTitle(false);	
}


BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
    cs.style &= ~(WS_MINIMIZEBOX | WS_MAXIMIZEBOX);
    cs.dwExStyle |= WS_EX_CONTEXTHELP;

    if( !CFrameWnd::PreCreateWindow(cs) )
        return FALSE;

    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
    CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
    CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnFileNew() 
{
    // Do something here to clear out existing document.
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd) 
{
    CFrameWnd::OnSetFocus(pOldWnd);
}

