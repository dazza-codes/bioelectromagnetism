///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: PropSheetGeneral.cpp $
//
// Description   :  
//
// Authors       : Almut Branner
//
// $Date: 3/04/04 5:26p $
//
// $History: PropSheetGeneral.cpp $
// 
// *****************  Version 9  *****************
// User: Kkorver      Date: 3/04/04    Time: 5:26p
// Updated in $/Neuroshare/PowerNAP
// Converted to use SharedPointers instead of Indexes
// 
// *****************  Version 8  *****************
// User: Abranner     Date: 2/06/04    Time: 12:41p
// Updated in $/Neuroshare/PowerNAP
// Update data access functions and fixed bugs.
// 
// *****************  Version 7  *****************
// User: Abranner     Date: 2/02/04    Time: 6:17p
// Updated in $/Neuroshare/PowerNAP
// First implementation of DiscardEmptyEntities.
// 
// *****************  Version 6  *****************
// User: Abranner     Date: 1/30/04    Time: 3:55p
// Updated in $/Neuroshare/PowerNAP
// Added option for discarding empty entities and streamlined data
// transfer.
// 
// *****************  Version 5  *****************
// User: Kkorver      Date: 10/22/03   Time: 11:17a
// Updated in $/Neuroshare/PowerNAP
// RebuildAllLists() renamed to RebuildAllListsAndUpdateViews() and now
// calls UpdateAllViews() at the end
// 
// *****************  Version 4  *****************
// User: Kkorver      Date: 10/21/03   Time: 2:43p
// Updated in $/Neuroshare/PowerNAP
// Renamed program to PowerNAP
// 
// *****************  Version 3  *****************
// User: Abranner     Date: 9/10/03    Time: 11:57a
// Updated in $/Neuroshare/nsClassifier
// Fixed problems after switching over to reading everything in at once.
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 8/27/03    Time: 2:59p
// Updated in $/Neuroshare/nsClassifier
// Moved CViewOptPop and CViewOptAlign to a property sheet
// PropSheetGeneral.
// 
// 
// 
// $NoKeywords: $
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PowerNAP.h"
#include "PropSheetGeneral.h"
#include "DocPowerNAP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropSheetGeneral

IMPLEMENT_DYNAMIC(CPropSheetGeneral, CPropertySheet)

CPropSheetGeneral::CPropSheetGeneral(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage,
                                     CDocPowerNAP* pDoc)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
    m_pDoc = pDoc;

    InitializePropPages();
}

CPropSheetGeneral::CPropSheetGeneral(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage,
                                     CDocPowerNAP* pDoc)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
    m_pDoc = pDoc;

    InitializePropPages();
}

CPropSheetGeneral::~CPropSheetGeneral()
{

}


BEGIN_MESSAGE_MAP(CPropSheetGeneral, CPropertySheet)
	//{{AFX_MSG_MAP(CPropSheetGeneral)
	//}}AFX_MSG_MAP
    ON_BN_CLICKED (ID_APPLY_NOW, OnApply)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropSheetGeneral message handlers

BOOL CPropSheetGeneral::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
    CWnd *pWnd = GetDlgItem(IDHELP);
    pWnd->ShowWindow(false);

	return bResult;
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Initialize all the property pages. Grab the appropriate data from the documents.
void CPropSheetGeneral::InitializePropPages()
{
    AddPage(&m_icPropPagePop);
    AddPage(&m_icPropPageWf);
    AddPage(&m_icPropPageData);

    // Initialize data

    /////////////////////////////////////////////////////////////////////////
    // PropPagePop
    m_icPropPagePop.m_nNumOfGroups = m_pDoc->m_nNumOfGroups;
    m_icPropPagePop.m_nNumOfSamples = m_pDoc->m_nNumOfSamples;
    m_icPropPagePop.m_nNumFiles = m_pDoc->m_icFileVector.size();

    if (!m_pDoc->m_icFileVector.empty())
        m_icPropPagePop.m_nTtlNumSamples = m_pDoc->m_nNumOfSamples * 
            m_pDoc->m_nNumOfGroups * m_pDoc->m_icFileVector.size();
    else
        m_icPropPagePop.m_nTtlNumSamples = m_pDoc->m_nNumOfSamples * 
            m_pDoc->m_nNumOfGroups;

    /////////////////////////////////////////////////////////////////////////
    // PropPageWf
    m_icPropPageWf.m_bAlignMeanPt = m_pDoc->m_bAlignMeanPt;
    m_icPropPageWf.m_nWhatPeaks = m_pDoc->m_nWhatPeaks;
    m_icPropPageWf.m_nAlignPt = m_pDoc->m_nAlignPt;
 
    if (!m_pDoc->m_icFileVector.empty())
    {
        DWORD dwNumPt = m_pDoc->GetNumOfPointsPerWave();

        if (dwNumPt == 0)  // If no waveform view exists yet
        {
            // Get number of data points in the first waveform
            ns_SEGMENTINFO isSInfo;
            uint32 nEntity = m_pDoc->GetActiveEntity();

            FileInfo &isInfo = *m_pDoc->m_icFileVector[0];

            m_pDoc->GetSegmentInfo(isInfo.icFile, nEntity, isSInfo);
            dwNumPt = isSInfo.dwMaxSampleCount;
        }

        m_icPropPageWf.m_nNumPt = dwNumPt;
    }
    else
        m_icPropPageWf.SetDlgItemText(IDC_EDT_NumPt, "N/A");

    /////////////////////////////////////////////////////////////////////////
    // PropPageData
    m_icPropPageData.m_bDiscardEmptyEntities = m_pDoc->m_bDiscardEmptyEntities;
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Update the data in the document.
void CPropSheetGeneral::UpdateDoc()
{
    if (m_pDoc != NULL)
    {
        m_pDoc->m_nNumOfGroups = m_icPropPagePop.m_nNumOfGroups;
        m_pDoc->m_nNumOfSamples = m_icPropPagePop.m_nNumOfSamples;

        m_pDoc->m_bAlignMeanPt = m_icPropPageWf.m_bAlignMeanPt;
        m_pDoc->m_nWhatPeaks = m_icPropPageWf.m_nWhatPeaks;
        m_pDoc->m_nAlignPt = m_icPropPageWf.m_nAlignPt;

        bool bChanged = false;
        
        if (m_pDoc->m_bDiscardEmptyEntities != m_icPropPageData.m_bDiscardEmptyEntities)
             bChanged = true;

        m_pDoc->m_bDiscardEmptyEntities = m_icPropPageData.m_bDiscardEmptyEntities;

        // Depending on what changed either rebuild everything or just data lists
        if ( (bChanged) && (!m_pDoc->m_bDiscardEmptyEntities) )
            m_pDoc->RebuildAllListsAndUpdateViews();
        else
            m_pDoc->RebuildSegListAndUpdateViews();  // This will also discard other empty entities
    }
}


// Author & Date:   Almut Branner   30 Jan 2004
// Purpose: Update the data in the document after apply was hit.
void CPropSheetGeneral::OnApply()
{
    GetActivePage()->UpdateData(true);

    UpdateDoc();

    m_icPropPagePop.SetModified(false);
    m_icPropPageWf.SetModified(false);
    m_icPropPageData.SetModified(false);
}


// Author & Date:   Almut Branner   1 Feb 2004
// Purpose: We only want to change the do something if we actually changed something.
//          Since the Apply button tracks this, we only have to check its 'enabled' status.
BOOL CPropSheetGeneral::DestroyWindow() 
{
    // This will figure out whether any data has changed
    if (GetDlgItem(ID_APPLY_NOW)->IsWindowEnabled())
        UpdateDoc();
	
	return CPropertySheet::DestroyWindow();
}

