///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: Centroid.h $
//
// Description   : interface for the Centroid List classes.
//
// Authors       : Kirk Korver
//
// $Date: 10/17/03 11:52a $
//
// $History: Centroid.h $
// 
// *****************  Version 3  *****************
// User: Kkorver      Date: 10/17/03   Time: 11:52a
// Updated in $/Neuroshare/nsClassifier
// WAVEFORM is now in CommonTypes.h
// 
// *****************  Version 2  *****************
// User: Abranner     Date: 9/09/03    Time: 3:03p
// Updated in $/Neuroshare/nsClassifier
// Changed the document to be able to incoorperate more entity types and
// loading more channels at a time. Waveforms are not stored in the
// document anymore. The WaveformList was turned into a SegmentList.
// 
// *****************  Version 1  *****************
// User: Abranner     Date: 9/08/03    Time: 4:07p
// Created in $/Neuroshare/nsClassifier
// 
// *****************  Version 9  *****************
// User: Awang        Date: 8/05/03    Time: 3:43p
// Updated in $/Neuroshare/nsClassifier
// Added SetNsUnit()
// 
// *****************  Version 8  *****************
// User: Awang        Date: 7/17/03    Time: 10:26a
// Updated in $/Neuroshare/nsClassifier
// Changed Noise unit definition
// 
// *****************  Version 7  *****************
// User: Awang        Date: 6/10/03    Time: 4:43p
// Updated in $/Neuroshare/nsClassifier
// waveform class converts between Neuroshare unitID and a sequential
// clusterID used here.
// 
// *****************  Version 6  *****************
// User: Awang        Date: 5/30/03    Time: 12:01p
// Updated in $/Neuroshare/nsClassifier
// Implemented cluster drawing
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 4/01/03    Time: 1:58p
// Updated in $/Neuroshare/nsClassifier
// Upgraded to use the STL for the new wavelist
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 3/27/03    Time: 1:57p
// Updated in $/Neuroshare/nsClassifier
// Added the visitor class to the wave form list
// 
// *****************  Version 3  *****************
// User: Kirk         Date: 3/25/03    Time: 11:19a
// Updated in $/Neuroshare/nsClassifier
// Converted for STL::list  to  LinkedList because of wierd memory problem
// 
// *****************  Version 2  *****************
// User: Kirk         Date: 3/24/03    Time: 11:48a
// Updated in $/Neuroshare/nsClassifier
// Renamed AdvanceToMatch() to FindFirstMatch()
// 
// *****************  Version 1  *****************
// User: Kirk         Date: 3/21/03    Time: 2:48p
// Created in $/Neuroshare/nsClassifier
// The list that stores the waveforms for further processing
// 
// $NoKeywords: $
//
// Centroid.h: 
//
//////////////////////////////////////////////////////////////////////

#ifndef CENTROIDS_H_INCLUDED
#define CENTROIDS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include "CommonTypes.h"

class Centroid
{
public:
    Centroid(Centroid const & rhs);       // Copy constructor
    Centroid(DWORD dwNSUnitID, WAVEFORM & icWaveform);
    ~Centroid();

    DWORD GetNumOfPoints() { return m_icWaveform.size(); }

    DWORD GetNsUnitID() { return m_dwNsUnitID; }
    DWORD GetUnitID();
    void GetWave(WAVEFORM & icWaveform) { icWaveform = m_icWaveform; }

    Centroid & operator = (Centroid const & rhs);
    
    UINT32 NSUnitToClstr(const UINT32 dwNSUnitID);
    UINT32 ClstrToNSUnit(const UINT32 dwCluster);

protected:
    DWORD m_dwNsUnitID;         // The unit ID in Neuroshare bit flag form
    DWORD m_dwUnitID;           // The unit ID in sequential numbering form for ClusterIDs

    WAVEFORM m_icWaveform;      // The actual wave form
};


#endif // include guard
