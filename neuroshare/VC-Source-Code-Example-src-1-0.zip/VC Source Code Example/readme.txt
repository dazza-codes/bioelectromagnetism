This package is intended to be a sample usage of the Neuroshare
libraries. It should read in a file using the nsNEVLibrary DLL. 
The files sim100.nev and nsNevLibrary.DLL are provided for clarity.

Without too much effort, this example can be modified to read a data
file with your custom Neuroshare compliant Library.

This version supports Version 1.0 of the Neuroshare Library.



Below is a list of the files in this package.

==== List of Files ===
readme.txt

bin\nsNEVLibrary.dll
bin\sim100.nev
bin\VC Source Code Example.exe

src\nsAPIdllimp.h
src\nsAPItypes.h
src\NsFile.cpp
src\NsFile.h
src\NsLibrary.cpp
src\NsLibrary.h
src\ReadMe.txt
src\res
src\resource.h
src\StdAfx.cpp
src\StdAfx.h
src\VC Source Code Example.cpp
src\VC Source Code Example.dsp
src\VC Source Code Example.dsw
src\VC Source Code Example.h
src\VC Source Code Example.rc
src\VC Source Code ExampleDlg.cpp
src\VC Source Code ExampleDlg.h
src\res\VC Source Code Example.ico
src\res\VC Source Code Example.rc2
