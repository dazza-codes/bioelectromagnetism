///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: StdAfx.cpp $
//
// Description   : source file that includes just the standard includes
//	                VC Source Code Example.pch will be the pre-compiled header
//	                stdafx.obj will contain the pre-compiled type information
//
// Authors       : Kirk Korver
//
// $Date: 1/27/03 1:07p $
//
// $History: StdAfx.cpp $
// 
// *****************  Version 2  *****************
// User: Kirk         Date: 1/27/03    Time: 1:07p
// Updated in $/Neuroshare/VC Source Code Example
// Added Required Headers
//
///////////////////////////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"



