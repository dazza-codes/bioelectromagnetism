//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VC Source Code Example.rc
//
#define IDD_VCSOURCECODEEXAMPLE_DIALOG  102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDC_BUTTON1                     1000
#define IDC_BUTTON_OPEN_FILE            1000
#define IDC_FILE_TYPE                   1001
#define IDC_FILE_NAME                   1002
#define IDC_DATE_CREATED                1003
#define IDC_ENTITY_COUNT                1004
#define IDC_TIME_RESOLUTION             1005
#define IDC_TIME_SPAN                   1006
#define IDC_APPLICATION                 1007
#define IDC_COMMENT                     1008
#define IDC_ENTITIES_UNKNOWN            1009
#define IDC_ENTITIES_EVENT              1010
#define IDC_ENTITIES_ANALOG             1011
#define IDC_ENTITIES_SEGMENT            1012
#define IDC_ENTITIES_NEURAL             1013
#define IDC_TIME_OF_FIRST_EVENT         1014
#define IDC_SEGMENT                     1015
#define IDC_RASTER                      1016
#define IDC_ANALOG                      1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
