///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NsFile.cpp $
//
// Description   : implementation of the NeuroshareLibrary class.
//
// Authors       : Kirk Korver
//
// $Date: 2/24/03 3:25p $
//
// $History: NsFile.cpp $
// 
// *****************  Version 6  *****************
// User: Kirk         Date: 2/24/03    Time: 3:25p
// Updated in $/Neuroshare/VC Source Code Example
// Removed fixed directory for the neuroshare library
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 1/27/03    Time: 2:17p
// Updated in $/Neuroshare/VC Source Code Example
// NeuroshareLibrary.h is now NsFile.h
// NsLibrary is now NsFile
// NsLibraryMgr is now MsFileMgr
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 1/27/03    Time: 1:08p
// Updated in $/Neuroshare/VC Source Code Example
// Added Required Headers
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "VC Source Code Example.h"
#include "NsFile.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////





// Author & Date:       Kirk Korver     1/10/2003
// Purpose: class factory for a NeuroshareLibrary
//          Scan through all of the possible DLL's on the system
//          and find the one that can read this data type.
//          Open this DLL + the data file and give it back.
//
// Inputs:
//  szDataFileName - the name of the "DATA" file to open with "some" DLL
NsFile * NsFileMgr::NewFile(LPCSTR szDataFileName)
{
    CString szDllName = "nsNEVLibrary.dll";
    NsFile * pcLib = new NsFile(szDllName);

    if (pcLib->m_icDLL.IsOK())
        pcLib->OpenFile(szDataFileName);    
    else
    {
        CString msg;
        msg.Format("Unable to open\n%s", szDllName);
        ::MessageBox(NULL, msg, "ERRRO", MB_ICONEXCLAMATION);
    }

    return pcLib;
}







NsFile::NsFile(LPCSTR szDllName) :
    m_icDLL(szDllName),
    m_hDataFile(NsFile::INVALID_HANDLE)
{

}

NsFile::~NsFile()
{
    CloseFile();
}


// Author & Date:   Kirk Korver     08 Jan 2003
// Purpose: Close the data file
ns_RESULT NsFile::CloseFile()
{ 
    if (m_hDataFile == INVALID_HANDLE)
        return ns_OK;

    // Othwise, close it
    ns_RESULT retVal = m_icDLL.CloseFile(m_hDataFile); 
    m_hDataFile = INVALID_HANDLE; 
    return retVal;  
}
