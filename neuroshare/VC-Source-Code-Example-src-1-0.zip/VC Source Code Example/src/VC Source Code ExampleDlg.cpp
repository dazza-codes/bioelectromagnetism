///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VC Source Code ExampleDlg.cpp $
//
// Description   : This implements a simplistic VC sample of the Neuroshare Library
//
// Authors       : Kirk Korver
//
// $Date: 2/24/03 2:15p $
//
// $History: VC Source Code ExampleDlg.cpp $
// 
// *****************  Version 6  *****************
// User: Kirk         Date: 2/24/03    Time: 2:15p
// Updated in $/Neuroshare/VC Source Code Example
// Updated to use the new version 1.0 API
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 1/27/03    Time: 2:17p
// Updated in $/Neuroshare/VC Source Code Example
// NeuroshareLibrary.h is now NsFile.h
// NsLibrary is now NsFile
// NsLibraryMgr is now MsFileMgr
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 1/27/03    Time: 1:06p
// Updated in $/Neuroshare/VC Source Code Example
// Added Required Headers
// Added drawing of the plots
//
///////////////////////////////////////////////////////////////////////////////////////////////////



#include "stdafx.h"
#include "VC Source Code Example.h"
#include "VC Source Code ExampleDlg.h"

#include "nsAPIdllimp.h"
#include "nsAPItypes.h"

#include "NsFile.h"


#include <memory>
//using namespace std;      // this could be a good idea, by I don't want to pollute the namespace


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////// CONSTANTS ///////////////////////////////////////////
static const COLORREF crMY_COLOR = RGB(255,   0, 255);
static const COLORREF crBLACK =    RGB(  0,   0,   0);


/////////////////////////////////////////////////////////////////////////////
// CVCSourceCodeExampleDlg dialog

CVCSourceCodeExampleDlg::CVCSourceCodeExampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVCSourceCodeExampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVCSourceCodeExampleDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

}

void CVCSourceCodeExampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVCSourceCodeExampleDlg)
	DDX_Control(pDX, IDC_ANALOG, m_icAnalogFrame);
	DDX_Control(pDX, IDC_SEGMENT, m_icSegmentFrame);
	DDX_Control(pDX, IDC_RASTER, m_icRasterFrame);
	DDX_Control(pDX, IDC_TIME_OF_FIRST_EVENT, m_icEventFrame);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVCSourceCodeExampleDlg, CDialog)
	//{{AFX_MSG_MAP(CVCSourceCodeExampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_OPEN_FILE, OnButtonOpenFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVCSourceCodeExampleDlg message handlers

BOOL CVCSourceCodeExampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
    // Tie together the Bitmap and the frame, also get sizes
    InitFrameBitmap(m_icAnalogRect,     m_icAnalogBMP,      m_icAnalogFrame);
    InitFrameBitmap(m_icSegmentRect,    m_icSegmentBMP,     m_icSegmentFrame);
    InitFrameBitmap(m_icRasterRect,     m_icRasterBMP,      m_icRasterFrame);
    InitFrameBitmap(m_icEventRect,      m_icEventBMP,       m_icEventFrame);


	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CVCSourceCodeExampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVCSourceCodeExampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CVCSourceCodeExampleDlg::OnButtonOpenFile() 
{

    // Prompt for the name of the file to open
    CFileDialog icFileDlg
        (
            TRUE,                                           // TRUE = file open 
            NULL,                                           // Default Extension - we use filters
//            "..\\Common Test Files \\sim100.nev",           // Filename - let them choose
            NULL,                                           // Filename - let them choose
            OFN_FILEMUSTEXIST,                              // flags - file must exist and hide read only
            "NEV-Files (*.nev)|*.nev|All Files (*.*)|*.*||",// File extensions
            this                                            // parent window - this one!!
        );

    if (icFileDlg.DoModal() == IDOK)    // if cancel was not pressed
    {
        // Ok, Let's start by storing what which file we will try to process
        SetDlgItemText(IDC_FILE_NAME, icFileDlg.GetPathName());


        std::auto_ptr <NsFile> pcLib (NsFileMgr::NewFile(icFileDlg.GetPathName()));

        if (pcLib->IsOK() == FALSE)
        {
            CString icMsg;
            icMsg.Format("I am unable to open:\n%s", icFileDlg.GetPathName());
            MessageBox(icMsg);
        }
        else
        {
            ShowFileInfo(*pcLib);
            ShowEntityInfo(*pcLib);

            // All of these load the info and draw a pretty picture
            ShowEvent(*pcLib);
            ShowAnalog(*pcLib);
            ShowSegment(*pcLib);
            ShowRaster(*pcLib);
        }

        // in all cases, we want to close the file
        pcLib->CloseFile();

        // cause the screen to redraw
        this->Invalidate(FALSE);
        this->UpdateWindow();   

    }
}


// Author & Date:   Kirk Korver     Jan 08 2003
// Purpose: get and display the file information from this dll
void CVCSourceCodeExampleDlg::ShowFileInfo(NsFile const & rcLib)
{

    // Let's check on the library info...we don't display this anywhere though
    ns_LIBRARYINFO isLibInfo;
    rcLib.GetLibraryInfo(&isLibInfo, sizeof(isLibInfo));

    CString icStr;

    ns_FILEINFO isFileInfo;

    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
        MessageBox("There was an error loading the file information!");
    else
    {
        // Ok we read it in, now let's put the stuff on the screen
        SetDlgItemText(IDC_FILE_TYPE, isFileInfo.szFileType);
        SetDlgItemInt(IDC_ENTITY_COUNT, isFileInfo.dwEntityCount);

        // Now let's deal with time
        SetDlgItemInt(IDC_TIME_RESOLUTION, UINT(1 / isFileInfo.dTimeStampResolution));
        SetDlgItemInt(IDC_TIME_SPAN, UINT(isFileInfo.dTimeSpan));
        SetDlgItemText(IDC_APPLICATION, isFileInfo.szAppName);
        
        // And how about when this was created
        icStr.Format("%lu/%lu/%lu  %lu:%lu:%lu", 
            isFileInfo.dwTime_Month, isFileInfo.dwTime_Day, isFileInfo.dwTime_Year,
            isFileInfo.dwTime_Hour, isFileInfo.dwTime_Min, isFileInfo.dwTime_Sec);

        SetDlgItemText(IDC_DATE_CREATED, icStr);

        // Now the very nice comments
        SetDlgItemText(IDC_COMMENT, isFileInfo.szFileComment);
    }
}


// Author & Date:       Kirk Korver     08 Jan 2003
// Purpse: Count and display the count of the entites
void CVCSourceCodeExampleDlg::ShowEntityInfo(NsFile const & rcLib)
{
    ns_FILEINFO isFileInfo;
    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
    {
        MessageBox("Unable to get the entity info from the File Info");
        return;
    }

    
    // Set equal to 0 because we are about to count how many we find
    UINT nUnknowns = 0;
    UINT nEvents = 0;
    UINT nAnalogs = 0;
    UINT nSegments = 0;
    UINT nNeurals = 0;

    // Ok, we now now how many entities, let's rock'n roll
    ns_ENTITYINFO isEntityInfo;
    for (DWORD i = 0; i < isFileInfo.dwEntityCount; ++i)
    {
        if (ns_OK != rcLib.GetEntityInfo(i, &isEntityInfo, sizeof(isEntityInfo)))
        {
            MessageBox("There was an error loading the entity information!");
        }
        else
        {
            // Life is good :-)
            switch(isEntityInfo.dwEntityType)
            {
            case ns_ENTITY_UNKNOWN:
                ++nUnknowns;
                break;

            case ns_ENTITY_EVENT:
                ++nEvents;
                break;

            case ns_ENTITY_ANALOG:
                ++nAnalogs;
                break;

            case ns_ENTITY_SEGMENT:
                ++nSegments;
                break;

            case ns_ENTITY_NEURALEVENT:
                ++nNeurals;
                break;
            
            default:
                // This case should never happen
                _ASSERT(0);
                break;
            }
        }

        // Now let's set these values on the screen
        SetDlgItemInt(IDC_ENTITIES_UNKNOWN, nUnknowns);
        SetDlgItemInt(IDC_ENTITIES_EVENT, nEvents);
        SetDlgItemInt(IDC_ENTITIES_ANALOG, nAnalogs);
        SetDlgItemInt(IDC_ENTITIES_SEGMENT, nSegments);
        SetDlgItemInt(IDC_ENTITIES_NEURAL, nNeurals);
    }
}


void CVCSourceCodeExampleDlg::ShowEvent(NsFile const & rcLib)
{
    ns_FILEINFO isFileInfo;
    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
    {
        MessageBox("Unable to get the entity info from the File Info");
        return;
    }

    // Let's make sure we have at least 1 entity
    if (isFileInfo.dwEntityCount < 1)
    {
        MessageBox("No Entities to process");
        return;
    }


    // I'm going to do some drawing, so get ready
	CDC icDC;
	icDC.CreateCompatibleDC(NULL);

    CPen icPen(PS_SOLID, 1, crMY_COLOR);
    icDC.SelectObject(icPen);

	icDC.SelectObject(m_icEventBMP);
    m_icEventFrame.Invalidate();        // Yeah this is a little on the bleeding edge, but I should
                                        // be able to say "draw this later, cuz I'm going to make changes
                                        // soon". 

    // Start off by erasing anything leftover (say from last time)
    icDC.FillSolidRect(m_icEventRect, crBLACK);

    // Now let's find the first entity of type "EVENT"
    for (DWORD idEntity = 0; idEntity < isFileInfo.dwEntityCount; ++idEntity)
    {
        ns_ENTITYINFO isEntityInfo;
        if (ns_OK != rcLib.GetEntityInfo(idEntity, &isEntityInfo, sizeof(isEntityInfo)))
        {
            MessageBox("There was an error loading the entity information!");
            return;
        }
        else
        {
            if (isEntityInfo.dwEntityType == ns_ENTITY_EVENT)
            {
                // aha, found one. Let's get busy

                // Now let's see what kind of event
                ns_EVENTINFO isEventInfo;
                if (ns_OK != rcLib.GetEventInfo(idEntity, &isEventInfo, sizeof(isEventInfo)))
                {
                    MessageBox("There was an error loading the event information!");
                    return;
                }

                switch (isEventInfo.dwEventType)
                {
                case ns_EVENT_TEXT:
                    MessageBox("ns_EVENT_TEXT Not tested!");
                    break;

                case ns_EVENT_CSV:
                    MessageBox("ns_EVENT_CSV Not tested!");
                    break;

                case ns_EVENT_BYTE:
                    MessageBox("ns_EVENT_BYTE Not tested!");
                    break;

                case ns_EVENT_WORD:
                    {

                        for(int i = 0; i < isEntityInfo.dwItemCount; ++i)
                        {
                            double dTimeStamp;
                            WORD wData;
                            uint32 cbUsed;

                            if (ns_OK == rcLib.GetEventData(idEntity, i, &dTimeStamp, &wData, sizeof wData, &cbUsed))
                            {
                                /////// display the data by drawing the line ////////

                                // the area has been invalidated above so let's boogie
                                
                                int nX = int(dTimeStamp * double(m_icEventRect.Width()) / isFileInfo.dTimeSpan);

                                icDC.MoveTo(nX, 0);
                                icDC.LineTo(nX, m_icEventRect.Height());

                            }
                            else
                            {
                                MessageBox("There was an error loading the event data!");
                                return;
                            }
                        }
                    }
                    break;

                case ns_EVENT_DWORD:
                    MessageBox("ns_EVENT_DWORD Not tested!");
                    break;

                default:
                    // This should never happen DLL has made a mistake
                    _ASSERT(0);
                    break;
                }

                // We exit here because we only want to see the "first" entry
                return;
            }
        }
    }
}


// Author & Date:   Kirk Korver     Jan 20, 2003
// Purpose: tie to gether the bitmap with the frame on the screen so that writing to the 
//  bitmap will "forever" show up on the screen, let's also save the bounding box size
// Inputs:
//  rcFrame - the frame on the dialog box
// Outputs:
//  rcRect - the bounding box
//  rcBitmap - the bitmap to bind to the frame
void CVCSourceCodeExampleDlg::InitFrameBitmap(CRect & rcRect, CBitmap & rcBitmap, CStatic & rcFrame)
{
    rcFrame.GetClientRect(&rcRect);
    CDC * pDC = rcFrame.GetDC();
    rcBitmap.CreateCompatibleBitmap(pDC, rcRect.Width(), rcRect.Height());
    rcFrame.SetBitmap(rcBitmap);
    rcFrame.ReleaseDC(pDC);
}


void CVCSourceCodeExampleDlg::ShowAnalog(NsFile const & rcLib)
{
    ns_FILEINFO isFileInfo;
    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
    {
        MessageBox("Unable to get the entity info from the File Info");
        return;
    }

    // Let's make sure we have at least 1 entity
    if (isFileInfo.dwEntityCount < 1)
    {
        MessageBox("No Entities to process");
        return;
    }


    // I'm going to do some drawing, so get ready
	CDC icDC;
	icDC.CreateCompatibleDC(NULL);

    CPen icPen(PS_SOLID, 1, crMY_COLOR);
    icDC.SelectObject(icPen);

	icDC.SelectObject(m_icAnalogBMP);
    m_icAnalogFrame.Invalidate();       // Yeah this is a little on the bleeding edge, but I should
                                        // be able to say "draw this later, cuz I'm going to make changes
                                        // soon". 

    // Start off by erasing anything leftover (say from last time)
    icDC.FillSolidRect(m_icAnalogRect, crBLACK);

    // Now let's find the first entity of type "ns_ENTITY_ANALOG"
    for (DWORD idEntity = 0; idEntity < isFileInfo.dwEntityCount; ++idEntity)
    {
        ns_ENTITYINFO isEntityInfo;
        if (ns_OK != rcLib.GetEntityInfo(idEntity, &isEntityInfo, sizeof(isEntityInfo)))
        {
            MessageBox("There was an error loading the entity information!");
            return;
        }
        else
        {
            if (isEntityInfo.dwEntityType == ns_ENTITY_ANALOG)
            {
                // We are only going to look at the first 250 samples
                double adData[250];

                // Ensure that we do have an entity to look at
                if (0 == isEntityInfo.dwItemCount)
                {
                    MessageBox("No analog indeces!");
                    return;
                }
                else
                {
                    int nCountMax = min(250, isEntityInfo.dwItemCount);

                    // now let's set the scaling for drawing
                    double dScaleX = double(this->m_icAnalogRect.Width()) / double(nCountMax);

                    ns_ANALOGINFO isAnalogInfo;
                    if (ns_OK != rcLib.GetAnalogInfo(idEntity, &isAnalogInfo, sizeof(isAnalogInfo)))
                    {
                        MessageBox("There was an error loading the analog information!");
                        return;
                    }
                    else
                    {
                        // And let's set the scaling in the Y dimension
                        double dScaleY = double(this->m_icAnalogRect.Height()) / (isAnalogInfo.dMaxVal - isAnalogInfo.dMinVal);
                        double dOffsetY = this->m_icAnalogRect.Height() / 2.0;

                        uint32 nDummy;
                        if (ns_OK != rcLib.GetAnalogData(idEntity, 0, nCountMax,  &nDummy, adData))
                        {
                            MessageBox("There was an error loading the analog data!");
                            return;
                        }
                        else
                        {
                            // ok..let's start drawing

                            int x;  // X coordinate
                            int y;  // Y coordinate

                            x = 0;
                            y = adData[0] * dScaleY + dOffsetY;

                            icDC.MoveTo(x, y);

                            for (int i = 1; i < nCountMax; ++i)
                            {
                                x = i * dScaleX;
                                y = adData[i] * dScaleY + dOffsetY;

                                icDC.LineTo(x, y);
                            }
                        }
                    }
                }

                // We exit here because we only want to see the "first" entry
                return;
            }
        }
    }
}

void CVCSourceCodeExampleDlg::ShowSegment(NsFile const & rcLib)
{
    ns_FILEINFO isFileInfo;
    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
    {
        MessageBox("Unable to get the entity info from the File Info");
        return;
    }

    // Let's make sure we have at least 1 entity
    if (isFileInfo.dwEntityCount < 1)
    {
        MessageBox("No Entities to process");
        return;
    }


    // I'm going to do some drawing, so get ready
	CDC icDC;
	icDC.CreateCompatibleDC(NULL);

    CPen icPen(PS_SOLID, 1, crMY_COLOR);
    icDC.SelectObject(icPen);

	icDC.SelectObject(m_icSegmentBMP);
    m_icSegmentFrame.Invalidate();      // Yeah this is a little on the bleeding edge, but I should
                                        // be able to say "draw this later, cuz I'm going to make changes
                                        // soon". 

    // Start off by erasing anything leftover (say from last time)
    icDC.FillSolidRect(m_icSegmentRect, crBLACK);

    // Now let's find the first entity of type "ns_ENTITY_SEGMENT"
    for (DWORD idEntity = 0; idEntity < isFileInfo.dwEntityCount; ++idEntity)
    {
        ns_ENTITYINFO isEntityInfo;
        if (ns_OK != rcLib.GetEntityInfo(idEntity, &isEntityInfo, sizeof(isEntityInfo)))
        {
            MessageBox("There was an error loading the entity information!");
            return;
        }
        else
        {
            if (isEntityInfo.dwEntityType == ns_ENTITY_SEGMENT)
            {
                // Got one. Let's rock'n roll

                // Ensure that we do have an entity to look at
                if (0 == isEntityInfo.dwItemCount)
                {
                    MessageBox("No segment indeces!");
                    return;
                }
                else
                {
                    // We display at max 6 signals
                    static const int MAX_DATA_SIZE = 6;
                    int nCountMax = min(MAX_DATA_SIZE, isEntityInfo.dwItemCount);

                    ns_SEGMENTINFO isSegmentInfo;
                    if (ns_OK != rcLib.GetSegmentInfo(idEntity, &isSegmentInfo, sizeof(isSegmentInfo)))
                    {
                        MessageBox("There was an error loading the segment data!");
                        return;
                    }

                    if (1 != isSegmentInfo.dwSourceCount)
                    {

                        MessageBox("We only support single sources currently");
                        return;
                    }
                    else
                    {
                        ns_SEGSOURCEINFO isSegmentSourceInfo;
                        if (ns_OK != rcLib.GetSegmentSourceInfo(idEntity, 0, &isSegmentSourceInfo, sizeof(isSegmentSourceInfo)))
                        {
                            MessageBox("There was an error loading the segment source information!");
                            return;
                        }
                        else
                        {
                            // Let's set the scaling 
                            double dScaleX = double(this->m_icSegmentRect.Width()) / double(isSegmentInfo.dwMaxSampleCount);
                            double dScaleY = double(this->m_icSegmentRect.Height()) / (isSegmentSourceInfo.dMaxVal - isSegmentSourceInfo.dMinVal);
                            double dOffsetY = this->m_icSegmentRect.Height() / 2.0;


                            // Remember, I'm not trying to dispaly all sigments, only the first 6
                            for (int nSegmentIndex = 0; nSegmentIndex < nCountMax; ++nSegmentIndex)
                            {
                                uint32 dwSampleCount;
                                uint32 dwUnitID;
                                double dTimeStamp;
                                double adData[1024];


                                if (ns_OK != rcLib.GetSegmentData(idEntity, nSegmentIndex, &dTimeStamp, adData, sizeof adData, &dwSampleCount, &dwUnitID))
                                {
                                    MessageBox ("There was an error loading the segment data!");
                                    return;
                                }
                                else
                                {
                                    // ok..let's start drawing

                                    int x;  // X coordinate
                                    int y;  // Y coordinate

                                    x = 0;
                                    y = adData[0] * dScaleY + dOffsetY;

                                    icDC.MoveTo(x, y);

                                    for (int i = 1; i < dwSampleCount; ++i)
                                    {
                                        x = i * dScaleX;
                                        y = adData[i] * dScaleY + dOffsetY;

                                        icDC.LineTo(x, y);
                                    }
                                }
                            }
                        }
                    }
                }

                // We exit here because we only want to see the "first" entity of the type we want
                return;
            }
        }
    }
}

// Author & Date:   Kirk Korver     Jan 23, 2003
// Purpose: return the number of events of the specified type
//  that exist in this library.
// Inputs:
//  rcLib - the library to search through
//  idEventType - the type we are looking for, e.g. ns_ENTITY_NEURALEVENT
// Outputs:
//  The number of events of that type found. 
//  In the case of error, 0 will be returned
int CVCSourceCodeExampleDlg::GetNumOfEvents(NsFile const & rcLib, int idEventType)
{
    ns_FILEINFO isFileInfo;
    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
    {
        //MessageBox("Unable to get the entity info from the File Info");
        return 0;
    }

    
    // Set equal to 0 because we are about to count how many we find
    int nCount = 0;

    // Ok, we now now how many entities, let's rock'n roll
    ns_ENTITYINFO isEntityInfo;
    for (DWORD i = 0; i < isFileInfo.dwEntityCount; ++i)
    {
        if (ns_OK == rcLib.GetEntityInfo(i, &isEntityInfo, sizeof(isEntityInfo)))
        {
            if (isEntityInfo.dwEntityType == idEventType)
                ++nCount;
        }
        else
        {
            //MessageBox("There was an error loading the entity information!");
            return 0;
        }
    }

    return nCount;
}



void CVCSourceCodeExampleDlg::ShowRaster(NsFile const & rcLib)
{
    ns_FILEINFO isFileInfo;
    if (ns_OK != rcLib.GetFileInfo(&isFileInfo, sizeof(isFileInfo)))
    {
        MessageBox("Unable to get the entity info from the File Info");
        return;
    }

    // Let's make sure we have at least 1 entity
    if (isFileInfo.dwEntityCount < 1)
    {
        MessageBox("No Entities to process");
        return;
    }


    // I'm going to do some drawing, so get ready
	CDC icDC;
	icDC.CreateCompatibleDC(NULL);

    CPen icPen(PS_SOLID, 1, crMY_COLOR);
    icDC.SelectObject(icPen);

	icDC.SelectObject(m_icRasterBMP);
    m_icRasterFrame.Invalidate();       // Yeah this is a little on the bleeding edge, but I should
                                        // be able to say "draw this later, cuz I'm going to make changes
                                        // soon". 

    // Start off by erasing anything leftover (say from last time)
    icDC.FillSolidRect(m_icRasterRect, crBLACK);

    // Let's set the scaling 
    double dScaleX = double(this->m_icRasterRect.Width()) / isFileInfo.dTimeSpan;
    double dScaleY = double(this->m_icRasterRect.Height()) / double(GetNumOfEvents(rcLib, ns_ENTITY_NEURALEVENT));


    int nNeuralCount = -1;  // Easier to use -1 so that I set it to 0 at top when found

    // Now let's find every entity of type "ns_ENTITY_NEURALEVENT"
    for (DWORD idEntity = 0; idEntity < isFileInfo.dwEntityCount; ++idEntity)
    {
        ns_ENTITYINFO isEntityInfo;
        if (ns_OK != rcLib.GetEntityInfo(idEntity, &isEntityInfo, sizeof(isEntityInfo)))
        {
            MessageBox("There was an error loading the entity information!");
            return;
        }
        else
        {
            if (isEntityInfo.dwEntityType == ns_ENTITY_NEURALEVENT)
            {
                // Got one. Let's rock'n roll
                ++nNeuralCount;

                // Ensure that we do have an entity to look at
                if (0 == isEntityInfo.dwItemCount)
                {
                    MessageBox("No neural indeces!");
                    return;
                }
                else
                {
                    // We display at max 1000 
                    static const int MAX_DATA_SIZE = 1000;
                    int nCountMax = min(MAX_DATA_SIZE, isEntityInfo.dwItemCount);
                    double adData[MAX_DATA_SIZE];


                    if (ns_OK != rcLib.GetNeuralData(idEntity, 0, nCountMax, adData))
                    {
                        MessageBox("There was an error loading the neural data!");
                        return;
                    }
                    else
                    {

                        for (int i = 0; i < nCountMax; ++i)
                        {
                            // ok..let's start drawing
                            int x;  // X coordinate
                            int y;  // Y coordinate

                            x = adData[i] * dScaleX;
                            y = nNeuralCount * dScaleY;

                            icDC.MoveTo(x, y);


                            //x = adData[i] * dScaleX;   same as above
                            y = nNeuralCount * dScaleY + dScaleY;

                            icDC.LineTo(x, y);
                        }
                    }
                }
            }
        }
    }
}


