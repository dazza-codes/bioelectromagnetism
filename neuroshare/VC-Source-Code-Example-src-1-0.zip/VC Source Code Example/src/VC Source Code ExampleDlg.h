///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: VC Source Code ExampleDlg.h $
//
// Description   : This implements a simplistic VC sample of the Neuroshare Library
//
// Authors       : Kirk Korver
//
// $Date: 1/27/03 2:17p $
//
// $History: VC Source Code ExampleDlg.h $
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 1/27/03    Time: 2:17p
// Updated in $/Neuroshare/VC Source Code Example
// NeuroshareLibrary.h is now NsFile.h
// NsLibrary is now NsFile
// NsLibraryMgr is now MsFileMgr
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 1/27/03    Time: 1:03p
// Updated in $/Neuroshare/VC Source Code Example
// Added required headers
// Renamed a few classes
//
///////////////////////////////////////////////////////////////////////////////////////////////////



#if !defined(AFX_VCSOURCECODEEXAMPLEDLG_H__31322D1A_74F9_4EAE_9031_B76E06B6AEB6__INCLUDED_)
#define AFX_VCSOURCECODEEXAMPLEDLG_H__31322D1A_74F9_4EAE_9031_B76E06B6AEB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class NsFile;     // forward declare to avoid #include "NeuroshareLibrary.h"



/////////////////////////////////////////////////////////////////////////////
// CVCSourceCodeExampleDlg dialog

class CVCSourceCodeExampleDlg : public CDialog
{
// Construction
public:
	CVCSourceCodeExampleDlg(CWnd* pParent = NULL);	// standard constructor


// Dialog Data
	//{{AFX_DATA(CVCSourceCodeExampleDlg)
	enum { IDD = IDD_VCSOURCECODEEXAMPLE_DIALOG };
	CStatic	m_icAnalogFrame;
	CStatic	m_icSegmentFrame;
	CStatic	m_icRasterFrame;
	CStatic	m_icEventFrame;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVCSourceCodeExampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CRect m_icAnalogRect;
	CBitmap m_icAnalogBMP;          // bitmap for storing analog signal

	CRect m_icSegmentRect;
	CBitmap m_icSegmentBMP;         // bitmap for storing segment 

	CRect m_icRasterRect;
	CBitmap m_icRasterBMP;          // bitmap for storing raster plots

	CRect m_icEventRect;
	CBitmap m_icEventBMP;           // bitmap for storing time of first event




    // Get and display the info about this file
    void ShowFileInfo(NsFile const & rcLib);
    void ShowEntityInfo(NsFile const & rcLib);
    void ShowEvent(NsFile const & rcLib);
	void ShowAnalog(NsFile const & rcLib);
	void ShowRaster(NsFile const & rcLib);
	void ShowSegment(NsFile const & rcLib);


    
    // Purpose: return the number of events of the specified type
    //  that exist in this library.
    // Inputs:
    //  rcLib - the library to search through
    //  idEventType - the type we are looking for, e.g. ns_ENTITY_NEURALEVENT
    // Outputs:
    //  The number of events of that type found. 
    //  In the case of error, 0 will be returned
    int GetNumOfEvents(NsFile const & rcLib, int idEventType);


    // Purpose: tie to gether the bitmap with the frame on the screen so that writing to the 
    //  bitmap will "forever" show up on the screen, let's also save the bounding box size
    // Inputs:
    //  rcFrame - the frame on the dialog box
    // Outputs:
    //  rcRect - the bounding box
    //  rcBitmap - the bitmap to bind to the frame
	void InitFrameBitmap(CRect & rcRect, CBitmap & rcBitmap, CStatic & rcFrame);



	// Generated message map functions
	//{{AFX_MSG(CVCSourceCodeExampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonOpenFile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VCSOURCECODEEXAMPLEDLG_H__31322D1A_74F9_4EAE_9031_B76E06B6AEB6__INCLUDED_)
