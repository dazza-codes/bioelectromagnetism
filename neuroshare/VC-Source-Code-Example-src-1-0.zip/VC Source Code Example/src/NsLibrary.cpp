///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NsLibrary.cpp $
//
// Description   : implementation of the NsLibrary class.
//
// Authors       : Kirk Korver
//
// $Date: 2/24/03 2:15p $
//
// $History: NsLibrary.cpp $
// 
// *****************  Version 6  *****************
// User: Kirk         Date: 2/24/03    Time: 2:15p
// Updated in $/Neuroshare/VC Source Code Example
// Updated to use the new version 1.0 API
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 1/27/03    Time: 2:17p
// Updated in $/Neuroshare/VC Source Code Example
// NeuroshareLibrary.h is now NsFile.h
// NsLibrary is now NsFile
// NsLibraryMgr is now MsFileMgr
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 1/27/03    Time: 1:08p
// Updated in $/Neuroshare/VC Source Code Example
// Added Requried Headers
// Shortened Neuroshare to Ns in names
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "VC Source Code Example.h"
#include "NsLibrary.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NsLibrary::NsLibrary(LPCSTR szDllName) :
    m_pfGetLibraryInfo(0),
    m_pfOpenFile(0),
    m_pfGetFileInfo(0),
    m_pfCloseFile(0),
    m_pfGetEntityInfo(0),
    m_pfGetEventInfo(0),
    m_pfGetEventData(0),
    m_pfGetAnalogInfo(0),
    m_pfGetAnalogData(0),
    m_pfGetSegmentInfo(0),
    m_pfGetSegmentSourceInfo(0),
    m_pfGetSegmentData(0),
    m_pfGetNeuralInfo(0),
    m_pfGetNeuralData(0),
    m_pfGetIndexByTime(0),
    m_pfGetTimeByIndex(0),
    m_hDLL(0)
{
    LoadDLL(szDllName);
}

NsLibrary::~NsLibrary()
{
    CleanUp();
}



// Author & Date:       Kirk Korver     08 Jan 2003
// Load the DLL into memory and set all of the function pointers
// Inputs:
//  szDllName - the name of the DLL to open
// Returns:
//  TRUE if life is good; FALSE, otherwise
bool NsLibrary::LoadDLL(LPCSTR szDllName)
{
    // Make it so we don't have to remember to unload prior to loading
    if (m_hDLL)
        CleanUp();

    do
    {
        m_hDLL = ::LoadLibrary(szDllName);
        if (!m_hDLL)
            break;


        // Now lets set all of our pointers


        // A macro to help with gettng the addresses
        #define SetPointers(MyName, Type, DllName)                  \
            MyName = (Type) GetProcAddress(m_hDLL, DllName);        \
            if (0 == MyName)                                        \
                break;                                              \


        SetPointers(m_pfGetLibraryInfo, NS_GETLIBRARYINFO, "ns_GetLibraryInfo")
        SetPointers(m_pfOpenFile, NS_OPENFILE, "ns_OpenFile")
        SetPointers(m_pfGetFileInfo, NS_GETFILEINFO, "ns_GetFileInfo")
        SetPointers(m_pfCloseFile, NS_CLOSEFILE, "ns_CloseFile")
        SetPointers(m_pfGetEntityInfo, NS_GETENTITYINFO, "ns_GetEntityInfo")
        SetPointers(m_pfGetEventInfo, NS_GETEVENTINFO, "ns_GetEventInfo")
        SetPointers(m_pfGetEventData, NS_GETEVENTDATA, "ns_GetEventData")
        SetPointers(m_pfGetAnalogInfo, NS_GETANALOGINFO, "ns_GetAnalogInfo")
        SetPointers(m_pfGetAnalogData, NS_GETANALOGDATA, "ns_GetAnalogData")
        SetPointers(m_pfGetSegmentInfo, NS_GETSEGMENTINFO, "ns_GetSegmentInfo")
        SetPointers(m_pfGetSegmentSourceInfo, NS_GETSEGMENTSOURCEINFO, "ns_GetSegmentSourceInfo")
        SetPointers(m_pfGetSegmentData, NS_GETSEGMENTDATA, "ns_GetSegmentData")
        SetPointers(m_pfGetNeuralInfo, NS_GETNEURALINFO, "ns_GetNeuralInfo")
        SetPointers(m_pfGetNeuralData, NS_GETNEURALDATA, "ns_GetNeuralData")
        SetPointers(m_pfGetIndexByTime, NS_GETINDEXBYTIME, "ns_GetIndexByTime")
        SetPointers(m_pfGetTimeByIndex, NS_GETTIMEBYINDEX, "ns_GetTimeByIndex")

        #undef SetPointers
        // We don't need the macro any more


        // If we get here, then life is good
        return true;

    } while (false);

    // if we got here, then bad things have happened
    CleanUp();
    return false;

}



// Author & Date:       Kirk Korver     08 Jan 2003
void NsLibrary::CleanUp()
{
    if (m_hDLL)
    {
        FreeLibrary(m_hDLL);
        m_hDLL = 0;
    }
    m_pfGetLibraryInfo = 0;
    m_pfOpenFile = 0;
    m_pfGetFileInfo = 0;
    m_pfCloseFile = 0;
    m_pfGetEntityInfo = 0;
    m_pfGetEventInfo = 0;
    m_pfGetEventData = 0;
    m_pfGetAnalogInfo = 0;
    m_pfGetAnalogData = 0;
    m_pfGetSegmentInfo = 0;
    m_pfGetSegmentSourceInfo = 0;
    m_pfGetSegmentData = 0;
    m_pfGetNeuralInfo = 0;
    m_pfGetNeuralData = 0;
    m_pfGetIndexByTime = 0;
    m_pfGetTimeByIndex = 0;
    m_pfGetLastErrorMsg = 0;
}