///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NsFile.h $
//
// Description   : interface for the NsFile class
//
// Authors       : Kirk Korver
//
// $Date: 2/24/03 2:15p $
//
// $History: NsFile.h $
// 
// *****************  Version 6  *****************
// User: Kirk         Date: 2/24/03    Time: 2:15p
// Updated in $/Neuroshare/VC Source Code Example
// Updated to use the new version 1.0 API
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 1/27/03    Time: 2:17p
// Updated in $/Neuroshare/VC Source Code Example
// NeuroshareLibrary.h is now NsFile.h
// NsLibrary is now NsFile
// NsLibraryMgr is now MsFileMgr
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 1/27/03    Time: 1:05p
// Updated in $/Neuroshare/VC Source Code Example
// Added required headers
// Renamed a few classes
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_NSFILE_H__AE48A298_906C_4AD3_8816_0793E502BEB4__INCLUDED_)
#define AFX_NSFILE_H__AE48A298_906C_4AD3_8816_0793E502BEB4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NsLibrary.h"
#include "nsAPItypes.h"


class NsFile;         // forward declaration for clarity....look lower for definition

class NsFileMgr
{
public:
    
    // Once you get this, it is up to you to "delete" it later on
    // reuturns NULL on failure
    static NsFile * NewFile(LPCSTR szDataFileName);

private:

    // get list of libraries available
    // get capabilities

    // find data file based on extension
    // find data file based on ???
};




class NsFile  
{
public:

    // The constructors....only allow the manager to construct us
	//NsFile();
	~NsFile();

    // return TRUE if this library is OK to use; FALSE, otherwise.
    bool IsOK()
        { return m_icDLL.IsOK() && m_hDataFile != INVALID_HANDLE; }


    
    
    ns_RESULT GetLibraryInfo(ns_LIBRARYINFO *pLibraryInfo, uint32 dwLibraryInfoSize) const
        { return m_icDLL.GetLibraryInfo(pLibraryInfo, dwLibraryInfoSize); }

    ns_RESULT GetFileInfo(ns_FILEINFO *pFileInfo, uint32 dwFileInfoSize) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetFileInfo(m_hDataFile, pFileInfo, dwFileInfoSize); }
    
    ns_RESULT CloseFile();
    
    ns_RESULT GetEntityInfo(uint32 dwEntityID, ns_ENTITYINFO *pEntityInfo, uint32 dwEntityInfoSize) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetEntityInfo(m_hDataFile, dwEntityID, pEntityInfo, dwEntityInfoSize); }
    
    ns_RESULT GetEventInfo(uint32 dwEntityID, ns_EVENTINFO *pEventInfo, uint32 dwEventInfoSize) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetEventInfo(m_hDataFile, dwEntityID, pEventInfo, dwEventInfoSize); }
    
    ns_RESULT GetEventData(uint32 dwEntityID, uint32 nIndex, double *pdTimeStamp, void *pData, uint32 dwDataSize, uint32 *pdwDataRetSize) const 
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetEventData(m_hDataFile, dwEntityID, nIndex, pdTimeStamp, pData, dwDataSize, pdwDataRetSize); }
    
    ns_RESULT GetAnalogInfo(uint32 dwEntityID, ns_ANALOGINFO *pAnalogInfo, uint32 dwAnalogInfoSize) const 
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetAnalogInfo(m_hDataFile, dwEntityID, pAnalogInfo, dwAnalogInfoSize); }
    
    ns_RESULT GetAnalogData(uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, uint32 *pdwContCount, double *pData) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetAnalogData(m_hDataFile, dwEntityID, dwStartIndex, dwIndexCount, pdwContCount, pData); }
    
    ns_RESULT GetSegmentInfo(uint32 dwEntityID, ns_SEGMENTINFO *pSegmentInfo, uint32 dwSegmentInfoSize) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetSegmentInfo(m_hDataFile, dwEntityID, pSegmentInfo, dwSegmentInfoSize); }
    
    ns_RESULT GetSegmentSourceInfo(uint32 dwEntityID, uint32 dwSourceID, ns_SEGSOURCEINFO *pSourceInfo, uint32 dwSourceInfoSize) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetSegmentSourceInfo(m_hDataFile, dwEntityID, dwSourceID, pSourceInfo, dwSourceInfoSize); }
    
    ns_RESULT GetSegmentData(uint32 dwEntityID, int32 nIndex, double *pdTimeStamp, double *pdData, uint32 dwDataBufferSize, uint32 *pdwSampleCount, uint32 *pdwUnitID) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetSegmentData(m_hDataFile, dwEntityID, nIndex, pdTimeStamp, pdData, dwDataBufferSize, pdwSampleCount, pdwUnitID); }
    
    ns_RESULT GetNeuralInfo(uint32 dwEntityID, ns_NEURALINFO *pNeuralInfo, uint32 dwNeuralInfoSize) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetNeuralInfo(m_hDataFile, dwEntityID, pNeuralInfo, dwNeuralInfoSize); }
    
    ns_RESULT GetNeuralData(uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, double *pdData) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetNeuralData(m_hDataFile, dwEntityID, dwStartIndex, dwIndexCount, pdData); }
    
    ns_RESULT GetIndexByTime(uint32 dwEntityID, double dTime, int32 nFlag, uint32 *pdwIndex) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetIndexByTime(m_hDataFile, dwEntityID, dTime, nFlag, pdwIndex); }

    ns_RESULT GetTimeByIndex(uint32 dwEntityID, uint32 dwIndex, double *pdTime) const
        { _ASSERT(m_hDataFile != INVALID_HANDLE); 
          return m_icDLL.GetTimeByIndex(m_hDataFile, dwEntityID, dwIndex, pdTime); }

    ns_RESULT GetLastErrorMsg(char *pszMsgBuffer, uint32 dwMsgBufferSize)
        { return m_icDLL.GetLastErrorMsg(pszMsgBuffer, dwMsgBufferSize); }


private:
    NsLibrary m_icDLL;
    uint32 m_hDataFile;

    // The value that means that the handle returned is invalid
    enum { INVALID_HANDLE = 0 };


    // The constructors....only allow the manager to construct us
    // Inputs:
    //  szDllName - the name of the DLL to use to open.
	NsFile(LPCSTR szDllName);


    // Open the DLL file specified
    // return TRUE if life is good; FALSE, otherwise
    bool LoadDLL(LPCSTR szDllFileName)
        { return m_icDLL.LoadDLL(szDllFileName); }


    
    ns_RESULT OpenFile(const char *pszFilename)
        { return m_icDLL.OpenFile(pszFilename, &m_hDataFile); }



    friend class NsFileMgr;

};

#endif // !defined(AFX_NSFILE_H__AE48A298_906C_4AD3_8816_0793E502BEB4__INCLUDED_)
