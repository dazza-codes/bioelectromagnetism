///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2003  Neuroshare Project                                                         
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// A copy of the GNU Lesser General Public License can be obtained by writing to:
//  Free Software Foundation, Inc.,
//  59 Temple Place, Suite 330,
//  Boston, MA  02111-1307
//  USA
//
// Contact information:
//  Angela Wang
//  CyberKinetics, Inc.,
//  391 G Chipeta Way
//  Salt Lake City,  UT  84108
//  USA
//  angela@bionictech.com
//
// Website:
//  www.neuroshare.org
//
// All other copyrights on this material are replaced by this license agreeement.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
// $Workfile: NsLibrary.h $
//
// Description   : interface for the NsLibrary class
//
// Authors       : Kirk Korver
//
// $Date: 2/24/03 2:15p $
//
// $History: NsLibrary.h $
// 
// *****************  Version 6  *****************
// User: Kirk         Date: 2/24/03    Time: 2:15p
// Updated in $/Neuroshare/VC Source Code Example
// Updated to use the new version 1.0 API
// 
// *****************  Version 5  *****************
// User: Kirk         Date: 1/27/03    Time: 2:17p
// Updated in $/Neuroshare/VC Source Code Example
// NeuroshareLibrary.h is now NsFile.h
// NsLibrary is now NsFile
// NsLibraryMgr is now MsFileMgr
// 
// *****************  Version 4  *****************
// User: Kirk         Date: 1/27/03    Time: 1:05p
// Updated in $/Neuroshare/VC Source Code Example
// Added Required Headers
// Added IsOK()
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef NS_LIBRARY_H_INCLUDED   // our standard include guards
#define NS_LIBRARY_H_INCLUDED

#if !defined(AFX_NSLIBRARY_H__E2222B00_9449_4789_9658_A3BF616D2F06__INCLUDED_)
#define AFX_NSLIBRARY_H__E2222B00_9449_4789_9658_A3BF616D2F06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nsAPIdllimp.h"

class NsLibrary
{
public:
    NsLibrary(LPCSTR szDllName);
    virtual ~NsLibrary();

    // Inputs:
    //  szDllName - the name of the DLL to open
    // Returns:
    //  TRUE if life is good; FALSE, otherwise
    bool LoadDLL(LPCSTR szDllName);


    // return TRUE of the DLL was loaded properly; FALSE, otherwise
    bool IsOK()
        { return m_hDLL != 0; }




    // All of these functions map exactly into the function prototypes for the neuroshare API,
    // look there for the documentation on what they do.

    ns_RESULT GetLibraryInfo(ns_LIBRARYINFO *pLibraryInfo, uint32 dwLibraryInfoSize) const
        { _ASSERT(m_pfGetLibraryInfo); return m_pfGetLibraryInfo(pLibraryInfo, dwLibraryInfoSize); }
    
    ns_RESULT OpenFile(const char *pszFilename, uint32 *hFile) const
        { _ASSERT(m_pfOpenFile); return m_pfOpenFile(pszFilename, hFile); }
    
    ns_RESULT GetFileInfo(uint32 hFile, ns_FILEINFO *pFileInfo, uint32 dwFileInfoSize) const
        { _ASSERT(m_pfGetFileInfo); return m_pfGetFileInfo(hFile, pFileInfo, dwFileInfoSize); }
    
    ns_RESULT CloseFile(uint32 hFile) const 
        { _ASSERT(m_pfCloseFile);  return m_pfCloseFile(hFile); }
    
    ns_RESULT GetEntityInfo(uint32 hFile, uint32 dwEntityID, ns_ENTITYINFO *pEntityInfo, uint32 dwEntityInfoSize) const
        { _ASSERT(m_pfGetEntityInfo); return m_pfGetEntityInfo(hFile, dwEntityID, pEntityInfo, dwEntityInfoSize); }
    
    ns_RESULT GetEventInfo(uint32 hFile, uint32 dwEntityID, ns_EVENTINFO *pEventInfo, uint32 dwEventInfoSize) const
        { _ASSERT(m_pfGetEventInfo); return m_pfGetEventInfo(hFile, dwEntityID, pEventInfo, dwEventInfoSize); }
    
    ns_RESULT GetEventData(uint32 hFile, uint32 dwEntityID, uint32 nIndex, double *pdTimeStamp, void *pData, uint32 dwDataSize, uint32 *pdwDataRetSize) const 
        { _ASSERT(m_pfGetEventData); return m_pfGetEventData(hFile, dwEntityID, nIndex, pdTimeStamp, pData, dwDataSize, pdwDataRetSize); }
    
    ns_RESULT GetAnalogInfo(uint32 hFile, uint32 dwEntityID, ns_ANALOGINFO *pAnalogInfo, uint32 dwAnalogInfoSize) const
        { _ASSERT(m_pfGetAnalogInfo); return m_pfGetAnalogInfo(hFile, dwEntityID, pAnalogInfo, dwAnalogInfoSize); }
    
    ns_RESULT GetAnalogData(uint32 hFile, uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, uint32 *pdwContCount, double *pData) const
        { _ASSERT(m_pfGetAnalogData); return m_pfGetAnalogData(hFile, dwEntityID, dwStartIndex, dwIndexCount, pdwContCount, pData); }
    
    ns_RESULT GetSegmentInfo(uint32 hFile, uint32 dwEntityID, ns_SEGMENTINFO *pSegmentInfo, uint32 dwSegmentInfoSize) const
        { _ASSERT(m_pfGetSegmentInfo); return m_pfGetSegmentInfo(hFile, dwEntityID, pSegmentInfo, dwSegmentInfoSize); }
    
    ns_RESULT GetSegmentSourceInfo(uint32 hFile, uint32 dwEntityID, uint32 dwSourceID, ns_SEGSOURCEINFO *pSourceInfo, uint32 dwSourceInfoSize) const
        { _ASSERT(m_pfGetSegmentSourceInfo); return m_pfGetSegmentSourceInfo(hFile, dwEntityID, dwSourceID, pSourceInfo, dwSourceInfoSize); }
    
    ns_RESULT GetSegmentData(uint32 hFile, uint32 dwEntityID, int32 nIndex, double *pdTimeStamp, double *pdData, uint32 dwDataBufferSize, uint32 *pdwSampleCount, uint32 *pdwUnitID) const
        { _ASSERT(m_pfGetSegmentData); return m_pfGetSegmentData(hFile, dwEntityID, nIndex, pdTimeStamp, pdData, dwDataBufferSize, pdwSampleCount, pdwUnitID); }
    
    ns_RESULT GetNeuralInfo(uint32 hFile, uint32 dwEntityID, ns_NEURALINFO *pNeuralInfo, uint32 dwNeuralInfoSize) const
        { _ASSERT(m_pfGetNeuralInfo); return m_pfGetNeuralInfo(hFile, dwEntityID, pNeuralInfo, dwNeuralInfoSize); }
    
    ns_RESULT GetNeuralData(uint32 hFile, uint32 dwEntityID, uint32 dwStartIndex, uint32 dwIndexCount, double *pdData) const
        { _ASSERT(m_pfGetNeuralData); return m_pfGetNeuralData(hFile, dwEntityID, dwStartIndex, dwIndexCount, pdData); }
    
    ns_RESULT GetIndexByTime(uint32 hFile, uint32 dwEntityID, double dTime, int32 nFlag, uint32 *pdwIndex) const
        { _ASSERT(m_pfGetIndexByTime); return m_pfGetIndexByTime(hFile, dwEntityID, dTime, nFlag, pdwIndex); }
    
    ns_RESULT GetTimeByIndex(uint32 hFile, uint32 dwEntityID, uint32 dwIndex, double *pdTime) const
        { _ASSERT(m_pfGetTimeByIndex); return m_pfGetTimeByIndex(hFile, dwEntityID, dwIndex, pdTime); }
    
    ns_RESULT GetLastErrorMsg(char *pszMsgBuffer, uint32 dwMsgBufferSize)
        { _ASSERT(m_pfGetTimeByIndex); return m_pfGetLastErrorMsg(pszMsgBuffer, dwMsgBufferSize); }

protected:
    HINSTANCE m_hDLL;       // The handle to the DLL


    NS_GETLIBRARYINFO m_pfGetLibraryInfo;
    NS_OPENFILE m_pfOpenFile;
    NS_GETFILEINFO m_pfGetFileInfo;
    NS_CLOSEFILE m_pfCloseFile;
    NS_GETENTITYINFO m_pfGetEntityInfo;
    NS_GETEVENTINFO m_pfGetEventInfo;
    NS_GETEVENTDATA m_pfGetEventData;
    NS_GETANALOGINFO m_pfGetAnalogInfo;
    NS_GETANALOGDATA m_pfGetAnalogData;
    NS_GETSEGMENTINFO m_pfGetSegmentInfo;
    NS_GETSEGMENTSOURCEINFO m_pfGetSegmentSourceInfo;
    NS_GETSEGMENTDATA m_pfGetSegmentData;
    NS_GETNEURALINFO m_pfGetNeuralInfo;
    NS_GETNEURALDATA m_pfGetNeuralData;
    NS_GETINDEXBYTIME m_pfGetIndexByTime;
    NS_GETTIMEBYINDEX m_pfGetTimeByIndex;
    NS_GETLASTERRORMSG m_pfGetLastErrorMsg;


    
    
    
    // Clean everything up
    void CleanUp();

};

#endif // !defined(AFX_NSLIBRARY_H__E2222B00_9449_4789_9658_A3BF616D2F06__INCLUDED_)


#endif  // NS_LIBRARY_H_INCLUDED   // our standard include guards
