For the "VB Source Code Example" program to work, the 
nsNEVLibrary.dll file has to be in the same directory as the 
exe file or in the path.