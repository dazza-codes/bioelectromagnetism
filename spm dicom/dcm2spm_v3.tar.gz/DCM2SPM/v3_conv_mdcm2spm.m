function [check] = v3_conv_mdcm2spm(dirDCM,dirSPM,ser,dummy,par1)
%===============================================================================
% v3_conv_mdcm2spm
% Conversion of Mosaic DICOM images from SIEMENS SONATA to SPM (ANALYZE) format
%===============================================================================
% INPUT parameters
%   dirDCM  - directory of original data 
%   dirSPM  - directory for SPM data
%   ser     - numbers of series
%   dummy   - matrix of dummy scans for each series
%   par1    - name SPM images as time series? ('y' or 'n'); default is 'n'
%
% OUTPUT parameters:
%   check   - function return 1 when successful, 0 otherwise.
%
% NOTE:
%   - MPRAGE DICOM images must be placed in dirDCM/MPR directory.
%   - needs these functions: 
%       v3_get_listdir.m
%       v3_flip_spm.m
%------------------------------------------------------------------------------
% Katholieke universiteit Leuven, Leuven, Belgium
% Last update: Sept 15, 2001
%===============================================================================

%===============================================================================
% 1. DEFAULT PARAMETERS
%===============================================================================

comp     = computer;
base1    = '.MR..';
base2    = 'im-';
base3    = 'im_';
ext1     = '.IMA';
ext2     = '.dcm';
ext3     = '.img';
ext3a    = '.hdr';
nameTS   = 'ts';
cmdMC    = 'medcon -ar -c anlz -f ';


%===============================================================================
% 2. CHECKING INPUT PARAMETERS
%===============================================================================

if nargin < 4 | nargin > 5
   disp('Number of input parameters incorrect. Stop.');
   help v3_conv_mdcm2spm;
   break;
elseif nargin == 4
   par1 = 'n';
end 

if ~strcmp(dirDCM(end),filesep)
   dirDCM = [dirDCM filesep];
end

if ~strcmp(dirSPM(end),filesep)
   dirSPM = [dirSPM filesep];
end

if isempty(ser) 
   disp(['Number of series not entered!']);
   help v3_conv_mdcm2spm;
   break;
end

%===============================================================================
% 3. MAIN PROCEDURE
%===============================================================================

disp(['Converting DICOM images...']);

% notp and nosl

notp=[];
nosl=[];
%clear slices; 
for i = 1:length(ser)
   list =  dir([dirDCM base1 num2str(ser(i)) '.*.*.*.*.*.*.*.*.*.IMA']); 
   notp=[notp,length(list)];
   slices = [];
   for j=1:length(list)
      pos1 = findstr(list(j).name,'.');
      slices = [slices,str2num(list(j).name(pos1(4)+1:pos1(5)-1))];
   end
   nosl=[nosl,min(slices)+1];
end

for i=1:length(ser)
   dirTS{i} = sprintf('%s%s%0.2d%s',dirSPM,nameTS,i,filesep);
   if ~exist(dirTS{i},'dir')
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
         unix(['mkdir ' dirTS{i}]); 
      elseif strcmp(comp(1:2),'PC')
         dos(['mkdir ' dirTS{i}]);
      end
   else
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
         unix(['rm -rf ' dirTS{i} ';mkdir ' dirTS{i}]);
      elseif strcmp(comp(1:2),'PC')
         dos(['rmdir /S /Q ' dirTS{i}]);
         dos(['mkdir ' dirTS{i}]);
      end
   end
   for j=1:notp(i)-dummy(i)
      eval(['cd ' dirTS{i}]);
      list = dir([dirDCM '.MR..' num2str(ser(i)) '.*.IMA']);
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
	 str=sprintf('%s%s%s%d%s%d%s%s%s%s%0.3d%s%s','mmv -s "',dirDCM,base1,ser(i),'.',nosl(i)-1+(j-1+dummy(i))*nosl(i),'.*',ext1,'" "',base2,j,ext2,'"');
         unix(str);
      elseif strcmp(comp(1:2),'PC')
         str=sprintf('%s%s%s%d%s%d%s%s%s%s%0.3d%s','copy /Y /B ',dirDCM,base1,ser(i),'.',nosl(i)-1+(j-1+dummy(i))*nosl(i),'.*',ext1,' ',base2,j,ext2);
         dos(str);
      end
   end
   listHDR{i} = [dirTS{i} sprintf('%s%0.3d%s',base2,1,ext2)];
   %str = ['strings ' listHDR{i} ' | grep sSliceArray.lSize'];
   %[dum,dumstr] = unix(str);
   %nosl(i) = str2num(dumstr(findstr(dumstr,'=')+1:end)); 
end

for i=1 : length(ser)
   eval(['cd ' dirTS{i}]);
   str = [cmdMC base2 '*' ext2];
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
      unix(str);
      listMCf{i} = v3_get_listdir(dirTS{i},['m*.img']);
   elseif strcmp(comp(1:2),'PC') 
      dos(str);
      listMCf{i} = v3_get_listdir(pwd,['m*.img']);
   end   
end

[a,b,c,d,e]=rddcmh(nosl,listHDR,1);

for i=1:length(ser)     % cycle over number of time series
   MosaicSize = a{i}(1);               % Size of MOSAIC image
   MosaicDIM  = ceil(sqrt(nosl(i)));   % Number of single images in MOSAIC
   ImageSize  = MosaicSize/MosaicDIM;  % Size of single image

   disp(['Separating images from time series No. ' num2str(i) ' ...']);
   a{i}(1:2) = ImageSize;
   a{i}(3)   = nosl(i);
   c{i}(1:2) = ImageSize/2;
   for j=1:notp(i)-dummy(i)   % cycle over number of time points (number of mosaic images)   
      NoEmptyIma = MosaicDIM^2 - nosl(i);   % Number of unfilled images in MOSAIC
      %infile = sprintf('%s%s%0.2d%s%s%0.3d%s%s%s%0.3d%s',dirTS{i},'m',j-1,'-',base2,j,ext3);
      infile = listMCf{i}(j,:);
      fid = fopen(infile,'rb','l');  % little endian is used
      if fid == -1
         disp(['??? Cannot open ',infile,' for reading.'])
         check=0;
         break;
      end   
      if MosaicSize
         [Mobraz,count] = fread(fid,[MosaicSize,MosaicSize],'uint16');
      else
         disp('??? Error: Invalid image size or wrong values of matrix sizes read from header.');
         check=0;
         break;
      end

      if fclose(fid) ~= 0
         disp(['The file ' infile ' cannot be closed.']);
      end

% DISPLAYING THE MOSAIC IMAGE AS READ FROM MEDCON CONVERTED FILE
%
%if ~isempty(Mobraz)
%   imagesc(Mobraz);
%   axis('image');
%   colormap('gray');
%end  

% SEPARATING THE MOSAIC IMAGE

      if strcmp(par1,'n')
         outfile = sprintf('%s%s%0.3d%s',dirTS{i},base3,j,ext3);
      elseif strcmp(par1,'y')
         outfile = sprintf('%s%s%0.2d%s%0.3d%s',dirTS{i},nameTS,i,'_',j,ext3);
      end
      fid=fopen(outfile,'wb');
      if fid == -1
         disp(['??? Cannot open ',outfile,' for writing.'])
         check=0;
         break;
      end   
      for m=1:MosaicDIM      % over rows in Mobraz
	 for n=1:MosaicDIM       % over columns in Mobraz
	    if NoEmptyIma~=0 & m==1 
	       n = n + NoEmptyIma; 
	       C(:,:) = Mobraz(1+(n-1)*ImageSize:n*ImageSize,(m-1)*ImageSize+1:m*ImageSize);
	       %fwrite(fid,Mobraz(1+(n-1)*ImageSize:n*ImageSize,(m-1)*ImageSize+1:m*ImageSize),'uint16');
	    else
	       C(:,:) = Mobraz(1+(n-1)*ImageSize:n*ImageSize,(m-1)*ImageSize+1:m*ImageSize);
	       %fwrite(fid,Mobraz(1+(n-1)*ImageSize:n*ImageSize,(m-1)*ImageSize+1:m*ImageSize),'uint16');
            end
	    count = fwrite(fid,C,'uint16');
	    %imagesc(C);
            %axis('image');
            %colormap('gray');
	    %pause;
	    if n == MosaicDIM
	       break;
	    end
         end     % end of cycle over 'n'
      end     % end of cycle over 'm'
      
      if fclose(fid) ~= 0
         disp(['The file ' infile ' cannot be closed.']);
      end
      
      % changing parameters for single images and making new headers

      check1 = spm_hwrite(outfile,a{i},b{i},1,4,0,c{i},'');
      if check1 ~= 348
         disp(['Size of SPM header file is not correct - ' nameSER(i,:)]);
	 disp('Header files will not be written for this series.');
      end   
   end  % end of cycle over 'j'
   
   eval(['cd ' dirTS{i}]);
   if strcmp(par1,'n')
      %P = v3_get_listdir(dirTS{i},[base3 '*.img']);
      P = v3_get_listdir(pwd,[base3 '*.img']);
   elseif strcmp(par1,'y')
      %P = v3_get_listdir(dirTS{i},[nameTS '*.img']);
      P = v3_get_listdir(pwd,[nameTS '*.img']);
   end
   v3_flip_spm('mosaic',P,d{i}); 
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
      unix(['rm -f ' dirTS{i} base2 '*.* '  dirTS{i} 'm*.*']);
   elseif strcmp(comp(1:2),'PC') == 1
      dos(['del /Q ' dirTS{i} base2 '*.* '  dirTS{i} 'm*.*']);
   end   
   disp(['Time series No. ' num2str(i) ' done.']); 
end     %  end of cycle over 'i'

eval(['cd ' dirSPM]);

check = 1;

