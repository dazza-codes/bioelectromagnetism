function check = v3_run_conv_mdcm2spm
%=========================================================================
% v3_run_conv_mdcm2spm
% Collects input parameters from GUI for DICOM to SPM comversion 
% Required for GUI to handle a conversion from DICOM to SPM format.
%=========================================================================
% by Katholieke univeristeit Leuven, Leuven, Belgium
% Last update: September 15, 2001
%=========================================================================

global T1 T2 TE3 CB1 CB2 but1 convMPR;

check = 0;
comp = computer;

dirPAT = get(T1,'String');
if isempty(dirPAT)
   msgtext='No patient directory selected.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return
end

dirSPM = get(T2,'String');
if isempty(dirSPM)
   msgtext='No SPM directory selected.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return
end

eval(['cd ' dirPAT]);

% matrix of start and end images

if ~isempty(get(TE3,'String'))
   matrix = str2num(get(TE3,'String'));
else
   msgtext='Matrix of start and end images not given.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return 
end

[Rmatrix,Cmatrix] = size(matrix);
if Cmatrix == 2
   ser = matrix(:,1);
   dum = matrix(:,2);
else
   msgtext='Matrix has more than 2 columns.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return
end

% delete original DICOM data?

if get(CB1,'Value') == 1
   del_ORIG = 'y';
else
   del_ORIG = 'n';
end

% change the base name of SPM files

par1= get(CB2,'Value');
if par1 == 1
   ren_data = 'y';
else
   ren_data = 'n';
end

set(but1,'Enable','off');

% Starting the conversion

if convMPR == 'n'
   check1 = v3_conv_mdcm2spm(dirPAT,dirSPM,ser,dum,ren_data);
   if check1 == 1
      msgbox('Conversion successful.','Done...');
   else
      msgbox('Conversion not completed. Something wrong happened...','Error...','Error','Modal');
   end
elseif convMPR == 'y'
   check1 = v3_conv_mdcm2spm(dirPAT,dirSPM,ser,dum,ren_data);
   check2 = v3_conv_mprdcm2spm(dirPAT,dirSPM);
   if check1 == 1 & check2 == 1
      msgbox('Conversion has been successful.','Done...')
   elseif check1 == 0 & check2 == 0
      msgbox('Conversion has failed.','Done...')
   else
      if check1 == 0
         msgbox('Conversion of fmri images has failed.','Done...');
      else
         msgbox('Conversion of anatomical images has failed.','Done...');
      end
   end
end
clear convMPR;
close(gcbf);

if del_ORIG == 'y'
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') |  strcmp(comp(1:2),'SG')
      str = ['rm -rf ' dirPAT]; 
      unix(str);
   elseif strcmp(comp(1:2),'PC') == 1
      str = ['rmdir /S /Q ' dirPAT]; 
      dos(str);
   end
end

disp(['All images in RADIOLOGICAL convention (R is L).']);
check = 1;

