=====================================================================
This is a free of charge distribution of the conversion program 
DICOM (siemens sonata) to SPM (analyze) format
=====================================================================

- converts single DICOM images to SPM 
- converts mosaic DICOM images to SPM

For detailed information please see:
http://www.kuleuven.ac.be/radiology/Research/fMRI/kulCONV/index.html

---
Katholieke universiteit Leuven, Leuven, Belgium
By Sarka Mierisova; September 15, 2001.
=====================================================================

