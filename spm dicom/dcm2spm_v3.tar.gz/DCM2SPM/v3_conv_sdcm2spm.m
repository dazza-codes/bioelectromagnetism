function check=v3_conv_sdcm2spm(dirPAT,dirSPM,nosl,notp,dummies,par1)
%=========================================================================
% v3_sdcm2spm - converts DICOM image files to SPM (ANALYZE) format
%=========================================================================
% INPUT parameters
%   dirPAT  - directory containing PATIENT data
%   dirSPM  - directory for SPM data
%   nosl    - matrix of number of slices in fMRI series
%   notp    - matrix of number of timepoints in fMRI series
%   dummies - matrix of number of dummy scans
%   par1    - = 0 when base name of SPM images is 'im_'
%             = 1 when base name of SPM images is 'ts01_','ts02_',...
% OUTPUT parameters
%   check  - returns 1 when successful, 0 otherwise
% NOTE:
%   medcon program must be installed.
%   every series must contain image slice No.1
%------------------------------------------------------------------------- 
% Katholieke universiteit Leuven, Belgium
% Last update: Sept 15, 2001
%=========================================================================

% ========================================================================
%  1. DEFAULT PARAMETERS
% ========================================================================

check    = 0;
comp     = computer;
nameSER  = 'series';           % default name for original DICOM images
nameTS   = 'ts';               % default name for timeseries        
base1    = 'im-';              % base name for renamed DICOM images
base2    = 'm*-';              % base name from MedCon program
base3    = 'im_';              % base name of SPM files
base4    = '.MR..';            % part of original name of DICOM files
ext1     = '.dcm';             % extention of DICOM images (after renaming)
ext2     = '.img';             % extention of SPM files from MedCon
ext3     = '.img';             % extention of SPM files 
ext3a    = '.hdr';             % extention of SPM header files
ext4     = '.IMA';             % extention of original DICOM files
cmdMC1   = 'medcon -ar -c anlz -f ';  %command line for MedCon program - beginning
slice1   = 1;                  % number of the first DICOM file 

if par1 == 1
   base3 = nameTS;
end

% ========================================================================
%  2. CHECKING NUMBER OF INPUT PARAMETERS
% ========================================================================

if ~(strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'PC') | strcmp(comp(1:2),'SG'))
   disp('Conversion runs under LINUX, on PCs and SG.');
   return;
end

if nargin ~= 6
   disp(['??? Wrong number of arguments. Stopped...']);
   help v3_conv_dcm2spm;
   break;
end

if isempty(nosl)
   rd_nosl='y';   % read nosl from DICOM images
else
   rd_nosl='n';   % do not read nosl from DICOM images
end

if isempty(notp)
   rd_notp='y';   % read notp from DICOM images
else
   rd_notp='n';   % do not read notp from DICOM images
end

% ========================================================================
%  3. CHECKING THE DIRECTORY STRUCTURE
% ========================================================================

disp('*** Converting fMRI data ***');

disp('Checking the directory structure ...');

% deleting 'ts??' or 'anat' directories

eval(['cd ' dirSPM]);
list=dir;
tmp1 = [];
for i=1:length(list)
   if ~isempty(findstr(list(i).name,nameTS)) & length(list(i).name) == 4
      tmp1 = [tmp1,i];
   end   
end

if length(tmp1) > 0
  for i=1:length(tmp1)
     if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG') 
        unix(['rm -rf ' list(tmp1(i)).name]);
     elseif strcmp(comp(1:2),'PC') 
        dos(['rmdir /S /Q ' list(tmp1(i)).name]);
     end
  end
end

eval(['cd ' dirPAT]);

%str = [base4 '*.' num2str(dummies*nosl+1) '.*.*.*.*.*.*.*.*' ext4];
str = [base4 '*.' num2str(slice1) '.*.*.*.*.*.*.*.*' ext4];
list=dir(str);

% how many series there are in PATIENT directory

disp(['  - You have ' num2str(length(list)) ' series.']);

% searching for series numbers

numSER = [];
for i = 1:length(list)
   pos1 = findstr(list(i).name,'.');
   num = str2num(list(i).name(pos1(3)+1:pos1(4)-1)); % SERIES number
   numSER = [numSER,num];
end
numSER  = sort(numSER);

clear listSER listTS;
for i=1:length(numSER)
   listSER(i,:) = sprintf('%s%s%0.2d%s',dirPAT,nameSER,numSER(i),filesep);
   listTS(i,:)  = sprintf('%s%s%0.2d%s',dirSPM,nameTS,i,filesep);
   if ~exist(listSER(i,:),'dir')
      eval(['!mkdir ' listSER(i,:)]);
   else
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG') 
         unix(['rm -rf ' listSER(i,:)]);
      elseif strcmp(comp(1:2),'PC') 
         dos(['rmdir /S /Q ' listSER(i,:)]);
      end
      eval(['!mkdir ' listSER(i,:)]);
   end
   if ~exist(listTS(i,:),'dir')
      eval(['!mkdir ' listTS(i,:)]);
   else
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
         unix(['rm -rf ' listTS(i,:)]);
      elseif strcmp(comp(1:2),'PC') 
         dos(['rmdir /S /Q ' listTS(i,:)]);
      end
      eval(['!mkdir ' listTS(i,:)]);
   end
end

% ========================================================================
%  4. SORTING DICOM IMAGES INTO STUDIES AND RENAMING DICOM IMAGES
% ========================================================================

disp('Sorting & Renaming DICOM images ...');

eval(['cd ' dirPAT]);

% 'moving' images (=making a link) into series?? directories - LINUX
% copying on DOS

for i=1:length(numSER)
   eval(['cd ' listSER(i,:)]);
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
      str = ['mmv -s "' dirPAT base4 num2str(numSER(i)) '.*.*.IMA" "' base1 '#1'ext1 '"'];
      unix(str);
      disp(['   done series ' num2str(numSER(i))]);

      list=dir([listSER(i,:) '*' ext1]);
      listHDR{i} = [pwd filesep list(1).name];

%   number of timepoints for every series
   
      if strcmp(rd_notp,'y')
         str = ['strings ' listHDR{i} ' | grep lRepetitions'];
         [dum,dumstr] = unix(str);
         notp(i) = str2num(dumstr(findstr(dumstr,'=')+1:end))+1-dummies(i);
      end
      if strcmp(rd_nosl,'y') 
         str = ['strings ' listHDR{i} ' | grep sSliceArray.lSize'];
         [dum,dumstr] = unix(str);
         nosl(i) = str2num(dumstr(findstr(dumstr,'=')+1:end));
      end

   elseif strcmp(comp(1:2),'PC') 
      list = dir([dirPAT base4 num2str(numSER(i)) '.*' ext4]);
      numIM = [];
      for j = 1: length(list)
         pos1 = findstr(list(j).name,'.');
         numIM = [numIM, str2num(list(j).name(pos1(4)+1:pos1(5)-1))];
      end
      numIM = sort(numIM);     
      for j = 1:length(numIM)
         str = ['copy /Y /B ' dirPAT base4 num2str(numSER(i)) '.' num2str(numIM(j)) '.*' ext4 ' ' base1 num2str(numIM(j)) ext1];
         dos(str);
      end
   
      disp(['   done series ' num2str(numSER(i))]);

      list=dir([listSER(i,:) '*' ext1]);
      listHDR{i} = [pwd filesep list(1).name];

%   number of timepoints for every series
   
      if strcmp(rd_notp,'y')
         str = ['strings ' listHDR{i} ' | grep lRepetitions'];
         [dum,dumstr] = dos(str);
         notp(i) = str2num(dumstr(findstr(dumstr,'=')+1:end))+1-dummies(i);
      end
      if strcmp(rd_nosl,'y') 
         str = ['strings ' listHDR{i} ' | grep sSliceArray.lSize'];
         [dum,dumstr] = dos(str);
         nosl(i) = str2num(dumstr(findstr(dumstr,'=')+1:end));
      end
   end   % end of 'if' statement - strcmp(comp..)

end  % end of cycle over 'i'

   disp(['Number of time points: ' num2str(notp)]);
   disp(['Number of slices     : ' num2str(nosl)]);
%   notp = [2 2]
%   nosl = [48 48]

% preparing parameters for SPM header files

[MatrixDim,VOXsize,origin,imorient,check1] = v3_rddcmh(nosl,listHDR,1);
clear check1;

% ========================================================================
%  5. CONVERTING DICOM IMAGES TO SPM (ANALYZE) FORMAT
% ========================================================================

disp('Converting DICOM images & Reorienting SPM images ...');

for i=1:length(numSER)
   eval(['cd ' listSER(i,:)]);

% grouping slices from one timepoint into one SPM file - 1
   
   for j = 1:notp(i)
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
         cmdline2 = 'cat ';
         medconin = '';
         kfrom = ((j-1)*nosl(i)+1) + (dummies(i)*nosl(i));
         kto   = (j*nosl(i)) + (dummies(i)*nosl(i));
         for k = kfrom:kto
            if k ~= kto
               cmdline2 = [cmdline2 sprintf('%s%s%d%s',base2,base1,k,ext2) ' '];
               medconin = [medconin sprintf('%s%d%s',base1,k,ext1) ' '];
            else
               cmdline2 = [cmdline2 sprintf('%s%s%d%s',base2,base1,k,ext2) ' > '];
               medconin = [medconin sprintf('%s%d%s',base1,k,ext1) ' '];
            end
         end
      elseif strcmp(comp(1:2),'PC')
         cmdline2 = 'copy /Y /B ';
         medconin = '';
         kfrom = ((j-1)*nosl(i)+1) + (dummies(i)*nosl(i));
         kto   = (j*nosl(i)) + (dummies(i)*nosl(i));
         for k = kfrom:kto
            if k ~= kto
               cmdline2 = [cmdline2 sprintf('%s%s%d%s',base2,base1,k,ext2) ' /B + '];
               medconin = [medconin sprintf('%s%d%s',base1,k,ext1) ' '];
            else
               cmdline2 = [cmdline2 sprintf('%s%s%d%s',base2,base1,k,ext2) ' '];
               medconin = [medconin sprintf('%s%d%s',base1,k,ext1) ' '];
            end
         end
      end

%  writing SPM header files

      if par1 == 0
         nameimg = sprintf('%s%s%0.3d%s',listTS(i,:),base3,j,ext3);
      elseif par1 == 1
         nameimg = sprintf('%s%s%0.2d%s%0.3d%s',listTS(i,:),nameTS,i,'_',j,ext3);
      end
         check1 = spm_hwrite(nameimg,MatrixDim{i},VOXsize{i},1,4,0,origin{i},'');
      if check1 ~= 348
         disp(['Size of SPM header file is not correct - ' nameSER(i,:)]);
         disp('Header files will not be written for this series.');
      end

% grouping slices from one timepoint into one SPM file - 2

      str1 = [cmdMC1 medconin];
      str2 = [cmdline2 nameimg];
      if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
         str  = [str1 '; ' str2];
         unix(str);
      elseif strcmp(comp(1:2),'PC') 
         dos(str1);
         dos(str2);
      end
   end
   
% deleting unnecessary files

   eval(['cd ' dirPAT]);
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG') 
      str2 = ['rm -rf ' listSER(i,:)];
      unix(str2); 
   elseif strcmp(comp(1:2),'PC') 
      str2 = ['rmdir /S /Q ' listSER(i,:)];
      dos(str2);
   end
  
% reorienting images

   P = v3_get_listdir(listTS(i,:),'*.img');
   flip_spm('single',P,imorient{i});
 
   disp(['   done timeseries ' num2str(i)]);   

end     % end of cycle over i (number of SERIES directories)   

eval(['cd ' dirSPM]);

disp('Conversion done.');

check=1;





