function select_rout
%==============================================================================
% SELECTION OF THE ROUTINE
%==============================================================================
% SELECT_ROUT: selects the routine to run.
%
%==============================================================================
% Katholieke universiteit Leuven, Leuven, Belgium
% Last update: September 15, 2001
%==============================================================================   

global POP1

which_rout = get(POP1,'Value');
comp = computer;

switch which_rout
   case {1}    % Single DICOM to SPM
      if comp(1:2) == 'PC'      
         v3_sdcm2spm_PC;
      else
         v3_sdcm2spm; 
      end
   case {2}    % Mosaic DICOM (old) to SPM
       mdcm2spm;
   case {3}    % Mosaic DICOM (new) to SPM
      if comp(1:2) == 'PC'      
         v3_mdcm2spm_PC;
      else
         v3_mdcm2spm;   
      end
end



