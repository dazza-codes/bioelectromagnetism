function check = v3_run_conv_sdcm2spm
%=========================================================================
% Collects input parameters from GUI for DICOM to SPM comversion 
% Required for GUI to handle a conversion from DICOM to SPM format.
%=========================================================================
% by Katholieke univeristeit Leuven, Leuven, Belgium
% Last update: September 15, 2001
%=========================================================================

global T1 T2 TE3 TE4 TE5 CB1 CB2 but1 convMPR;

check = 0;
comp = computer;

dirPAT = get(T1,'String');
if isempty(dirPAT)
   msgtext='No patient directory selected.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return
end

dirSPM = get(T2,'String');
if isempty(dirSPM)
   msgtext='No SPM directory selected.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return
end

eval(['cd ' dirPAT]);

% number of slices

nosl = str2num(get(TE3,'String'));

if ~isempty(find(nosl<=zeros))
   msgtext='One or more elements are negative or zero (slices).';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return 
end

% number of time points

notp = str2num(get(TE4,'String'));

if ~isempty(find(notp<=zeros))
   msgtext='One or more elements are negative or zero (timepoints).';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return 
end

% number of dummy scans

if ~isempty(get(TE5,'String'))
   dummies = str2num(get(TE5,'String'));
else
   msgtext='Matrix of number of dummy scans not given.';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return 
end

if ~isempty(find(dummies<zeros))
   msgtext='One or more elements are negative (dummies).';
   msgname='Error in input data.';
   msgbox(msgtext,msgname,'Error','Modal')
   return 
end

% delete original DICOM data?

if get(CB1,'Value') == 1
   del_ORIG = 'y';
else
   del_ORIG = 'n';
end

% change the base name of SPM files

par1= get(CB2,'Value');

set(but1,'Enable','off');

% Starting the conversion

if convMPR == 'n'
   check1 = v3_conv_sdcm2spm(dirPAT,dirSPM,nosl,notp,dummies,par1);
   if check1 == 1
      msgbox('Conversion successful.','Done...');
   else
      msgbox('Conversion not completed. Something wrong happened...','Error...','Error','Modal');
   end
elseif convMPR == 'y'
   check1 = v3_conv_sdcm2spm(dirPAT,dirSPM,nosl,notp,dummies,par1);
   check2 = v3_conv_mprdcm2spm(dirPAT,dirSPM);
   if check1 == 1 & check2 == 1
      msgbox('Conversion has been successful.','Done...')
   elseif check1 == 0 & check2 == 0
      msgbox('Conversion has failed.','Done...')
   else
      if check1 == 0
         msgbox('Conversion of fmri images has failed.','Done...');
      else
         msgbox('Conversion of anatomical images has failed.','Done...');
      end
   end
end
clear convMPR;
close(gcbf);

if del_ORIG == 'y'
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') |  strcmp(comp(1:2),'SG')
      str = ['rm -rf ' dirPAT]; 
      unix(str);
   elseif strcmp(comp(1:2),'PC') == 1
      str = ['rmdir /S /Q ' dirPAT]; 
      dos(str);
   end
end
check = 1;

