function flip_spm(IMtype,P,orient)
%======================================================================
% REORIENTS SPM IMAGES
%======================================================================
% P      ... list of files (obtained by get_listdir.m)
% orient ... orientation of acquisition;
%            = 'sag', 'cor' or 'tra'
% IMtype ... 'single' or 'mosaic'
%----------------------------------------------------------------------
% Stefan Sunaert & Erik Beatse & Sarka Mierisova
% Katholieke universiteit Leuven, Leuven, Belgium.
% Last update: September 15, 2001
%======================================================================

switch lower(IMtype)
case 'single'
   if orient == 'sag'
      mat =  [ 0.0000   0.0000    1.0000   0.0000;...
               1.0000   0.0000    0.0000   0.0000;...
               0.0000   1.0000    0.0000   0.0000;...
               0.0000   0.0000    0.0000   1.0000];
      disp('    Sagital images (single).');
   elseif orient == 'cor'
      mat =  [ 1.0000   0.0000    0.0000   0.0000;...
               0.0000   0.0000   -1.0000   0.0000;...
               0.0000   1.0000    0.0000   0.0000;...
               0.0000   0.0000    0.0000   1.0000];
      disp('    Coronal images (single).');
   elseif orient == 'tra'
      mat =  [ 1.0000   0.0000    0.0000   0.0000;...
               0.0000   1.0000    0.0000   0.0000;...
               0.0000   0.0000    1.0000   0.0000;...
               0.0000   0.0000    0.0000   1.0000];
      disp('    Transversal images (single) - reorientation not required.');
      return;
   end
case 'mosaic'
   if orient == 'tra'
   mat = [ -1.0000    0.0000    0.0000    0.0000;
            0.0000    1.0000    0.0000    0.0000;
            0.0000    0.0000   -1.0000    0.0000;
            0.0000    0.0000    0.0000    1.0000];
      disp('    Transversal images (mosaic).');
   elseif orient == 'cor'
   mat = [ -1.0000    0.0000    0.0000    0.0000;
            0.0000    0.0000    1.0000    0.0000;
	    0.0000    1.0000    0.0000    0.0000;
	    0.0000    0.0000    0.0000    1.0000];
      disp('    Coronal images (mosaic).');
   elseif orient == 'sag'
   mat = [  0.0000    0.0000   -1.0000    0.0000;
            1.0000    0.0000    0.0000    0.0000;
            0.0000    1.0000    0.0000    0.0000;
	    0.0000    0.0000    0.0000    1.0000];
      disp('    Sagital images (mosaic).');
   end
end


Mats = zeros(4,4,size(P,1));
for i=1:size(P,1),
  Mats(:,:,i) = spm_get_space(P(i,:));
end
for i=1:size(P,1),
  spm_get_space(P(i,:),mat*Mats(:,:,i));
end
