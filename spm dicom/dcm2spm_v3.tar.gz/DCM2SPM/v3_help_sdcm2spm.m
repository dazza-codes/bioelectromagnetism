%
%===============================================================================
%                  Conversion of DICOM images to SPM.
%===============================================================================
%1. Select directory of DICOM data.
%   The following file structure is supposed:
%   DICOM_dir   -->  directory containing all fMRI data - DICOM images
%     |- MPR    -->  sub-directory containing anatomical DICOM images
%
%2. Select directory for SPM data
%   An empty directory for converted files. In this directory the following 
%   file structure is created:
%     SPM_dir
%      |- anat   - sub-directory with converted anatomical images
%      |- ts01   - timeseries #1 (default file names: 'im_???.???')
%      |- ts02   - timeseries #2
%      |- ...    - etc.
%
%3. No. dummy scans.
%   Number of dummies for each series separated by spaces
%     e.g. 5 5 5 5 5
%
%4. No. slices. - optional
%   Number of slices for each series separated by spaces
%     e.g. 32 32 32 48 48
%
%5. No. timepoints. - optional
%   Number of time points for each series separated by spaces
%     e.g. 120 120 120 120 120
%
%NOTES:
% - To delete original DICOM data check the box 'Delete original DICOM data?'
% - Default file names in ts?? directories can be changes by checking the box
%   'Name SPM files as timeseries?' and the file names become 'ts??_???.???'
%------
%Comments and suggestions to sarka.mierisova@uz.kuleuven.ac.be
%===============================================================================
%
%
