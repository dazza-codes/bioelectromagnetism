function [F,check] = v3_get_listdir(adr,fil)

%=======================================================================
% v3_GET_LISTDIR - Get a list of files from a specified directory
%=======================================================================
% INPUT parameters:
%   adr .... directory to list
%   fil .... specification of file (*.xxx,...)
% OUTPUT parameters
%   F   .... list of files with a full path
%   check .. function returns 1 when successful, 0 otherwise
% ---
% Katholieke universiteit Leuven, Leuven, Belgium
% Last update: September 15, 2001
%=======================================================================

check = 0;
CURdir = '.';
UPdir  = '..';

if nargin > 2
   error('Too many input argument');
   break
end

if ~exist('adr') | isempty(adr)
   adr = CURdir;
end

if ~exist('fil') | isempty(fil)
   fil = '*';
end

if ~strcmp(adr(end),filesep)
   adr = [adr filesep];
end

list = dir([adr filesep fil]);
if length(list)
   for i=1:length(list)
      if ~(strcmp(CURdir,list(i).name) | strcmp(UPdir,list(i).name))
         if ~exist('F') | isempty(F)
            F = char([adr list(i).name]);
         else
            F = char(F,[adr list(i).name]);
         end
      end
   end
else
   F = '';
end

check = 1;
