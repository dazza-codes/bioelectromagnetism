function [MatrixDim,VOXsize,origin,IMAGEorient,check] = v3_rddcmh(nosl,names,ods)
%=========================================================================
%  v3_rddcmh - reads DICOM ascii headers and extracts parameters needed
%           to make SPM header files
%=========================================================================
%  SYNTAX:
%  [MatrixDim,VOXsize,origin,IMAGEorient,check] = v3_rddcmh(nosl,names,ods) 
% ---
%  Input parameters:
%    nosl  = matrix of number of slices; nosl=[32 32 48 ...]
%    names = cell array of DICOM file names; aa{1}='im00001.dcm';
%            aa{2}='im00002.dcm', ...
%    ods   = delete ascii headers afterwards? (=1 or 0 for yes or no)
%  Output parameters:
%    MatrixDim = [dimX dimY dimZ] -  matrix size
%    VOXsize   = [VOXx VOXy VOXz] -  voxel size
%    origin    = [i j k]          -  origin as defined for SPM
%    check     = 1 when successful, 0 otherwise
%  Note: Requires MedCon program   
%-------------------------------------------------------------------------
% Katholieke universiteit Leuven, Belgium
% by Sarka Mierisova (sarka.mierisova@uz.kuleuven.ac.be)
% Sept 15, 2001
%=========================================================================

% MedCon program has to be installed

check = 0;

if nargin ~= 3
  help rddcmh;
  break;
end

ext1 = '.dcm';
ext2 = '.hdc';
comp = computer;

slspace = 0;

from = 1;
to   = length(names);

for i=from:to
% making an ASCII DICOM header
   namedcm = names{i};
   pos1 = findstr(namedcm,ext1);
   namehdr = [namedcm(1:pos1(end)-1) ext2];
   cmdline1 = ['medcon -f ' namedcm ' > ' namehdr];
   unix(cmdline1);
% reading an ASCII header
   fid=fopen(namehdr,'rt');
   for j=1:130 % that's the DICOM header, the 1st part of file made by MedCon program
      line=fgets(fid);
      % SliceThickness im [mm]
      if ~isempty(findstr(line,'(0018,0050)'))
         pos1 = findstr(line,'[');
         pos2 = findstr(line,']');
         slthick = str2num(line(pos1(2)+1:pos2(2)-1)); 
      end
      % SpacingBetweenSlices
      if ~isempty(findstr(line,'(0018,0088)'))
         pos1 = findstr(line,'[');
         pos2 = findstr(line,']');
         %slspace = round(str2num(line(pos1(2)+1:pos2(2)-1))/10*slthick); 
         slspace = str2num(line(pos1(2)+1:pos2(2)-1)); 
      end
      % Image Orientation
      if ~isempty(findstr(line,'(0020,0037)'))
         pos1 = findstr(line,'[');
	 pos2 = findstr(line,']');
         num1 = str2num(line(pos1(2)+1:pos2(2)-1));
         num2 = str2num(line(pos1(3)+1:pos2(3)-1));
         num3 = str2num(line(pos1(4)+1:pos2(4)-1));
         num4 = str2num(line(pos1(5)+1:pos2(5)-1));
         num5 = str2num(line(pos1(6)+1:pos2(6)-1));
         num6 = str2num(line(pos1(7)+1:pos2(7)-1));
	 if num1 ~= 0 & num5 ~= 0           %  1  0  0  0  1  0
	    imorient = 'tra';
	 elseif num2 ~= 0 & num6 ~= 0       %  0  1  0  0  0 -1
	    imorient = 'sag';
	 elseif num1 ~= 0 & num6 ~= 0       %  1  0  0  0  0 -1
	    imorient = 'cor';
	 end
      end
      % Matrix - Rows
      if ~isempty(findstr(line,'(0028,0010)'))
         pos1 = findstr(line,':');
         pos2 = findstr(line,'(');
         dimY = str2num(line(pos1(1)+1:pos2(2)-1)); 
      end
      % Matrix - Columns
      if ~isempty(findstr(line,'(0028,0011)'))
         pos1 = findstr(line,':');
         pos2 = findstr(line,'(');
         dimX = str2num(line(pos1(1)+1:pos2(2)-1)); 
      end
      % PixelSpacing (Resolution)
      if ~isempty(findstr(line,'(0028,0030)'))
         pos1 = findstr(line,'[');
         pos2 = findstr(line,']');
         VOXy = str2num(line(pos1(2)+1:pos2(2)-1)); 
         VOXx = str2num(line(pos1(3)+1:pos2(3)-1)); 
      end
      
   end
   fclose(fid);
   if ods == 1
      eval(['delete ' namehdr]);
   end
   dimZ = nosl(i);
   if slspace == 0 
      % when line "SpacingBetweenSlices" not found
      VOXz = slthick;
   else
      % the value is sum of slthickness and of space between slices
      VOXz = slspace; 
   end
   MatrixDim{i} = [dimX dimY dimZ];
   VOXsize{i} = [VOXx VOXy VOXz];
   if nosl(i) == 1
      origin{i} = [fix(dimX/2) fix(dimY/2) nosl(i)];
   else
      origin{i} = [fix(dimX/2) fix(dimY/2) fix(dimZ/2)];
   end
   IMAGEorient{i} = imorient; 
end

check = 1;

