function check=v3_conv_mprdcm2spm(dirDCM,dirSPM)
%=========================================================================
% v3_conv_mprdcm2spm - converts MPRAGE DICOM images to SPM (ANALYZE) format
%=========================================================================
% INPUT parameters
%   dirDCM  - directory of anatomical DICOM images 
%   dirSPM  - directory for SPM data
% OUTPUT parameters
%   check  - returns 1 when successful, 0 otherwise
% NOTE:
%   medcon program must be installed.
%-----------
% Needed scripts:
%   v3_get_listdir.m
%   v3_flip_spm.m
%------------------------------------------------------------------------- 
% Katholieke universiteit Leuven, Belgium
% Last update: Sept 15, 2001
%=========================================================================

% ========================================================================
%  1. DEFAULT PARAMETERS
% ========================================================================

check    = 0;
comp     = computer;
nameMPR  = 'MPR';              % default source name for mprage images        
nameANAT = 'anat';             % default destination name for anatomical images        
base1    = 'im-';              % base name for renamed DICOM images
base2    = 'm*-';              % base name from MedCon program
base3    = 'mpr';              % base name of SPM files
base4    = '.MR..';            % part of original name of DICOM files
ext1     = '.dcm';             % extention of DICOM images (after renaming)
ext2     = '.img';             % extention of SPM files from MedCon
ext3     = '.img';             % extention of SPM files 
ext3a    = '.hdr';             % extention of SPM header files
ext4     = '.IMA';             % extention of original DICOM files
cmdMC1   = 'medcon -ar -c anlz -f ';  %command line for MedCon program - beginning


% ========================================================================
%  2. CHECKING NUMBER OF INPUT PARAMETERS
% ========================================================================

if ~(strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'PC') | strcmp(comp(1:2),'SG'))
   disp('Conversion runs under LINUX, Win PCs and SGI.');
   return;
end

if nargin ~= 2
   disp(['??? Wrong number of arguments. Stopped...']);
   help conv_mprdcm2spm;
   break;
end

if dirDCM(end) ~= filesep
   dirMPR   = [dirDCM filesep nameMPR filesep];    % default directory for orig. anatomical images
else
   dirMPR   = [dirDCM nameMPR filesep];    % default directory for orig. anatomical images
end

if dirSPM(end) ~= filesep
   dirANAT  = [dirSPM filesep nameANAT filesep];   % default directory for anatomical image
else
   dirANAT  = [dirSPM nameANAT filesep];   % default directory for anatomical image
end

list = dir([dirMPR base4 '*' ext4]);
nosl = length(list);

eval(['cd ' dirMPR]);

% ========================================================================
%  3. CHECKING THE DIRECTORY STRUCTURE
% ========================================================================

disp('*** Converting anatomical data ***');

disp('Checking the directory structure ...');

% deleting 'anat' directory if present and/or making a new one

if exist(dirANAT,'dir')
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') |  strcmp(comp(1:2),'SG')
      unix(['rm -rf ' dirANAT ' ;mkdir ' dirANAT]);
   elseif strcmp(comp(1:2),'PC')
      dos(['rmdir /S /Q ' dirANAT]);
      dos(['mkdir ' dirANAT]);
   end   
else
   if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') |  strcmp(comp(1:2),'SG')
      unix(['mkdir ' dirANAT]);
   elseif strcmp(comp(1:2),'PC')
      dos(['mkdir ' dirANAT]);
   end    
end

list=dir([dirMPR base4 '*.' num2str(1) '.*.*.*.*.*.*.*.*' ext4]);
if length(list) ~= 1
   disp('Conversion of anatomical images: More than 1 series found.');
   disp('Check images in your mpr directory.');
   break;
end

pos1 = findstr(list(1).name,'.');
if length(pos1) == 13
   numSER = str2num(list.name(pos1(3)+1:pos1(4)-1));
else
   disp(['File names of DICOM images inconsistent.']);
   check = 0;
   break;
end

% ========================================================================
%  4. SORTING DICOM IMAGES INTO STUDIES AND RENAMING DICOM IMAGES
% ========================================================================

disp('Sorting & Renaming DICOM images ...');

eval(['cd ' dirMPR]);
% 'moving' images (=making a link) into series?? directories

if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') |  strcmp(comp(1:2),'SG')
   str = ['mmv -s "' dirMPR base4 num2str(numSER) '.*.*' ext4 '" "'dirANAT base1 '#1' ext1 '"'];
   unix(str);
elseif strcmp(comp(1:2),'PC')
   list=dir([base4 num2str(numSER) '.*' ext4]);
   for i=1:length(list)
      str = ['copy /Y /B ' base4 num2str(numSER) '.' num2str(i) '.*' ext4 ' ' dirANAT base1 num2str(i) ext1];
      dos(str);
   end
end
eval(['cd ' dirANAT]);

% preparing parameters for SPM header files

list=dir([dirANAT base1 num2str(1) ext1]);
listHDR{1}=list.name;
[MatrixDim,VOXsize,origin,imorient,check1] = v3_rddcmh(nosl,listHDR,1);
clear check1;

nameimg = sprintf('%s%s%s',dirANAT,base3,ext3);
check1 = spm_hwrite(nameimg,MatrixDim{1},VOXsize{1},1,4,0,origin{1},'');
if check1 ~= 348
   disp(['Size of SPM header file is not correct.']);
end

% ========================================================================
%  5. CONVERTING DICOM IMAGES TO SPM (ANALYZE) FORMAT
% ========================================================================

disp('Converting DICOM images & Reorienting SPM images ...');

% grouping slices from one timepoint into one SPM file - 1
   
if strcmp(comp(1:2),'LN') | strcmp(comp(1:3),'GLN') | strcmp(comp(1:2),'SG')
   cmdline1 = 'cat ';
   for k = 1:nosl
      if k ~= nosl
         cmdline1 = [cmdline1 sprintf('%s%s%d%s',base2,base1,k,ext2) ' '];
      else
         cmdline1 = [cmdline1 sprintf('%s%s%d%s',base2,base1,k,ext2) ' > '];
      end
   end
   unix([cmdMC1 base1 '*' ext1 ' ; ' cmdline1 nameimg]);
   unix(['rm -f ' dirANAT base2 '*.* ' base1 '*.*']); 
elseif strcmp(comp(1:2),'PC')
   dos([cmdMC1 base1 '*' ext1]);
   if nosl > 50   % because of DOS, the input string too long
      noloops = fix(nosl/50) + 1;
      for kk = 1:noloops
         if kk == 1
            cmdline1 = 'copy /Y /B ';
         else
            cmdline1 = ['copy /Y /B ' nameimg ' /B + '];
         end
         if kk ~= noloops
            nosl_b =  1 + (50*(kk-1));
            nosl_e = 50 + (50*(kk-1));
         else
            nosl_b =  1 + (50*(kk-1));
            nosl_e = nosl;
         end
         for k = nosl_b:nosl_e
            if k ~= nosl_e
               cmdline1 = [cmdline1 sprintf('%s%s%d%s',base2,base1,k,ext2) ' /B + '];
            else
               cmdline1 = [cmdline1 sprintf('%s%s%d%s',base2,base1,k,ext2) ' '];
            end
         end
         dos([cmdline1 nameimg]);   
      end
   else
      for k = 1:nosl
         if k ~= nosl
            cmdline1 = [cmdline1 sprintf('%s%s%d%s',base2,base1,k,ext2) ' /B + '];
         else
            cmdline1 = [cmdline1 sprintf('%s%s%d%s',base2,base1,k,ext2) ' ']
         end
      end
      dos([cmdMC1 base1 '*' ext1]);
      dos([cmdline1 nameimg]);   
   end
   dos(['del /Q ' dirANAT base2 '*.* ' base1 '*.*']); 
end

% reorienting images

P = v3_get_listdir(pwd,'*.img');
v3_flip_spm('single',P,imorient{1});
eval(['cd ' dirSPM]);
 
disp('Conversion of anatomical images done.');

check=1;





