function check = get_dir(inp1)
%==============================================================================
% Get a directory name
% Uses an SPM99 function spm_get.m
% Required for GUI to handle a conversion from DICOM to SPM format
% inp1 = 'sDCMdir' 'mDCMdir' or 'SPMdir'
%-----------------------------------------------------------------------------
% by Katholieke Universiteit Leuven, Leuven, Belgium
% Last update: Sept 15, 2001
%==============================================================================

global T1 T2 convMPR

dirMPR  = ['MPR' filesep];
dirCUR  = pwd;

switch inp1
   case {'sDCMdir'}  % selecting directory of single DICOM data
      dirPAT = spm_get(-1,[],'Select directory of your single DICOM data');
      dirPAT = [dirPAT filesep];

      eval(['cd ' dirPAT]);

% checking for DICOM images in selected directory

      list = dir('.MR..*.1.*.*.*.*.*.*.*.*.IMA');
      count = length(list);
      if count <= 0
         msgtext='No DICOM images in this directory. Select another one.';
         msgname='Error message';
         msgbox(msgtext,msgname,'Error','Modal')
         set(T1,'String','');
      else
         set(T1,'String',dirPAT);
         convMPR = 'y';
         if ~exist(dirMPR,'dir')
            msgtext='No anatomical DICOM images found in this directory.';
            msgname='Warning message';
            msgbox(msgtext,msgname,'Warn','Modal')
            convMPR = 'n';
         else
            eval(['cd ' dirMPR]);
            list = dir('.MR..*.IMA');
            count = length(list);
            if count <= 0
               msgtext='No anatomical DICOM images found in this directory.';
               msgname='Warning message';
               msgbox(msgtext,msgname,'Warn','Modal')
               convMPR = 'n';
            end
         end
      end             
   case {'mDCMdir'}  % selecting directory of mosaic DICOM data
      dirPAT = spm_get(-1,[],'Select directory of your mosaic DICOM data');
      dirPAT = [dirPAT filesep];

      eval(['cd ' dirPAT]);

% checking for DICOM images in selected directory

      list = dir('.MR..*.*.*.*.*.*.*.*.*.*.IMA');
      count = length(list);
      if count <= 0
         msgtext='No DICOM images in this directory. Select another one.';
         msgname='Error message';
         msgbox(msgtext,msgname,'Error','Modal')
         set(T1,'String','');
      else
         set(T1,'String',dirPAT);
         convMPR = 'y';
         if ~exist(dirMPR,'dir')
            msgtext='No anatomical DICOM images found in this directory.';
            msgname='Warning message';
            msgbox(msgtext,msgname,'Warn','Modal')
            convMPR = 'n';
         else
            eval(['cd ' dirMPR]);
            list = dir('.MR..*.IMA');
            count = length(list);
            if count <= 0
               msgtext='No anatomical DICOM images found in this directory.';
               msgname='Warning message';
               msgbox(msgtext,msgname,'Warn','Modal')
               convMPR = 'n';
            end
         end
      end             
   case {'SPMdir'}  % selecting directory for SPM data
      dirSPM = spm_get(-1,[],'Select directory for SPM data');
      dirSPM = [dirSPM filesep];

      eval(['cd ' dirSPM]);
      set(T2,'String',dirSPM);
end

eval(['cd ' dirCUR]);

check = 1;

