%
%===============================================================================
%                  Conversion of DICOM images to SPM.
%===============================================================================
%1. Select directory of DICOM data.
%   The following file structure is supposed:
%   DICOM_dir   -->  directory containing all fMRI data - DICOM images
%     |- MPR    -->  sub-directory containing anatomical DICOM images
%
%2. Select directory for SPM data
%   An empty directory for converted files. In this directory the following 
%   file structure is created:
%     SPM_dir
%      |- anat   - sub-directory with converted anatomical images
%      |- ts01   - timeseries 1 (default file names: 'im_???.???')
%      |- ts02   - timeseries 2
%      |- ...    - etc.
%
%3. Number of time series and dummy scans (2 column-matrix)
%   e.g. [15 4;16 4;17 4]
%   where 15,16,17 are the numbers of time series and 4,4,4 are the numbers of dummy 
%   scans
%
%NOTES:
% - To delete original DICOM data check the box 'Delete original DICOM data?'
% - Default file names in ts?? directories can be changes by checking the box
%   'Name SPM files as timeseries?' and the file names become 'ts??_???.???'
%------
%Comments and suggestions to sarka.mierisova@uz.kuleuven.ac.be
%===============================================================================
%
%
