%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   lighter(h)
%	Used to lighten some gradient or pulse in the
%	sequence.
%	h = handles to lighten as passed back from gradient or pulse
%
%	Craig Jones (craig@msmri.medicine.ubc.ca)
%

%
%  $Id: lighter.m,v 1.1.1.1 2000/02/14 17:11:59 craig Exp $
%
function [] = lighter(h)

for index=1:length(h)
	set(h(index), 'color', [.7 .7 .7]);
end
