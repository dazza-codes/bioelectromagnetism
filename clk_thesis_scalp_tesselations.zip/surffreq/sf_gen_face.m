function face = sf_gen_face(points, edges)
% SF_GEN_FACE	Generate faces from intrinsic points and triangulating edges
%		face = SF_GEN_FACE(points, edges)
%		(work done by C MEX-file)

% Copyright (c) 1997 Clif Kussmaul. All rights reserved.

