function [idx] = sf_find_vals(vals,list)
% SF_FIND_VALS    	Find row indices in LIST for given VALS
%   	    	    	[idx] = SF_FIND_VAL(vals, list)
%   	    	    	(work done by C MEX-file)

% Copyright (c) 1997 Clif Kussmaul. All rights reserved.

