function man(varargin)

for i = 1:nargin
    help(varargin{i})
end
