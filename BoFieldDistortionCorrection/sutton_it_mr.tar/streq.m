function y = streq(a,b)
	y = strcmp(a,b);
