function display(a)
disp('MRI_DFT object:')
disp(struct(a))
