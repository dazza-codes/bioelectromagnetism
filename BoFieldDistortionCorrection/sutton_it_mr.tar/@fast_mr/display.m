function display(a)
disp('FAST_MR object:')
disp(struct(a))
