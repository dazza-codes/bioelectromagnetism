 function X = dtft_mex(omega, x)

warning 'need mex file'
