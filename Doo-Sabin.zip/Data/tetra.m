function [pt,pgon]=tetra

pt=[0 0 0;
    1 0 0;
    0 1 0;
    0.5 0.5 1];
 
pgon={[1 2 3]
   [2 4 3]
   [1 4 2]
   [3 4 1]};
