 function color=simplyred(pt,nv);
 color=[1 0 0];
