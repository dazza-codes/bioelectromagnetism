function color=sine(pt,nv)   % colorfile for pgontrace
color=sin(3*sum(nv));
