function Save_Binary_Vol4(vol4,filename,filetype)
% Save_Binary_Vol4(vol4,filename,filetype)
% Saves Binary data corresponding with a 4-D array.
% The filename should include the desired extension, e.g., '.img'
% To save Analyze format or just binary data.
% [Nx,Ny,Nz,Nt]=size(vol4)
% Nt can be one as it is for anatomical data (MRI),
% or bigger than one as for fMRI data.
% filetype correspond to precision, see fread Matlab command.
% The format of the file created here is NATIVE ! 
% Binary files created with a format different from NATIVE with Save_Binary_Vol4
% were always incorrectly read with Read_Binary_Vol4. 
% Input matrix vol4 can be uint16, uint32 (2 or 4 bytes unsigned integer), etc, but
% should be in agreement with the filetype 

% rgpm 20-7-2000

%if nargin<4, formato='native'; end 
formato='native';

[Nx,Ny,Nz,Nt]=size(vol4);

[fid,message] = fopen(filename,'w',formato);
if fid==-1, myerror([message, ' / Save_Binary_Vol4 ']), end

Nxy=Nx*Ny;
h=waitbar(0, ['Writing data to --> ',filename]);
for t=1:Nt,
   if Nt>1,waitbar(t/Nt); end 
   for z=1:Nz,
      if Nt==1, waitbar(z/Nz); end
      tempmat=vol4(:,:,z,t); 
      cont=fwrite(fid,tempmat(:),filetype);
      if cont~=Nxy, [cont,'<>',Nxy], myerror(' Save_Binary_Vol4 '); end
   end
end
close(h)
fclose(fid);


%over
