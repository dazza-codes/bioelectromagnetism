function Save_Ana_Header(header,filename)
% Save_Ana_Header(header,filename)
% Save Analyze header file
% The filename should include the desired extension, e.g., '.hdr'

% rgpm 20-12-2000

formato='native';
%if nargin<3, formato='native'; end

[fid,message] = fopen(filename,'w',formato);

if fid==-1, myerror([message, ' / Save_Ana_Header ']), end

%            header_key

nada=header.hk.sizeof_hdr;
fwrite(fid,nada,'uint32');   

nada=header.hk.data_type;
fwrite(fid,nada,'uchar');   

nada=header.hk.db_name;
fwrite(fid,nada,'uchar');   

nada=header.hk.extents;
fwrite(fid,nada,'uint32');   

nada=header.hk.session_error;
fwrite(fid,nada,'uint16');   

nada=header.hk.regular;
fwrite(fid,nada,'uchar');   

nada=header.hk.hkey_un0;
fwrite(fid,nada,'uchar');   

%               image_dimensions

nada=header.dime.dim;
fwrite(fid,nada,'uint16');   

nada=header.dime.vox_units;
fwrite(fid,nada,'uchar');   

nada=header.dime.cal_units;
fwrite(fid,nada,'uchar');   

nada=header.dime.unused1;
fwrite(fid,nada,'uint16');   

nada=header.dime.datatype;
fwrite(fid,nada,'uint16');   

nada=header.dime.bitpix;
fwrite(fid,nada,'uint16');   

nada=header.dime.dim_un0;
fwrite(fid,nada,'uint16');   

nada=single(header.dime.pixdim);
fwrite(fid,nada,'float32');   

nada=single(header.dime.vox_offset);
fwrite(fid,nada,'float32');   

nada=single(header.dime.funused1);
fwrite(fid,nada,'float32');   

nada=single(header.dime.funused2); 
fwrite(fid,nada,'float32');   

nada=single(header.dime.funused3);
fwrite(fid,nada,'float32');   

nada=single(header.dime.cal_max);
fwrite(fid,nada,'float32');   

nada=single(header.dime.cal_min);
fwrite(fid,nada,'float32');   

nada=header.dime.compressed;
fwrite(fid,nada,'uint32');   

nada=header.dime.verified;
fwrite(fid,nada,'uint32');   

nada=header.dime.glmax;
fwrite(fid,nada,'uint32');   

nada=header.dime.glmin;
fwrite(fid,nada,'uint32');   

%                          data_history

nada=header.hist.descrip;
fwrite(fid,nada,'uchar');   

nada=header.hist.aux_file;
fwrite(fid,nada,'uchar');   

nada=header.hist.orient;
fwrite(fid,nada,'uchar');   

nada=header.hist.originator; % segun SPM
fwrite(fid,nada,'int16');   

nada=header.hist.generated;
fwrite(fid,nada,'uchar');   

nada=header.hist.scannum;
fwrite(fid,nada,'uchar');   

nada=header.hist.patient_id;
fwrite(fid,nada,'uchar');   

nada= fwrite(fid,nada,'uchar');   
data_history.exp_date=char(nada);

nada=header.hist.exp_time;
fwrite(fid,nada,'uchar');   

nada=header.hist.hist_un0;
fwrite(fid,nada,'uchar');   

nada=header.hist.views;
fwrite(fid,nada,'uint32');   

nada=header.hist.vols_added;
fwrite(fid,nada,'uint32');   

nada=header.hist.start_field;
fwrite(fid,nada,'uint32');   

nada=header.hist.field_skip;
fwrite(fid,nada,'uint32');   

nada=header.hist.omax;
fwrite(fid,nada,'uint32');   

nada=header.hist.omin;
fwrite(fid,nada,'uint32');   

nada=header.hist.smax;
fwrite(fid,nada,'uint32');   

nada=header.hist.smin;
fwrite(fid,nada,'uint32');   

fclose(fid);

%over