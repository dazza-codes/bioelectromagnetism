function Save_Ana_file(data,header,filename)
% Save_Ana_file(data,header,filename)
% Save in Analyze format the 4D input data.
% Two files are created filename.hdr and filename.img
% The format of the files created here is NATIVE ! 
% Binary files created with a format different from NATIVE with Save_Binary_Vol4
% were always incorrectly read with Read_Binary_Vol4. 

% rgpm 21-12-2000

%if nargin<4, formato='native'; end

filetype=Ana_data_file_type(header.dime.datatype,[]);
header.dime.glmax=max(data(:));
header.dime.glmin=min(data(:));


%creating and/or saving header in NATIVE format
Save_Ana_Header(header,[filename,'.hdr'])

% saving data in precision filetype and NATIVE format
Save_Binary_Vol4(data,[filename,'.img'],filetype)


% over