function myerror(msg)
% Display message msg and stops running.
% 'Run time error ' message for m-code compiled with mcc
% because the matlab function ERROR has no effect in the display
% after compilation.

% rgpm 15-6-2000

h=msgbox([msg,' / Press ok to finish '],' RUN TIME ERROR ','error');
uiwait(h)
error(' ')
